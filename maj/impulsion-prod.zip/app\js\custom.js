/* =====================================================================
   PROJETS DE VENTE / ÉTUDE + DALLES HORS CATALOGUE
   p.sale = true : le projet ne réserve aucun stock (étude, devis de vente, rendu client).
   p.customProducts = [{ id: 'cust…', custom: true, category: 'dalle', ref, name, … }] : dalles propres au projet,
   invisibles dans le catalogue, utilisables pour tous les rendus (plans, pixel map, 3D, PDF).
   ===================================================================== */
const isCustomProd = (prod) => !!(prod && prod.custom);
function findCustomProduct(id) { const cur = typeof ui !== 'undefined' && ui.projectId && Store.db.projects.find((x) => x.id === ui.projectId); const own = cur && (cur.customProducts || []).find((x) => x.id === id); if (own) return own; for (const p of Store.db.projects) { const c = (p.customProducts || []).find((x) => x.id === id); if (c) return c; } return null; }
/* dalles disponibles pour un projet : catalogue + dalles hors catalogue du projet */
const projectDalles = (p) => [...Store.db.products.filter((x) => x.category === 'dalle'), ...((p && p.customProducts) || [])];
const prodOptionLabel = (x) => `${isCustomProd(x) ? '✎ ' : ''}${x.ref ? x.ref + ' — ' : ''}${x.name}${isCustomProd(x) ? ' (hors catalogue)' : ''}`;

function customPanelForm(c) {
  const f = (k, label, step = 1, type = 'number') => `<label class="f">${label}<input type="${type}" ${type === 'number' ? `step="${step}"` : ''} data-cp="${k}" value="${esc(c[k] ?? '')}"></label>`;
  return `<h2>${c._new ? 'Dalle hors catalogue' : 'Modifier la dalle hors catalogue'}</h2>
    <div class="small muted">Pour un projet de vente ou une étude : la dalle n'est pas ajoutée au catalogue ni au stock, elle sert uniquement aux rendus de ce projet (plans, pixel map, 3D, dossier PDF).</div>
    <div class="form" style="margin-top:12px">${f('name', 'Nom *', 1, 'text')}${f('ref', 'Référence / modèle', 1, 'text')}${f('brand', 'Marque', 1, 'text')}${f('pitch', 'Pitch (mm)', 0.01)}
      ${f('widthMm', 'Largeur (mm) *')}${f('heightMm', 'Hauteur (mm) *')}${f('depthMm', 'Épaisseur (mm)')}${f('weightKg', 'Poids (kg)', 0.1)}
      ${f('pxW', 'Pixels en largeur *')}${f('pxH', 'Pixels en hauteur *')}${f('powerMax', 'Conso max (W)')}${f('powerAvg', 'Conso moyenne (W)')}
      ${f('maxChain', 'Dalles max par ligne élec')}</div>
    <div class="tiny muted" style="margin-top:6px">Astuce : avec le pitch et les dimensions, les pixels se calculent tout seuls (500 mm / P3,9 = 128 px).</div>
    <div class="modal-actions">${!c._new ? '<button class="ghost" data-act="cpToCatalog" style="margin-right:auto">⇪ Ajouter au catalogue</button>' : ''}<button data-act="closeModal">Annuler</button><button class="primary" data-act="cpSave">${c._new ? 'Créer et utiliser' : 'Enregistrer'}</button></div>`;
}
const customActions = {
  cpNew(el) {
    ui.cpTarget = el && el.dataset.target || 'screen';
    ui.edit = { _new: true, id: uid('cust'), custom: true, category: 'dalle', name: '', ref: '', brand: '', pitch: 3.91, widthMm: 500, heightMm: 500, depthMm: 80, pxW: 128, pxH: 128, weightKg: 8, powerMax: 200, powerAvg: 70, maxChain: 10, stock: 0 };
    openModal(customPanelForm(ui.edit));
  },
  cpEdit() { const s = curScreen(); const c = getProduct(s && s.productId); if (!isCustomProd(c)) return; ui.cpTarget = 'none'; ui.edit = deepClone(c); openModal(customPanelForm(ui.edit)); },
  cpSave() {
    const c = ui.edit; document.querySelectorAll('[data-cp]').forEach((el) => { const k = el.dataset.cp; c[k] = ['name', 'ref', 'brand'].includes(k) ? el.value.trim() : num(el.value); });
    if (!c.name) return toast('Donnez un nom à la dalle', 'warn'); if (!(c.widthMm > 0 && c.heightMm > 0 && c.pxW > 0 && c.pxH > 0)) return toast('Dimensions et pixels obligatoires', 'warn');
    const p = curProject(); p.customProducts = p.customProducts || []; const isNew = c._new; delete c._new;
    const i = p.customProducts.findIndex((x) => x.id === c.id); if (i >= 0) p.customProducts[i] = c; else p.customProducts.push(c);
    const s = curScreen(); if (isNew && ui.cpTarget === 'screen' && s) { s.productId = c.id; ['elec', 'data'].forEach((k) => { s[k].assign = null; s[k].orders = {}; }); if (isArch(s)) archFit(s); }
    p.screens.forEach((x) => { if (x.productId === c.id && isArch(x)) archFit(x); });
    Store.save(); closeModal(); render(); toast(isNew ? 'Dalle hors catalogue créée ✔' : 'Dalle mise à jour ✔');
    if (isNew && ui.cpTarget && ui.cpTarget !== 'screen' && actions[ui.cpTarget]) setTimeout(() => actions[ui.cpTarget](), 50);
  },
  cpToCatalog() {
    const c = ui.edit; if (!confirm(`Ajouter « ${c.name} » au catalogue (stock 0) ? Les écrans de ce projet utiliseront la référence du catalogue.`)) return;
    const p = curProject(); const prod = Object.assign(deepClone(c), { id: uid('prd'), custom: undefined, stock: 0 }); delete prod.custom; delete prod._new;
    Store.db.products.push(prod); p.screens.forEach((s) => { if (s.productId === c.id) s.productId = prod.id; }); p.customProducts = (p.customProducts || []).filter((x) => x.id !== c.id);
    Store.save(); closeModal(); render(); toast('Ajoutée au catalogue ✔ — pensez à renseigner le stock');
  }
};
function customChange(t) {
  if (!t.dataset.cp) return false;
  if ((t.dataset.cp === 'pitch' || t.dataset.cp === 'widthMm' || t.dataset.cp === 'heightMm') && ui.edit) { // pixels calculés à partir du pitch
    const g = (k) => num((document.querySelector(`[data-cp="${k}"]`) || {}).value); const pitch = g('pitch');
    if (pitch > 0) { const w = document.querySelector('[data-cp="pxW"]'), h = document.querySelector('[data-cp="pxH"]'); if (w) w.value = Math.round(g('widthMm') / pitch); if (h) h.value = Math.round(g('heightMm') / pitch); }
  }
  return true;
}
