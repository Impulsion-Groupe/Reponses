/* =====================================================================
   RENDER — plans SVG (élec / data), vues de dessus, pixel map, vue 3D
   ===================================================================== */
const THEMES = {
  dark: { bg: '#0a0f12', txt: '#ffffff', txt2: '#e9f0f3', mut: '#8ba2ae', dim: '#5d7581', grid: '#3a4850', hatch: '#1b2328', pA: '#0f2c36', pB: '#123844', pS: '#2f4552' },
  light: { bg: '#ffffff', txt: '#0d1a20', txt2: '#0d1a20', mut: '#40525c', dim: '#7a8b94', grid: '#b5c3ca', hatch: '#eef2f4', pA: '#d6e6ec', pB: '#c3d9e2', pS: '#8fa7b2' }
};
const lineColor = (i) => LINE_COLORS[i % LINE_COLORS.length];

function cellSize(screen) {
  const p = getProduct(screen.productId) || {};
  const ratio = (num(p.heightMm) || 500) / (num(p.widthMm) || 500);
  let cw = screen.cols <= 14 ? 92 : Math.max(38, Math.floor(1300 / screen.cols));
  let ch = cw * ratio;
  if (ch * screen.rows > 1300) { ch = Math.max(30, 1300 / screen.rows); cw = ch / ratio; }
  return { cw, ch };
}

/* Plan de câblage (kind = 'elec' | 'data')
   opts.rear : vue de dos (miroir) — opts.sel : ligne sélectionnée — opts.export : ajoute cartouche + légende */
/* Coins à angle fort (≥ 45°, ex. cube à 90°) : repérés sur les plans à plat */
function cornerMarks(screen, o) {
  if (!screen.hAngles || (typeof isBoard === 'function' && isBoard(screen)) || (typeof isArch === 'function' && isArch(screen))) return '';
  let s = ''; const cols = screen.cols, rows = screen.rows;
  screen.hAngles.forEach((a, j) => { a = num(a); if (Math.abs(a) < 45) return; const c = o.rear ? cols - 1 - j : j + 1; const x = o.x0 + c * o.cw;
    s += `<line x1="${x}" y1="${o.y0 - 4}" x2="${x}" y2="${o.y0 + rows * o.ch + 4}" stroke="#ffb547" stroke-width="2" stroke-dasharray="6 4" pointer-events="none"/><text x="${x}" y="${o.y0 + rows * o.ch + 16}" fill="#ffb547" font-size="10" text-anchor="middle" pointer-events="none">coin ${a > 0 ? '+' : ''}${a}°</text>`; });
  (screen.vAngles || []).forEach((a, j) => { a = num(a); if (Math.abs(a) < 45) return; const y = o.y0 + (j + 1) * o.ch;
    s += `<line x1="${o.x0 - 4}" y1="${y}" x2="${o.x0 + cols * o.cw + 4}" y2="${y}" stroke="#ffb547" stroke-width="2" stroke-dasharray="6 4" pointer-events="none"/>`; });
  return s;
}
function planSVG(screen, kind, opts = {}) {
  if (isBoard(screen)) return boardPlanSVG(screen, kind, opts);
  if (isArch(screen) && (screen.pixmap || {}).archView !== 'flat') return archPlanSVG(screen, kind, opts);
  const plan = resolvePlan(screen, kind);
  const { cols, rows } = screen; const { cw, ch } = cellSize(screen);
  const exp = !!opts.export; const T = THEMES[opts.light ? 'light' : 'dark'];
  const mx = 34, top = exp ? 92 : 34;
  const W = cols * cw + mx * 2;
  const legendRows = exp ? Math.ceil(plan.lines.length / 6) : 0;
  const H = rows * ch + top + 34 + (exp ? 30 + legendRows * 26 : 0);
  const col = (c) => (opts.rear ? cols - 1 - c : c);
  const X = (i) => mx + col(i % cols) * cw; const Y = (i) => top + Math.floor(i / cols) * ch;
  const cx = (i) => X(i) + cw / 2, cy = (i) => Y(i) + ch / 2;
  const prefix = kind === 'elec' ? 'C' : 'P';
  const fs = Math.max(9, Math.min(18, cw / 4.8));
  const posInLine = new Map(); plan.lines.forEach((l) => l.panels.forEach((idx, k) => posInLine.set(idx, k + 1)));
  let s = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${W} ${H}" width="${W}" height="${H}" font-family="Segoe UI, Arial, sans-serif">`;
  s += `<defs>${plan.lines.map((l) => `<marker id="ar${kind}${l.index}" viewBox="0 0 10 10" refX="7" refY="5" markerWidth="5.5" markerHeight="5.5" orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z" fill="${lineColor(l.index)}"/></marker>`).join('')}
    <pattern id="hatch" width="8" height="8" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><rect width="8" height="8" fill="${T.hatch}"/><line x1="0" y1="0" x2="0" y2="8" stroke="${T.grid}" stroke-width="3"/></pattern></defs>`;
  s += `<rect width="${W}" height="${H}" fill="${T.bg}"/>`;
  if (exp) {
    const prj = opts.project ? opts.project.name + ' — ' : '';
    s += `<text x="${mx}" y="38" fill="${T.txt}" font-size="22" font-weight="700">${esc(prj + screen.name)}</text>`;
    s += `<text x="${mx}" y="62" fill="${T.mut}" font-size="13">${kind === 'elec' ? 'PLAN ÉLECTRIQUE' : 'PLAN DATA'} · ${cols}×${rows} dalles · ${opts.rear ? 'VUE DE DOS (côté câblage)' : 'VUE DE FACE (côté public)'} · ${esc(Store.db.settings.company)}</text>`;
  }
  s += `<text x="${W / 2}" y="${top - 12}" fill="${T.dim}" font-size="11" text-anchor="middle" letter-spacing="2">${opts.rear ? '◀ VUE DE DOS ▶' : 'VUE DE FACE'}</text>`;
  s += cornerMarks(screen, { x0: mx, y0: top, cw, ch, rear: opts.rear, color: T.dim });
  // Dalles
  for (let i = 0; i < cols * rows; i++) {
    const a = plan.assign[i]; const line = plan.lines[a];
    const color = a >= 0 ? lineColor(a) : null;
    const dim = opts.sel != null && opts.sel !== a ? 0.55 : 1;
    const over = line && line.over;
    s += `<g opacity="${dim}"><rect data-idx="${i}" x="${X(i) + 1.5}" y="${Y(i) + 1.5}" width="${cw - 3}" height="${ch - 3}" rx="3" fill="${color ? color + '33' : 'url(#hatch)'}" stroke="${over ? '#ff5d6c' : color || T.grid}" stroke-width="${opts.sel === a ? 2.6 : 1.4}" ${over ? 'stroke-dasharray="5 3"' : ''}/>`;
    if (a >= 0) {
      s += `<text x="${cx(i)}" y="${Y(i) + ch * 0.36}" fill="${T.txt}" font-size="${fs}" font-weight="700" text-anchor="middle" pointer-events="none">${prefix}${a + 1}</text>`;
      s += `<text x="${cx(i)}" y="${Y(i) + ch * 0.86}" fill="${color}" font-size="${fs * 0.72}" font-weight="600" text-anchor="middle" pointer-events="none">#${posInLine.get(i)}</text>`;
    } else s += `<text x="${cx(i)}" y="${cy(i) + 4}" fill="${T.mut}" font-size="${fs * 0.75}" text-anchor="middle" pointer-events="none">libre</text>`;
    if (cw > 44) s += `<text x="${X(i) + 6}" y="${Y(i) + 13}" fill="${T.dim}" font-size="9" pointer-events="none">${(i % cols) + 1}·${Math.floor(i / cols) + 1}</text>`;
    s += `</g>`;
  }
  // Chemins
  plan.lines.forEach((l) => {
    if (!l.panels.length) return;
    const c = lineColor(l.index); const dim = opts.sel != null && opts.sel !== l.index ? 0.5 : 1;
    s += `<g opacity="${dim}" pointer-events="none">`;
    for (let k = 0; k < l.panels.length - 1; k++) {
      const a = l.panels[k], b = l.panels[k + 1];
      const x1 = cx(a), y1 = cy(a) + ch * 0.08, x2 = cx(b), y2 = cy(b) + ch * 0.08;
      const dx = x2 - x1, dy = y2 - y1, L = Math.hypot(dx, dy) || 1; const sh = Math.min(12, L * 0.16);
      s += `<line x1="${x1 + dx / L * sh}" y1="${y1 + dy / L * sh}" x2="${x2 - dx / L * sh}" y2="${y2 - dy / L * sh}" stroke="${c}" stroke-width="2.4" marker-end="url(#ar${kind}${l.index})"/>`;
    }
    const f = l.panels[0];
    s += `<circle cx="${cx(f)}" cy="${cy(f) + ch * 0.08}" r="${Math.max(6, fs * 0.5)}" fill="${c}" stroke="${T.bg}" stroke-width="2"/><text x="${cx(f)}" y="${cy(f) + ch * 0.08 + 3.5}" font-size="${Math.max(8, fs * 0.5)}" text-anchor="middle" fill="#00141c" font-weight="800">${kind === 'elec' ? '⚡' : '▶'}</text>`;
    s += `</g>`;
  });
  // Repères colonnes / rangées
  for (let c = 0; c < cols; c++) s += `<text x="${mx + col(c) * cw + cw / 2}" y="${top + rows * ch + 18}" fill="${T.dim}" font-size="10" text-anchor="middle">${c + 1}</text>`;
  for (let r = 0; r < rows; r++) s += `<text x="${mx - 10}" y="${top + r * ch + ch / 2 + 4}" fill="${T.dim}" font-size="10" text-anchor="end">${r + 1}</text>`;
  if (exp) {
    const sum = kind === 'elec' ? elecSummary(screen, plan) : dataSummary(screen, plan);
    let y0 = top + rows * ch + 44;
    sum.rows.forEach((r, k) => {
      const x = mx + (k % 6) * Math.max(150, (W - 2 * mx) / 6); const y = y0 + Math.floor(k / 6) * 26;
      const extra = kind === 'elec' ? `${r.n} dalles · ${fmt(r.A, 1)} A · ${r.phase}` : `${r.n} dalles · ${fmt(r.pct, 0)} %`;
      s += `<rect x="${x}" y="${y - 11}" width="12" height="12" rx="3" fill="${lineColor(r.line.index)}"/><text x="${x + 18}" y="${y}" fill="${T.txt2}" font-size="12"><tspan font-weight="700">${r.name}</tspan> ${extra}</text>`;
    });
  }
  return s + '</svg>';
}

/* Miniature de l'écran (cartes) */
function thumbSVG(screen) {
  if (isBoard(screen)) return boardThumbSVG(screen);
  if (isArch(screen)) return archThumbSVG(screen);
  const { cols, rows } = screen; const p = getProduct(screen.productId) || {};
  const r = (num(p.heightMm) || 500) / (num(p.widthMm) || 500); const cw = 10, ch = 10 * r;
  let s = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${cols * cw} ${rows * ch}">`;
  for (let y = 0; y < rows; y++) for (let x = 0; x < cols; x++) s += `<rect x="${x * cw + .4}" y="${y * ch + .4}" width="${cw - .8}" height="${ch - .8}" fill="${(x + y) % 2 === 0 ? screen.pixmap.c1 : screen.pixmap.c2}"/>`;
  return s + '</svg>';
}

/* Vue de dessus (courbure horizontale) ou de côté (courbure verticale) avec cotes */
function profileSVG(screen, axis, opts = {}) {
  const g = screenGeometry(screen);
  const isH = axis === 'h';
  const prof = isH ? g.H : g.V; const n = isH ? screen.cols : screen.rows; const angles = isH ? screen.hAngles : screen.vAngles;
  const d = g.d || 60; const T = THEMES[opts.light ? 'light' : 'dark']; const pts = prof.pts;
  const xs = pts.map((p) => p[0]), ys = pts.map((p) => p[1]);
  const minX = Math.min(...xs), maxX = Math.max(...xs), minY = Math.min(...ys) - d, maxY = Math.max(...ys);
  const span = Math.max(maxX - minX, 1), dep = Math.max(maxY - minY, 1);
  const pad = 80;
  // axe h : x -> horizontal, profondeur -> vertical (public en bas)
  // axe v : hauteur -> vertical, profondeur -> horizontal (public à droite)
  let W, Hh, sc;
  let ox = pad;
  if (isH) { W = opts.width || 760; sc = (W - pad * 2) / span; const maxD = opts.maxDepthPx || 380; if (dep * sc > maxD) { sc = maxD / dep; ox = (W - span * sc) / 2; } Hh = Math.max(200, dep * sc + 180); } // formes fermées (cube, U) : hauteur limitée
  else { Hh = opts.height || 460; sc = Math.min((Hh - 120) / span, 500 / dep); W = Math.max(420, dep * sc + 300); }
  const M = isH ? (x, y) => [ox + (x - minX) * sc, 70 + (y - minY) * sc]
    : (x, y) => [W / 2 - dep * sc / 2 + (y - minY) * sc, 60 + (x - minX) * sc];
  let s = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${W} ${Hh}" width="${W}" height="${Hh}" font-family="Segoe UI, Arial, sans-serif"><rect width="${W}" height="${Hh}" fill="${T.bg}"/>`;
  s += `<text x="16" y="24" fill="${T.mut}" font-size="11" letter-spacing="2">${isH ? 'VUE DE DESSUS — COURBURE HORIZONTALE' : 'VUE DE CÔTÉ — COURBURE VERTICALE'}</text>`;
  for (let i = 0; i < n; i++) {
    const [x1, y1] = pts[i], [x2, y2] = pts[i + 1];
    const dx = x2 - x1, dy = y2 - y1, L = Math.hypot(dx, dy) || 1; const nx = dy / L * d, ny = -dx / L * d;
    const poly = [[x1, y1], [x2, y2], [x2 + nx, y2 + ny], [x1 + nx, y1 + ny]].map(([x, y]) => M(x, y).join(',')).join(' ');
    s += `<polygon points="${poly}" fill="${i % 2 ? T.pB : T.pA}" stroke="${T.pS}" stroke-width="1"/>`;
    const a = M(x1, y1), b = M(x2, y2);
    s += `<line x1="${a[0]}" y1="${a[1]}" x2="${b[0]}" y2="${b[1]}" stroke="${i % 2 ? screen.pixmap.c1 : screen.pixmap.c2}" stroke-width="3.5" stroke-linecap="round"/>`;
  }
  if (n <= 40) for (let j = 1; j < n; j++) {
    const a = num(angles[j - 1]); if (!a) continue; const q = M(pts[j][0], pts[j][1]);
    s += `<text x="${q[0] + (isH ? 0 : 16)}" y="${q[1] + (isH ? 18 : 4)}" fill="${a > 0 ? '#5fd3f0' : '#ffb547'}" font-size="10" text-anchor="${isH ? 'middle' : 'start'}">${a > 0 ? '+' : ''}${a}°</text>`;
  }
  if (isFinite(prof.R) && prof.R < span * 4) {
    const cy0 = prof.total >= 0 ? Math.min(...ys) + prof.R : Math.max(...ys) - prof.R;
    const c = M(0, cy0), e = M(pts[0][0], pts[0][1]);
    if (c[0] > -50 && c[0] < W + 50 && c[1] > -50 && c[1] < Hh + 50) {
      s += `<circle cx="${c[0]}" cy="${c[1]}" r="3.5" fill="#ff3d9a"/><line x1="${c[0]}" y1="${c[1]}" x2="${e[0]}" y2="${e[1]}" stroke="#ff3d9a" stroke-dasharray="4 4"/>`;
      s += `<text x="${c[0] + 8}" y="${c[1] - 6}" fill="#ff3d9a" font-size="11">R ${fmt(prof.R / 1000, 2)} m</text>`;
    } else s += `<text x="${W - 16}" y="24" fill="#ff3d9a" font-size="11" text-anchor="end">R ${fmt(prof.R / 1000, 2)} m</text>`;
  }
  const A = M(minX, maxY), B = M(maxX, maxY);
  if (isH) {
    s += dimLine(A[0], A[1] + 34, B[0], T, `Largeur ${fmt(prof.extent / 1000, 3)} m`);
    if (prof.sag > 1) { const q1 = M(maxX, Math.min(...ys)), q2 = M(maxX, maxY); s += dimLineV(q1[0] + 26, q1[1], q2[1], `Flèche ${fmt(prof.sag / 1000, 3)} m`); }
    s += `<text x="${W / 2}" y="${Hh - 12}" fill="${T.dim}" font-size="11" text-anchor="middle" letter-spacing="3">▼ PUBLIC ▼</text>`;
  } else {
    const t = M(minX, minY), bt = M(maxX, minY);
    s += dimLineV(t[0] - 24, t[1], bt[1], `Hauteur ${fmt(prof.extent / 1000, 3)} m`);
    if (prof.sag > 1) s += `<text x="${W / 2}" y="${Hh - 34}" fill="#ffb547" font-size="11" text-anchor="middle">Flèche ${fmt(prof.sag / 1000, 3)} m</text>`;
    s += `<text x="${W - 16}" y="${Hh / 2}" fill="${T.dim}" font-size="11" text-anchor="end" letter-spacing="2">PUBLIC ▶</text>`;
  }
  return s + '</svg>';
}
function dimLine(x1, y, x2, T, label) {
  T = T || THEMES.dark;
  return `<g stroke="${T.mut}" fill="${T.mut}"><line x1="${x1}" y1="${y}" x2="${x2}" y2="${y}" stroke-width="1"/><line x1="${x1}" y1="${y - 6}" x2="${x1}" y2="${y + 6}"/><line x1="${x2}" y1="${y - 6}" x2="${x2}" y2="${y + 6}"/>
  <rect x="${(x1 + x2) / 2 - 70}" y="${y - 10}" width="140" height="20" rx="5" fill="${T.bg}" stroke="none"/><text x="${(x1 + x2) / 2}" y="${y + 4}" font-size="12" text-anchor="middle" stroke="none" fill="${T.txt2}">${label}</text></g>`;
}
function dimLineV(x, y1, y2, label) {
  return `<g stroke="#8ba2ae"><line x1="${x}" y1="${y1}" x2="${x}" y2="${y2}"/><line x1="${x - 6}" y1="${y1}" x2="${x + 6}" y2="${y1}"/><line x1="${x - 6}" y1="${y2}" x2="${x + 6}" y2="${y2}"/></g>
  <text x="${x - 6}" y="${(y1 + y2) / 2 - 8}" font-size="11" fill="#ffb547" text-anchor="end">${label}</text>`;
}

/* ---------- Pixel map (résolution native) ---------- */
function drawPixmap(canvas, screen) {
  if (isBoard(screen)) return drawBoardPixmap(canvas, screen);
  if (isArch(screen) && screen.pixmap.archView !== 'flat') return drawArchPixmap(canvas, screen);
  return drawPixmapFlat(canvas, screen);
}
function drawPixmapFlat(canvas, screen) {
  const p = getProduct(screen.productId) || {}; const pm = screen.pixmap;
  const pw = num(p.pxW) || 128, ph = num(p.pxH) || 128; const W = screen.cols * pw, H = screen.rows * ph;
  canvas.width = W; canvas.height = H; const ctx = canvas.getContext('2d');
  const fsz = Math.max(8, Math.floor(Math.min(pw, ph) * 0.2));
  for (let r = 0; r < screen.rows; r++) for (let c = 0; c < screen.cols; c++) {
    const x = c * pw, y = r * ph;
    ctx.fillStyle = (c + r) % 2 === 0 ? pm.c1 : pm.c2; ctx.fillRect(x, y, pw, ph);
    if (pm.cross) { ctx.strokeStyle = 'rgba(255,255,255,.35)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + pw, y + ph); ctx.moveTo(x + pw, y); ctx.lineTo(x, y + ph); ctx.stroke(); }
    if (pm.grid) { ctx.strokeStyle = 'rgba(255,255,255,.55)'; ctx.lineWidth = 1; ctx.strokeRect(x + .5, y + .5, pw - 1, ph - 1); }
    ctx.fillStyle = pm.textColor; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    if (pm.numbers) { ctx.font = `bold ${fsz}px Segoe UI, Arial`; ctx.fillText(`${c + 1}.${r + 1}`, x + pw / 2, y + ph / 2 - (pm.coords ? fsz * 0.35 : 0)); }
    if (pm.coords) { ctx.font = `${Math.max(7, fsz * 0.5)}px Segoe UI, Arial`; ctx.fillText(`x${x} y${y}`, x + pw / 2, y + ph / 2 + fsz * 0.55); }
  }
  if (pm.circle) {
    ctx.strokeStyle = '#fff'; ctx.lineWidth = Math.max(1, Math.min(W, H) / 300);
    ctx.beginPath(); ctx.arc(W / 2, H / 2, Math.min(W, H) / 2 - ctx.lineWidth, 0, Math.PI * 2); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(W, H); ctx.moveTo(W, 0); ctx.lineTo(0, H); ctx.moveTo(W / 2, 0); ctx.lineTo(W / 2, H); ctx.moveTo(0, H / 2); ctx.lineTo(W, H / 2); ctx.stroke();
  }
  if (pm.title) {
    const t1 = screen.name; const t2 = `${W} × ${H} px · ${screen.cols}×${screen.rows} dalles`;
    const big = Math.max(12, Math.floor(Math.min(W / 18, H / 7)));
    ctx.font = `bold ${big}px Segoe UI, Arial`; const tw = Math.max(ctx.measureText(t1).width, ctx.measureText(t2).width * 0.55) + big;
    ctx.fillStyle = 'rgba(0,0,0,.72)'; ctx.fillRect(W / 2 - tw / 2, H / 2 - big * 1.05, tw, big * 2.1);
    ctx.fillStyle = '#fff'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(t1, W / 2, H / 2 - big * 0.3);
    ctx.font = `${big * 0.5}px Segoe UI, Arial`; ctx.fillText(t2, W / 2, H / 2 + big * 0.55);
  }
  return { W, H };
}

/* ---------- Vue 3D (projection perspective, rotation à la souris) ---------- */
function draw3D(canvas, screen, view) {
  const dpr = window.devicePixelRatio || 1; const cw = canvas.clientWidth, chh = canvas.clientHeight;
  canvas.width = cw * dpr; canvas.height = chh * dpr; const ctx = canvas.getContext('2d'); ctx.scale(dpr, dpr);
  ctx.clearRect(0, 0, cw, chh);
  const g = screenGeometry(screen); const Hp = g.H.pts, Vp = g.V.pts;
  const ext = Math.max(g.width, g.height, 1);
  const cy = Math.cos(view.yaw), sy = Math.sin(view.yaw), cp = Math.cos(view.pitch), sp = Math.sin(view.pitch);
  const D = ext * 2.4; const f = Math.min(cw, chh) * 1.9;
  const vMid = (Vp[0][1] + Vp[screen.rows][1]) / 2;
  const AC = isArch(screen) ? archCells(screen) : null; const AG = null;
  const P = (c, r) => {
    let x = Hp[c][0], y = -Vp[r][0], z = Hp[c][1] + (Vp[r][1] - vMid);
    if (AG) { x = AG[r][c][0]; y = AG[r][c][1] - g.height / 2; z = 0; }
    let x2 = x * cy + z * sy, z2 = -x * sy + z * cy; // yaw
    let y2 = y * cp - z2 * sp, z3 = y * sp + z2 * cp; // pitch
    const k = f / (D - z3) * view.zoom; return [cw / 2 + x2 * k, chh / 2 - y2 * k, z3];
  };
  const quads = [];
  for (let r = 0; r < screen.rows; r++) for (let c = 0; c < screen.cols; c++) {
    const PQ = (q) => { let x = q[0], y = q[1] - g.height / 2, z = 0; let x2 = x * cy + z * sy, z2 = -x * sy + z * cy; let y2 = y * cp - z2 * sp, z3 = y * sp + z2 * cp; const k = f / (D - z3) * view.zoom; return [cw / 2 + x2 * k, chh / 2 - y2 * k, z3]; };
    const [a, b, d, e] = AC ? AC[r][c].map(PQ) : [P(c, r), P(c + 1, r), P(c + 1, r + 1), P(c, r + 1)];
    quads.push({ pts: [a, b, d, e], z: (a[2] + b[2] + d[2] + e[2]) / 4, c, r });
  }
  quads.sort((q1, q2) => q1.z - q2.z);
  quads.forEach((q) => {
    const [a, b, , e] = q.pts; const cross = (b[0] - a[0]) * (e[1] - a[1]) - (b[1] - a[1]) * (e[0] - a[0]);
    const front = cross > 0;
    ctx.beginPath(); q.pts.forEach((p, i) => (i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]))); ctx.closePath();
    ctx.fillStyle = front ? ((q.c + q.r) % 2 === 0 ? screen.pixmap.c1 : screen.pixmap.c2) : '#2a3238';
    ctx.globalAlpha = front ? 0.95 : 1; ctx.fill(); ctx.globalAlpha = 1;
    ctx.strokeStyle = front ? 'rgba(255,255,255,.35)' : '#11181c'; ctx.lineWidth = 1; ctx.stroke();
  });
  // sol
  ctx.fillStyle = 'rgba(139,162,174,.6)'; ctx.font = '11px Segoe UI, Arial'; ctx.fillText('Glisser pour tourner · molette pour zoomer · double-clic : vue de face', 12, chh - 12);
}

/* ---------- SVG -> PNG ---------- */
function svgToPNG(svg, scale = 2) {
  return new Promise((res, rej) => {
    const img = new Image();
    img.onload = () => {
      const c = document.createElement('canvas'); c.width = img.width * scale; c.height = img.height * scale;
      const ctx = c.getContext('2d'); ctx.scale(scale, scale); ctx.drawImage(img, 0, 0); res(c.toDataURL('image/png'));
    };
    img.onerror = rej;
    img.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
  });
}

/* ---------- Pixel map : formats d'export (natif, ajusté 1080p/4K, placé dans une sortie vidéo) ---------- */
const PIX_SIZES = [['1920x1080', 'Full HD 1920 × 1080'], ['3840x2160', '4K UHD 3840 × 2160'], ['custom', 'Personnalisé…']];
function pixOut(s) {
  const o = Object.assign({ mode: 'native', size: '1920x1080', w: 1920, h: 1080, x: 0, y: 0 }, s.pixmap.out || {});
  if (o.size !== 'custom') { const [w, h] = o.size.split('x').map(Number); o.w = w; o.h = h; }
  o.w = Math.max(16, Math.min(16384, Math.round(num(o.w)) || 1920)); o.h = Math.max(16, Math.min(16384, Math.round(num(o.h)) || 1080));
  o.x = Math.round(num(o.x)); o.y = Math.round(num(o.y));
  return o;
}
/* Dessine l'image finale à exporter ; renvoie { W, H, mapW, mapH, o, scale, over } */
function composePixmap(canvas, s) {
  const src = document.createElement('canvas'); const { W: mw, H: mh } = drawPixmap(src, s); const o = pixOut(s);
  if (o.mode === 'native') { canvas.width = mw; canvas.height = mh; canvas.getContext('2d').drawImage(src, 0, 0); return { W: mw, H: mh, mapW: mw, mapH: mh, o, scale: 1, over: null }; }
  canvas.width = o.w; canvas.height = o.h; const ctx = canvas.getContext('2d');
  ctx.fillStyle = '#000'; ctx.fillRect(0, 0, o.w, o.h);
  if (o.mode === 'fit') {
    const sc = Math.min(o.w / mw, o.h / mh); const dw = Math.round(mw * sc), dh = Math.round(mh * sc);
    ctx.imageSmoothingEnabled = sc < 1; ctx.imageSmoothingQuality = 'high';
    ctx.drawImage(src, Math.round((o.w - dw) / 2), Math.round((o.h - dh) / 2), dw, dh);
    return { W: o.w, H: o.h, mapW: mw, mapH: mh, o, scale: sc, over: null };
  }
  ctx.imageSmoothingEnabled = false; ctx.drawImage(src, o.x, o.y);
  const over = { right: Math.max(0, o.x + mw - o.w), bottom: Math.max(0, o.y + mh - o.h), left: Math.max(0, -o.x), top: Math.max(0, -o.y) };
  return { W: o.w, H: o.h, mapW: mw, mapH: mh, o, scale: 1, over: Object.values(over).some((v) => v > 0) ? over : null };
}
function pixFileName(s, r) {
  const n = safeName(s.name) + '_pixelmap';
  if (r.o.mode === 'native') return `${n}_natif_${r.W}x${r.H}.png`;
  if (r.o.mode === 'fit') return `${n}_${r.W}x${r.H}.png`;
  return `${n}_sortie_${r.W}x${r.H}_X${r.o.x}_Y${r.o.y}.png`;
}
const pixOutLabel = (s) => { const o = pixOut(s); return o.mode === 'native' ? 'Résolution native' : o.mode === 'fit' ? `Ajusté ${o.w} × ${o.h}` : `Sortie ${o.w} × ${o.h} · X ${o.x} Y ${o.y}`; };
