// Impulsion Prod — processus principal Electron
// Gère : fenêtre, stockage des données sur disque, sauvegardes automatiques, exports fichiers & PDF.
const { app, BrowserWindow, ipcMain, dialog, shell, Menu, net } = require('electron');
const path = require('path');
const fs = require('fs');
const os = require('os');

// Nom d'origine conservé pour la config : un renommage ne doit pas perdre le dossier de données choisi
app.setPath('userData', path.join(app.getPath('appData'), 'Impulsion LED Manager'));
const CONFIG_FILE = () => path.join(app.getPath('userData'), 'config.json');
const DATA_NAME = 'impulsion-led-data.json';
const MAX_BACKUPS = 60;

function readConfig() {
  try { return JSON.parse(fs.readFileSync(CONFIG_FILE(), 'utf8')); } catch (e) { return {}; }
}
function writeConfig(cfg) {
  fs.mkdirSync(path.dirname(CONFIG_FILE()), { recursive: true });
  fs.writeFileSync(CONFIG_FILE(), JSON.stringify(cfg, null, 2));
}
function dataDir() {
  const cfg = readConfig();
  const dir = cfg.dataDir && fs.existsSync(cfg.dataDir) ? cfg.dataDir : path.join(app.getPath('documents'), 'Impulsion LED Manager');
  fs.mkdirSync(dir, { recursive: true });
  fs.mkdirSync(path.join(dir, 'sauvegardes'), { recursive: true });
  return dir;
}
const dataFile = () => path.join(dataDir(), DATA_NAME);
const backupDir = () => path.join(dataDir(), 'sauvegardes');

function stamp() {
  const d = new Date(); const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}_${p(d.getHours())}h${p(d.getMinutes())}m${p(d.getSeconds())}`;
}
function pruneBackups() {
  try {
    const files = fs.readdirSync(backupDir()).filter((f) => f.endsWith('.json')).sort();
    // 60 plus récentes + une par jour pendant 120 jours
    const old = files.slice(0, Math.max(0, files.length - MAX_BACKUPS)); const lim = new Date(Date.now() - 120 * 864e5).toISOString().slice(0, 10); const byDay = {};
    old.forEach((f) => { const d = f.slice(11, 21); (byDay[d] = byDay[d] || []).push(f); });
    Object.entries(byDay).forEach(([d, g]) => { g.sort(); (d < lim ? g : g.slice(0, -1)).forEach((f) => fs.unlinkSync(path.join(backupDir(), f))); });
  } catch (e) { /* ignore */ }
}
function backupNow(reason) {
  const f = dataFile();
  if (!fs.existsSync(f)) return null;
  const dest = path.join(backupDir(), `sauvegarde_${stamp()}_${reason}.json`);
  fs.copyFileSync(f, dest);
  pruneBackups();
  return dest;
}
let lastHourlyBackup = 0;
function writeData(json) {
  const f = dataFile();
  // sauvegarde horaire automatique avant écrasement
  if (Date.now() - lastHourlyBackup > 60 * 60 * 1000) { backupNow('auto'); lastHourlyBackup = Date.now(); }
  const tmp = f + '.tmp';
  fs.writeFileSync(tmp, json);
  fs.renameSync(tmp, f); // écriture atomique : jamais de fichier à moitié écrit
}

let win;
const SAFE_URL = /^(https:\/\/(wa\.me|api\.whatsapp\.com|web\.whatsapp\.com|chat\.whatsapp\.com|script\.google\.com|drive\.google\.com|docs\.google\.com|github\.com|[\w-]+\.github\.io)\/|whatsapp:|sms:|mailto:|tel:)/i;
const hasWhatsApp = () => { try { return !!app.getApplicationNameForProtocol('whatsapp://'); } catch (e) { return false; } };
function openSafe(url) {
  url = String(url); if (!SAFE_URL.test(url)) return false;
  const m = url.match(/^https:\/\/wa\.me\/(\d+)(?:\?text=(.*))?$/);
  if (m) url = (hasWhatsApp() ? `whatsapp://send?phone=${m[1]}` : `https://api.whatsapp.com/send?phone=${m[1]}`) + (m[2] ? `&text=${m[2]}` : '');
  const g = url.match(/^https:\/\/chat\.whatsapp\.com\/([A-Za-z0-9]+)$/); if (g && hasWhatsApp()) url = `whatsapp://chat?code=${g[1]}`;
  shell.openExternal(url); return true;
}
function createWindow() {
  win = new BrowserWindow({
    width: 1480, height: 920, minWidth: 1100, minHeight: 700,
    backgroundColor: '#0b1116', title: 'Impulsion Prod',
    icon: path.join(__dirname, 'app', 'assets', 'icon.png'),
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false }
  });
  win.loadFile(path.join(__dirname, 'app', 'index.html'));
  win.webContents.setWindowOpenHandler(({ url }) => { openSafe(url); return { action: 'deny' }; });
  const menu = Menu.buildFromTemplate([
    { label: 'Fichier', submenu: [
      { label: 'Ouvrir le dossier des données', click: () => shell.openPath(dataDir()) },
      { label: 'Ouvrir le dossier des sauvegardes', click: () => shell.openPath(backupDir()) },
      { type: 'separator' }, { role: 'quit', label: 'Quitter' } ] },
    { label: 'Édition', submenu: [ { role: 'undo', label: 'Annuler' }, { role: 'redo', label: 'Rétablir' }, { type: 'separator' }, { role: 'cut', label: 'Couper' }, { role: 'copy', label: 'Copier' }, { role: 'paste', label: 'Coller' }, { role: 'selectAll', label: 'Tout sélectionner' } ] },
    { label: 'Affichage', submenu: [ { role: 'reload', label: 'Recharger' }, { role: 'toggleDevTools', label: 'Outils développeur' }, { type: 'separator' }, { role: 'resetZoom', label: 'Zoom 100 %' }, { role: 'zoomIn', label: 'Zoom +' }, { role: 'zoomOut', label: 'Zoom −' }, { role: 'togglefullscreen', label: 'Plein écran' } ] }
  ]);
  Menu.setApplicationMenu(menu);
}

app.whenReady().then(() => {
  // Sauvegarde à chaque démarrage (protège les données lors des mises à jour de l'application)
  try { backupNow('demarrage-v' + app.getVersion()); } catch (e) {}
  createWindow();
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
});
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });

// ---------- IPC ----------
ipcMain.handle('data:load', () => {
  const f = dataFile();
  let raw = null;
  if (fs.existsSync(f)) raw = fs.readFileSync(f, 'utf8');
  return { raw, path: f, dir: dataDir(), version: app.getVersion() };
});
ipcMain.handle('data:save', (e, json) => { writeData(json); return true; });
ipcMain.on('data:saveSync', (e, json) => { try { writeData(json); e.returnValue = true; } catch (err) { e.returnValue = false; } });
ipcMain.handle('data:backup', (e, reason) => backupNow(reason || 'manuelle'));
ipcMain.handle('data:openFolder', (e, which) => shell.openPath(which === 'backups' ? backupDir() : dataDir()));
ipcMain.handle('data:listBackups', () => {
  try { return fs.readdirSync(backupDir()).filter((f) => f.endsWith('.json')).sort().reverse(); } catch (e) { return []; }
});
ipcMain.handle('data:readBackup', (e, name) => fs.readFileSync(path.join(backupDir(), path.basename(name)), 'utf8'));
ipcMain.handle('data:chooseFolder', async () => {
  const r = await dialog.showOpenDialog(win, { title: 'Choisir le dossier des données (ex : OneDrive, Dropbox, serveur)', properties: ['openDirectory', 'createDirectory'] });
  if (r.canceled || !r.filePaths[0]) return null;
  const oldFile = dataFile();
  const newDir = r.filePaths[0];
  const newFile = path.join(newDir, DATA_NAME);
  if (!fs.existsSync(newFile) && fs.existsSync(oldFile)) fs.copyFileSync(oldFile, newFile);
  const cfg = readConfig(); cfg.dataDir = newDir; writeConfig(cfg);
  dataDir();
  return { dir: newDir, raw: fs.existsSync(newFile) ? fs.readFileSync(newFile, 'utf8') : null };
});
ipcMain.handle('file:save', async (e, { defaultName, filters, base64, text }) => {
  const r = await dialog.showSaveDialog(win, { defaultPath: path.join(app.getPath('downloads'), defaultName), filters });
  if (r.canceled || !r.filePath) return null;
  if (base64 != null) fs.writeFileSync(r.filePath, Buffer.from(base64, 'base64'));
  else fs.writeFileSync(r.filePath, text, 'utf8');
  return r.filePath;
});
ipcMain.handle('file:open', async (e, { filters }) => {
  const r = await dialog.showOpenDialog(win, { properties: ['openFile'], filters });
  if (r.canceled || !r.filePaths[0]) return null;
  return fs.readFileSync(r.filePaths[0], 'utf8');
});
ipcMain.handle('pdf:make', async (e, { html, defaultName, landscape }) => {
  const tmp = path.join(os.tmpdir(), `impulsion-report-${Date.now()}.html`);
  fs.writeFileSync(tmp, html, 'utf8');
  const pdfWin = new BrowserWindow({ show: false, webPreferences: { offscreen: false } });
  await pdfWin.loadFile(tmp);
  await new Promise((r) => setTimeout(r, 600));
  const pdf = await pdfWin.webContents.printToPDF({ printBackground: true, landscape: landscape !== false, pageSize: 'A4', margins: { marginType: 'custom', top: 0.3, bottom: 0.3, left: 0.3, right: 0.3 } });
  pdfWin.destroy();
  try { fs.unlinkSync(tmp); } catch (err) {}
  const r = await dialog.showSaveDialog(win, { defaultPath: path.join(app.getPath('downloads'), defaultName), filters: [{ name: 'PDF', extensions: ['pdf'] }] });
  if (r.canceled || !r.filePath) return null;
  fs.writeFileSync(r.filePath, pdf);
  shell.openPath(r.filePath);
  return r.filePath;
});
ipcMain.handle('open:external', (e, url) => openSafe(url));
ipcMain.handle('wa:detect', () => hasWhatsApp());
ipcMain.handle('remote:post', async (e, url, body) => {
  if (!/^https:\/\/script\.google\.com\/macros\/s\/[\w-]+\/exec$/.test(String(url))) throw new Error('Adresse non autorisée');
  const res = await net.fetch(url, { method: 'POST', body: String(body), headers: { 'Content-Type': 'text/plain;charset=utf-8' }, redirect: 'follow' }); return await res.text();
});
ipcMain.handle('remote:get', async (e, url) => {
  if (!/^https:\/\/(script\.google\.com\/macros\/s\/[\w-]+\/exec\?|[\w-]+\.github\.io\/)/.test(String(url))) throw new Error('Adresse non autorisée');
  const res = await net.fetch(url, { redirect: 'follow' }); return await res.text();
});
