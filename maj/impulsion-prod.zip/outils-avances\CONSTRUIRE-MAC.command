#!/bin/bash
cd "$(dirname "$0")/.."
command -v node >/dev/null || { echo "Installez Node.js depuis https://nodejs.org"; open https://nodejs.org; read; exit 1; }
npm install && npm run dist:mac && open dist
read -p "Termine. Entree pour fermer."
