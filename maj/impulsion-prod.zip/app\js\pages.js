/* =====================================================================
   PAGES HÉBERGÉES (GitHub Pages) — les techniciens ouvrent une page statique
   qui interroge le script Google sans compte Google : plus d'erreur
   « Impossible d'ouvrir le fichier » quand le téléphone a plusieurs comptes.
   ===================================================================== */
const PAGES_MARK = 'IMPULSION-PAGES-v1';
function normPagesUrl(v) {
  v = String(v || '').trim(); if (!v) return '';
  if (!/^https?:\/\//i.test(v)) v = 'https://' + v;
  v = v.replace(/^http:\/\//i, 'https://').replace(/index\.html?$/i, '').replace(/[?#].*$/, '');
  v = v.replace(/\.git\/?$/i, ''); // adresse de clonage collée (…/Depot.git)
  // adresse du dépôt collée par erreur (github.com/Compte/Depot) → adresse GitHub Pages (compte.github.io/Depot/)
  const m = v.match(/^https:\/\/(?:www\.)?github\.com\/([^/]+)\/([^/]+)/i); if (m) v = `https://${m[1].toLowerCase()}.github.io/${m[2]}/`;
  return v.endsWith('/') ? v : v + '/';
}
const pagesBase = () => normPagesUrl(Store.db.settings.pagesUrl);
const pagesActive = () => replyActive() && !!pagesBase() && Store.db.settings.pagesApi === Store.db.settings.replyUrl.trim();
function pagesHTML() {
  const st = Store.db.settings; const js = (v) => JSON.stringify(String(v)).replace(/</g, '\\u003c');
  return REPLY_PAGES.split('__API_JSON__').join(js(st.replyUrl.trim()))
    .split('__COMPANY_JSON__').join(js(st.company || 'Impulsion'))
    .split('__COMPANY_HTML__').join(esc(st.company || 'Impulsion'));
}
/* ---------- Pack GitHub : pages techniciens + application téléphone ---------- */
const MOBILE_MARK = 'IMPULSION-APP-MOBILE';
function mobileManifest(kind) {
  const co = Store.db.settings.company || 'Impulsion';
  const icons = [192, 512].map((s) => ({ src: `icon-${s}.png`, sizes: `${s}x${s}`, type: 'image/png', purpose: 'any' }));
  return JSON.stringify(kind === 'app'
    ? { id: './app.html', name: 'Impulsion Prod', short_name: 'Impulsion Prod', description: `Projets, planning, équipe et stock — ${co}`, start_url: './app.html', scope: './', display: 'standalone', orientation: 'portrait', background_color: '#0a1014', theme_color: '#0a1014', lang: 'fr', icons }
    : { id: './?espace=1', name: `Mes bookings — ${co}`, short_name: 'Mes bookings', description: `Mes dates et feuilles de route ${co}`, start_url: './?espace=1', scope: './', display: 'standalone', orientation: 'portrait', background_color: '#0a1014', theme_color: '#0a1014', lang: 'fr', icons }, null, 1);
}
const MOBILE_SW = `/* Impulsion Prod — fonctionnement hors connexion (dernière version consultée) */
const C = 'ip-pages-v2';
self.addEventListener('install', (e) => self.skipWaiting());
self.addEventListener('activate', (e) => e.waitUntil(self.clients.claim()));
self.addEventListener('fetch', (e) => {
  const r = e.request; if (r.method !== 'GET' || new URL(r.url).origin !== location.origin) return;
  e.respondWith(fetch(r.url, { cache: 'no-store', credentials: 'same-origin' }).then((res) => { const cp = res.clone(); caches.open(C).then((c) => c.put(r, cp)); return res; }).catch(() => caches.match(r, { ignoreSearch: true })));
});
`;
function packFiles() {
  const enc = new TextEncoder(); const b64 = (s) => Uint8Array.from(atob(s), (c) => c.charCodeAt(0));
  return [
    { name: 'index.html', data: enc.encode(pagesHTML()) }, { name: 'app.html', data: enc.encode(MOBILE_APP) },
    { name: 'app.webmanifest', data: enc.encode(mobileManifest('app')) }, { name: 'espace.webmanifest', data: enc.encode(mobileManifest('espace')) },
    { name: 'sw.js', data: enc.encode(MOBILE_SW) }, { name: 'icon-192.png', data: b64(MOBILE_ICONS[192]) }, { name: 'icon-512.png', data: b64(MOBILE_ICONS[512]) }
  ];
}
const mobileAppLink = () => `${pagesBase()}app.html#c=${encodeURIComponent(syncCode())}`;
async function fetchText(url) {
  try { const r = await fetch(url, { cache: 'no-store' }); if (r.ok) return await r.text(); } catch (e) { /* CORS : on passe par l'application */ }
  if (window.desktop && window.desktop.remoteGet) return window.desktop.remoteGet(url);
  throw new Error('Page injoignable');
}

function pagesSetupHTML() {
  const st = Store.db.settings; const base = pagesBase(); const on = pagesActive();
  const stale = base && st.pagesApi && st.pagesApi !== st.replyUrl.trim();
  const step = (n, title, body) => `<div class="setup-step"><div class="num">${n}</div><div class="grow"><b>${title}</b><div class="small muted" style="margin-top:4px">${body}</div></div></div>`;
  return `<div class="card" style="margin-top:16px"><div class="grid g2" style="align-items:start">
    <div><h3>🔗 Liens sans erreur Google (recommandé)</h3>
      <div class="small" style="line-height:1.6">Quand un technicien est connecté à <b>plusieurs comptes Google</b> sur son téléphone, Google affiche « Impossible d'ouvrir le fichier ». La solution : héberger la page de réponse et la feuille de route sur <b>GitHub Pages</b> (gratuit). La page interroge votre script Google <b>sans compte Google</b> : l'erreur disparaît pour tout le monde, et les liens sont plus courts.</div>
      <div class="row" style="margin-top:12px">${on ? `<span class="tag ok">● Actif</span><span class="small muted">Les liens envoyés utilisent <b>${esc(base)}</b></span>` : stale ? '<span class="tag bad">● À mettre à jour</span>' : '<span class="tag warn">● Pas encore en place</span>'}</div>
      ${stale ? '<div class="alert bad" style="margin-top:10px">L\'adresse du script Google a changé depuis la mise en ligne de la page : retéléchargez <b>index.html</b> (étape 1) et remplacez-le sur GitHub (étape 4), puis « Enregistrer et tester ».</div>' : ''}
      ${replyActive() && replyState.version && replyState.version < 7 ? '<div class="alert" style="margin-top:10px">Mettez d\'abord le script Google à jour (v7) : bouton « Copier le code » ci-dessus, remplacer, Ctrl+S, Gérer les déploiements → Nouvelle version.</div>' : ''}
      ${on ? `<div class="row" style="margin-top:10px"><button class="sm" data-act="pagesOpen">Ouvrir la page ↗</button><button class="sm" data-act="pagesTest">Tester</button></div>` : ''}
      ${on && !st.pagesMobile ? '<div class="alert warn" style="margin-top:10px">📱 <b>Nouveau : application téléphone et espace techniciens.</b> Téléchargez le <b>pack</b> (étape 1), glissez les 7 fichiers dans votre dépôt GitHub (étape 4), puis « Tester ».</div>' : ''}
    </div>
    <div><h3>Mise en place (une fois, ~10 min)</h3>
      ${step(1, 'Télécharger les fichiers', `<button class="sm primary" data-act="pagesPack" ${replyActive() ? '' : 'disabled'}>⇩ Télécharger le pack (zip)</button> — page des techniciens + application téléphone (7 fichiers). Dézippez-le. <a data-act="pagesDownload">index.html seul</a>`)}
      ${step(2, 'Créer un compte GitHub (gratuit)', `<button class="sm" data-act="pagesGithub" data-v="https://github.com/signup">github.com/signup ↗</button> — choisissez un pseudo simple (ex. <code>impulsion-groupe</code>), il apparaîtra dans l'adresse.`)}
      ${step(3, 'Créer un dépôt', `<button class="sm" data-act="pagesGithub" data-v="https://github.com/new">Nouveau dépôt ↗</button> — nom : <code>reponses</code> · <b>Public</b> · cochez « Add a README file » → <b>Create repository</b>.`)}
      ${step(4, 'Déposer la page', `Dans le dépôt : <b>Add file → Upload files</b> → glissez <b>les 7 fichiers dézippés</b> d'un coup (ils remplacent les anciens) → <b>Commit changes</b>.`)}
      ${step(5, 'Activer GitHub Pages', `<b>Settings → Pages</b> → Source : <b>Deploy from a branch</b> → Branch : <b>main</b> / <b>(root)</b> → <b>Save</b>. Patientez 1 à 2 minutes : l'adresse s'affiche en haut (ex. <code>https://impulsion-groupe.github.io/reponses/</code>).`)}
      ${step(6, 'Coller l\'adresse ici', `<div class="row" style="margin-top:6px"><input class="grow" id="pagesUrlInput" value="${esc(st.pagesUrl || '')}" placeholder="https://votre-pseudo.github.io/reponses/"><button class="primary" data-act="pagesSave" ${replyActive() ? '' : 'disabled'}>Enregistrer et tester</button></div>`)}
    </div></div></div>`;
}

const pagesActions = {
  async pagesPack() { if (IS_WEB || !MOBILE_APP) return toast('Le pack se télécharge depuis le PC', 'warn'); await saveBlob('impulsion-pages-github.zip', makeZip(packFiles()), 'zip', 'Archive ZIP'); toast('Pack téléchargé — dézippez-le et glissez les 7 fichiers dans votre dépôt GitHub'); },
  pagesDownload() { saveFileText('index.html', pagesHTML(), 'html', 'Page web'); toast('index.html téléchargé — déposez-le dans votre dépôt GitHub'); },
  pagesGithub(el) { window.open(el.dataset.v, '_blank'); },
  pagesOpen() { window.open(pagesBase(), '_blank'); },
  async pagesSave() {
    const v = normPagesUrl(document.getElementById('pagesUrlInput').value);
    if (!v) return toast('Collez l\'adresse GitHub Pages (https://….github.io/…/)', 'warn');
    Store.db.settings.pagesUrl = v; Store.db.settings.pagesApi = ''; Store.save();
    await pagesActions.pagesTest(true);
  },
  async pagesTest(fromSave) {
    const st = Store.db.settings; const base = pagesBase(); toast('Vérification de la page…');
    try {
      const html = await withTimeout(fetchText(base + 'index.html'), 20000);
      if (!html.includes(PAGES_MARK)) throw new Error('la page trouvée n\'est pas celle de l\'application (vérifiez le fichier index.html déposé)');
      if (!html.includes(JSON.stringify(st.replyUrl.trim()).replace(/</g, '\\u003c'))) throw new Error('la page a été générée pour une autre adresse de script : retéléchargez index.html et remplacez-le');
      const j = await withTimeout(remoteGet({ action: 'info', t: 'rtestpage' }), 25000).catch((e) => { throw new Error(/Clé invalide/.test(e.message) ? 'le script Google doit être mis à jour (v7)' : e.message); });
      void j; st.pagesApi = st.replyUrl.trim();
      st.pagesMobile = await withTimeout(fetchText(base + 'app.html'), 15000).then((t) => t.includes(MOBILE_MARK)).catch(() => false);
      Store.save(); render();
      toast(st.pagesMobile ? 'Pages en ligne ✔ (techniciens + application téléphone) 🎉' : 'Page en ligne ✔ — l\'application téléphone n\'est pas encore déposée (pack, étape 1)'); confetti();
    } catch (e) {
      st.pagesApi = ''; Store.save(); render();
      toast('Page non validée : ' + e.message + (fromSave ? ' — si vous venez d\'activer GitHub Pages, patientez 2 minutes puis « Enregistrer et tester ».' : ''), 'bad');
    }
  }
};
