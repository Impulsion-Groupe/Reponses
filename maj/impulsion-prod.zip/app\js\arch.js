/* =====================================================================
   ÉCRAN EN ARCHE — une bande de dalles qui suit une arche (face au public)
   s.arch = { shape: 'portique' | 'cintre' | 'surbaisse', span (m, ouverture intérieure), clear (m, hauteur libre au centre), rise (m, flèche de l'arc surbaissé) }
   Colonnes = dalles le long de l'arche (pied gauche → pied droit), rangées = largeur de la bande.
   Le pixel map et les plans sont « déroulés » (une longue bande), la 3D montre l'arche.
   ===================================================================== */
const ARCH_SHAPES = [['cintre', 'Plein cintre (demi-cercle)'], ['surbaisse', 'Arc surbaissé'], ['portique', 'Portique (angles droits)']];
const isArch = (s) => !!(s && s.arch && !isBoard(s));
function archParts(s) {
  const p = getProduct(s.productId) || {}; const w = num(p.widthMm) || 500, h = num(p.heightMm) || 500;
  const A = s.arch; const B = s.rows * h; const S = Math.max(500, num(A.span) * 1000); const Hc = Math.max(500, num(A.clear) * 1000);
  const C = S + B; const segs = []; // segments de la ligne médiane : { type: 'L', a, b } ou { type: 'A', c, r, a0, a1 }
  const line = (a, b) => segs.push({ type: 'L', a, b, len: Math.hypot(b[0] - a[0], b[1] - a[1]) });
  const arc = (c, r, a0, a1) => segs.push({ type: 'A', c, r, a0, a1, len: Math.abs(a1 - a0) * r });
  if (A.shape === 'portique') {
    const rc = B / 2; const yb = Hc + B / 2; // axe de la traverse ; coins arrondis de rayon B/2 (angle intérieur vif)
    line([-C / 2, 0], [-C / 2, yb - rc]); arc([-C / 2 + rc, yb - rc], rc, Math.PI, Math.PI / 2);
    line([-C / 2 + rc, yb], [C / 2 - rc, yb]); arc([C / 2 - rc, yb - rc], rc, Math.PI / 2, 0); line([C / 2, yb - rc], [C / 2, 0]);
  } else if (A.shape === 'surbaisse') {
    const f = Math.min(C / 2, Math.max(100, num(A.rise) * 1000 || C / 4)); const R = (C * C / 4 + f * f) / (2 * f); const ys = Math.max(0, Hc + B / 2 - f); const cy = ys + f - R; const a0 = Math.atan2(ys - cy, -C / 2);
    if (ys > 0) line([-C / 2, 0], [-C / 2, ys]); arc([0, cy], R, a0, Math.PI - a0); if (ys > 0) line([C / 2, ys], [C / 2, 0]);
  } else {
    const R = C / 2; const yc = Hc + B / 2 - R;
    if (yc > 0) { line([-C / 2, 0], [-C / 2, yc]); arc([0, yc], R, Math.PI, 0); line([C / 2, yc], [C / 2, 0]); }
    else { const as = Math.asin(Math.min(1, -yc / R)); arc([0, yc], R, Math.PI - as, as); }
  }
  const L = segs.reduce((a, g) => a + g.len, 0);
  return { w, h, B, S, Hc, C, segs, L };
}
/* point et tangente sur la ligne médiane à l'abscisse curviligne t */
function archAt(P, t) {
  let acc = 0;
  for (const g of P.segs) {
    if (t <= acc + g.len + 1e-6 || g === P.segs[P.segs.length - 1]) {
      const u = g.len ? Math.min(1, Math.max(0, (t - acc) / g.len)) : 0;
      if (g.type === 'L') { const dx = g.b[0] - g.a[0], dy = g.b[1] - g.a[1], n = Math.hypot(dx, dy) || 1; return { x: g.a[0] + dx * u, y: g.a[1] + dy * u, tx: dx / n, ty: dy / n }; }
      const a = g.a0 + (g.a1 - g.a0) * u; const sg = Math.sign(g.a1 - g.a0) || -1;
      return { x: g.c[0] + g.r * Math.cos(a), y: g.c[1] + g.r * Math.sin(a), tx: -Math.sin(a) * sg, ty: Math.cos(a) * sg };
    }
    acc += g.len;
  }
  return { x: 0, y: 0, tx: 1, ty: 0 };
}
/* nombre de dalles le long de l'arche */
const archRigid = (s) => s.arch.rigid !== false;
/* Portique en dalles rigides : jambes + coins + traverse, tout en dalles entières alignées */
function portiqueCounts(s) { const P = archParts(s); const nLeg = Math.max(1, Math.round(P.Hc / P.w)); const nTop = Math.max(1, Math.round(P.S / P.w)); return { P, nLeg, nTop, cols: 2 * (nLeg + s.rows) + nTop }; }
function archFit(s) { const P = archParts(s); s.cols = archRigid(s) && s.arch.shape === 'portique' ? portiqueCounts(s).cols : archCurvedRigid(s) ? Math.max(2, innerChords(s, s.rows * P.h).length) : Math.max(2, Math.round(P.L / P.w)); fitAngles(s); s.hAngles.fill(0); s.vAngles.fill(0); ['elec', 'data'].forEach((k) => { s[k].assign = null; s[k].orders = {}; }); }
/* grille des sommets [x, hauteur, z] : rangée 0 = bord extérieur de la bande */
function archGrid(s) {
  const P = archParts(s); const grid = [];
  for (let r = 0; r <= s.rows; r++) {
    const row = []; const u = (s.rows / 2 - r) * P.h;
    for (let k = 0; k <= s.cols; k++) { const q = archAt(P, k * P.L / s.cols); const nx = -q.ty, ny = q.tx; row.push([q.x + nx * u, Math.max(0, q.y + ny * u), 0]); }
    grid.push(row);
  }
  return grid;
}
/* Dalles rigides sur une courbe : elles se touchent sur le bord intérieur (cordes de longueur w), ouvertures en V à l'extérieur */
function innerChords(s, B) {
  const P = archParts(s); const off = B / 2; const inner = (t) => { const q = archAt(P, Math.min(P.L, Math.max(0, t))); return [q.x + q.ty * off, q.y - q.tx * off]; };
  const walk = (t0) => { const out = []; let t = t0; let a = inner(t); for (let guard = 0; guard < 500; guard++) { let lo = t, hi = Math.min(P.L, t + P.w * 2.5); if (Math.hypot(inner(hi)[0] - a[0], inner(hi)[1] - a[1]) < P.w - 1) break; for (let i = 0; i < 40; i++) { const m = (lo + hi) / 2; if (Math.hypot(inner(m)[0] - a[0], inner(m)[1] - a[1]) < P.w) lo = m; else hi = m; } const b = inner(hi); out.push([a, b]); t = hi; a = b; } return { out, rest: P.L - t }; };
  // depuis chaque pied jusqu'au sommet (symétrique), les pieds restent au sol
  const half = []; { let t = 0; let pa = inner(0); for (let guard = 0; guard < 300; guard++) { let lo = t, hi = Math.min(P.L, t + P.w * 2.5); for (let i = 0; i < 40; i++) { const m = (lo + hi) / 2; if (Math.hypot(inner(m)[0] - pa[0], inner(m)[1] - pa[1]) < P.w) lo = m; else hi = m; } const b = inner(hi); if (b[0] > 1e-6 || hi > P.L / 2 + 1) break; half.push([pa, b]); t = hi; pa = b; } }
  const last = half.length ? half[half.length - 1][1] : inner(0); const gap = Math.abs(2 * last[0]);
  const mid = []; if (gap >= P.w - 1) { const y = inner(P.L / 2)[1]; mid.push([[-P.w / 2, y], [P.w / 2, y]]); }
  const right = half.map(([a, b]) => [[-b[0], b[1]], [-a[0], a[1]]]).reverse();
  const out = [...half, ...mid, ...right]; out.topGap = mid.length ? gap - P.w : gap; return out;
}
const archCurvedRigid = (s) => archRigid(s) && s.arch.shape !== 'portique';
/* Repères (centre, tangente, normale extérieure) de chaque colonne de dalles */
function archFrames(s) {
  const P = archParts(s); const fr = [];
  if (archRigid(s) && s.arch.shape === 'portique') {
    const { nLeg, nTop } = portiqueCounts(s); const w = P.w, B = s.rows * P.h, S = nTop * w, Hc = nLeg * w, xl = -S / 2 - B / 2, xr = S / 2 + B / 2;
    for (let k = 0; k < nLeg + s.rows; k++) fr.push({ x: xl, y: (k + 0.5) * w, tx: 0, ty: 1, nx: -1, ny: 0 });
    for (let j = 0; j < nTop; j++) fr.push({ x: -S / 2 + (j + 0.5) * w, y: Hc + B / 2, tx: 1, ty: 0, nx: 0, ny: 1 });
    for (let k = nLeg + s.rows - 1; k >= 0; k--) fr.push({ x: xr, y: (k + 0.5) * w, tx: 0, ty: -1, nx: 1, ny: 0 });
    return { P, fr, w, S, Hc };
  }
  for (let k = 0; k < s.cols; k++) { const q = archAt(P, (k + 0.5) * P.L / s.cols); fr.push({ x: q.x, y: q.y, tx: q.tx, ty: q.ty, nx: -q.ty, ny: q.tx }); }
  return { P, fr, w: P.w, S: P.S, Hc: P.Hc };
}
/* Quadrilatère de chaque dalle [r][c] = 4 points [x, hauteur, 0] (rangée 0 = bord extérieur) */
function archCells(s) {
  if (!archRigid(s)) { const G = archGrid(s); const out = []; for (let r = 0; r < s.rows; r++) { const row = []; for (let c = 0; c < s.cols; c++) row.push([G[r][c], G[r][c + 1], G[r + 1][c + 1], G[r + 1][c]]); out.push(row); } return out; }
  if (archCurvedRigid(s)) {
    const P = archParts(s); const B = s.rows * P.h; const ch = innerChords(s, B).slice(0, s.cols); const out = [];
    for (let r = 0; r < s.rows; r++) { const u0 = (s.rows - r) * P.h, u1 = (s.rows - r - 1) * P.h; const row = [];
      ch.forEach(([a, b]) => { const L = Math.hypot(b[0] - a[0], b[1] - a[1]) || 1; const tx = (b[0] - a[0]) / L, ty = (b[1] - a[1]) / L; const nx = -ty, ny = tx; const pt = (q, u) => [q[0] + nx * u, Math.max(0, q[1] + ny * u), 0]; row.push([pt(a, u0), pt(b, u0), pt(b, u1), pt(a, u1)]); });
      while (row.length < s.cols) row.push(row[row.length - 1]); out.push(row); }
    return out;
  }
  const F = archFrames(s); const h = F.P.h; const hw = F.w / 2; const out = [];
  for (let r = 0; r < s.rows; r++) {
    const u0 = (s.rows / 2 - r) * h, u1 = (s.rows / 2 - r - 1) * h; const row = [];
    F.fr.slice(0, s.cols).forEach((f) => { const pt = (a, u) => [f.x + f.tx * a + f.nx * u, Math.max(0, f.y + f.ty * a + f.ny * u), 0]; row.push([pt(-hw, u0), pt(hw, u0), pt(hw, u1), pt(-hw, u1)]); });
    out.push(row);
  }
  return out;
}
function archInfo(s) {
  const P = archParts(s); const pts = archCells(s).flat(2);
  const W = Math.max(...pts.map((p) => p[0])) - Math.min(...pts.map((p) => p[0])); const H = Math.max(...pts.map((p) => p[1]));
  const rigidPort = archRigid(s) && s.arch.shape === 'portique'; const F = rigidPort ? archFrames(s) : null;
  return { P, W, H, stretch: rigidPort || archCurvedRigid(s) ? 1 : (P.L / s.cols) / P.w, realS: F ? F.S : P.S, realHc: F ? F.Hc : P.Hc, Ldev: rigidPort || archCurvedRigid(s) ? s.cols * P.w : P.L };
}
/* Vue de face (SVG) */
function archSVG(s, opt = {}) {
  const CL = archCells(s); const I = archInfo(s); const T = opt.light ? THEMES.light : THEMES.dark; const pm = s.pixmap;
  const pad = 400; const minX = -I.W / 2 - pad, W = I.W + pad * 2, Hh = I.H + pad * 2; const Y = (y) => I.H + pad - y; const X = (x) => x - minX;
  let o = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${W} ${Hh}" style="width:100%;max-height:${opt.maxH || 420}px;background:${T.bg}">`;
  o += `<line x1="0" y1="${Y(0)}" x2="${W}" y2="${Y(0)}" stroke="${T.mut}" stroke-width="${W / 400}"/>`;
  for (let r = 0; r < s.rows; r++) for (let k = 0; k < s.cols; k++) {
    const q = CL[r][k];
    o += `<polygon points="${q.map((p) => X(p[0]) + ',' + Y(p[1])).join(' ')}" fill="${(k + r) % 2 ? pm.c2 : pm.c1}" stroke="${T.bg}" stroke-width="${W / 900}"/>`;
  }
  const P = I.P; const fs = W / 45;
  o += `<text x="${W / 2}" y="${Y(0) + pad * 0.6}" text-anchor="middle" fill="${T.txt}" font-size="${fs}" font-family="Segoe UI, Arial">Ouverture ${fmt(I.realS / 1000, 2)} m · hauteur libre ${fmt(I.realHc / 1000, 2)} m · hors-tout ${fmt(I.W / 1000, 2)} × ${fmt(I.H / 1000, 2)} m</text>`;
  return o + '</svg>';
}
function archCardHTML(s) {
  const A = s.arch; const I = archInfo(s); const P = I.P;
  return `<div class="card" style="margin-bottom:16px"><h3>🌈 Arche</h3>
    <div class="row" style="gap:10px;flex-wrap:wrap;margin-bottom:10px"><div class="seg">${ARCH_SHAPES.map(([v, l]) => `<button class="${A.shape === v ? 'on' : ''}" data-act="archShape" data-v="${v}">${l}</button>`).join('')}</div>
      <div class="seg"><button class="${archRigid(s) ? 'on' : ''}" data-act="archRigid" data-v="1" title="Dalles carrées, jamais déformées">▣ Dalles rigides</button><button class="${archRigid(s) ? '' : 'on'}" data-act="archRigid" data-v="0" title="Dalles souples qui épousent la courbe">◠ Dalles souples</button></div></div>
    <div class="form">
      <label class="f">Ouverture intérieure (m)<input type="number" min="0.5" step="0.1" data-arch="span" value="${num(A.span)}"></label>
      <label class="f">Hauteur libre au centre (m)<input type="number" min="0.5" step="0.1" data-arch="clear" value="${num(A.clear)}"></label>
      ${A.shape === 'surbaisse' ? `<label class="f">Flèche de l'arc (m)<input type="number" min="0.1" step="0.1" data-arch="rise" value="${num(A.rise) || fmt(P.C / 4000, 2)}"></label>` : ''}
      <label class="f">Largeur de la bande (dalles)<input type="number" min="1" max="20" data-arch="rows" value="${s.rows}"></label></div>
    <div class="canvas-wrap" style="margin-top:12px;min-height:0">${archSVG(s)}</div>
    <div class="tiny muted" style="margin-top:6px">${s.cols} dalles le long de l'arche (pied gauche → pied droit) × ${s.rows} de large · longueur développée ${fmt(I.Ldev / 1000, 2)} m${archRigid(s) && A.shape === 'portique' ? ` · dalles entières : ouverture réelle <b>${fmt(I.realS / 1000, 2)} m</b>, hauteur libre réelle <b>${fmt(I.realHc / 1000, 2)} m</b>` : archRigid(s) ? ` · dalles rigides : ouvertures en V à l'extérieur de la courbe${(() => { const g = innerChords(s, s.rows * P.h).topGap; return g > 20 ? ` · ⚠ <b>jeu au sommet ${fmt(g / 10, 0)} cm</b> <button class="sm" data-act="archClose">✨ Ajuster l'ouverture pour fermer</button>` : ''; })()}` : ''}${!(archRigid(s) && A.shape === 'portique') && Math.abs(I.stretch - 1) > 0.02 ? ` · ⚠ ajustement ${I.stretch > 1 ? '+' : ''}${fmt((I.stretch - 1) * 100, 1)} % par dalle (jeu / recouvrement à prévoir)` : ''}. Plans et pixel map sont <b>déroulés</b> : une bande de ${s.cols} × ${s.rows}.</div></div>`;
}
const archActions = {
  addArch() {
    const prods = projectDalles(curProject()); if (!prods.length) return customActions.cpNew({ dataset: { target: 'addArch' } });
    const p = curProject(); const s = newScreen(Store.db, prods[0].id); s.name = 'Arche'; s.rows = 2; s.arch = { shape: 'cintre', span: 4, clear: 3, rise: 1, rigid: true };
    archFit(s); p.screens.push(s); Store.save(); go('screen', { screenId: s.id, tab: 'config' }); toast(`Arche créée : ${s.cols} × ${s.rows} dalles`);
  },
  archShape(el) { const s = curScreen(); s.arch.shape = el.dataset.v; archFit(s); Store.save(); render(); },
  archClose() { // cherche l'ouverture la plus proche (± 60 cm) qui ferme le sommet
    const s = curScreen(); const P = archParts(s); const s0 = num(s.arch.span); let best = null;
    for (let d = 0; d <= 60; d++) for (const sg of d ? [-1, 1] : [1]) { const sp = Math.round((s0 + sg * d / 100) * 100) / 100; if (sp < 0.5) continue; s.arch.span = sp; const g = innerChords(s, s.rows * P.h).topGap; if (!best || g < best.g - 0.5) best = { sp, g }; if (g < 5) break; }
    s.arch.span = best ? best.sp : s0; archFit(s); Store.save(); render(); toast(`Ouverture ajustée à ${fmt(s.arch.span, 2)} m (jeu ${fmt(best.g / 10, 0)} cm)`);
  },
  archView(el) { const s = curScreen(); s.pixmap.archView = el.dataset.v; Store.save(); render(); },
  archRigid(el) { const s = curScreen(); s.arch.rigid = el.dataset.v === '1'; archFit(s); Store.save(); render(); }
};
function archChange(t) {
  if (!t.dataset.arch) return false; const s = curScreen(); if (!s || !s.arch) return true; const k = t.dataset.arch;
  if (k === 'rows') s.rows = Math.max(1, Math.min(20, parseInt(t.value, 10) || 1)); else s.arch[k] = Math.max(0.1, num(t.value));
  archFit(s); Store.save(); render(); return true;
}

/* ---------- Plans élec / data en forme d'arche ---------- */
function archPlanSVG(screen, kind, opts = {}) {
  const plan = resolvePlan(screen, kind); const { cols, rows } = screen; const CL = archCells(screen); const I = archInfo(screen);
  const exp = !!opts.export; const T = THEMES[opts.light ? 'light' : 'dark']; const prefix = kind === 'elec' ? 'C' : 'P';
  const k = Math.min(1250 / I.W, 760 / I.H, 0.4); const mx = 40, top = exp ? 96 : 40;
  const legendRows = exp ? Math.ceil(plan.lines.length / 6) : 0;
  const W = Math.max(I.W * k + mx * 2, 700), H = I.H * k + top + 40 + (exp ? 30 + legendRows * 26 : 0);
  const x0 = W / 2; const X = (x) => x0 + (opts.rear ? -x : x) * k; const Y = (y) => top + (I.H - y) * k;
  const cellOf = (i) => CL[Math.floor(i / cols)][i % cols]; const ctr = (i) => { const q = cellOf(i); return [X(q.reduce((a, p) => a + p[0], 0) / 4), Y(q.reduce((a, p) => a + p[1], 0) / 4)]; };
  const pw = (getProduct(screen.productId) || {}).widthMm || 500; const cpx = pw * k; const fs = Math.max(8, Math.min(16, cpx / 4.6));
  const posInLine = new Map(); plan.lines.forEach((l) => l.panels.forEach((idx, n) => posInLine.set(idx, n + 1)));
  let s = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${W} ${H}" width="${W}" height="${H}" font-family="Segoe UI, Arial, sans-serif">`;
  s += `<defs>${plan.lines.map((l) => `<marker id="ar${kind}${l.index}" viewBox="0 0 10 10" refX="7" refY="5" markerWidth="5.5" markerHeight="5.5" orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z" fill="${lineColor(l.index)}"/></marker>`).join('')}
    <pattern id="hatch" width="8" height="8" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><rect width="8" height="8" fill="${T.hatch}"/><line x1="0" y1="0" x2="0" y2="8" stroke="${T.grid}" stroke-width="3"/></pattern></defs>`;
  s += `<rect width="${W}" height="${H}" fill="${T.bg}"/>`;
  if (exp) {
    const prj = opts.project ? opts.project.name + ' — ' : '';
    s += `<text x="${mx}" y="38" fill="${T.txt}" font-size="22" font-weight="700">${esc(prj + screen.name)}</text>`;
    s += `<text x="${mx}" y="62" fill="${T.mut}" font-size="13">${kind === 'elec' ? 'PLAN ÉLECTRIQUE' : 'PLAN DATA'} · ARCHE ${cols}×${rows} dalles · ${opts.rear ? 'VUE DE DOS (côté câblage)' : 'VUE DE FACE (côté public)'} · ${esc(Store.db.settings.company)}</text>`;
  }
  s += `<text x="${W / 2}" y="${top - 14}" fill="${T.dim}" font-size="11" text-anchor="middle" letter-spacing="2">${opts.rear ? '◀ VUE DE DOS ▶' : 'VUE DE FACE'}</text>`;
  s += `<line x1="${mx / 2}" y1="${Y(0)}" x2="${W - mx / 2}" y2="${Y(0)}" stroke="${T.grid}" stroke-width="2"/>`;
  for (let i = 0; i < cols * rows; i++) {
    const a = plan.assign[i]; const line = plan.lines[a]; const color = a >= 0 ? lineColor(a) : null; const dim = opts.sel != null && opts.sel !== a ? 0.55 : 1;
    const q = cellOf(i).map((p) => [X(p[0]), Y(p[1])]); const [cx, cy] = ctr(i);
    s += `<g opacity="${dim}"><polygon data-idx="${i}" points="${q.map((p) => p.join(',')).join(' ')}" fill="${color ? color + '33' : 'url(#hatch)'}" stroke="${line && line.over ? '#ff5d6c' : color || T.grid}" stroke-width="${opts.sel === a ? 3 : 1.6}" stroke-linejoin="round" style="cursor:pointer"/>`;
    if (a >= 0) { s += `<text x="${cx}" y="${cy - fs * 0.15}" fill="${T.txt}" font-size="${fs}" font-weight="700" text-anchor="middle" pointer-events="none">${prefix}${a + 1}</text><text x="${cx}" y="${cy + fs * 0.95}" fill="${color}" font-size="${fs * 0.72}" font-weight="600" text-anchor="middle" pointer-events="none">#${posInLine.get(i)}</text>`; }
    else s += `<text x="${cx}" y="${cy + 4}" fill="${T.mut}" font-size="${fs * 0.75}" text-anchor="middle" pointer-events="none">libre</text>`;
    s += '</g>';
  }
  plan.lines.forEach((l) => {
    if (!l.panels.length) return; const c = lineColor(l.index); const dim = opts.sel != null && opts.sel !== l.index ? 0.5 : 1;
    s += `<g opacity="${dim}" pointer-events="none">`;
    for (let n = 0; n < l.panels.length - 1; n++) {
      const [x1, y1] = ctr(l.panels[n]), [x2, y2] = ctr(l.panels[n + 1]); const dx = x2 - x1, dy = y2 - y1, L = Math.hypot(dx, dy) || 1; const sh = Math.min(10, L * 0.18);
      s += `<line x1="${x1 + dx / L * sh}" y1="${y1 + dy / L * sh + fs * 0.35}" x2="${x2 - dx / L * sh}" y2="${y2 - dy / L * sh + fs * 0.35}" stroke="${c}" stroke-width="2.2" marker-end="url(#ar${kind}${l.index})"/>`;
    }
    const [fx, fy] = ctr(l.panels[0]); s += `<circle cx="${fx}" cy="${fy + fs * 0.35}" r="${Math.max(6, fs * 0.5)}" fill="${c}" stroke="${T.bg}" stroke-width="2"/><text x="${fx}" y="${fy + fs * 0.35 + 3.5}" font-size="${Math.max(8, fs * 0.5)}" text-anchor="middle" fill="#00141c" font-weight="800">${kind === 'elec' ? '⚡' : '▶'}</text></g>`;
  });
  // repère : pied gauche / pied droit
  const foot = (i, t) => { const [cx] = ctr(i); return `<text x="${cx}" y="${Y(0) + 18}" fill="${T.dim}" font-size="11" text-anchor="middle">${t}</text>`; };
  s += foot(0, opts.rear ? 'pied gauche (vu de face)' : 'pied gauche') + foot(cols - 1, opts.rear ? 'pied droit (vu de face)' : 'pied droit');
  if (exp) {
    const sum = kind === 'elec' ? elecSummary(screen, plan) : dataSummary(screen, plan); const y0 = top + I.H * k + 50;
    sum.rows.forEach((r, n) => { const x = mx + (n % 6) * Math.max(150, (W - 2 * mx) / 6); const y = y0 + Math.floor(n / 6) * 26; const extra = kind === 'elec' ? `${r.n} dalles · ${fmt(r.A, 1)} A · ${r.phase}` : `${r.n} dalles · ${fmt(r.pct, 0)} %`; s += `<rect x="${x}" y="${y - 11}" width="12" height="12" rx="3" fill="${lineColor(r.line.index)}"/><text x="${x + 18}" y="${y}" fill="${T.txt2}" font-size="12"><tspan font-weight="700">${r.name}</tspan> ${extra}</text>`; });
  }
  return s + '</svg>';
}
/* ---------- Pixel map en forme d'arche : le contenu de chaque dalle placé à sa vraie position ---------- */
function drawArchPixmap(canvas, s) {
  const p = getProduct(s.productId) || {}; const pw = num(p.pxW) || 128, ph = num(p.pxH) || 128; const kx = pw / (num(p.widthMm) || 500);
  const strip = document.createElement('canvas'); drawPixmapFlat(strip, Object.assign({}, s, { pixmap: Object.assign({}, s.pixmap, { title: false, circle: false }) })); const pm = s.pixmap;
  const CL = archCells(s); const I = archInfo(s); const pts = CL.flat(2); const minX = Math.min(...pts.map((q) => q[0]));
  const W = Math.ceil(I.W * kx), H = Math.ceil(I.H * kx); canvas.width = W; canvas.height = H; const ctx = canvas.getContext('2d');
  ctx.fillStyle = '#000'; ctx.fillRect(0, 0, W, H); ctx.imageSmoothingEnabled = false;
  const X = (x) => (x - minX) * kx, Y = (y) => H - y * kx;
  for (let r = 0; r < s.rows; r++) for (let c = 0; c < s.cols; c++) {
    const Q = CL[r][c].map((q) => [X(q[0]), Y(q[1])]);
    // contenu toujours dans le même sens : on prend le coin qui met la dalle « debout » (rotation la plus proche de 0°)
    let k = 0; if (pm.archUpright !== false) { let best = Infinity; for (let i = 0; i < 4; i++) { const a0 = Q[i], b0 = Q[(i + 1) % 4]; const ang = Math.abs(Math.atan2(b0[1] - a0[1], b0[0] - a0[0])); if (ang < best - 1e-6) { best = ang; k = i; } } }
    const A = Q[k], B = Q[(k + 1) % 4], C = Q[(k + 2) % 4], D = Q[(k + 3) % 4];
    ctx.save(); ctx.beginPath(); ctx.moveTo(A[0], A[1]); ctx.lineTo(B[0], B[1]); ctx.lineTo(C[0], C[1]); ctx.lineTo(D[0], D[1]); ctx.closePath(); ctx.clip();
    ctx.setTransform((B[0] - A[0]) / pw, (B[1] - A[1]) / pw, (D[0] - A[0]) / ph, (D[1] - A[1]) / ph, A[0], A[1]);
    ctx.drawImage(strip, c * pw, r * ph, pw, ph, 0, 0, pw, ph); ctx.restore();
  }
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  if (pm.circle) { // mire sur l'arche entière, visible seulement sur les dalles
    ctx.save(); ctx.beginPath(); CL.flat().forEach((q) => { const pp = q.map((v) => [X(v[0]), Y(v[1])]); ctx.moveTo(pp[0][0], pp[0][1]); pp.slice(1).forEach((v) => ctx.lineTo(v[0], v[1])); ctx.closePath(); }); ctx.clip();
    const lw = Math.max(2, Math.min(W, H) / 250); const r0 = Math.min(W / 2, H) - lw; ctx.strokeStyle = '#fff'; ctx.lineWidth = lw; ctx.beginPath();
    ctx.arc(W / 2, H, r0, Math.PI, 2 * Math.PI); ctx.moveTo(0, 0); ctx.lineTo(W, H); ctx.moveTo(W, 0); ctx.lineTo(0, H); ctx.moveTo(W / 2, 0); ctx.lineTo(W / 2, H); ctx.moveTo(0, H / 2); ctx.lineTo(W, H / 2); ctx.stroke(); ctx.restore();
  }
  if (pm.title) { // titre au centre de l'ouverture
    const t1 = s.name; const t2 = `Arche ${s.cols}×${s.rows} dalles · bande déroulée ${s.cols * pw} × ${s.rows * ph} px`;
    let big = Math.max(12, Math.floor(Math.min(W / 16, H / 9))); const openW = I.realS * kx * 0.94;
    { ctx.font = `bold ${big}px Segoe UI, Arial`; const a1 = ctx.measureText(t1).width; ctx.font = `${big * 0.5}px Segoe UI, Arial`; const a2 = ctx.measureText(t2).width; const need = Math.max(a1, a2) + big; if (need > openW) big = Math.max(9, Math.floor(big * openW / need)); }
    ctx.font = `bold ${big}px Segoe UI, Arial`; const w1 = ctx.measureText(t1).width; ctx.font = `${big * 0.5}px Segoe UI, Arial`; const tw = Math.max(w1, ctx.measureText(t2).width) + big; ctx.font = `bold ${big}px Segoe UI, Arial`;
    const ty = H * 0.62; ctx.fillStyle = 'rgba(0,0,0,.72)'; ctx.fillRect(W / 2 - tw / 2, ty - big * 1.05, tw, big * 2.1);
    ctx.fillStyle = '#fff'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(t1, W / 2, ty - big * 0.3); ctx.font = `${big * 0.5}px Segoe UI, Arial`; ctx.fillText(t2, W / 2, ty + big * 0.55);
  }
  return { W, H };
}
function archThumbSVG(s) {
  const CL = archCells(s); const I = archInfo(s); const pts = CL.flat(2); const minX = Math.min(...pts.map((q) => q[0])); const pm = s.pixmap;
  let o = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${I.W} ${I.H}">`;
  CL.forEach((row, r) => row.forEach((q, c) => { o += `<polygon points="${q.map((p) => `${p[0] - minX},${I.H - p[1]}`).join(' ')}" fill="${(c + r) % 2 ? pm.c2 : pm.c1}"/>`; }));
  return o + '</svg>';
}
