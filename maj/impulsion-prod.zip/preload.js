const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('desktop', {
  isDesktop: true,
  load: () => ipcRenderer.invoke('data:load'),
  save: (json) => ipcRenderer.invoke('data:save', json),
  saveSync: (json) => ipcRenderer.sendSync('data:saveSync', json),
  backup: (reason) => ipcRenderer.invoke('data:backup', reason),
  openFolder: (which) => ipcRenderer.invoke('data:openFolder', which),
  listBackups: () => ipcRenderer.invoke('data:listBackups'),
  readBackup: (name) => ipcRenderer.invoke('data:readBackup', name),
  chooseFolder: () => ipcRenderer.invoke('data:chooseFolder'),
  saveFile: (opts) => ipcRenderer.invoke('file:save', opts),
  openFile: (opts) => ipcRenderer.invoke('file:open', opts),
  makePdf: (opts) => ipcRenderer.invoke('pdf:make', opts),
  openExternal: (url) => ipcRenderer.invoke('open:external', url),
  hasWhatsApp: () => ipcRenderer.invoke('wa:detect'),
  remoteGet: (url) => ipcRenderer.invoke('remote:get', url),
  remotePost: (url, body) => ipcRenderer.invoke('remote:post', url, body)
});
