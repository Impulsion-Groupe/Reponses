/* =====================================================================
   FEUILLE DE ROUTE — tout ce dont l'équipe a besoin sur une prestation :
   lieu & accès, planning horaire, contacts, équipe, transport, matériel,
   écrans & plans, infos pratiques. Export PDF, résumé WhatsApp, page en ligne.
   ===================================================================== */
const RM_PRESETS = ['RDV dépôt / chargement', 'Départ dépôt', 'Arrivée sur site', 'Déchargement', 'Montage', 'Tests / calage', 'Briefing sécurité', 'Répétition', 'Ouverture public', 'Show', 'Repas', 'Démontage', 'Rechargement', 'Retour dépôt'];
const RM_INCLUDE = [['crew', 'Équipe (validés)'], ['options', '… + techniciens en option'], ['phones', 'Téléphones de l\'équipe'], ['fleet', 'Transport & chauffeurs'], ['material', 'Liste de matériel (à cocher)'], ['screens', 'Fiches écrans'], ['plans', 'Plans de câblage (vue de dos)'], ['scene', 'Vue 3D de la scène']];

function ensureRoadmap(p) {
  if (!p.roadmap) p.roadmap = {};
  const rm = p.roadmap;
  rm.contacts = Array.isArray(rm.contacts) ? rm.contacts : [];
  rm.schedule = Array.isArray(rm.schedule) ? rm.schedule : [];
  rm.include = Object.assign({ crew: true, options: false, phones: true, fleet: true, material: true, screens: true, plans: true, scene: true }, rm.include || {});
  rm.address = rm.address != null ? rm.address : (p.venue || '');
  if (!rm.seeded && !rm.schedule.length && p.start) { rm.schedule = seedSchedule(p); rm.seeded = true; }
  return rm;
}
function seedSchedule(p) {
  const s = p.start, e = p.end || p.start; const it = (date, time, label) => ({ id: uid('sch'), date, time, label, note: '' });
  const out = [it(s, '07:30', 'RDV dépôt / chargement'), it(s, '09:00', 'Départ dépôt'), it(s, '11:00', 'Arrivée sur site — déchargement & montage'), it(s, '18:00', 'Tests / calage')];
  if (e !== s) out.push(it(e, '18:00', 'Démontage'), it(e, '22:00', 'Retour dépôt'));
  else out.push(it(s, '23:00', 'Démontage'));
  return out;
}
const rmLink = (p) => (replyActive() && p.roadmap && p.roadmap.token && p.roadmap.publishedAt ? (pagesActive() ? `${pagesBase()}?f=${p.roadmap.token}` : `${Store.db.settings.replyUrl.trim()}?f=${p.roadmap.token}`) : '');

/* ---------- Données de la feuille de route ---------- */
function sceneJpeg(p) {
  ensurePlacement(p); const c = document.createElement('canvas');
  drawScene(c, p, Object.assign({ yaw: -0.45, pitch: 0.32, zoom: 1, mode: 'damier', labels: true }, ui.sceneView || {}), { w: 1200, h: 680 });
  return c.toDataURL('image/jpeg', 0.82);
}
function roadmapData(p, lite) {
  const rm = ensureRoadmap(p); const inc = rm.include; const st = Store.db.settings;
  const crew = p.crew.filter((r) => r.status === 'valide' || (inc.options && r.status === 'option'))
    .map((r) => { const t = getTech(r.techId) || {}; return { name: techName(t), phone: inc.phones ? t.phone || '' : '', role: r.role || '', dates: fmtDays(r.dates) + (hoursShort(r) ? ' · 🕐 ' + hoursShort(r) : ''), status: r.status === 'option' ? 'Option' : 'Validé' }; });
  const fleet = p.fleet.map((f) => { const v = getVehicle(f.vehicleId) || {}; const d = getTech(f.driverId) || {}; return { vehicle: v.name || '', plate: v.plate || '', dates: fmtDays(rangeDays(f.start, f.end)), driver: f.driverId ? techName(d) : '', phone: inc.phones ? d.phone || '' : '', note: f.note || '' }; });
  const material = [...projectUsage(p).entries()].map(([pid, u]) => { const x = getProduct(pid); return x && { ref: x.ref, name: x.name, cat: CATEGORIES[x.category], qty: u.qty, m2: panelM2(x) ? fmt(m2(x, u.qty), 2) + ' m²' : '' }; }).filter(Boolean);
  const screens = p.screens.map((s) => {
    const g = screenGeometry(s); const pe = resolvePlan(s, 'elec'), pd = resolvePlan(s, 'data'); const ds = dataSummary(s, pd); const prod = getProduct(s.productId) || {};
    return { name: s.name, board: isBoard(s), product: prod.name || '',
      dims: isBoard(s) ? `${panelCount(s)} panneaux · ${fmt(g.width / 1000, 2)} m linéaires` : `${fmt(g.width / 1000, 2)} × ${fmt(g.height / 1000, 2)} m · ${s.cols}×${s.rows} dalles`,
      m2: fmt(g.surface, 2) + ' m²', res: `${isBoard(s) ? fmt(s.cols * num(prod.pxW) * s.rows * num(prod.pxH)) + ' px' : g.resW + ' × ' + g.resH + ' px'}`,
      power: fmt(g.pMax / 1000, 2) + ' kW', weight: fmt(g.weight) + ' kg', elec: pe.lines.filter((l) => l.panels.length).length, data: pd.lines.filter((l) => l.panels.length).length,
      proc: ds.proc ? `${ds.proc.name} × ${ds.procs}` : '', zones: isBoard(s) ? s.zones.map((z, i) => `Z${i + 1} ${z.name} : ${z.count}`) : [],
      plans: !lite && inc.plans ? [{ title: 'Plan électrique — vue de dos', svg: planSVG(s, 'elec', { rear: true, light: true, export: true, project: p }) }, { title: 'Plan data — vue de dos', svg: planSVG(s, 'data', { rear: true, light: true, export: true, project: p }) }] : [] };
  });
  const schedule = [...rm.schedule].filter((x) => x.label || x.time).sort((a, b) => (a.date || '').localeCompare(b.date || '') || (a.time || '').localeCompare(b.time || ''))
    .map((x) => ({ date: x.date || '', day: x.date ? dayLabel(x.date) : '', time: x.time || '', label: x.label || '', note: x.note || '' }));
  return { v: 1, company: st.company, updatedAt: new Date().toLocaleString('fr-FR', { dateStyle: 'short', timeStyle: 'short' }),
    project: { name: p.name, client: p.client || '', venue: p.venue || '', dates: `${fmtDate(p.start)} → ${fmtDate(p.end)}`, status: STATUSES[p.status] },
    address: rm.address || '', place: p.venue && !(rm.address || '').toLowerCase().includes(p.venue.toLowerCase()) ? p.venue : '', mapsQuery: (rm.address || p.venue || '').replace(/\s*\n+\s*/g, ', '), access: rm.access || '', contacts: rm.contacts.filter((c) => c.name || c.phone), schedule,
    lodging: rm.lodging || '', meals: rm.meals || '', dress: rm.dress || '', safety: rm.safety || '', notes: rm.notes || '',
    crew: inc.crew ? crew : [], fleet: inc.fleet ? fleet : [], material: inc.material ? material : [], screens: inc.screens ? screens : [],
    files: inc.files !== false ? roadmapFiles(p) : [],
    sceneImg: !lite && inc.scene && p.screens.length ? sceneJpeg(p) : '' };
}

/* ---------- Résumé texte (WhatsApp) ---------- */
function roadmapText(p, opts = {}) {
  const d = roadmapData(p, true); const L = [];
  L.push(`📋 FEUILLE DE ROUTE — ${d.project.name}`); L.push(`📅 ${d.project.dates}`);
  if (d.mapsQuery) { L.push(`📍 ${[d.place, d.address].filter(Boolean).join(' — ').replace(/\s*\n+\s*/g, ', ')}`); L.push(`🗺️ https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(d.mapsQuery)}`); }
  if (d.access) L.push(`🅿️ Accès : ${d.access}`);
  if (d.schedule.length) { L.push('', '🕐 PLANNING'); let day = ''; d.schedule.forEach((x) => { if (x.day !== day) { day = x.day; L.push(`— ${day || 'Date à définir'} —`); } L.push(`• ${x.time || '--:--'} ${x.label}${x.note ? ' (' + x.note + ')' : ''}`); }); }
  if (d.contacts.length) { L.push('', '📞 CONTACTS SUR SITE'); d.contacts.forEach((c) => L.push(`• ${c.name}${c.role ? ' (' + c.role + ')' : ''}${c.phone ? ' : ' + c.phone : ''}`)); }
  if (d.crew.length && !opts.noCrew) { L.push('', '👷 ÉQUIPE'); d.crew.forEach((c) => L.push(`• ${c.name}${c.role ? ' — ' + c.role : ''}${c.phone ? ' — ' + c.phone : ''}${c.status === 'Option' ? ' (option)' : ''}`)); }
  if (d.fleet.length) { L.push('', '🚚 TRANSPORT'); d.fleet.forEach((f) => L.push(`• ${f.vehicle}${f.plate ? ' (' + f.plate + ')' : ''} — ${f.dates}${f.driver ? ' — chauffeur : ' + f.driver : ''}${f.note ? ' — ' + f.note : ''}`)); }
  if ((d.files || []).length) { L.push('', '💾 FICHIERS DE CONFIGURATION'); d.files.forEach((f) => L.push(`• ${f.ref} — ${f.name} : ${f.url}`)); }
  if (d.screens.length) { L.push('', '🖥️ ÉCRANS'); d.screens.forEach((s) => L.push(`• ${s.name} : ${s.dims} · ${s.elec} ligne(s) élec · ${s.data} port(s) data`)); }
  [['🏨 Hébergement', d.lodging], ['🍽️ Repas', d.meals], ['👕 Tenue', d.dress], ['⚠️ Sécurité', d.safety], ['📝 Notes', d.notes]].forEach(([k, v]) => { if (v) L.push('', `${k} : ${v}`); });
  const link = rmLink(p); if (link) L.push('', `👉 Feuille de route complète (plans, matériel…) : ${link}`);
  return L.join('\n');
}

/* ---------- PDF ---------- */
function roadmapPdfHTML(p) {
  const d = roadmapData(p); const nl = (s) => esc(s).replace(/\n/g, '<br>');
  const css = `@page{size:A4 portrait;margin:12mm}@page land{size:A4 landscape;margin:8mm}
    body{font-family:Segoe UI,Arial,sans-serif;color:#0d1a20;font-size:11.5px;margin:0}
    .hdr{display:flex;justify-content:space-between;align-items:center;border-bottom:3px solid #0b5c78;padding-bottom:8px;margin-bottom:12px}.hdr img{height:42px}
    h1{font-size:24px;margin:0}h2{font-size:14px;color:#0b5c78;margin:16px 0 6px;text-transform:uppercase;letter-spacing:.06em;border-bottom:1px solid #c7d3d9;padding-bottom:3px}
    table{border-collapse:collapse;width:100%}th,td{border:1px solid #c7d3d9;padding:4px 7px;text-align:left;vertical-align:top}th{background:#e8f1f4;font-size:10px;text-transform:uppercase}
    .muted{color:#5b6b73}.two{display:flex;gap:14px}.two>div{flex:1}.box{border:1px solid #c7d3d9;border-radius:6px;padding:8px 10px;margin-bottom:8px}
    .day td{background:#0b5c78;color:#fff;font-weight:700}.chk{width:18px;height:12px;border:1.5px solid #0d1a20;display:inline-block;border-radius:2px}
    .land{page:land;page-break-before:always}.land svg,.land img{width:100%;height:auto;max-height:185mm}.avoid{page-break-inside:avoid}`;
  let h = `<!doctype html><html><head><meta charset="utf-8"><title>Feuille de route — ${esc(p.name)}</title><style>${css}</style></head><body>`;
  h += `<div class="hdr"><div><div class="muted" style="letter-spacing:.2em;font-size:10px">FEUILLE DE ROUTE</div><h1>${esc(d.project.name)}</h1><div>${esc(d.project.dates)} · ${esc(d.project.status)}${d.project.client ? ' · Client : ' + esc(d.project.client) : ''}</div></div><img src="${LOGO_DATA}"></div>`;
  h += `<div class="two"><div><h2>📍 Lieu & accès</h2><div class="box">${d.place ? `<b>${esc(d.place)}</b><br>` : ''}${nl(d.address)}${d.access ? `<br><br><b>Accès / parking :</b><br>${nl(d.access)}` : ''}</div></div>
    <div><h2>📞 Contacts sur site</h2>${d.contacts.length ? `<table>${d.contacts.map((c) => `<tr><td><b>${esc(c.name)}</b><br><span class="muted">${esc(c.role || '')}</span></td><td>${esc(c.phone || '')}</td></tr>`).join('')}</table>` : '<div class="muted">—</div>'}</div></div>`;
  if (d.schedule.length) {
    let day = null; h += `<h2>🕐 Planning</h2><table class="avoid"><tr><th style="width:60px">Heure</th><th>Étape</th><th>Note</th></tr>`;
    d.schedule.forEach((x) => { if (x.day !== day) { day = x.day; h += `<tr class="day"><td colspan="3">${esc(day || 'Date à définir')}</td></tr>`; } h += `<tr><td><b>${esc(x.time)}</b></td><td>${esc(x.label)}</td><td>${esc(x.note)}</td></tr>`; });
    h += '</table>';
  }
  if (d.crew.length) h += `<h2>👷 Équipe</h2><table class="avoid"><tr><th>Nom</th><th>Poste</th><th>Téléphone</th><th>Dates</th><th>Statut</th></tr>${d.crew.map((c) => `<tr><td><b>${esc(c.name)}</b></td><td>${esc(c.role)}</td><td>${esc(c.phone)}</td><td>${esc(c.dates)}</td><td>${c.status}</td></tr>`).join('')}</table>`;
  if (d.fleet.length) h += `<h2>🚚 Transport</h2><table class="avoid"><tr><th>Véhicule</th><th>Immat.</th><th>Dates</th><th>Chauffeur</th><th>Téléphone</th><th>Note</th></tr>${d.fleet.map((f) => `<tr><td><b>${esc(f.vehicle)}</b></td><td>${esc(f.plate)}</td><td>${esc(f.dates)}</td><td>${esc(f.driver)}</td><td>${esc(f.phone)}</td><td>${esc(f.note)}</td></tr>`).join('')}</table>`;
  if (d.screens.length) h += `<h2>🖥️ Écrans</h2><table class="avoid"><tr><th>Écran</th><th>Dimensions</th><th>Surface</th><th>Résolution</th><th>Élec</th><th>Data</th><th>Puissance</th><th>Poids</th></tr>${d.screens.map((s) => `<tr><td><b>${esc(s.name)}</b><br><span class="muted">${esc(s.product)}</span>${s.zones.length ? `<br><span class="muted">${s.zones.map(esc).join(' · ')}</span>` : ''}</td><td>${esc(s.dims)}</td><td>${s.m2}</td><td>${s.res}</td><td>${s.elec} ligne(s)</td><td>${s.data} port(s)${s.proc ? '<br>' + esc(s.proc) : ''}</td><td>${s.power}</td><td>${s.weight}</td></tr>`).join('')}</table>`;
  const prat = [['🏨 Hébergement', d.lodging], ['🍽️ Repas', d.meals], ['👕 Tenue', d.dress], ['⚠️ Sécurité / EPI', d.safety], ['📝 Notes', d.notes]].filter(([, v]) => v);
  if (prat.length) h += `<h2>ℹ️ Infos pratiques</h2>${prat.map(([k, v]) => `<div class="box"><b>${k}</b><br>${nl(v)}</div>`).join('')}`;
  if (d.material.length) h += `<h2>📦 Matériel</h2><table><tr><th style="width:24px">✓</th><th>Réf.</th><th>Désignation</th><th>Catégorie</th><th style="text-align:right">Qté</th><th style="width:24px">✓</th></tr>${d.material.map((m) => `<tr><td><span class="chk"></span></td><td>${esc(m.ref)}</td><td>${esc(m.name)}</td><td>${esc(m.cat)}</td><td style="text-align:right"><b>${m.qty}</b>${m.m2 ? '<br><span class="muted">' + m.m2 + '</span>' : ''}</td><td><span class="chk"></span></td></tr>`).join('')}</table><div class="muted" style="margin-top:4px">1re colonne : chargé au départ · dernière colonne : rechargé au retour</div>`;
  if (d.sceneImg) h += `<div class="land"><h2>🎬 Vue d'ensemble</h2><img src="${d.sceneImg}"></div>`;
  d.screens.forEach((s) => s.plans.forEach((pl) => { h += `<div class="land"><h2>${esc(s.name)} — ${esc(pl.title)}</h2>${pl.svg}</div>`; }));
  h += `<div class="muted" style="margin-top:14px;font-size:9px">Édité le ${esc(d.updatedAt)} · ${esc(d.company)}</div></body></html>`;
  return h;
}

/* ---------- Publication en ligne (relais Google) ---------- */
async function remotePost(obj) {
  const url = Store.db.settings.replyUrl.trim(); const body = JSON.stringify(obj); let txt;
  if (window.desktop && window.desktop.remotePost) txt = await window.desktop.remotePost(url, body);
  else txt = await (await fetch(url, { method: 'POST', body, headers: { 'Content-Type': 'text/plain;charset=utf-8' }, redirect: 'follow' })).text();
  let j; try { j = JSON.parse(txt); } catch (e) {
    if (/Authorization is required|autorisation est requise|Autorisation requise|requires authorization|needs authorization|Vous devez disposer d'une autorisation/i.test(txt)) throw new Error('Google demande une autorisation : dans l\'éditeur Apps Script, choisissez la fonction « autoriserAgenda », cliquez ▶ Exécuter et acceptez (Paramètres avancés → Accéder), puis Déployer → Gérer les déploiements → ✏️ → Nouvelle version.');
    if (/doPost|introuvable|not found/i.test(txt)) throw new Error('Le script Google doit être mis à jour (v3) pour publier les feuilles de route — Équipe → Réponses en 1 clic.');
    throw new Error('Réponse inattendue du script Google');
  }
  if (!j.ok) throw new Error(j.error || 'Erreur du script'); return j;
}
function roadmapHash(p) { const d = roadmapData(p, true); delete d.updatedAt; return JSON.stringify(d); }
async function publishRoadmap(p) {
  const rm = ensureRoadmap(p); if (!replyActive()) throw new Error('Activez d\'abord le relais Google (Équipe → Réponses en 1 clic)');
  if (!rm.token) rm.token = 'f' + randToken(20);
  try { await uploadProjectFiles(p); } catch (e) { toast('⚠ Fichiers RCG non envoyés : ' + e.message, 'warn'); }
  const j = await withTimeout(remotePost({ action: 'publish', key: ensureReplyKey(), token: rm.token, data: roadmapData(p) }), 45000);
  rm.publishedAt = new Date().toISOString(); rm.pubHash = roadmapHash(p); replyState.version = j.version || replyState.version; Store.save(); return rmLink(p);
}

/* ---------- Page « Feuille de route » ---------- */
function vRoadmap() {
  const p = curProject(); if (!p) return vProjects();
  const rm = ensureRoadmap(p); const link = rmLink(p);
  const team = roadmapRecipients(p);
  const ta = (k, label, ph, h = 70) => `<label class="f">${label}<textarea data-rm="${k}" placeholder="${esc(ph)}" style="min-height:${h}px">${esc(rm[k] || '')}</textarea></label>`;
  const sched = [...rm.schedule].sort((a, b) => (a.date || '').localeCompare(b.date || '') || (a.time || '').localeCompare(b.time || ''));
  return `<div class="crumbs"><a data-nav-go="projects">Projets</a> › <a data-act="openProject" data-id="${p.id}">${esc(p.name)}</a> › Feuille de route</div>
  <div class="page-head"><div><h1>📋 Feuille de route</h1><div class="sub">${esc(p.name)} · ${fmtDate(p.start)} → ${fmtDate(p.end)} — l'équipe, le transport, le matériel et les écrans sont repris automatiquement du projet</div></div>
    <div class="row"><button data-act="rmPdf">⇩ PDF</button><button data-act="rmCopy">📋 Copier le résumé</button><button data-act="rmGroup">💬 Groupe WhatsApp</button>
    <button data-act="rmPublish" ${replyActive() ? '' : 'disabled title="Activez le relais Google (Équipe → Réponses en 1 clic)"'}>🌐 ${rm.publishedAt ? 'Mettre à jour en ligne' : 'Publier en ligne'}</button>
    <button class="primary" data-act="rmSend" ${team.length ? '' : 'disabled title="Aucun technicien validé ni chauffeur avec téléphone"'}>📲 Envoyer à l'équipe (${team.length})</button></div></div>
  ${replyActive() ? (link ? `<div class="alert ok row" style="justify-content:space-between">🌐 <span class="grow">En ligne — mise à jour le ${new Date(rm.publishedAt).toLocaleString('fr-FR', { dateStyle: 'short', timeStyle: 'short' })}. Elle se met à jour automatiquement quand vous modifiez la feuille de route ou le projet.</span><button class="sm" data-act="rmOpen">Ouvrir ↗</button><button class="sm" data-act="rmCopyLink">Copier le lien</button></div>`
    : '<div class="alert">🌐 Pas encore publiée : « Publier en ligne » crée une page consultable sur téléphone (plans, Maps, appel en 1 clic). L\'envoi à l\'équipe la publie automatiquement.</div>')
    : '<div class="alert">Pour partager un lien en ligne, activez le relais Google dans <a data-act="rmGoSetup">Équipe → Réponses en 1 clic</a>. En attendant : PDF ou résumé à coller dans WhatsApp.</div>'}
  ${groupCardHTML(p, rm)}
  ${calEnabled() && Store.db.settings.calRoadmap === true ? '<div class="alert ok">📅 Cette feuille de route est aussi intégrée aux événements Google Agenda des techniciens (option et validés selon votre réglage) et suit vos modifications.</div>' : ''}
  ${replyActive() && replyState.version && replyState.version < 3 ? '<div class="alert bad">Le script Google est une ancienne version : pour publier la feuille de route, mettez-le à jour (Équipe → Réponses en 1 clic → copier le code, remplacer, Ctrl+S, Gérer les déploiements → Nouvelle version).</div>' : ''}
    ${(() => { const pf = projectFiles(p); if (!pf.length) return ''; const pend = pf.filter(({ f }) => !f.url || f.up !== f.hash).length;
      return `<div class="card" style="margin-bottom:16px"><div class="row" style="justify-content:space-between;margin-bottom:8px"><h3 style="margin:0">💾 Fichiers de configuration (${pf.length})</h3>${replyActive() ? `<button class="sm" data-act="rmFilesUpload">☁ ${pend ? `Mettre en ligne (${pend})` : 'Renvoyer'}</button>` : ''}</div>
        ${pf.map(({ prod, f }) => `<div class="pf-row"><span>📄 <b>${esc(f.name)}</b> <span class="tiny muted">${esc(prod.ref)} · ${fmtBytes(f.size)}</span></span><span class="tiny ${f.url && f.up === f.hash ? '' : 'muted'}">${f.url && f.up === f.hash ? '☁ en ligne' : 'pas encore en ligne'}</span></div>`).join('')}
        <div class="tiny muted" style="margin-top:6px">Fichiers des références utilisées dans ce projet (Catalogue → référence). Ils sont mis en ligne à la publication et apparaissent dans la feuille de route, le résumé WhatsApp et l'agenda des techniciens.</div></div>`; })()}
    <div class="card" style="margin-bottom:16px"><div class="row" style="justify-content:space-between;margin-bottom:8px"><h3 style="margin:0">🕐 Planning horaire</h3><button class="sm ghost" data-act="rmSeed">↻ Planning type</button></div>
      <div class="card flat" style="border-radius:10px"><table><tr><th>Date</th><th>Heure</th><th>Étape</th><th>Note</th><th></th></tr>
      ${sched.map((x) => `<tr><td><input type="date" data-rms="date" data-id="${x.id}" value="${x.date || ''}" style="width:138px"></td><td><input type="time" data-rms="time" data-id="${x.id}" value="${x.time || ''}" style="width:112px"></td>
        <td><input data-rms="label" data-id="${x.id}" value="${esc(x.label)}" style="width:100%;min-width:260px"></td><td><input data-rms="note" data-id="${x.id}" value="${esc(x.note || '')}" placeholder="lieu, consigne…" style="width:100%;min-width:200px"></td>
        <td class="num"><button class="sm ghost danger" data-act="rmDelSched" data-id="${x.id}">✕</button></td></tr>`).join('') || '<tr><td colspan="5" class="muted">Aucune étape.</td></tr>'}</table></div>
      <div class="tiny muted" style="margin:10px 0 6px">Ajouter une étape :</div><div class="row" style="gap:5px">${RM_PRESETS.map((l) => `<button class="sm chip" data-act="rmAddSched" data-v="${esc(l)}">＋ ${esc(l)}</button>`).join('')}<button class="sm chip" data-act="rmAddSched" data-v="">＋ Autre…</button></div></div>
  <div class="grid g2" style="align-items:start">
  <div>
    <div class="card" style="margin-bottom:16px"><h3>📍 Lieu & accès</h3><div class="grid" style="gap:10px">
      ${ta('address', 'Adresse du site', 'ex. 1 place de la Gare, 59000 Lille', 54)}${ta('access', 'Accès, parking, quai de livraison, badges', 'ex. Entrée logistique rue X, quai n°3, badge à retirer au PC sécurité')}</div></div>
    <div class="card"><div class="row" style="justify-content:space-between;margin-bottom:8px"><h3 style="margin:0">📞 Contacts sur site</h3><button class="sm" data-act="rmAddContact">＋ Contact</button></div>
      ${rm.contacts.length ? `<table>${rm.contacts.map((c, i) => `<tr><td><input data-rmc="name" data-i="${i}" value="${esc(c.name || '')}" placeholder="Nom" style="width:100%"></td><td><input data-rmc="role" data-i="${i}" value="${esc(c.role || '')}" placeholder="Rôle (régisseur, client…)" style="width:100%"></td><td><input data-rmc="phone" data-i="${i}" value="${esc(c.phone || '')}" placeholder="Téléphone" style="width:130px"></td><td class="num"><button class="sm ghost danger" data-act="rmDelContact" data-i="${i}">✕</button></td></tr>`).join('')}</table>` : '<div class="muted small">Ajoutez le régisseur du site, le contact client, la sécurité…</div>'}</div>
  </div>
  <div>
    <div class="card" style="margin-bottom:16px"><h3>ℹ️ Infos pratiques</h3><div class="grid" style="gap:10px">
      ${ta('lodging', '🏨 Hébergement', 'Hôtel, adresse, réservation au nom de…', 54)}${ta('meals', '🍽️ Repas', 'Catering sur place à 12h30, paniers repas…', 54)}${ta('dress', '👕 Tenue', 'Tenue noire, chaussures de sécurité…', 44)}${ta('safety', '⚠️ Sécurité / EPI', 'Casque obligatoire pendant le levage, harnais…', 54)}${ta('notes', '📝 Notes', 'Toute autre information utile', 54)}</div></div>
    <div class="card" style="margin-bottom:16px"><h3>Contenu repris du projet</h3>
      ${RM_INCLUDE.map(([k, l]) => `<label class="row small" style="gap:8px;margin:6px 0"><input type="checkbox" data-rmi="${k}" ${rm.include[k] ? 'checked' : ''}>${l}</label>`).join('')}
      <div class="tiny muted" style="margin-top:6px">${p.crew.filter((r) => r.status === 'valide').length} validé(s) · ${p.fleet.length} véhicule(s) · ${projectUsage(p).size} référence(s) · ${p.screens.length} écran(s)</div></div>
    <div class="card"><h3>Aperçu du résumé WhatsApp</h3><pre class="msg-preview" style="max-height:420px;overflow:auto">${esc(roadmapText(p))}</pre></div>
  </div></div>`;
}
/* Destinataires : techniciens validés (+ options si cochées) et chauffeurs, avec téléphone */
function roadmapRecipients(p) {
  const rm = ensureRoadmap(p); const ids = [];
  p.crew.filter((r) => r.status === 'valide' || (rm.include.options && r.status === 'option')).forEach((r) => { if (!ids.includes(r.techId)) ids.push(r.techId); });
  p.fleet.forEach((f) => { if (f.driverId && !ids.includes(f.driverId)) ids.push(f.driverId); });
  return ids.filter((id) => { const t = getTech(id); return t && normPhone(t.phone); });
}
function fdrVars(p, techId) {
  const t = getTech(techId) || {}; const r = p.crew.find((x) => x.techId === techId && x.status === 'valide') || p.crew.find((x) => x.techId === techId);
  const base = r ? reqVars(r, p) : { prenom: t.firstName, nom: t.lastName, societe: Store.db.settings.company, projet: p.name, client: p.client, lieu: p.venue, dates: fmtDays(projectDays(p)), role: 'Chauffeur' };
  return Object.assign({}, base, { lienfdr: rmLink(p), lien: '' });
}

/* ---------- Groupe WhatsApp de l'équipe ---------- */
const GROUP_RE = /^\s*https:\/\/chat\.whatsapp\.com\/[A-Za-z0-9]{10,}\s*$/;
function groupCardHTML(p, rm) {
  const team = roadmapRecipients(p); const inv = rm.groupInvited || {}; const ok = GROUP_RE.test(rm.groupLink || '');
  const todo = team.filter((id) => !inv[id]);
  return `<div class="card" style="margin-bottom:16px"><div class="row" style="justify-content:space-between;flex-wrap:wrap;gap:8px"><h3 style="margin:0">👥 Groupe WhatsApp de l'équipe</h3>
    ${ok ? `<div class="row" style="gap:6px"><button data-act="rmGroup">💬 Poster la feuille de route dans le groupe</button><button class="primary" data-act="rmGroupInvite" ${todo.length ? '' : 'disabled'}>📲 Inviter ${todo.length ? todo.length + ' personne(s)' : 'l\'équipe'}</button></div>` : ''}</div>
    <div class="row" style="gap:8px;margin-top:10px;align-items:flex-end;flex-wrap:wrap"><label class="f" style="flex:1;min-width:280px">Lien d'invitation du groupe<input data-rm="groupLink" value="${esc(rm.groupLink || '')}" placeholder="https://chat.whatsapp.com/…"></label>
      ${rm.groupLink && !ok ? '<span class="tiny warn-t">Le lien doit commencer par https://chat.whatsapp.com/</span>' : ''}</div>
    ${ok ? `<div class="gr-list">${team.map((id) => { const t = getTech(id); return `<span class="gr-chip ${inv[id] ? 'on' : ''}">${inv[id] ? '✔' : '○'} ${esc(techName(t))}${inv[id] ? ` <span class="tiny muted">${new Date(inv[id]).toLocaleDateString('fr-FR', { day: '2-digit', month: 'short' })}</span>` : ''}</span>`; }).join('') || '<span class="tiny muted">Aucun technicien validé ni chauffeur pour l\'instant.</span>'}</div>
      ${team.length && todo.length && Object.keys(inv).length ? `<div class="tiny warn-t" style="margin-top:6px">${todo.length} personne(s) bookée(s) depuis : pensez à les inviter.</div>` : ''}
      ${Object.keys(inv).length ? '<div class="tiny muted" style="margin-top:6px"><a data-act="rmGroupInviteAll">Renvoyer l\'invitation à tout le monde</a></div>' : ''}`
    : `<ol class="small" style="line-height:1.7;margin:10px 0 0 18px"><li>Dans WhatsApp : <b>Nouveau groupe</b> (nommez-le « ${esc(p.name)} »), ajoutez au moins une personne puis créez-le.</li><li>Infos du groupe → <b>Inviter via un lien</b> → <b>Copier le lien</b>, et collez-le ci-dessus.</li><li>« Inviter » envoie le lien à chaque technicien validé et chauffeur ; « Poster la feuille de route » ouvre directement le groupe avec le résumé copié.</li></ol>`}
  </div>`;
}
const roadmapActions = {
  rmGroupInvite() { const p = curProject(); const rm = ensureRoadmap(p); const inv = rm.groupInvited || {}; const ids = roadmapRecipients(p).filter((id) => !inv[id]); if (!ids.length) return toast('Tout le monde a déjà reçu l\'invitation'); startQueue(p.id, ids.map((techId) => ({ type: 'grp', techId }))); },
  rmGroupInviteAll() { const p = curProject(); startQueue(p.id, roadmapRecipients(p).map((techId) => ({ type: 'grp', techId }))); },
  openRoadmap() { go('roadmap', { projectId: ui.projectId }); },
  rmGoSetup() { go('team', { teamTab: 'reponses' }); },
  rmAddSched(el) {
    const p = curProject(); const rm = ensureRoadmap(p); const last = [...rm.schedule].sort((a, b) => (a.date || '').localeCompare(b.date || '') || (a.time || '').localeCompare(b.time || '')).pop();
    rm.schedule.push({ id: uid('sch'), date: last ? last.date : p.start || '', time: '', label: el.dataset.v || '', note: '' }); Store.save(); render();
  },
  rmDelSched(el) { const rm = ensureRoadmap(curProject()); rm.schedule = rm.schedule.filter((x) => x.id !== el.dataset.id); Store.save(); render(); },
  rmSeed() { const p = curProject(); const rm = ensureRoadmap(p); if (rm.schedule.length && !confirm('Remplacer le planning par un planning type ?')) return; rm.schedule = seedSchedule(p); Store.save(); render(); },
  rmAddContact() { const rm = ensureRoadmap(curProject()); rm.contacts.push({ name: '', role: '', phone: '' }); Store.save(); render(); },
  rmDelContact(el) { const rm = ensureRoadmap(curProject()); rm.contacts.splice(+el.dataset.i, 1); Store.save(); render(); },
  rmPdf() {
    const p = curProject(); const html = roadmapPdfHTML(p); const name = `${safeName(p.name)}_feuille-de-route.pdf`;
    if (NATIVE_FILES) { toast('Génération du PDF…'); window.desktop.makePdf({ html, defaultName: name, landscape: false }).then((r) => r && toast('PDF prêt ✔')); }
    else { const w = window.open('', '_blank', 'width=1000,height=900'); if (!w) return toast('Autorisez les fenêtres pop-up pour exporter', 'warn'); w.document.write(html); w.document.close(); toast('Choisissez « Enregistrer au format PDF » dans la fenêtre d\'impression'); setTimeout(() => w.print(), 700); }
  },
  rmCopy() { copyText(roadmapText(curProject()), true); toast('Résumé copié 📋 — collez-le dans WhatsApp (Ctrl+V)'); },
  async rmGroup() {
    const p = curProject();
    if (replyActive()) { try { toast('Mise à jour de la version en ligne…'); await publishRoadmap(p); } catch (e) { toast('⚠ ' + e.message, 'warn'); } }
    await copyText(roadmapText(p), true);
    const gl = ensureRoadmap(p).groupLink; if (GROUP_RE.test(gl || '')) { openExternal(gl.trim()); toast('Feuille de route copiée 📋 — le groupe s\'ouvre : Ctrl+V puis Entrée'); ensureRoadmap(p).groupPostedAt = new Date().toISOString(); Store.save(); render(); return; }
    let url = 'whatsapp://send'; const mode = Store.db.settings.waMode;
    if (mode === 'web') url = 'https://web.whatsapp.com/';
    else if (mode !== 'app' && window.desktop && window.desktop.hasWhatsApp) { try { if (!(await window.desktop.hasWhatsApp())) url = 'https://web.whatsapp.com/'; } catch (e) { /* */ } }
    openExternal(url); toast('Résumé copié 📋 — ouvrez le groupe de l\'équipe puis Ctrl+V et Entrée');
    render();
  },
  async rmPublish() {
    const p = curProject(); toast('Publication…');
    try { await publishRoadmap(p); toast('Feuille de route en ligne ✔'); confetti(); } catch (e) { toast('Publication impossible : ' + e.message, 'bad'); }
    render();
  },
  rmOpen() { const l = rmLink(curProject()); if (l) window.open(l, '_blank'); },
  rmCopyLink() { const l = rmLink(curProject()); if (l) { copyText(l, true); toast('Lien copié 📋'); } },
  async rmSend() {
    const p = curProject(); const ids = roadmapRecipients(p); if (!ids.length) return toast('Aucun destinataire avec téléphone', 'warn');
    if (replyActive()) { try { toast('Mise à jour de la version en ligne…'); await publishRoadmap(p); } catch (e) { toast('⚠ Version en ligne non mise à jour (' + e.message + ') — le résumé sera envoyé à la place', 'warn'); } }
    startQueue(p.id, ids.map((techId) => ({ type: 'fdr', techId })));
  }
};
function roadmapChange(t) {
  const p = curProject(); if (!p || ui.view !== 'roadmap') return false; const rm = ensureRoadmap(p);
  const preview = () => { const el = document.querySelector('.msg-preview'); if (el) el.textContent = roadmapText(p); };
  if (t.dataset.rm) { rm[t.dataset.rm] = t.value; Store.save(); preview(); if (t.dataset.rm === 'groupLink') render(); return true; }
  if (t.dataset.rms) { const x = rm.schedule.find((y) => y.id === t.dataset.id); if (x) { x[t.dataset.rms] = t.value; Store.save(); if (t.dataset.rms === 'date' || t.dataset.rms === 'time') { const y = $main().scrollTop; render(); $main().scrollTop = y; } else preview(); } return true; }
  if (t.dataset.rmc) { const c = rm.contacts[+t.dataset.i]; if (c) { c[t.dataset.rmc] = t.value; Store.save(); preview(); } return true; }
  if (t.dataset.rmi) { rm.include[t.dataset.rmi] = t.checked; Store.save(); render(); return true; }
  return false;
}
