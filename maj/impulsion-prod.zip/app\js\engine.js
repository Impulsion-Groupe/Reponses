/* =====================================================================
   ENGINE — calculs : chemins de câblage, répartition, géométrie, stock
   ===================================================================== */
const getProduct = (id) => Store.db.products.find((p) => p.id === id) || (id && String(id).startsWith('cust') && typeof findCustomProduct === 'function' ? findCustomProduct(id) : undefined);
const getProject = (id) => Store.db.projects.find((p) => p.id === id);

/* ---------- Chemin global (ordre de parcours des dalles) ----------
   orient 'h' : on parcourt rangée par rangée ; 'v' : colonne par colonne
   pattern 'snake' : aller-retour (serpentin) ; 'raster' : toujours dans le même sens (retour au début)
   start : coin de départ TL / TR / BL / BR (vue de face) */
function pathOrder(cols, rows, orient, pattern, start) {
  const top = start[0] === 'T', left = start[1] === 'L';
  const out = [];
  if (orient === 'h') {
    for (let k = 0; k < rows; k++) {
      const r = top ? k : rows - 1 - k;
      let ltr = left; if (pattern === 'snake' && k % 2 === 1) ltr = !ltr;
      for (let j = 0; j < cols; j++) { const c = ltr ? j : cols - 1 - j; out.push(r * cols + c); }
    }
  } else {
    for (let k = 0; k < cols; k++) {
      const c = left ? k : cols - 1 - k;
      let ttb = top; if (pattern === 'snake' && k % 2 === 1) ttb = !ttb;
      for (let j = 0; j < rows; j++) { const r = ttb ? j : rows - 1 - j; out.push(r * cols + c); }
    }
  }
  return out;
}

/* ---------- Capacités ---------- */
function elecCapacity(screen) {
  const p = getProduct(screen.productId) || {};
  const e = screen.elec;
  const watt = num(e.basis === 'avg' ? p.powerAvg : p.powerMax) || num(p.powerMax) || 1;
  const usable = num(e.voltage) * num(e.amps) * num(e.safety) / 100;
  let cap = Math.floor(usable / watt);
  const limits = [];
  if (num(p.maxChain) > 0) limits.push(num(p.maxChain));
  if (num(e.maxPerLine) > 0) limits.push(num(e.maxPerLine));
  limits.forEach((l) => { cap = Math.min(cap, l); });
  return { cap: Math.max(1, cap), watt, usable, byPower: Math.floor(usable / watt) };
}
function dataCapacity(screen) {
  const p = getProduct(screen.productId) || {};
  const d = screen.data;
  const proc = getProduct(d.processorId);
  const pxPort = num(proc && proc.pxPerPort) || num(d.pxPerPort) || 655360;
  const px = (num(p.pxW) || 1) * (num(p.pxH) || 1);
  let cap = Math.floor(pxPort / px);
  if (num(d.maxPerPort) > 0) cap = Math.min(cap, num(d.maxPerPort));
  return { cap: Math.max(1, cap), pxPort, px };
}

/* ---------- Répartition automatique ----------
   strategy 'whole'    : lignes alignées sur des colonnes/rangées entières (pratique à câbler)
            'balanced' : charge équilibrée entre lignes le long du chemin
            'fill'     : chaque ligne remplie au maximum */
function autoAssign(screen, cfg, cap) {
  const { cols, rows } = screen; const N = cols * rows;
  const order = pathOrder(cols, rows, cfg.orient, cfg.pattern, cfg.start);
  const assign = new Array(N).fill(-1);
  if (cfg.strategy === 'fill') {
    order.forEach((idx, i) => { assign[idx] = Math.floor(i / cap); });
  } else if (cfg.strategy === 'balanced') {
    const L = Math.ceil(N / cap);
    const base = Math.floor(N / L), extra = N % L; let i = 0;
    for (let l = 0; l < L; l++) { const n = base + (l < extra ? 1 : 0); for (let k = 0; k < n; k++) assign[order[i++]] = l; }
  } else { // whole
    const lineLen = cfg.orient === 'h' ? cols : rows; const nLines = cfg.orient === 'h' ? rows : cols;
    let line = 0; let i = 0;
    if (lineLen <= cap) {
      const k = Math.max(1, Math.floor(cap / lineLen));
      const G = Math.ceil(nLines / k); const base = Math.floor(nLines / G), extra = nLines % G;
      for (let g = 0; g < G; g++) { const nl = base + (g < extra ? 1 : 0); for (let q = 0; q < nl * lineLen; q++) assign[order[i++]] = line; line++; }
    } else {
      const s = Math.ceil(lineLen / cap); const base = Math.floor(lineLen / s), extra = lineLen % s;
      for (let L = 0; L < nLines; L++) for (let g = 0; g < s; g++) { const n = base + (g < extra ? 1 : 0); for (let q = 0; q < n; q++) assign[order[i++]] = line; line++; }
    }
  }
  return assign;
}

/* Résout un plan (élec ou data) : assignation + ordre de câblage de chaque ligne */
/* ---------- Boarding (panneaux bord terrain) : zones indépendantes sur une ligne ---------- */
const isBoard = (s) => !!s && s.type === 'boarding';
function zoneStarts(s) { const out = []; let a = 0; (s.zones || []).forEach((z) => { out.push(a); a += Math.max(1, num(z.count) | 0); }); return out; }
const zRows = (s, z) => Math.max(1, Math.round(num(z && z.rows)) || Math.max(1, num(s.rows) | 0));
const zOff = (s, z) => Math.max(0, s.rows - zRows(s, z)); // zones moins hautes : alignées en bas (posées au sol)
function panelExists(s, i) { if (!isBoard(s)) return true; const r = Math.floor(i / s.cols), c = i % s.cols; return r >= zOff(s, s.zones[zoneOfCol(s, c)]); }
function panelCount(s) { return isBoard(s) ? s.zones.reduce((a, z) => a + Math.max(1, num(z.count) | 0) * zRows(s, z), 0) : s.cols * s.rows; }
function zoneOfCol(s, c) { const st = zoneStarts(s); let z = 0; st.forEach((a, i) => { if (c >= a) z = i; }); return z; }
/* Parcours : chaque zone est parcourue séparément, l'une après l'autre */
/* Liaisons choisies à la main : cfg.groups = [[zoneId, zoneId…], …] (chaque groupe = une chaîne sur un même port) */
function linkGroups(s, cfg) {
  if (!Array.isArray(cfg.groups)) return null; const ids = new Set(s.zones.map((z) => z.id)); const seen = new Set();
  return cfg.groups.map((g) => (g || []).filter((id) => ids.has(id) && !seen.has(id) && seen.add(id))).filter((g) => g.length);
}
function zonePathIdx(s, zi, cfg) {
  const z = s.zones[zi]; const n = Math.max(1, num(z.count) | 0); const zr = zRows(s, z), off = zOff(s, z); const st = zoneStarts(s)[zi];
  return pathOrder(n, zr, cfg.orient, cfg.pattern, cfg.start).map((li) => (Math.floor(li / n) + off) * s.cols + st + (li % n));
}
function boardPath(s, cfg) {
  const out = []; const st = zoneStarts(s); const G = linkGroups(s, cfg);
  if (G) { const order = [...G.flat(), ...s.zones.map((z) => z.id).filter((id) => !G.flat().includes(id))]; order.forEach((id) => out.push(...zonePathIdx(s, s.zones.findIndex((z) => z.id === id), cfg))); return out; }
  s.zones.forEach((z, zi) => {
    const n = Math.max(1, num(z.count) | 0);
    const zr = zRows(s, z), off = zOff(s, z);
    pathOrder(n, zr, cfg.orient, cfg.pattern, cfg.start).forEach((li) => { const r = Math.floor(li / n), c = li % n; out.push((r + off) * s.cols + st[zi] + c); });
  });
  return out;
}
/* Répartition automatique zone par zone : une ligne ne traverse jamais deux zones */
function boardAutoAssign(s, cfg, cap) {
  const N = s.cols * s.rows; const assign = new Array(N).fill(-1); const st = zoneStarts(s); let base = 0;
  const G = linkGroups(s, cfg);
  if (G) { // chaînes choisies : les blocs d'une chaîne se suivent sur le même port (nouveau port si la capacité est atteinte)
    let line = -1; const inG = new Set(G.flat());
    G.forEach((g) => {
      line++; let used = 0;
      g.forEach((id) => {
        const idx = zonePathIdx(s, s.zones.findIndex((z) => z.id === id), cfg);
        if (used > 0 && used + idx.length > cap && idx.length <= cap) { line++; used = 0; } // bloc entier sur le port suivant plutôt que coupé
        idx.forEach((i) => { if (used >= cap) { line++; used = 0; } assign[i] = line; used++; });
      });
    });
    base = line + 1;
    s.zones.forEach((z, zi) => {
      if (inG.has(z.id)) return; const n = Math.max(1, num(z.count) | 0); const zr = zRows(s, z), off = zOff(s, z);
      const sc = Object.assign({}, cfg, { strategy: cfg.strategy === 'whole' && zr === 1 ? 'balanced' : cfg.strategy });
      const a = autoAssign({ cols: n, rows: zr }, sc, cap); a.forEach((l, li) => { assign[(Math.floor(li / n) + off) * s.cols + st[zi] + (li % n)] = base + l; }); base += Math.max(0, ...a) + 1;
    });
    return assign;
  }
  if (cfg.joinZones) { // zones entières regroupées sur un même départ tant que la capacité le permet
    let line = -1, used = Infinity;
    s.zones.forEach((z, zi) => {
      const n = Math.max(1, num(z.count) | 0); const zr = zRows(s, z), off = zOff(s, z); const P = n * zr;
      const idxs = []; for (let r = 0; r < zr; r++) for (let c = 0; c < n; c++) idxs.push((r + off) * s.cols + st[zi] + c);
      if (P <= cap) { if (line < 0 || used + P > cap) { line++; used = 0; } idxs.forEach((i) => { assign[i] = line; }); used += P; return; }
      const sub = { cols: n, rows: zr }; const sc = Object.assign({}, cfg, { strategy: cfg.strategy === 'whole' && zr === 1 ? 'balanced' : cfg.strategy });
      const a = autoAssign(sub, sc, cap); const first = line + 1; const mx = Math.max(0, ...a);
      a.forEach((l, li) => { const r = Math.floor(li / n), c = li % n; assign[(r + off) * s.cols + st[zi] + c] = first + l; });
      line = first + mx; used = a.filter((l) => l === mx).length;
    });
    return assign;
  }
  s.zones.forEach((z, zi) => {
    const n = Math.max(1, num(z.count) | 0); const zr = zRows(s, z), off = zOff(s, z);
    const sub = { cols: n, rows: zr };
    const sc = Object.assign({}, cfg, { strategy: cfg.strategy === 'whole' && zr === 1 ? 'balanced' : cfg.strategy });
    const a = autoAssign(sub, sc, cap);
    a.forEach((l, li) => { const r = Math.floor(li / n), c = li % n; assign[(r + off) * s.cols + st[zi] + c] = base + l; });
    base += Math.max(0, ...a) + 1;
  });
  return assign;
}
function panelLabel(s, i) {
  const r = Math.floor(i / s.cols), c = i % s.cols;
  if (!isBoard(s)) return `${c + 1}·${r + 1}`;
  const zi = zoneOfCol(s, c); const z = s.zones[zi]; return `Z${zi + 1}-${c - zoneStarts(s)[zi] + 1}${zRows(s, z) > 1 ? '·' + (r - zOff(s, z) + 1) : ''}`;
}

function resolvePlan(screen, kind) {
  const cfg = screen[kind];
  const capInfo = kind === 'elec' ? elecCapacity(screen) : dataCapacity(screen);
  const N = screen.cols * screen.rows;
  let assign = cfg.assign;
  let manual = true;
  if (!Array.isArray(assign) || assign.length !== N) { assign = isBoard(screen) ? boardAutoAssign(screen, cfg, capInfo.cap) : autoAssign(screen, cfg, capInfo.cap); manual = false; }
  const order = isBoard(screen) ? boardPath(screen, cfg) : pathOrder(screen.cols, screen.rows, cfg.orient, cfg.pattern, cfg.start);
  const rank = new Array(N); order.forEach((idx, i) => { rank[idx] = i; });
  const nLines = Math.max(0, ...assign) + 1;
  const lines = [];
  for (let l = 0; l < nLines; l++) {
    const members = []; assign.forEach((a, i) => { if (a === l) members.push(i); });
    let seq = members.sort((a, b) => rank[a] - rank[b]);
    const mo = cfg.orders && cfg.orders[l];
    if (Array.isArray(mo) && mo.length) {
      const set = new Set(members); const fixed = mo.filter((i) => set.has(i)); const fs = new Set(fixed);
      seq = fixed.concat(seq.filter((i) => !fs.has(i)));
    }
    const zs = isBoard(screen) ? [...new Set(seq.map((i) => zoneOfCol(screen, i % screen.cols)))] : [];
    lines.push({ index: l, panels: seq, over: seq.length > capInfo.cap, manualOrder: !!(mo && mo.length), zones: zs, cross: zs.length > 1 });
  }
  const unassigned = assign.reduce((n, a, i) => n + (a < 0 && panelExists(screen, i) ? 1 : 0), 0);
  return { assign, lines, cap: capInfo, manual, unassigned };
}

function elecSummary(screen, plan) {
  const e = screen.elec; const w = plan.cap.watt; const V = num(e.voltage) || 230;
  const phases = num(e.phases) === 1 ? 1 : 3;
  const phaseW = new Array(phases).fill(0);
  const rows = plan.lines.filter((l) => l.panels.length).map((l, i) => {
    const W = l.panels.length * w; const ph = i % phases; phaseW[ph] += W;
    return { name: 'C' + (l.index + 1), line: l, n: l.panels.length, W, A: W / V, pct: (W / V) / num(e.amps) * 100, phase: 'L' + (ph + 1) };
  });
  const totalW = rows.reduce((s, r) => s + r.W, 0);
  const phaseA = phaseW.map((x) => x / V);
  const maxA = Math.max(0, ...phaseA);
  const std = [16, 32, 63, 125, 250, 400]; const feed = std.find((x) => x >= maxA * 1.0) || '> 400';
  return { rows, totalW, phaseW, phaseA, feed, phases, V };
}
function dataSummary(screen, plan) {
  const px = plan.cap.px;
  const rows = plan.lines.filter((l) => l.panels.length).map((l) => ({ name: 'P' + (l.index + 1), line: l, n: l.panels.length, px: l.panels.length * px, pct: l.panels.length * px / plan.cap.pxPort * 100 }));
  const proc = getProduct(screen.data.processorId);
  const ports = rows.length;
  const procs = proc && num(proc.ports) > 0 ? Math.ceil(ports / num(proc.ports)) : 0;
  return { rows, ports, proc, procs, totalPx: panelCount(screen) * px };
}

/* ---------- Géométrie & courbure ----------
   Angle à chaque jonction : + = concave (les bords viennent vers le public), − = convexe. */
function curveProfile(n, len, angles) {
  const pts = [[0, 0]]; let dir = 0;
  for (let i = 0; i < n; i++) {
    const [x, y] = pts[i]; pts.push([x + len * Math.cos(dir), y + len * Math.sin(dir)]);
    if (i < n - 1) dir += (num(angles[i]) * Math.PI) / 180;
  }
  // aligne la corde sur l'axe X, centrée
  const [x0, y0] = pts[0], [x1, y1] = pts[n];
  const a = Math.atan2(y1 - y0, x1 - x0); const ca = Math.cos(-a), sa = Math.sin(-a);
  let p = pts.map(([x, y]) => [(x - x0) * ca - (y - y0) * sa, (x - x0) * sa + (y - y0) * ca]);
  const xs = p.map((q) => q[0]), ys = p.map((q) => q[1]);
  const minX = Math.min(...xs), maxX = Math.max(...xs), minY = Math.min(...ys), maxY = Math.max(...ys);
  const cx = (p[0][0] + p[n][0]) / 2;
  p = p.map(([x, y]) => [x - cx, y]);
  const total = angles.slice(0, n - 1).reduce((s, v) => s + num(v), 0);
  const chord = Math.hypot(x1 - x0, y1 - y0);
  const nonZero = angles.slice(0, n - 1).map(num).filter((v) => v !== 0);
  const uniform = n > 1 && nonZero.length === n - 1 && nonZero.every((v) => v === nonZero[0]);
  let R = Infinity;
  if (uniform) R = len / (2 * Math.sin(Math.abs(nonZero[0]) * Math.PI / 360));
  else if (nonZero.length) R = circumR(pts[0], pts[Math.floor(n / 2)], pts[n]);
  const arc = n > 1 ? total + (num(angles[0]) + num(angles[n - 2])) / 2 : 0;
  return { pts: p, arc, extent: maxX - minX, sag: maxY - minY, total, chord, R, uniform, developed: n * len, closed: Math.abs(total) >= 360 - 1e-6, flat: nonZero.length === 0, corner: nonZero.some((v) => Math.abs(v) >= 45) };
}
function circumR(a, b, c) {
  const A = Math.hypot(b[0] - c[0], b[1] - c[1]), B = Math.hypot(a[0] - c[0], a[1] - c[1]), C = Math.hypot(a[0] - b[0], a[1] - b[1]);
  const area = Math.abs((b[0] - a[0]) * (c[1] - a[1]) - (c[0] - a[0]) * (b[1] - a[1])) / 2;
  return area < 1e-9 ? Infinity : (A * B * C) / (4 * area);
}
function screenGeometry0(screen) {
  const p = getProduct(screen.productId) || {};
  const w = num(p.widthMm) || 500, h = num(p.heightMm) || 500, d = num(p.depthMm) || 0;
  const H = curveProfile(screen.cols, w, screen.hAngles);
  const V = curveProfile(screen.rows, h, screen.vAngles);
  const n = panelCount(screen);
  return {
    w, h, d, H, V, panels: n,
    width: H.extent, height: V.extent, depth: H.sag + V.sag + d,
    surface: (n * w * h) / 1e6,
    resW: screen.cols * num(p.pxW), resH: screen.rows * num(p.pxH),
    weight: n * num(p.weightKg), pMax: n * num(p.powerMax), pAvg: n * num(p.powerAvg)
  };
}function screenGeometry(screen) {
  const g = screenGeometry0(screen);
  if (typeof isArch === 'function' && isArch(screen)) { const I = archInfo(screen); g.width = I.W; g.height = I.H; g.depth = g.d || num((getProduct(screen.productId) || {}).depthMm) || 80; g.arch = I; }
  return g;
}


/* ---------- Matériel & stock ---------- */
function projectUsage(project) {
  const m = new Map();
  const add = (id, q, auto) => { if (!id || !q) return; const cur = m.get(id) || { qty: 0, auto: 0, manual: 0 }; cur.qty += q; cur[auto ? 'auto' : 'manual'] += q; m.set(id, cur); };
  project.screens.forEach((s) => {
    add(s.productId, panelCount(s), true);
    if (s.data.processorId) { const ds = dataSummary(s, resolvePlan(s, 'data')); add(s.data.processorId, ds.procs, true); }
  });
  project.extras.forEach((x) => add(x.productId, num(x.qty), false));
  return m;
}
const counts = (p) => !p.sale && p.status !== 'annule' && p.status !== 'termine' && (p.status !== 'devis' || Store.db.settings.reserveDevis);
const overlaps = (aS, aE, bS, bE) => aS && bS && aS <= (bE || bS) && bS <= (aE || aS);
// Pic d'utilisation d'un produit sur une période (en excluant éventuellement un projet)
function peakUsage(productId, start, end, excludeId) {
  const active = Store.db.projects.filter((p) => p.id !== excludeId && counts(p) && overlaps(start, end, p.start, p.end));
  if (!active.length) return { peak: 0, projects: [] };
  const usages = active.map((p) => ({ p, q: (projectUsage(p).get(productId) || { qty: 0 }).qty })).filter((x) => x.q > 0);
  const times = [start, ...usages.map((u) => u.p.start).filter((t) => t >= start && t <= end)];
  let peak = 0;
  times.forEach((t) => { const s = usages.filter((u) => u.p.start <= t && (u.p.end || u.p.start) >= t).reduce((a, u) => a + u.q, 0); peak = Math.max(peak, s); });
  return { peak, projects: usages };
}
function projectShortages(project) {
  const out = [];
  if (!project.start || project.sale) return out;
  projectUsage(project).forEach((u, pid) => {
    const prod = getProduct(pid); if (!prod || prod.custom) return;
    const others = peakUsage(pid, project.start, project.end || project.start, project.id);
    const free = num(prod.stock) - others.peak;
    if (u.qty > free) out.push({ prod, need: u.qty, free, missing: u.qty - Math.max(0, free), others: others.projects });
  });
  return out;
}

/* ---------- Infos câbles (estimation) ---------- */
function cableEstimate(screen) {
  const pe = resolvePlan(screen, 'elec'), pd = resolvePlan(screen, 'data');
  const n = panelCount(screen);
  const lE = pe.lines.filter((l) => l.panels.length).length, lD = pd.lines.filter((l) => l.panels.length).length;
  return { powerIn: lE, powerJumpers: n - lE, dataIn: lD, dataJumpers: n - lD };
}
