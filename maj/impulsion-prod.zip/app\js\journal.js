/* =====================================================================
   HISTORIQUE — qui a fait quoi (signé avec le compte connecté)
   db.log = [{ id, at, by, byName, kind: add|mod|del|info, type, ref, label, parts: [] }]   (plus récent en premier)
   ===================================================================== */
const JOURNAL_TYPES = {
  projects: { t: 'project', ic: '✦', one: 'le projet', label: (x) => x.name },
  products: { t: 'product', ic: '▦', one: 'la référence', label: (x) => [x.ref, x.name].filter(Boolean).join(' — ') },
  techs: { t: 'tech', ic: '☺', one: 'le technicien', label: (x) => [x.firstName, x.lastName].filter(Boolean).join(' ') },
  vehicles: { t: 'vehicle', ic: '⛟', one: 'le véhicule', label: (x) => [x.name, x.plate].filter(Boolean).join(' · ') },
  users: { t: 'user', ic: '👤', one: 'le compte', label: (x) => x.name }
};
const PART_NAMES = {
  name: 'nom', client: 'client', venue: 'lieu', start: 'dates', end: 'dates', out: 'dates', back: 'dates', status: 'statut', notes: 'notes', cat: 'catégorie',
  screens: 'écrans', crew: 'équipe', fleet: 'transport', extras: 'matériel', roadmap: 'feuille de route', scene: 'scène 3D', boards: 'boarding',
  stock: 'stock', pwd: 'mot de passe', color: 'couleur', title: 'fonction', phone: 'téléphone', email: 'email', skills: 'compétences'
};
/* Champs techniques (automatismes) : jamais comptés comme une modification */
const JOURNAL_IGNORE = new Set(['_mod', 'cal', 'calError', 'regHash', 'token', 'pubHash', 'pubError', 'updatedAt', 'espace', 'indispo']);
const journal = { snap: null, timer: null, muted: 0 };

function cleanForDiff(o) {
  if (Array.isArray(o)) return o.map(cleanForDiff);
  if (o && typeof o === 'object') { const r = {}; Object.keys(o).sort().forEach((k) => { if (!JOURNAL_IGNORE.has(k)) r[k] = cleanForDiff(o[k]); }); return r; }
  return o;
}
function journalTake() {
  const db = Store.db; const s = { settings: JSON.stringify(cleanForDiff(Object.assign({}, db.settings, { waMode: 0, replySince: 0, lastHours: 0, lastReqKind: 0 }))) };
  Object.keys(JOURNAL_TYPES).forEach((k) => { s[k] = new Map((db[k] || []).map((x) => [x.id, { json: JSON.stringify(cleanForDiff(x)), x }])); });
  return s;
}
/* Repart de l'état actuel sans rien enregistrer (données reçues d'un autre poste, automatismes…) */
function journalResync() { clearTimeout(journal.timer); journal.snap = journalTake(); }
function journalSchedule() { if (!journal.snap) return journalResync(); clearTimeout(journal.timer); journal.timer = setTimeout(journalFlush, 1500); }

function journalAdd(e) {
  const log = (Store.db.log = Store.db.log || []); const u = curUser();
  const entry = Object.assign({ id: uid('log'), at: new Date().toISOString(), by: u ? u.id : '', byName: u ? u.name : '' }, e);
  // regroupe les modifications successives du même élément par la même personne (15 min)
  const last = log[0];
  if (entry.kind === 'mod' && last && last.kind === 'mod' && last.by === entry.by && last.ref === entry.ref && last.type === entry.type && Date.now() - Date.parse(last.at) < 15 * 60000) {
    last.parts = [...new Set([...(last.parts || []), ...(entry.parts || [])])]; last.at = entry.at; last.label = entry.label; return last;
  }
  log.unshift(entry); if (log.length > 1500) log.length = 1500; return entry;
}
function journalFlush() {
  clearTimeout(journal.timer); if (!journal.snap || !Store.db) return;
  const before = journal.snap; const now = journalTake(); const u = curUser(); const stamp = { by: u ? u.id : '', byName: u ? u.name : '', at: new Date().toISOString() };
  let n = 0;
  Object.entries(JOURNAL_TYPES).forEach(([k, T]) => {
    const a = before[k] || new Map(); const b = now[k];
    b.forEach((v, id) => {
      const old = a.get(id);
      if (!old) { journalAdd({ kind: 'add', type: T.t, ref: id, label: T.label(v.x) || '—' }); v.x._mod = stamp; n++; return; }
      if (old.json === v.json) return;
      const o = JSON.parse(old.json); const c = JSON.parse(v.json);
      const parts = [...new Set(Object.keys(Object.assign({}, o, c)).filter((kk) => JSON.stringify(o[kk]) !== JSON.stringify(c[kk])).map((kk) => PART_NAMES[kk] || null).filter(Boolean))];
      journalAdd({ kind: 'mod', type: T.t, ref: id, label: T.label(v.x) || '—', parts }); v.x._mod = stamp; n++;
    });
    a.forEach((v, id) => { if (!b.has(id)) { const lb = T.label(v.x) || '—'; journalAdd({ kind: 'del', type: T.t, ref: id, label: lb }); tombAdd(id, { type: k, label: lb, by: stamp.by, byName: stamp.byName }); trashAdd(k, v.x, 'supprimé sur ce poste'); n++; } });
  });
  if (before.settings !== now.settings) { journalAdd({ kind: 'mod', type: 'settings', ref: 'settings', label: 'Paramètres', parts: [] }); n++; }
  journal.snap = journalTake();
  if (n) Store.saveNow();
}
(function hookJournal() { const save = Store.save.bind(Store); Store.save = function () { save(); if (!journal.muted) journalSchedule(); }; })();

/* ---------- Affichage ---------- */
const KIND_TXT = { add: 'a créé', mod: 'a modifié', del: 'a supprimé' };
function logLine(e) {
  const T = Object.values(JOURNAL_TYPES).find((x) => x.t === e.type); const u = getUser(e.by);
  const who = u ? `<b style="color:${u.color}">${esc(u.name)}</b>` : `<b>${esc(e.byName || (e.type === 'reply' ? '' : 'Ce poste'))}</b>`;
  const target = e.type === 'project' && getProject(e.ref) ? `<a data-act="openProject" data-id="${e.ref}">« ${esc(e.label)} »</a>` : `« ${esc(e.label)} »`;
  const time = new Date(e.at).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
  if (e.kind === 'info') return `<div class="log-row"><span class="log-t">${time}</span><span class="log-ic">${e.ic || '•'}</span><span>${e.byName ? who + ' ' : ''}${esc(e.text || '')}${e.ref && e.type === 'project' && getProject(e.ref) ? ` — <a data-act="openProject" data-id="${e.ref}">${esc(getProject(e.ref).name)}</a>` : ''}</span></div>`;
  return `<div class="log-row"><span class="log-t">${time}</span><span class="log-ic">${T ? T.ic : '⚙'}</span><span>${u ? avatar(u, 18) + ' ' : ''}${who} ${KIND_TXT[e.kind] || ''} ${T ? T.one + ' ' + target : 'les paramètres'}${e.parts && e.parts.length ? ` <span class="muted">— ${esc(e.parts.join(', '))}</span>` : ''}</span></div>`;
}
function vJournal() {
  journalFlush();
  const f = ui.logFilter || 'all'; const fu = ui.logUser || 'all';
  const all = (Store.db.log || []).filter((e) => (f === 'all' || e.type === f) && (fu === 'all' || e.by === fu)).slice(0, 400);
  const days = new Map(); all.forEach((e) => { const d = e.at.slice(0, 10); if (!days.has(d)) days.set(d, []); days.get(d).push(e); });
  const dayTitle = (d) => (d === todayISO() ? 'Aujourd\'hui' : d === addDays(todayISO(), -1) ? 'Hier' : new Date(d + 'T12:00').toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long' }));
  const ntr = ((Store.db.local || {}).trash || []).length;
  return `<div class="page-head"><div><h1>Historique</h1><div class="sub">Qui a fait quoi, sur tous les postes</div></div>
    <div class="row"><button data-act="trashOpen">🗑 Corbeille${ntr ? ` (${ntr})` : ''}</button>${IS_DESKTOP && window.desktop.listBackups ? '<button data-act="recoverOpen">♻ Récupérer depuis une sauvegarde</button>' : ''}<button class="primary" data-act="allSheetsOpen" title="Plusieurs fichiers « Impulsion LED – Réponses techniciens » dans votre Drive : tout récupérer et regrouper">🗂 Tout récupérer (toutes les feuilles Google)</button><button data-act="gsOldOpen" title="Reprendre ce qui manque dans une ancienne version des données en ligne">🕘 Récupérer depuis l'historique Google</button><button data-act="rebuildOpen" title="Recrée les projets perdus à partir des demandes déjà envoyées aux techniciens">🧩 Reconstituer depuis les demandes</button><select data-ui-sel="logUser"><option value="all">Tout le monde</option>${users().map((u) => `<option value="${u.id}" ${fu === u.id ? 'selected' : ''}>${esc(u.name)}</option>`).join('')}</select>
    <select data-ui-sel="logFilter">${[['all', 'Tout'], ['project', 'Projets'], ['reply', 'Réponses techniciens'], ['tech', 'Techniciens'], ['product', 'Catalogue'], ['vehicle', 'Véhicules'], ['user', 'Comptes'], ['settings', 'Paramètres']].map(([v, l]) => `<option value="${v}" ${f === v ? 'selected' : ''}>${l}</option>`).join('')}</select></div></div>
  ${all.length ? [...days].map(([d, es]) => `<div class="card log-day"><h3>${dayTitle(d)}</h3>${es.map(logLine).join('')}</div>`).join('') : '<div class="card"><div class="muted">Rien pour l\'instant. Chaque création, modification ou suppression apparaîtra ici avec le nom de la personne.</div></div>'}`;
}
const modTxt = (x) => { if (!x || !x._mod) return ''; const u = getUser(x._mod.by); return `Modifié par ${esc(u ? u.name : x._mod.byName || 'ce poste')} ${agoTxt(x._mod.at)}`; };

/* ---------- Corbeille & récupération ---------- */
const COLL_TXT = { projects: 'Projet', techs: 'Technicien', products: 'Référence', vehicles: 'Véhicule', users: 'Compte' };
function restoreItems(list, how) {
  let n = 0; journalFlush();
  list.forEach(({ coll, item }) => {
    const arr = (Store.db[coll] = Store.db[coll] || []); if (arr.some((x) => x.id === item.id)) return;
    arr.push(deepClone(item)); tombRevive(item.id); n++;
  });
  journalResync();
  list.forEach(({ coll, item }) => journalAdd({ kind: 'info', type: (JOURNAL_TYPES[coll] || {}).t || coll, ref: item.id, ic: '♻', text: `a restauré ${(JOURNAL_TYPES[coll] || {}).one || ''} « ${(JOURNAL_TYPES[coll] && JOURNAL_TYPES[coll].label(item)) || item.name || ''} » (${how})` }));
  Store.save(); return n;
}
const journalRecoverActions = {
  trashOpen() {
    const tr = (Store.db.local && Store.db.local.trash) || [];
    openModal(`<h2>🗑 Corbeille de ce poste</h2><div class="small muted">Tout ce qui a été supprimé ici, ou retiré par la synchronisation (supprimé sur un autre poste), est gardé ici : 80 derniers éléments.</div>
      ${tr.length ? `<table style="margin-top:12px">${tr.map((t, i) => { const here = (Store.db[t.coll] || []).some((x) => x.id === t.item.id);
        return `<tr><td><b>${esc(t.label)}</b><div class="tiny muted">${COLL_TXT[t.coll] || t.coll} · ${new Date(t.at).toLocaleString('fr-FR', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' })} · ${esc(t.why || '')}</div></td>
        <td class="num">${here ? '<span class="tag ok">Présent</span>' : `<button class="sm primary" data-act="trashRestore" data-i="${i}">♻ Restaurer</button>`}</td></tr>`; }).join('')}</table>` : '<div class="card muted" style="margin-top:12px">La corbeille est vide.</div>'}
      <div class="modal-actions"><button data-act="closeModal">Fermer</button></div>`);
  },
  trashRestore(el) {
    const t = Store.db.local.trash[+el.dataset.i]; if (!t) return;
    const n = restoreItems([{ coll: t.coll, item: t.item }], 'corbeille'); Store.db.local.trash.splice(+el.dataset.i, 1);
    journalRecoverActions.trashOpen(); render(); toast(n ? `« ${t.label} » restauré ✔ — il revient aussi sur les autres postes` : 'Déjà présent');
  },
  async recoverOpen() {
    let list = []; try { list = await window.desktop.listBackups(); } catch (e) { return toast('Sauvegardes inaccessibles : ' + e.message, 'bad'); }
    openModal(`<h2>♻ Récupérer depuis une sauvegarde</h2><div class="small muted">Choisissez une sauvegarde : l'application liste les projets, techniciens, références et véhicules qu'elle contient et qui n'existent plus aujourd'hui. Vous cochez ce que vous voulez récupérer, <b>rien d'autre n'est modifié</b>.</div>
      <label class="f" style="margin-top:12px">Sauvegarde<select id="recBk"><option value="*">🔎 Chercher dans TOUTES les sauvegardes (${list.length})</option>${list.map((n) => `<option value="${esc(n)}">${esc(n.replace(/^sauvegarde_|\.json$/g, '').replace(/_/g, ' '))}</option>`).join('')}</select></label>
      <div id="recList" style="margin-top:12px"></div>
      <div class="modal-actions"><button data-act="closeModal">Fermer</button><button data-act="recoverScan">Voir le contenu</button><button class="primary" data-act="recoverGo">♻ Récupérer la sélection</button></div>`);
    if (list.length) journalRecoverActions.recoverScan();
  },
  async recoverScan() {
    const name = document.getElementById('recBk').value; const box = document.getElementById('recList'); box.innerHTML = '<div class="muted">Lecture…</div>';
    try {
      const names = name === '*' ? await window.desktop.listBackups() : [name]; // du plus récent au plus ancien
      const items = []; const seen = new Set(); let k0 = 0;
      for (const nm of names) {
        k0++; if (names.length > 1) box.innerHTML = `<div class="muted">Lecture des sauvegardes… ${k0} / ${names.length}</div>`;
        let db; try { db = JSON.parse(await window.desktop.readBackup(nm)); } catch (e) { continue; }
        Object.keys(COLL_TXT).forEach((k) => (db[k] || []).forEach((x) => { if (seen.has(x.id) || (Store.db[k] || []).some((y) => y.id === x.id)) return; seen.add(x.id); items.push({ coll: k, item: x, from: nm }); }));
      }
      items.sort((a, b) => (a.coll === 'projects' ? 0 : 1) - (b.coll === 'projects' ? 0 : 1));
      ui.recItems = items;
      box.innerHTML = items.length ? `<div class="small"><b>${items.length}</b> élément(s) absent(s) aujourd'hui :</div><table>${items.map((x, i) => `<tr><td><label style="display:flex;gap:8px;align-items:center"><input type="checkbox" data-rec="${i}" ${x.coll === 'projects' ? 'checked' : ''} style="width:auto"><span><b>${esc((JOURNAL_TYPES[x.coll] && JOURNAL_TYPES[x.coll].label(x.item)) || x.item.name || '—')}</b> <span class="tiny muted">${COLL_TXT[x.coll]}${x.item.start ? ' · ' + fmtDate(x.item.start) : ''}${x.from && names.length > 1 ? ' · sauvegarde du ' + esc(x.from.replace(/^sauvegarde_|\.json$/g, '').replace(/_.*$/, '')) : ''}</span></span></label></td></tr>`).join('')}</table>`
        : '<div class="card muted">Rien de manquant dans cette sauvegarde : tout ce qu\'elle contient existe encore.</div>';
    } catch (e) { box.innerHTML = `<div class="alert bad">${esc(e.message)}</div>`; }
  },
  recoverGo() {
    const sel = [...document.querySelectorAll('[data-rec]:checked')].map((c) => ui.recItems[+c.dataset.rec]).filter(Boolean);
    if (!sel.length) return toast('Cochez au moins un élément', 'warn');
    const n = restoreItems(sel, 'sauvegarde'); closeModal(); render(); toast(`${n} élément(s) récupéré(s) ✔ — ils reviennent aussi sur les autres postes`);
  }
};

/* ---------- Reconstituer un projet perdu à partir des demandes envoyées (script v14) ----------
   Chaque demande WhatsApp a été enregistrée en ligne (projet, lieu, poste, jours, horaires) avec son jeton :
   on recrée le projet et son équipe avec LES MÊMES jetons → les liens déjà envoyés continuent de marcher,
   les réponses déjà reçues sont reprises, inutile de redemander aux techniciens. */
async function rebuildScan(sheetId) {
  const ex = sheetId ? { id: sheetId } : {};
  const reg = await withTimeout(remoteGet(Object.assign({ action: 'reglist', key: ensureReplyKey() }, ex)), 30000);
  if (!reg || !reg.rows) throw new Error('Le script Google doit être mis à jour (v14) : Équipe → Réponses en 1 clic → Copier le code, puis Nouvelle version.');
  const rep = await withTimeout(remoteGet(Object.assign({ action: 'list', key: ensureReplyKey(), since: 0 }, ex)), 30000);
  const last = {}; (rep.rows || []).sort((a, b) => a.at - b.at).forEach((r) => { last[r.t] = r; });
  const known = new Set(); Store.db.projects.forEach((p) => (p.crew || []).forEach((r) => { if (r.token) known.add(r.token); }));
  const groups = new Map();
  reg.rows.filter((x) => x.info && x.info.projet && !known.has(x.t)).forEach((x) => {
    const key = x.info.projet.trim().toLowerCase(); if (!groups.has(key)) groups.set(key, { name: x.info.projet.trim(), lieu: x.info.lieu || '', rows: [] });
    groups.get(key).rows.push(x);
  });
  return [...groups.values()].map((g) => {
    const days = [...new Set(g.rows.flatMap((x) => (x.info.days || []).map((d) => d.d)))].sort();
    const crew = g.rows.sort((a, b) => b.at - a.at).map((x) => {
      const cands = Store.db.techs.filter((t) => (t.firstName || '').trim().toLowerCase() === String(x.info.prenom || '').trim().toLowerCase());
      const r = last[x.t]; const st = r && ['valide', 'option', 'indispo', 'attente'].includes(r.status) ? r.status : (r && /non|indispo/i.test(r.status) ? 'indispo' : 'attente');
      return { token: x.t, at: x.at, prenom: x.info.prenom || '?', techId: cands.length === 1 ? cands[0].id : '', cands, role: x.info.role || '', dates: (x.info.days || []).map((d) => d.d).sort(), note: x.info.hoursNote || '', kind: x.info.kind || 'booking', status: st, reply: r || null };
    });
    // une ligne par technicien (la demande la plus récente)
    const seen = new Set(); const uniq = crew.filter((c) => { const k = c.techId || c.prenom; if (seen.has(k)) return false; seen.add(k); return true; });
    return { name: g.name, lieu: g.lieu, start: days[0] || '', end: days[days.length - 1] || '', crew: uniq };
  }).sort((a, b) => (b.start || '').localeCompare(a.start || ''));
}
Object.assign(journalRecoverActions, {
  async rebuildOpen() {
    if (!replyActive()) return toast('Le relais Google n\'est pas configuré sur ce poste', 'warn');
    openModal('<h2>🧩 Reconstituer depuis les demandes</h2><div class="muted">Lecture des demandes envoyées…</div>');
    try { ui.rebuild = await rebuildScan(ui.rebuildSheet || ''); ui.rebuildSheet = ''; } catch (e) { return openModal(`<h2>🧩 Reconstituer depuis les demandes</h2><div class="alert bad">${esc(e.message)}</div><div class="modal-actions"><button data-act="closeModal">Fermer</button></div>`); }
    const L = ui.rebuild;
    openModal(`<h2>🧩 Reconstituer depuis les demandes</h2><div class="small muted">Projets trouvés dans les demandes WhatsApp déjà envoyées, mais absents de l'application. Ils sont recréés avec leur équipe, les dates, les postes et les réponses déjà reçues ; <b>les liens envoyés aux techniciens continuent de fonctionner</b>. Il restera à refaire les écrans / le matériel.</div>
      ${L.length ? L.map((g, i) => `<div class="card" style="margin-top:10px"><label style="display:flex;gap:8px;align-items:center"><input type="checkbox" data-rb="${i}" checked style="width:auto"><b style="font-size:15px">${esc(g.name)}</b></label>
        <div class="tiny muted">${esc(g.lieu || '')} · ${g.start ? fmtDate(g.start) + (g.end !== g.start ? ' → ' + fmtDate(g.end) : '') : 'dates ?'} · ${g.crew.length} technicien(s)</div>
        <table style="margin-top:6px">${g.crew.map((c, j) => `<tr><td>${c.cands.length === 1 ? `<b>${esc(techName(c.cands[0]))}</b>` : `<select data-rbt="${i}:${j}"><option value="">— ${esc(c.prenom)} : choisir —</option>${(c.cands.length ? c.cands : Store.db.techs).map((t) => `<option value="${t.id}">${esc(techName(t))}</option>`).join('')}</select>`}</td>
          <td class="tiny">${esc(c.role || '')}</td><td class="tiny">${esc(fmtDays(c.dates))}</td><td>${(CREW_ST[c.status] || {}).ic || ''} ${esc((CREW_ST[c.status] || {}).l || c.status)}</td></tr>`).join('')}</table></div>`).join('')
        : '<div class="card muted" style="margin-top:12px">Aucune demande orpheline : toutes les demandes envoyées correspondent à un projet existant.</div>'}
      <div class="modal-actions"><button data-act="closeModal">Fermer</button>${L.length ? '<button class="primary" data-act="rebuildGo">🧩 Recréer les projets cochés</button>' : ''}</div>`);
  },
  rebuildGo() {
    const L = ui.rebuild || []; let n = 0;
    document.querySelectorAll('[data-rbt]').forEach((s) => { const [i, j] = s.dataset.rbt.split(':').map(Number); if (s.value) L[i].crew[j].techId = s.value; });
    [...document.querySelectorAll('[data-rb]:checked')].forEach((c) => {
      const g = L[+c.dataset.rb]; if (!g) return;
      actions.newProject(); const p = ui.edit; closeModal(); delete p._new;
      Object.assign(p, { name: g.name, venue: g.lieu, start: g.start || todayISO(), end: g.end || g.start || todayISO(), status: 'confirme', notes: 'Projet reconstitué le ' + new Date().toLocaleDateString('fr-FR') + ' à partir des demandes envoyées (écrans et matériel à refaire).' });
      p.screens = p.screens || []; p.crew = [];
      g.crew.filter((x) => x.techId).forEach((x) => {
        p.crew.push({ id: uid('crw'), techId: x.techId, role: x.role, kind: x.kind === 'option' ? 'option' : 'booking', dates: x.dates.length ? x.dates : projectDays(p), status: x.status, token: x.token, regHash: 'rebuilt',
          hours: Object.assign(typeof emptyHours === 'function' ? emptyHours() : {}, { note: x.note }), history: [{ at: new Date().toISOString(), action: 'reconstitué', status: x.status }],
          sentAt: new Date(x.at).toISOString(), ack: x.status === 'valide' ? true : undefined });
      });
      Store.db.projects.push(p); n++;
    });
    Store.save(); closeModal(); render(); toast(`${n} projet(s) recréé(s) ✔ — complétez les écrans et le matériel`);
  }
});

/* ---------- Ancienne version des données en ligne (historique des versions Google Sheets) ---------- */
Object.assign(journalRecoverActions, {
  gsOldOpen() {
    openModal(`<h2>🕘 Récupérer depuis l'historique Google</h2>
      <div class="small" style="line-height:1.7">Google garde toutes les anciennes versions des données partagées. Pour reprendre ce qui manque :
      <ol style="margin:6px 0 0 18px"><li>Ouvrez <a data-act="gsOldSheet">la feuille Google « Impulsion LED – Réponses techniciens »</a> (dans votre Google Drive).</li>
      <li>Menu <b>Fichier → Historique des versions → Afficher l'historique des versions</b>.</li>
      <li>À droite, cliquez sur une version <b>où vos projets existaient encore</b> (ex. vendredi soir, ou ce matin).</li>
      <li>En haut, cliquez sur <b>⋮ → Créer une copie</b>, puis ouvrez la copie.</li>
      <li>Copiez l'adresse de la copie (barre d'adresse) et collez-la ici :</li></ol></div>
      <div class="alert warn small" style="margin-top:10px">Vous voyez une feuille presque vide dont l'historique ne remonte qu'à aujourd'hui ? C'est une <b>nouvelle</b> feuille créée par erreur : dans Google Drive, cherchez l'<b>autre</b> fichier « Impulsion LED – Réponses techniciens » (le plus ancien) et collez directement <b>son</b> adresse ici, sans faire de copie.</div>
      <div id="gsCur" class="tiny muted" style="margin-top:6px"></div>
      <input id="gsOldUrl" placeholder="https://docs.google.com/spreadsheets/d/…" style="width:100%;margin-top:10px">
      <div class="row" style="margin-top:8px"><button class="sm" data-act="gsOldRebuild">🧩 Reconstituer depuis les demandes de ce fichier</button><button class="sm" data-act="gsUseSheet">🔗 Reconnecter le partage à ce fichier</button></div>
      <div id="recList" style="margin-top:12px"></div>
      <div class="modal-actions"><button data-act="closeModal">Fermer</button><button data-act="gsOldScan">Voir le contenu</button><button class="primary" data-act="recoverGo">♻ Récupérer la sélection</button></div>`);
    remotePost({ action: 'sheetinfo', key: ensureReplyKey() }).then((j) => { const el = document.getElementById('gsCur'); if (el && j && j.created) el.innerHTML = `Feuille utilisée actuellement par le partage : créée le ${new Date(j.created).toLocaleString('fr-FR', { day: 'numeric', month: 'long', hour: '2-digit', minute: '2-digit' })}${Date.now() - j.created < 7 * 864e5 ? ' — <b style="color:var(--warn)">récente : probablement la feuille créée par erreur</b>' : ''} · <a data-act="gsOpenUrl" data-v="${esc(j.url)}">ouvrir</a>`; }).catch(() => {});
  },
  gsOpenUrl(el) { openExternal(el.dataset.v); },
  gsSheetId() { const v = (document.getElementById('gsOldUrl') || {}).value || ''; const m = v.match(/\/d\/([A-Za-z0-9_-]{5,})/) || v.trim().match(/^([A-Za-z0-9_-]{25,})$/); return m ? m[1] : ''; },
  async gsOldRebuild() { const id = journalRecoverActions.gsSheetId(); if (!id) return toast('Collez d\'abord l\'adresse du fichier', 'warn'); ui.rebuildSheet = id; journalRecoverActions.rebuildOpen(); },
  async gsUseSheet() {
    const id = journalRecoverActions.gsSheetId(); if (!id) return toast('Collez d\'abord l\'adresse du fichier', 'warn');
    if (!confirm('Reconnecter le partage à ce fichier ? Les demandes, réponses des techniciens et données de ce fichier redeviennent celles utilisées par tous les postes. Rien n\'est supprimé : les données de ce PC sont fusionnées avec celles du fichier.')) return;
    try {
      const j = await withTimeout(remotePost({ action: 'usesheet', key: ensureReplyKey(), id }), 30000);
      closeModal(); toast('Partage reconnecté à « ' + (j.sheet || 'la feuille') + ' » ✔ — fusion en cours…'); await syncCycle(true); render();
    } catch (e) { toast(/Action inconnue|Jeton/.test(e.message) ? 'Le script Google doit être mis à jour (v16)' : e.message, 'bad'); }
  },
  gsOldSheet() { openExternal('https://drive.google.com/drive/search?q=' + encodeURIComponent('Impulsion LED – Réponses techniciens')); },
  async gsOldScan() {
    const id0 = journalRecoverActions.gsSheetId(); const m = id0 ? [0, id0] : null;
    const box = document.getElementById('recList'); if (!m) { box.innerHTML = '<div class="alert bad">Collez l\'adresse de la copie (elle contient /spreadsheets/d/…).</div>'; return; }
    box.innerHTML = '<div class="muted">Lecture de l\'ancienne version…</div>';
    try {
      const j = await withTimeout(remotePost({ action: 'dbfrom', key: ensureReplyKey(), id: m[1] }), 60000);
      if (!j || !j.data) throw new Error((j && j.error) || 'Le script Google doit être mis à jour (v15).');
      const items = []; Object.keys(COLL_TXT).forEach((k) => (j.data[k] || []).forEach((x) => { if (!(Store.db[k] || []).some((y) => y.id === x.id)) items.push({ coll: k, item: x, from: 'Google' }); }));
      items.sort((a, b) => (a.coll === 'projects' ? 0 : 1) - (b.coll === 'projects' ? 0 : 1)); ui.recItems = items;
      box.innerHTML = items.length ? `<div class="small"><b>${items.length}</b> élément(s) absent(s) aujourd'hui :</div><table>${items.map((x, i) => `<tr><td><label style="display:flex;gap:8px;align-items:center"><input type="checkbox" data-rec="${i}" ${x.coll === 'projects' ? 'checked' : ''} style="width:auto"><span><b>${esc((JOURNAL_TYPES[x.coll] && JOURNAL_TYPES[x.coll].label(x.item)) || x.item.name || '—')}</b> <span class="tiny muted">${COLL_TXT[x.coll]}${x.item.start ? ' · ' + fmtDate(x.item.start) : ''}</span></span></label></td></tr>`).join('')}</table>`
        : '<div class="card muted">Cette version ne contient rien de plus que ce que vous avez déjà. Essayez une version plus ancienne ou plus récente.</div>';
    } catch (e) { box.innerHTML = `<div class="alert bad">${esc(e.message)}</div>`; }
  }
});

/* ---------- Plusieurs feuilles Google (créées par erreur) : tout récupérer et regrouper (script v17) ---------- */
const sheetDate = (t) => new Date(t).toLocaleString('fr-FR', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
Object.assign(journalRecoverActions, {
  async allSheetsOpen() {
    openModal('<h2>🗂 Tout récupérer</h2><div class="muted">Recherche des feuilles « Impulsion LED – Réponses techniciens » dans votre Google Drive…</div>');
    let j; try { j = await withTimeout(remotePost({ action: 'sheetsall', key: ensureReplyKey() }), 90000); } catch (e) {
      return openModal(`<h2>🗂 Tout récupérer</h2><div class="alert bad">${esc(/Action inconnue|Jeton/.test(e.message) ? 'Le script Google doit être mis à jour (v17) : Équipe → Réponses en 1 clic → Copier le code, puis Nouvelle version.' : e.message)}</div><div class="modal-actions"><button data-act="closeModal">Fermer</button></div>`); }
    const S = (ui.sheets = (j.sheets || []).filter((x) => !x.error)); const best = S.slice().sort((a, b) => (b.demandes - a.demandes) || (a.created - b.created))[0];
    ui.sheetTarget = best ? best.id : '';
    openModal(`<h2>🗂 Tout récupérer</h2><div class="small muted">${S.length} feuille(s) trouvée(s). L'application va chercher dans <b>toutes</b> ce qui manque aujourd'hui (projets, techniciens, références, demandes envoyées), puis regrouper les demandes et réponses des techniciens dans <b>une seule</b> feuille, utilisée ensuite par tous les postes. Rien n'est supprimé.</div>
      <table style="margin-top:10px"><tr><th>Garder</th><th>Créée</th><th>Modifiée</th><th class="num">Demandes</th><th class="num">Réponses</th><th class="num">Projets</th></tr>
      ${S.map((x) => `<tr><td><input type="radio" name="sheetTgt" value="${x.id}" ${x.id === ui.sheetTarget ? 'checked' : ''} style="width:auto" onchange="ui.sheetTarget=this.value"> ${x.current ? '<span class="tag info">actuelle</span>' : ''}</td><td class="tiny">${sheetDate(x.created)}</td><td class="tiny">${sheetDate(x.updated)}</td><td class="num">${x.demandes}</td><td class="num">${x.reponses}</td><td class="num">${x.projects}</td></tr>`).join('')}</table>
      <div class="tiny muted" style="margin-top:6px">« Garder » = la feuille qui sera utilisée ensuite (proposée : celle qui a le plus de demandes).</div>
      <div id="allList" style="margin-top:12px"></div>
      <div class="modal-actions"><button data-act="closeModal">Fermer</button><button class="primary" data-act="allSheetsScan">🔎 Chercher ce qui manque</button></div>`);
  },
  async allSheetsScan() {
    const box = document.getElementById('allList'); const S = ui.sheets || []; const items = new Map(); const rb = new Map();
    const mine = (k, id) => (Store.db[k] || []).some((y) => y.id === id);
    for (let i = 0; i < S.length; i++) {
      box.innerHTML = `<div class="muted">Lecture des feuilles… ${i + 1} / ${S.length}</div>`;
      const sh = S[i];
      try { const d = await withTimeout(remotePost({ action: 'dbfrom', key: ensureReplyKey(), id: sh.id }), 60000);
        Object.keys(COLL_TXT).forEach((k) => (d.data[k] || []).forEach((x) => { if (mine(k, x.id)) return; const prev = items.get(x.id); if (!prev || prev.upd < sh.updated) items.set(x.id, { coll: k, item: x, upd: sh.updated }); })); } catch (e) { /* feuille sans données */ }
      try { (await rebuildScan(sh.id)).forEach((g) => { const k = g.name.trim().toLowerCase(); const prev = rb.get(k); if (!prev) rb.set(k, g); else { const tk = new Set(prev.crew.map((c) => c.token)); g.crew.forEach((c) => { if (!tk.has(c.token) && !prev.crew.some((x) => (x.techId || x.prenom) === (c.techId || c.prenom))) prev.crew.push(c); }); } }); } catch (e) { /* */ }
    }
    // un projet retrouvé complet dans une feuille passe avant sa reconstitution depuis les demandes
    const names = new Set([...items.values()].filter((x) => x.coll === 'projects').map((x) => (x.item.name || '').trim().toLowerCase()));
    Store.db.projects.forEach((p) => names.add((p.name || '').trim().toLowerCase()));
    const R = (ui.allRebuild = [...rb.values()].filter((g) => !names.has(g.name.trim().toLowerCase())));
    const I = (ui.allItems = [...items.values()].sort((a, b) => (a.coll === 'projects' ? 0 : 1) - (b.coll === 'projects' ? 0 : 1)));
    box.innerHTML = (I.length || R.length) ? `${I.length ? `<div class="small"><b>Retrouvés complets</b> (avec écrans, matériel, équipe) :</div><table>${I.map((x, i) => `<tr><td><label style="display:flex;gap:8px;align-items:center"><input type="checkbox" data-ai="${i}" ${x.coll === 'projects' ? 'checked' : ''} style="width:auto"><span><b>${esc((JOURNAL_TYPES[x.coll] && JOURNAL_TYPES[x.coll].label(x.item)) || x.item.name || '—')}</b> <span class="tiny muted">${COLL_TXT[x.coll]}${x.item.start ? ' · ' + fmtDate(x.item.start) : ''}</span></span></label></td></tr>`).join('')}</table>` : ''}
      ${R.length ? `<div class="small" style="margin-top:10px"><b>Reconstitués depuis les demandes envoyées</b> (équipe et réponses ; écrans à refaire) :</div><table>${R.map((g, i) => `<tr><td><label style="display:flex;gap:8px;align-items:center"><input type="checkbox" data-ar="${i}" checked style="width:auto"><span><b>${esc(g.name)}</b> <span class="tiny muted">${esc(g.lieu || '')} · ${g.start ? fmtDate(g.start) : ''} · ${g.crew.map((c) => esc(c.cands.length === 1 ? techName(c.cands[0]) : c.prenom)).join(', ')}</span></span></label></td></tr>`).join('')}</table>` : ''}
      <div class="modal-actions" style="position:static"><button class="primary" data-act="allSheetsGo">♻ Tout récupérer et regrouper</button></div>`
      : `<div class="card muted">Rien ne manque : tout ce que contiennent ces feuilles existe déjà dans l'application.</div><div class="modal-actions" style="position:static"><button class="primary" data-act="allSheetsGo">🔗 Regrouper quand même les demandes dans la feuille gardée</button></div>`;
  },
  async allSheetsGo() {
    const I = ui.allItems || []; const R = ui.allRebuild || [];
    const selI = [...document.querySelectorAll('[data-ai]:checked')].map((c) => I[+c.dataset.ai]).filter(Boolean);
    const selR = new Set([...document.querySelectorAll('[data-ar]:checked')].map((c) => +c.dataset.ar));
    const n1 = selI.length ? restoreItems(selI, 'feuilles Google') : 0;
    let n2 = 0;
    if (selR.size) { ui.rebuild = R.filter((_, i) => selR.has(i)); openModal('<div></div>'); ui.rebuild.forEach((g, i) => { document.getElementById('modal').querySelector('div').insertAdjacentHTML('beforeend', `<input type="checkbox" data-rb="${i}" checked>`); }); journalRecoverActions.rebuildGo(); n2 = ui.rebuild.length; }
    openModal('<h2>🗂 Regroupement…</h2><div class="muted">Les demandes et réponses de toutes les feuilles sont regroupées dans la feuille gardée.</div>');
    try {
      const j = await withTimeout(remotePost({ action: 'consolidate', key: ensureReplyKey(), id: ui.sheetTarget, ids: (ui.sheets || []).map((x) => x.id) }), 120000);
      Store.db.settings.replySince = 0; Store.save(); // relit toutes les réponses (déjà vues : ignorées)
      await syncCycle(true); try { await syncReplies(true); } catch (e) { /* */ }
      closeModal(); render();
      toast(`✔ ${n1} élément(s) récupéré(s), ${n2} projet(s) reconstitué(s) · ${j.added.demandes} demande(s) et ${j.added.reponses} réponse(s) regroupées`);
    } catch (e) { closeModal(); render(); toast(`Récupéré : ${n1 + n2} élément(s). Regroupement impossible : ${e.message}`, 'bad'); }
  }
});
