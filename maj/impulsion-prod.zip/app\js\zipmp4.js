/* =====================================================================
   OUTILS FICHIERS : ZIP (sans compression) et MP4 H.264 (muxer minimal)
   ===================================================================== */
const CRC_TABLE = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
function crc32(u8) { let c = 0xffffffff; for (let i = 0; i < u8.length; i++) c = CRC_TABLE[(c ^ u8[i]) & 255] ^ (c >>> 8); return (c ^ 0xffffffff) >>> 0; }
/* files : [{ name, data: Uint8Array }] → Blob .zip */
function makeZip(files) {
  const enc = new TextEncoder(); const parts = []; const central = []; let offset = 0;
  const d = new Date(); const time = (d.getHours() << 11) | (d.getMinutes() << 5) | (d.getSeconds() >> 1); const date = ((d.getFullYear() - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate();
  files.forEach((f) => {
    const name = enc.encode(f.name); const crc = crc32(f.data); const size = f.data.length;
    const h = new DataView(new ArrayBuffer(30));
    h.setUint32(0, 0x04034b50, true); h.setUint16(4, 20, true); h.setUint16(6, 0x0800, true); h.setUint16(8, 0, true); h.setUint16(10, time, true); h.setUint16(12, date, true);
    h.setUint32(14, crc, true); h.setUint32(18, size, true); h.setUint32(22, size, true); h.setUint16(26, name.length, true); h.setUint16(28, 0, true);
    parts.push(new Uint8Array(h.buffer), name, f.data);
    const c = new DataView(new ArrayBuffer(46));
    c.setUint32(0, 0x02014b50, true); c.setUint16(4, 20, true); c.setUint16(6, 20, true); c.setUint16(8, 0x0800, true); c.setUint16(10, 0, true); c.setUint16(12, time, true); c.setUint16(14, date, true);
    c.setUint32(16, crc, true); c.setUint32(20, size, true); c.setUint32(24, size, true); c.setUint16(28, name.length, true); c.setUint32(42, offset, true);
    central.push(new Uint8Array(c.buffer), name);
    offset += 30 + name.length + size;
  });
  const cdSize = central.reduce((a, x) => a + x.length, 0);
  const e = new DataView(new ArrayBuffer(22));
  e.setUint32(0, 0x06054b50, true); e.setUint16(8, files.length, true); e.setUint16(10, files.length, true); e.setUint32(12, cdSize, true); e.setUint32(16, offset, true);
  return new Blob([...parts, ...central, new Uint8Array(e.buffer)], { type: 'application/zip' });
}

/* ---------- MP4 (H.264, images clés + fréquence d'images constante) ---------- */
class Mp4Writer {
  constructor(width, height, fps) { this.w = width; this.h = height; this.fps = fps; this.samples = []; this.avcC = null; }
  add(chunk, meta) {
    if (meta && meta.decoderConfig && meta.decoderConfig.description && !this.avcC) this.avcC = new Uint8Array(meta.decoderConfig.description.buffer ? meta.decoderConfig.description.buffer.slice(0) : meta.decoderConfig.description);
    const data = new Uint8Array(chunk.byteLength); chunk.copyTo(data); this.samples.push({ data, key: chunk.type === 'key' });
  }
  finish() {
    const S = this.samples; if (!S.length || !this.avcC) throw new Error('Aucune image encodée');
    const u32 = (v) => [(v >>> 24) & 255, (v >>> 16) & 255, (v >>> 8) & 255, v & 255]; const u16 = (v) => [(v >> 8) & 255, v & 255];
    const str = (s) => [...s].map((c) => c.charCodeAt(0));
    const box = (type, ...kids) => { const body = kids.flat(Infinity); return [...u32(body.length + 8), ...str(type), ...body]; };
    const full = (type, ver, flags, ...kids) => box(type, [ver, (flags >> 16) & 255, (flags >> 8) & 255, flags & 255], ...kids);
    const TS = 90000; const dur = Math.round(TS / this.fps); const total = dur * S.length; const matrix = [...u32(0x10000), ...u32(0), ...u32(0), ...u32(0), ...u32(0x10000), ...u32(0), ...u32(0), ...u32(0), ...u32(0x40000000)];
    const ftyp = box('ftyp', str('isom'), u32(512), str('isom'), str('iso2'), str('avc1'), str('mp41'));
    const mdatSize = 8 + S.reduce((a, s) => a + s.data.length, 0); const firstOff = ftyp.length + 8;
    if (mdatSize > 0xffffffff) throw new Error('Vidéo trop lourde (> 4 Go) : réduisez la durée ou la qualité');
    const offs = []; let o = firstOff; S.forEach((s) => { offs.push(o); o += s.data.length; });
    const avc1 = box('avc1', [0, 0, 0, 0, 0, 0], u16(1), u16(0), u16(0), u32(0), u32(0), u32(0), u16(this.w), u16(this.h), u32(0x480000), u32(0x480000), u32(0), u16(1), new Array(32).fill(0), u16(0x18), u16(0xffff), box('avcC', [...this.avcC]));
    const stbl = box('stbl',
      full('stsd', 0, 0, u32(1), avc1),
      full('stts', 0, 0, u32(1), u32(S.length), u32(dur)),
      full('stss', 0, 0, u32(S.filter((s) => s.key).length), S.map((s, i) => (s.key ? u32(i + 1) : [])).flat()),
      full('stsc', 0, 0, u32(1), u32(1), u32(1), u32(1)),
      full('stsz', 0, 0, u32(0), u32(S.length), S.map((s) => u32(s.data.length)).flat()),
      full('stco', 0, 0, u32(S.length), offs.map(u32).flat()));
    const minf = box('minf', full('vmhd', 0, 1, u16(0), u16(0), u16(0), u16(0)), box('dinf', full('dref', 0, 0, u32(1), full('url ', 0, 1))), stbl);
    const mdia = box('mdia', full('mdhd', 0, 0, u32(0), u32(0), u32(TS), u32(total), u16(0x55c4), u16(0)), full('hdlr', 0, 0, u32(0), str('vide'), u32(0), u32(0), u32(0), str('Impulsion LED'), [0]), minf);
    const trak = box('trak', full('tkhd', 0, 3, u32(0), u32(0), u32(1), u32(0), u32(Math.round(total / TS * 1000)), u32(0), u32(0), u16(0), u16(0), u16(0), u16(0), matrix, u32(this.w << 16), u32(this.h << 16)), mdia);
    const moov = box('moov', full('mvhd', 0, 0, u32(0), u32(0), u32(1000), u32(Math.round(total / TS * 1000)), u32(0x10000), u16(0x100), u16(0), u32(0), u32(0), matrix, new Array(24).fill(0), u32(2)), trak);
    return new Blob([new Uint8Array(ftyp), new Uint8Array([...u32(mdatSize), ...str('mdat')]), ...S.map((s) => s.data), new Uint8Array(moov)], { type: 'video/mp4' });
  }
}
async function pickH264(w, h, fps, bitrate) {
  const lv = w * h > 2228224 ? ['640033', '640034', '4d0033', '420033'] : ['640028', '64002a', '4d0028', '42002a'];
  for (const l of lv) {
    const cfg = { codec: 'avc1.' + l, width: w, height: h, bitrate, framerate: fps, avc: { format: 'avc' }, latencyMode: 'quality' };
    try { if ((await VideoEncoder.isConfigSupported(cfg)).supported) return cfg; } catch (e) { /* suivant */ }
    try { const c2 = Object.assign({}, cfg); delete c2.latencyMode; if ((await VideoEncoder.isConfigSupported(c2)).supported) return c2; } catch (e) { /* suivant */ }
  }
  return null;
}
/* Sauvegarde d'un Blob (Electron : boîte d'enregistrement ; sinon téléchargement) */
async function saveBlob(name, blob, ext, label) {
  if (NATIVE_FILES) {
    const buf = new Uint8Array(await blob.arrayBuffer()); let bin = ''; for (let i = 0; i < buf.length; i += 0x8000) bin += String.fromCharCode.apply(null, buf.subarray(i, i + 0x8000));
    return saveFileBase64(name, btoa(bin), ext, label);
  }
  const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name; document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 60000); toast('Téléchargement : ' + name);
}
