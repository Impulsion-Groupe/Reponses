/* =====================================================================
   TÉLÉPHONE / TABLETTE
   - menu tiroir (☰) et titre de page en haut sur petit écran
   - gestes tactiles → mêmes actions qu'à la souris (3D, plan d'implantation, peinture de dalles)
   - version hébergée (app.html sur GitHub) : connexion par le code de partage, puis tout comme sur PC
   ===================================================================== */
(function mobileShell() {
  const body = document.body;
  const close = () => body.classList.remove('nav-open');
  document.getElementById('mburger')?.addEventListener('click', () => body.classList.toggle('nav-open'));
  document.getElementById('mshade')?.addEventListener('click', close);
  document.getElementById('nav')?.addEventListener('click', (e) => { if (e.target.closest('a')) setTimeout(close, 60); });
  document.getElementById('side')?.addEventListener('click', (e) => { if (e.target.closest('[data-nav-go],.user-chip')) setTimeout(close, 60); });
  // titre de la page affichée + état de sauvegarde, recopiés dans la barre du haut
  const sync = () => {
    const h = document.querySelector('#main .page-head h1, #main h1'); const t = document.getElementById('mtitle');
    if (t) t.textContent = h ? h.textContent.trim() : 'Impulsion Prod';
    const s = document.getElementById('saveState'); const m = document.getElementById('msave');
    if (s && m) { m.textContent = s.textContent; m.style.color = getComputedStyle(s).color; }
  };
  new MutationObserver(sync).observe(document.getElementById('main'), { childList: true });
  const ss = document.getElementById('saveState'); if (ss) new MutationObserver(sync).observe(ss, { childList: true, characterData: true, subtree: true, attributes: true });
})();

/* ---------- Tactile : traduit le doigt en souris pour les vues qui se manipulent ---------- */
(function touchBridge() {
  let T = null;
  const fake = (t, target, extra) => Object.assign({ clientX: t.clientX, clientY: t.clientY, target, button: 0, buttons: 1, shiftKey: false, ctrlKey: false, _p: false, preventDefault() { this._p = true; }, stopPropagation() {} }, extra || {});
  const dist = (a, b) => Math.hypot(a.clientX - b.clientX, a.clientY - b.clientY);
  document.addEventListener('touchstart', (e) => {
    if (e.touches.length === 2 && T && T.el && T.el.onwheel) { T.pinch = dist(e.touches[0], e.touches[1]); e.preventDefault(); return; }
    if (e.touches.length !== 1) return;
    let el = e.target; while (el && el !== document.body && !el.onmousedown) el = el.parentElement;
    if (!el || el === document.body) { T = null; return; }
    const ev = fake(e.touches[0], e.target); el.onmousedown(ev);
    T = { el, canvas: el.tagName === 'CANVAS', active: ev._p || el.tagName === 'CANVAS' };
    if (T.active) e.preventDefault();
  }, { passive: false });
  document.addEventListener('touchmove', (e) => {
    if (!T) return;
    if (e.touches.length === 2 && T.pinch && T.el.onwheel) {
      const d = dist(e.touches[0], e.touches[1]); const r = d / T.pinch;
      if (r > 1.08 || r < 0.92) { T.el.onwheel(fake(e.touches[0], e.target, { deltaY: r > 1 ? -1 : 1 })); T.pinch = d; }
      e.preventDefault(); return;
    }
    if (!T.active) return;
    const t = e.touches[0]; const target = document.elementFromPoint(t.clientX, t.clientY) || e.target; const ev = fake(t, target);
    if (window.onmousemove) window.onmousemove(ev);
    if (T.el.onmouseover) T.el.onmouseover(ev);
    e.preventDefault();
  }, { passive: false });
  document.addEventListener('touchend', (e) => {
    if (!T) return; if (e.touches.length) return;
    if (T.active && window.onmouseup) window.onmouseup(fake(e.changedTouches[0], e.target));
    T = null;
  });
})();

/* ---------- Version hébergée : première connexion ---------- */
function webJoinHTML(err) {
  return `<div class="login-card" style="max-width:460px;margin:0 auto;padding:calc(30px + env(safe-area-inset-top)) 20px 30px">
    <div style="text-align:center"><img src="assets/logo-white.png" alt="" style="width:220px;max-width:70%"><div class="brand-sub" style="margin:6px 0 22px">PROD</div></div>
    <div class="card small" style="line-height:1.6">Sur votre PC : <b>Comptes & partage → 📱 Installer sur mon téléphone</b>, puis ouvrez le lien reçu sur ce téléphone.<br><br>Ou collez ici <b>le lien d'installation ou le code</b> (il commence par ILM1-) :</div>
    <textarea id="webCode" rows="4" style="width:100%;margin-top:12px;font-family:monospace;font-size:13px" placeholder="ILM1-…"></textarea>
    ${err ? `<div class="alert bad" style="margin-top:10px">${esc(err)}</div>` : ''}
    <button style="width:100%;margin-top:10px;min-height:44px" onclick="navigator.clipboard&&navigator.clipboard.readText().then(function(t){document.getElementById('webCode').value=t;webJoin(t)}).catch(function(){toast('Appuyez longuement dans la case puis « Coller »','warn')})">📋 Coller le lien ou le code copié</button>
    <button class="primary" style="width:100%;margin-top:10px;min-height:48px;font-size:16px" onclick="webJoin(document.getElementById('webCode').value)">Se connecter</button>
    <div class="tiny muted" style="margin-top:14px">Déjà connecté dans le navigateur mais pas depuis l'icône ? Sur iPhone, l'icône a sa propre mémoire : collez le code une fois ici, ou supprimez l'icône et rajoutez-la depuis le navigateur <b>après</b> vous être connecté.</div>
    <div class="tiny muted" style="margin-top:8px">Le code donne accès à toutes les données de l'entreprise : réservé à la direction.</div></div>`;
}
function showWebJoin(err) {
  let el = document.getElementById('login'); if (!el) { el = document.createElement('div'); el.id = 'login'; document.body.appendChild(el); }
  el.innerHTML = webJoinHTML(err); el.classList.remove('hidden');
  const sp = document.getElementById('splash'); if (sp) sp.classList.add('out');
}
async function webJoin(code) {
  // accepte le code seul ou le lien complet (…app.html#c=ILM1-…) collé tel quel
  let txt = String(code || ''); try { txt = decodeURIComponent(txt); } catch (e) { /* */ }
  const mm = txt.match(/ILM1-[A-Za-z0-9+/=]+/); code = mm ? mm[0] : txt.trim();
  const o = parseCode(code); if (!o) return showWebJoin('Code invalide : il commence par ILM1-');
  const el = document.getElementById('login'); if (el) el.innerHTML = '<div class="empty" style="padding-top:140px">☁ Connexion aux données partagées…</div>';
  const st = Store.db.settings; st.replyUrl = o.u; st.replyKey = o.k;
  try {
    const res = await firstContact(); if (!res.rev || !res.data) throw new Error('Aucune donnée partagée : activez d\'abord le partage sur le PC (Comptes & partage).');
    await useRemote(res); localInfo().userId = null; await Store.saveNow();
    // le code reste dans l'adresse (#j=…) : sur iPhone, l'icône de l'écran d'accueil a son propre stockage,
    // elle se reconnecte ainsi toute seule au premier lancement
    try { history.replaceState(null, '', location.pathname + location.search + '#j=' + encodeURIComponent(String(code).trim())); } catch (e) { /* */ }
    location.reload();
  } catch (e) { showWebJoin(typeof syncErr === 'function' ? syncErr(e) : e.message); }
}
/* Appelée au démarrage : false = on reste sur l'écran de connexion */
async function webBoot() {
  if (!IS_WEB) return true;
  document.body.classList.add('is-web');
  const dp = document.getElementById('dataPath'); if (dp) dp.textContent = 'Téléphone — données partagées';
  if ('serviceWorker' in navigator) { try { navigator.serviceWorker.register('sw.js').catch(() => {}); } catch (e) { /* */ } }
  webManifest();
  const m = location.hash.match(/[#&]c=(ILM1-[A-Za-z0-9+/=%]+)/);
  if (m) { await webJoin(decodeURIComponent(m[1])); return false; }
  const j = location.hash.match(/[#&]j=(ILM1-[A-Za-z0-9+/=%]+)/);
  if (!syncOn()) { if (j) { await webJoin(decodeURIComponent(j[1])); return false; } showWebJoin(); return false; }
  return true;
}
/* lien d'installation ouvert alors que la page est déjà affichée */
window.addEventListener('hashchange', () => { if (IS_WEB && /c=ILM1-/.test(location.hash)) location.reload(); });

/* Manifeste construit à la volée : l'icône installée rouvre l'adresse actuelle (avec #j=code),
   ce qui reconnecte l'icône même si elle n'a pas la mémoire du navigateur (iPhone) */
function webManifest() {
  try {
    const base = location.href.replace(/[?#].*$/, '').replace(/[^/]*$/, '');
    const start = location.href.replace(/#c=/, '#j=');
    const mf = { id: base + 'app.html', name: 'Impulsion Prod', short_name: 'Impulsion Prod', start_url: start, scope: base, display: 'standalone', orientation: 'any', background_color: '#080d10', theme_color: '#080d10', lang: 'fr',
      icons: [192, 512].map((z) => ({ src: base + 'icon-' + z + '.png', sizes: z + 'x' + z, type: 'image/png' })) };
    let l = document.querySelector('link[rel=manifest]'); if (!l) { l = document.createElement('link'); l.rel = 'manifest'; document.head.appendChild(l); }
    l.href = 'data:application/manifest+json,' + encodeURIComponent(JSON.stringify(mf));
  } catch (e) { /* */ }
}
