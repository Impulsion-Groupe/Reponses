/* =====================================================================
   SCÈNE — vue 3D de tous les écrans d'un projet + implantation (vue de dessus)
   Repère monde (mm) : x = gauche→droite, y = hauteur, z = vers le public.
   Chaque écran a une implantation s.place = { x, y (profondeur), z (hauteur du bas), rot (°) }.
   ===================================================================== */
const rad = (d) => (num(d) * Math.PI) / 180;

/* Objets de la scène : un écran classique = 1 objet ; un boarding = 1 objet par zone */
function sceneObjects(p) {
  const out = [];
  p.screens.forEach((s, si) => {
    if (isBoard(s)) { const st = zoneStarts(s); s.zones.forEach((z, zi) => out.push({ key: s.id + '#' + z.id, s, si, z, zi, name: z.name, full: `${s.name} · ${z.name}`, cols: z.count, rows: zRows(s, z), colStart: st[zi], holder: z })); }
    else out.push({ key: s.id, s, si, name: s.name, full: s.name, cols: s.cols, rows: s.rows, colStart: 0, holder: s });
  });
  out.forEach((o, i) => { o.idx = i; o.color = LINE_COLORS[i % LINE_COLORS.length]; });
  return out;
}
/* Géométrie locale d'un objet : grille de la face avant [lx, hauteur depuis le bas, lz], profil vu de dessus, dimensions */
function objLocal(o) {
  const s = o.s;
  if (o.z) {
    const p = getProduct(s.productId) || {}; const w = num(p.widthMm) || 500, h = num(p.heightMm) || 500, d = num(p.depthMm) || 80;
    const L = o.cols * w, Ht = o.rows * h, t = rad(s.tilt || 0);
    const grid = []; for (let r = 0; r <= o.rows; r++) { const row = []; const u = (o.rows - r) * h; for (let k = 0; k <= o.cols; k++) row.push([-L / 2 + k * w, u * Math.cos(t), -u * Math.sin(t)]); grid.push(row); }
    return { grid, profile: [[-L / 2, 0], [L / 2, 0]], width: L, height: Ht * Math.cos(t), depth: d + Ht * Math.sin(t), d: d + Ht * Math.sin(t) };
  }
  if (isArch(s)) { const G = archGrid(s); const I = archInfo(s); const CL = archCells(s); return { cells: CL, grid: archRigid(s) ? CL.map((row) => row.map((q) => q[0])).concat([CL[CL.length - 1].map((q) => q[3])]).map((row) => row.concat([row[row.length - 1]])) : G, profile: [[-I.W / 2, 0], [I.W / 2, 0]], width: I.W, height: I.H, depth: I.P.w * 0 + (num((getProduct(s.productId) || {}).depthMm) || 80), d: num((getProduct(s.productId) || {}).depthMm) || 80 }; }
  const g = screenGeometry(s); const Hp = g.H.pts, Vp = g.V.pts; const vMid = (Vp[0][1] + Vp[s.rows][1]) / 2; const hT = g.V.extent;
  const grid = []; for (let r = 0; r <= s.rows; r++) { const row = []; for (let k = 0; k <= s.cols; k++) row.push([Hp[k][0], -Vp[r][0] + hT / 2, Hp[k][1] + (Vp[r][1] - vMid)]); grid.push(row); }
  return { grid, profile: Hp.map((q) => [q[0], q[1]]), width: g.width, height: hT, depth: g.depth, d: g.d || 80 };
}
function objW(o) { const pl = o.holder.place || { x: 0, y: 0, z: 0, rot: 0 }; const th = rad(pl.rot); const c = Math.cos(th), sn = Math.sin(th); return ([lx, up, lz]) => [num(pl.x) + lx * c - lz * sn, num(pl.z) + up, num(pl.y) + lx * sn + lz * c]; }

/* Terrain : zones d'un boarding réparties sur les 4 côtés, tournées vers le centre */
function arrangeAroundPitch(s, p) {
  const V = p.implant; if (V && V.kind === 'court') return arrangeAroundCourt(s, p, V);
  const objs = sceneObjects(p).filter((o) => o.s === s); const sides = { N: [], E: [], S: [], W: [] }; const order = ['N', 'E', 'S', 'W'];
  objs.forEach((o, i) => sides[order[i % 4]].push(o));
  const len = (arr) => arr.reduce((a, o) => a + objLocal(o).width, 0) + 500 * Math.max(0, arr.length - 1);
  const Wd = Math.max(len(sides.N), len(sides.S), 6000) + 4000; const Dp = Math.max(len(sides.E), len(sides.W), Wd * 0.55) + 2000;
  const others = sceneObjects(p).filter((o) => o.s !== s && o.holder.place);
  const cz = others.length ? Math.max(...others.map((o) => num(o.holder.place.y))) + 3000 + Dp / 2 : 0;
  const put = (arr, fn) => { let a = -len(arr) / 2; arr.forEach((o) => { const L = objLocal(o).width; o.holder.place = Object.assign({ z: 0 }, fn(a + L / 2)); a += L + 500; }); };
  put(sides.N, (t) => ({ x: Math.round(t), y: Math.round(cz - Dp / 2), rot: 0 }));
  put(sides.S, (t) => ({ x: Math.round(-t), y: Math.round(cz + Dp / 2), rot: 180 }));
  put(sides.E, (t) => ({ x: Math.round(Wd / 2), y: Math.round(cz + t), rot: 90 }));
  put(sides.W, (t) => ({ x: Math.round(-Wd / 2), y: Math.round(cz - t), rot: -90 }));
}
/* Boarding autour d'un terrain : à la limite de l'aire de jeu (terrain + zone libre propre au sport) */
const BOARD_SIDES = [['4', '4 côtés'], ['2', '2 longueurs'], ['U', 'En U (3 côtés, sans le côté écrans)'], ['N', '1 longueur côté écrans'], ['S', '1 longueur côté public'], ['ends', '2 largeurs (derrière les buts)']];
function arrangeAroundCourt(s, p, V) {
  const R = courtRun(V); const C = courtShapes(V.court, V.L, V.W); const gap = num(V.boardGap) * 1000 || 0;
  const hx = (C.L / 2 + R.end) * 1000 + gap, hy = (C.W / 2 + R.side) * 1000 + gap; // demi-dimensions jusqu'aux panneaux (repère du terrain, mm)
  const cap = { N: 2 * hx, S: 2 * hx, E: 2 * hy, W: 2 * hy };
  const use = { '4': ['N', 'S', 'E', 'W'], '2': ['N', 'S'], U: ['S', 'E', 'W'], N: ['N'], S: ['S'], ends: ['E', 'W'] }[V.boardSides || '4'] || ['N', 'S', 'E', 'W'];
  const objs = sceneObjects(p).filter((o) => o.s === s); const sides = { N: [], E: [], S: [], W: [] }; const used = { N: 0, E: 0, S: 0, W: 0 }; const sp = 300;
  objs.forEach((o) => { const w = objLocal(o).width; const k = use.slice().sort((a, b) => (used[a] + w) / cap[a] - (used[b] + w) / cap[b])[0]; sides[k].push(o); used[k] += w + sp; });
  const T = venueT(V); const rot0 = num(V.rot); const len = (arr) => arr.reduce((a, o) => a + objLocal(o).width, 0) + sp * Math.max(0, arr.length - 1);
  const put = (arr, at, rot) => { let a = -len(arr) / 2; arr.forEach((o) => { const L = objLocal(o).width; const [x, y] = T(at(a + L / 2)); o.holder.place = { x: Math.round(x), y: Math.round(y), z: 0, rot: ((rot + rot0 + 540) % 360) - 180 }; a += L + sp; }); };
  // N = côté écrans (y négatif), S = côté public ; les panneaux regardent le terrain
  put(sides.N, (t) => [t, -hy], 0); put(sides.S, (t) => [-t, hy], 180); put(sides.E, (t) => [hx, t], 90); put(sides.W, (t) => [-hx, -t], -90);
  const over = Object.keys(sides).filter((k) => len(sides[k]) > cap[k] + 1);
  if (over.length) toast(`⚠ Le boarding dépasse sur ${over.length} côté(s) : ${over.map((k) => `${fmt(len(sides[k]) / 1000, 1)} m pour ${fmt(cap[k] / 1000, 1)} m`).join(', ')}`, 'warn');
}
/* Place automatiquement ce qui n'a pas encore d'implantation */
function ensurePlacement(p) {
  const objs = sceneObjects(p); if (objs.every((o) => o.holder.place)) return;
  const newBoards = p.screens.filter((s) => isBoard(s) && !s.deco && s.zones.every((z) => !z.place));
  // 1) écrans classiques côte à côte, 2) boarding autour d'un terrain devant eux
  const placed = objs.filter((o) => o.holder.place); const un = objs.filter((o) => !o.holder.place && !newBoards.includes(o.s));
  let right;
  if (placed.length) right = Math.max(...placed.map((o) => num(o.holder.place.x) + objLocal(o).width / 2));
  else { const total = un.reduce((a, o) => a + objLocal(o).width, 0) + 1000 * Math.max(0, un.length - 1); right = -total / 2 - 1000; }
  un.forEach((o) => { const w = objLocal(o).width; o.holder.place = { x: Math.round(right + 1000 + w / 2), y: 0, z: 0, rot: 0 }; right += 1000 + w; });
  newBoards.forEach((s) => arrangeAroundPitch(s, p));
  Store.save();
}
function alignScreens(p) {
  const objs = sceneObjects(p); const ws = objs.map((o) => objLocal(o).width); const total = ws.reduce((a, b) => a + b, 0) + 1000 * (ws.length - 1);
  let x = -total / 2;
  objs.forEach((o, i) => { o.holder.place = Object.assign({ z: 0 }, o.holder.place || {}, { x: Math.round(x + ws[i] / 2), y: 0, rot: 0 }); x += ws[i] + 1000; });
}
function sceneBounds(p) {
  let mnX = Infinity, mxX = -Infinity, mnZ = Infinity, mxZ = -Infinity, mxY = 0;
  sceneObjects(p).forEach((o) => { const W = objW(o); objLocal(o).grid.flat().forEach((q) => { const [x, y, z] = W(q); mnX = Math.min(mnX, x); mxX = Math.max(mxX, x); mnZ = Math.min(mnZ, z); mxZ = Math.max(mxZ, z); mxY = Math.max(mxY, y); }); });
  const vb = typeof venueBounds === 'function' ? venueBounds(p) : null; if (vb) { mnX = Math.min(mnX, vb.mnX); mxX = Math.max(mxX, vb.mxX); mnZ = Math.min(mnZ, vb.mnZ); mxZ = Math.max(mxZ, vb.mxZ); }
  if (!isFinite(mnX)) { mnX = -2000; mxX = 2000; mnZ = -500; mxZ = 500; mxY = 2000; }
  return { mnX, mxX, mnZ, mxZ, mxY, w: mxX - mnX, d: mxZ - mnZ };
}

/* ---------- Rendu 3D (projection perspective, tri par profondeur) ---------- */
function drawScene(canvas, p, view, size) {
  const dpr = size ? 1 : window.devicePixelRatio || 1;
  const cw = size ? size.w : canvas.clientWidth, chh = size ? size.h : canvas.clientHeight;
  canvas.width = cw * dpr; canvas.height = chh * dpr; const ctx = canvas.getContext('2d'); ctx.scale(dpr, dpr);
  const bg = ctx.createRadialGradient(cw / 2, chh * 0.35, 10, cw / 2, chh / 2, Math.max(cw, chh) * 0.8);
  bg.addColorStop(0, '#13262f'); bg.addColorStop(1, '#05080a'); ctx.fillStyle = bg; ctx.fillRect(0, 0, cw, chh);
  const B = sceneBounds(p); const T = [(B.mnX + B.mxX) / 2, B.mxY * 0.45, (B.mnZ + B.mxZ) / 2];
  const ext = Math.max(B.w, B.d, B.mxY, 3000);
  const dist = ext * 1.55 + 4000; const f = Math.min(cw, chh * 1.6) * 1.25 * view.zoom;
  const cy = Math.cos(view.yaw), sy = Math.sin(view.yaw), cp = Math.cos(view.pitch), sp = Math.sin(view.pitch);
  const P = ([x, y, z]) => {
    x -= T[0]; y -= T[1]; z -= T[2];
    const x1 = x * cy - z * sy, z1 = x * sy + z * cy;
    const y2 = y * cp - z1 * sp, z2 = y * sp + z1 * cp;
    const dz = Math.max(200, dist - z2); const k = f / dz;
    return [cw / 2 + x1 * k, chh / 2 - y2 * k, z2, k];
  };
  // Sol : quadrillage 1 m
  const g0 = Math.floor((B.mnX - 3000) / 1000) * 1000, g1 = Math.ceil((B.mxX + 3000) / 1000) * 1000;
  const h0 = Math.floor((B.mnZ - 3000) / 1000) * 1000, h1 = Math.ceil((B.mxZ + 6000) / 1000) * 1000;
  ctx.lineWidth = 1;
  for (let x = g0; x <= g1; x += 1000) { const a = P([x, 0, h0]), b = P([x, 0, h1]); ctx.strokeStyle = x === 0 ? 'rgba(25,166,204,.35)' : 'rgba(139,162,174,.12)'; ctx.beginPath(); ctx.moveTo(a[0], a[1]); ctx.lineTo(b[0], b[1]); ctx.stroke(); }
  for (let z = h0; z <= h1; z += 1000) { const a = P([g0, 0, z]), b = P([g1, 0, z]); ctx.strokeStyle = z === 0 ? 'rgba(25,166,204,.35)' : 'rgba(139,162,174,.12)'; ctx.beginPath(); ctx.moveTo(a[0], a[1]); ctx.lineTo(b[0], b[1]); ctx.stroke(); }
  venue3D(ctx, p, P);
  // Dalles de tous les écrans
  const quads = []; const labels = [];
  sceneObjects(p).forEach((o) => {
    const loc = objLocal(o); const W = objW(o); const pm = o.s.pixmap; const solid = o.color;
    const grid = loc.grid.map((row) => row.map(W));
    for (let r = 0; r < o.rows; r++) for (let c = 0; c < o.cols; c++) {
      const pts = (loc.cells ? loc.cells[r][c].map(W) : [grid[r][c], grid[r][c + 1], grid[r + 1][c + 1], grid[r + 1][c]]).map(P);
      const col = view.mode === 'ecran' ? ((c + r) % 2 ? solid : shade(solid, -0.18)) : (o.colStart + c + r) % 2 === 0 ? pm.c1 : pm.c2;
      quads.push({ pts, z: pts.reduce((a, q) => a + q[2], 0) / 4, col });
    }
    const z0 = num((o.holder.place || {}).z);
    if (z0 > 50) { [grid[o.rows][0], grid[o.rows][o.cols]].forEach((q) => { const a = P(q), b = P([q[0], 0, q[2]]); quads.push({ line: [a, b], z: (a[2] + b[2]) / 2 }); }); }
    labels.push({ o, at: P(W([0, loc.height + 250, 0])) });
  });
  quads.sort((a, b) => a.z - b.z);
  quads.forEach((q) => {
    if (q.line) { ctx.strokeStyle = 'rgba(139,162,174,.45)'; ctx.setLineDash([4, 4]); ctx.beginPath(); ctx.moveTo(q.line[0][0], q.line[0][1]); ctx.lineTo(q.line[1][0], q.line[1][1]); ctx.stroke(); ctx.setLineDash([]); return; }
    const [a, b, , e] = q.pts; const front = (b[0] - a[0]) * (e[1] - a[1]) - (b[1] - a[1]) * (e[0] - a[0]) > 0;
    ctx.beginPath(); q.pts.forEach((pt, i) => (i ? ctx.lineTo(pt[0], pt[1]) : ctx.moveTo(pt[0], pt[1]))); ctx.closePath();
    ctx.fillStyle = front ? q.col : '#2a3238'; ctx.fill();
    ctx.strokeStyle = front ? 'rgba(255,255,255,.3)' : '#11181c'; ctx.lineWidth = 1; ctx.stroke();
  });
  // Silhouette 1,80 m pour l'échelle
  const px = (B.mnX + B.mxX) / 2, pz = B.mxZ + 3000;
  const pt = (x, y) => P([px + x, y, pz]);
  ctx.strokeStyle = 'rgba(233,240,243,.75)'; ctx.lineWidth = Math.max(1.5, pt(0, 0)[3] * 60); ctx.lineCap = 'round';
  const L = (a, b) => { const A = pt(...a), Bq = pt(...b); ctx.beginPath(); ctx.moveTo(A[0], A[1]); ctx.lineTo(Bq[0], Bq[1]); ctx.stroke(); };
  L([-170, 0], [0, 900]); L([170, 0], [0, 900]); L([0, 900], [0, 1480]); L([0, 1400], [-260, 950]); L([0, 1400], [260, 950]);
  const hd = pt(0, 1640); ctx.beginPath(); ctx.arc(hd[0], hd[1], Math.max(3, hd[3] * 125), 0, Math.PI * 2); ctx.stroke(); ctx.lineCap = 'butt';
  // Étiquettes
  if (view.labels !== false) labels.forEach(({ o, at }) => {
    const loc = objLocal(o); const txt = o.z ? `${o.full} · ${o.cols * o.rows} pan. · ${fmt(loc.width / 1000, 1)} m` : `${o.name} · ${fmt(loc.width / 1000, 2)}×${fmt(loc.height / 1000, 2)} m`;
    ctx.font = '600 12px Segoe UI, Arial'; const w = ctx.measureText(txt).width + 16;
    ctx.fillStyle = 'rgba(6,12,15,.82)'; ctx.fillRect(at[0] - w / 2, at[1] - 22, w, 20);
    ctx.fillStyle = view.mode === 'ecran' ? o.color : '#e9f0f3'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(txt, at[0], at[1] - 12);
  });
  ctx.textAlign = 'left'; ctx.textBaseline = 'alphabetic';
  ctx.fillStyle = 'rgba(139,162,174,.7)'; ctx.font = '11px Segoe UI, Arial';
  if (!size) ctx.fillText('Glisser : tourner · Molette : zoom · Double-clic : vue de face · Quadrillage 1 m · silhouette 1,80 m', 12, chh - 12);
}
function shade(hex, k) {
  const n = parseInt(hex.slice(1), 16); const f = (v) => Math.max(0, Math.min(255, Math.round(v + (k < 0 ? v * k : (255 - v) * k))));
  return '#' + [f(n >> 16), f((n >> 8) & 255), f(n & 255)].map((v) => v.toString(16).padStart(2, '0')).join('');
}

/* ---------- Vue de dessus (implantation) ---------- */
function scenePlanSVG(p, opts = {}) {
  const T = THEMES[opts.light ? 'light' : 'dark'];
  const B = sceneBounds(p);
  const vb = opts.vb || { x: Math.floor((B.mnX - 2500) / 1000) * 1000, y: Math.floor((B.mnZ - 2000) / 1000) * 1000, w: 0, h: 0 };
  if (!opts.vb) { vb.w = Math.ceil((B.mxX + 2500) / 1000) * 1000 - vb.x; vb.h = Math.ceil((B.mxZ + 3500) / 1000) * 1000 - vb.y; }
  const S = vb.w / (opts.light ? 700 : 560); // 1 unité ≈ 1 px à l'écran
  let s = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="${vb.x} ${vb.y} ${vb.w} ${vb.h}" data-vb="${vb.x},${vb.y},${vb.w},${vb.h}" font-family="Segoe UI, Arial, sans-serif" style="width:100%;height:auto;display:block">`;
  s += `<rect x="${vb.x}" y="${vb.y}" width="${vb.w}" height="${vb.h}" fill="${T.bg}"/>`;
  for (let x = Math.ceil(vb.x / 1000) * 1000; x <= vb.x + vb.w; x += 1000) s += `<line x1="${x}" y1="${vb.y}" x2="${x}" y2="${vb.y + vb.h}" stroke="${x === 0 ? '#19a6cc' : T.grid}" stroke-opacity="${x === 0 ? 0.5 : 0.35}" stroke-width="${S * 1.2}"/>`;
  for (let y = Math.ceil(vb.y / 1000) * 1000; y <= vb.y + vb.h; y += 1000) s += `<line x1="${vb.x}" y1="${y}" x2="${vb.x + vb.w}" y2="${y}" stroke="${y === 0 ? '#19a6cc' : T.grid}" stroke-opacity="${y === 0 ? 0.5 : 0.35}" stroke-width="${S * 1.2}"/>`;
  s += venueSVG(p, S);
  sceneObjects(p).forEach((o) => {
    const loc = objLocal(o); const pl = o.holder.place || {}; const th = rad(pl.rot); const c = Math.cos(th), sn = Math.sin(th);
    const d = loc.d; const col = o.color;
    const W = (lx, lz) => [num(pl.x) + lx * c - lz * sn, num(pl.y) + lx * sn + lz * c];
    const front = loc.profile.map(([lx, lz]) => W(lx, lz));
    const back = loc.profile.map(([lx, lz], i, a) => { const j = Math.min(i, a.length - 2); const dx = a[j + 1][0] - a[j][0], dz = a[j + 1][1] - a[j][1]; const L = Math.hypot(dx, dz) || 1; return W(lx + (dz / L) * d, lz - (dx / L) * d); });
    const poly = [...front, ...back.reverse()].map((q) => q.join(',')).join(' ');
    const sel = ui.sceneSel === o.key;
    s += `<g class="pl-scr" data-scr="${o.key}" style="cursor:move">
      <polygon points="${poly}" fill="${col}" fill-opacity="${sel ? 0.45 : 0.25}" stroke="${col}" stroke-width="${S * (sel ? 3 : 1.6)}"/>
      <polyline points="${front.map((q) => q.join(',')).join(' ')}" fill="none" stroke="${col}" stroke-width="${S * 5}" stroke-linecap="round"/>`;
    const mid = W(0, loc.profile[Math.floor((loc.profile.length - 1) / 2)][1]);
    // texte placé du côté opposé au public de l'objet
    const nx = -sn, nz = c; const tx = mid[0] - nx * (d + S * 14), tz = mid[1] - nz * (d + S * 14);
    const sub = `${o.z ? o.cols * o.rows + " pan. · " : ''}${fmt(loc.width / 1000, 2)} m${num(pl.rot) ? ` · ${num(pl.rot) > 0 ? '+' : ''}${num(pl.rot)}°` : ''}${num(pl.z) ? ` · h ${fmt(num(pl.z) / 1000, 2)} m` : ''}`;
    s += `<text x="${tx}" y="${tz - S * 6}" font-size="${S * 13}" font-weight="700" text-anchor="middle" fill="${T.txt}" pointer-events="none">${esc(o.name)}</text>
      <text x="${tx}" y="${tz + S * 7}" font-size="${S * 10}" text-anchor="middle" fill="${T.mut}" pointer-events="none">${sub}</text></g>`;
  });
  // repère public + échelle
  s += `<text x="${vb.x + vb.w / 2}" y="${vb.y + vb.h - S * 12}" font-size="${S * 11}" text-anchor="middle" fill="${T.dim}" letter-spacing="${S * 3}">▼ PUBLIC ▼</text>`;
  const sx = vb.x + S * 20, sy = vb.y + vb.h - S * 18;
  s += `<line x1="${sx}" y1="${sy}" x2="${sx + 1000}" y2="${sy}" stroke="${T.mut}" stroke-width="${S * 2}"/><text x="${sx + 500}" y="${sy - S * 6}" font-size="${S * 10}" text-anchor="middle" fill="${T.mut}">1 m</text>`;
  s += `<text x="${vb.x + S * 14}" y="${vb.y + S * 20}" font-size="${S * 11}" fill="${T.mut}" letter-spacing="${S * 2}">IMPLANTATION — VUE DE DESSUS</text>`;
  return s + '</svg>';
}

/* ---------- Page « Vue 3D de la scène » ---------- */
function vScene() {
  const p = curProject(); if (!p) return vProjects();
  ensurePlacement(p);
  ui.sceneView = ui.sceneView || { yaw: -0.45, pitch: 0.32, zoom: 1, mode: 'damier', labels: true };
  const B = sceneBounds(p); const v = ui.sceneView;
  const tot = p.screens.reduce((a, s) => { const g = screenGeometry(s); a.m2 += g.surface; a.px += g.resW * g.resH; a.n += g.panels; a.kw += g.pMax / 1000; a.kg += g.weight; return a; }, { m2: 0, px: 0, n: 0, kw: 0, kg: 0 });
  const objs = sceneObjects(p);
  const inp = (o, k, step, val) => `<input type="number" step="${step}" data-pl="${k}" data-id="${o.key}" value="${val}" style="width:78px">`;
  return `<div class="crumbs"><a data-nav-go="projects">Projets</a> › <a data-act="openProject" data-id="${p.id}">${esc(p.name)}</a> › Vue 3D de la scène</div>
  <div class="page-head"><div><h1>🎬 Vue 3D de la scène</h1><div class="sub">${p.screens.length} écran(s) · ${fmt(tot.n)} dalles · ${fmt(tot.m2, 2)} m² · emprise ${fmt(B.w / 1000, 2)} × ${fmt(B.d / 1000, 2)} m · hauteur max ${fmt(B.mxY / 1000, 2)} m</div></div>
    <div class="row">${p.screens.some((x) => isBoard(x) && !x.deco) ? '<button data-act="sceneAround">⬚ Boarding autour du terrain</button>' : ''}<button data-act="sceneAlign">↔ Aligner côte à côte</button><button data-act="sceneExport3D">⇩ PNG 3D</button><button data-act="sceneExportPlan">⇩ PNG implantation</button><button class="primary" data-act="exportProjectPDF">⇩ Dossier PDF</button></div></div>
  ${p.screens.length ? `<div class="card" style="margin-bottom:16px;padding:12px">
    <div class="toolbar" style="margin-bottom:8px"><div class="seg">${[['face', 'Face', 0, 0.12], ['3q', '3/4', -0.55, 0.3], ['dessus', 'Dessus', 0, 1.35], ['gauche', 'Côté', -1.45, 0.15]].map(([k, l, y, pi]) => `<button data-act="sceneCam" data-y="${y}" data-p="${pi}">${l}</button>`).join('')}</div>
      <div class="seg"><button class="${v.mode !== 'ecran' ? 'on' : ''}" data-act="sceneMode" data-v="damier">Damier pixel map</button><button class="${v.mode === 'ecran' ? 'on' : ''}" data-act="sceneMode" data-v="ecran">Une couleur par écran</button></div>
      <label class="row small" style="gap:6px"><input type="checkbox" data-scene-labels ${v.labels !== false ? 'checked' : ''}>Noms</label></div>
    <canvas id="scene3d"></canvas></div>
  ${venueCardHTML(p)}
  <div class="editor" style="grid-template-columns:minmax(0,1.1fr) minmax(0,1fr)">
    <div class="card"><h3>Implantation — glissez les écrans</h3><div id="scenePlan" class="scene-plan">${scenePlanSVG(p)}</div>
      <div class="tiny muted" style="margin-top:6px">Glisser : déplacer (pas de 10 cm) · Molette sur un écran : rotation ±5° · le public est en bas.</div></div>
    <div class="card flat"><table><tr><th>Écran</th><th>X (m)</th><th>Profondeur (m)</th><th>Hauteur du bas (m)</th><th>Rotation (°)</th></tr>
      ${objs.map((o) => { const loc = objLocal(o); const pl = o.holder.place; return `<tr class="${ui.sceneSel === o.key ? 'sel-row' : ''}"><td><span class="dot" style="background:${o.color}"></span><a data-act="openScreen" data-id="${o.s.id}">${esc(o.name)}</a><div class="tiny muted">${o.z ? `${esc(o.s.name)} · ${o.cols} pan. · ${fmt(loc.width / 1000, 2)} m` : `${fmt(loc.width / 1000, 2)} × ${fmt(loc.height / 1000, 2)} m`}</div></td>
        <td>${inp(o, 'x', 0.1, fmt3(pl.x))}</td><td>${inp(o, 'y', 0.1, fmt3(pl.y))}</td><td>${inp(o, 'z', 0.1, fmt3(pl.z))}</td><td>${inp(o, 'rot', 5, num(pl.rot))}</td></tr>`; }).join('')}</table>
      <div class="tiny muted" style="padding:10px 14px">X : position du centre (0 = axe de la scène) · Profondeur : + vers le public · Hauteur du bas : 0 = posé au sol, sinon accroché / sur pied · Rotation : + = sens horaire vu de dessus.</div>
      <div style="padding:0 14px 14px" class="grid g3">
        <div class="big-stats" style="grid-template-columns:1fr"><div><span>Pixels total</span><b>${fmt(tot.px)}</b></div></div>
        <div class="big-stats" style="grid-template-columns:1fr"><div><span>Puissance max</span><b>${fmt(tot.kw, 1)} kW</b></div></div>
        <div class="big-stats" style="grid-template-columns:1fr"><div><span>Poids écrans</span><b>${fmt(tot.kg)} kg</b></div></div></div></div>
  </div>` : `<div class="card empty"><div class="e">🎬</div>Ajoutez des écrans au projet pour composer la scène.</div>`}`;
}
const fmt3 = (mm) => Math.round(num(mm)) / 1000;

/* ---------- Interactions ---------- */
function setupScene(p) {
  const c = document.getElementById('scene3d'); if (!c) return;
  const redraw = () => drawScene(c, p, ui.sceneView); redraw();
  venueEnsureLoaded(p).then((ch) => { if (ch && document.getElementById('scene3d') === c) render(); });
  let drag = null;
  c.onmousedown = (e) => { drag = { x: e.clientX, y: e.clientY, yaw: ui.sceneView.yaw, pitch: ui.sceneView.pitch }; };
  c.onwheel = (e) => { e.preventDefault(); ui.sceneView.zoom = Math.max(0.3, Math.min(5, ui.sceneView.zoom * (e.deltaY < 0 ? 1.1 : 0.9))); redraw(); };
  c.ondblclick = () => { Object.assign(ui.sceneView, { yaw: 0, pitch: 0.12, zoom: 1 }); redraw(); };
  // Plan : glisser-déposer
  const wrap = document.getElementById('scenePlan'); let pd = null;
  const toSvg = (svg, e) => { const pt = svg.createSVGPoint(); pt.x = e.clientX; pt.y = e.clientY; return pt.matrixTransform(svg.getScreenCTM().inverse()); };
  const refresh = (vb) => { wrap.innerHTML = scenePlanSVG(p, { vb }); redraw(); };
  wrap.onmousedown = (e) => {
    const g = e.target.closest('[data-scr]'); if (!g) return; e.preventDefault();
    const o = sceneObjects(p).find((x) => x.key === g.dataset.scr); const s = o.holder; const svg = wrap.querySelector('svg'); const q = toSvg(svg, e);
    const [x, y, w, h] = svg.dataset.vb.split(',').map(Number);
    ui.sceneSel = o.key; pd = { s, key: o.key, ox: q.x - num(s.place.x), oy: q.y - num(s.place.y), vb: { x, y, w, h } };
    refresh(pd.vb);
  };
  wrap.onwheel = (e) => {
    const g = e.target.closest('[data-scr]'); if (!g) return; e.preventDefault();
    const o = sceneObjects(p).find((x) => x.key === g.dataset.scr); const s = o.holder; let r = num(s.place.rot) + (e.deltaY < 0 ? 5 : -5); if (r > 180) r -= 360; if (r < -180) r += 360; s.place.rot = r;
    const svg = wrap.querySelector('svg'); const [x, y, w, h] = svg.dataset.vb.split(',').map(Number); ui.sceneSel = o.key;
    refresh({ x, y, w, h }); syncPlaceInputs(o.key, s); clearTimeout(ui.sceneSaveT); ui.sceneSaveT = setTimeout(() => Store.save(), 400);
  };
  window.onmousemove = (e) => {
    if (drag) { ui.sceneView.yaw = drag.yaw + (e.clientX - drag.x) / 200; ui.sceneView.pitch = Math.max(-0.2, Math.min(1.5, drag.pitch + (e.clientY - drag.y) / 200)); redraw(); }
    if (pd) { const q = toSvg(wrap.querySelector('svg'), e); pd.s.place.x = Math.round((q.x - pd.ox) / 100) * 100; pd.s.place.y = Math.round((q.y - pd.oy) / 100) * 100; refresh(pd.vb); syncPlaceInputs(pd.key, pd.s); }
  };
  window.onmouseup = () => { drag = null; if (pd) { pd = null; Store.save(); const y = $main().scrollTop; render(); $main().scrollTop = y; } };
}
function syncPlaceInputs(key, s) {
  ['x', 'y', 'z'].forEach((k) => { const el = document.querySelector(`[data-pl="${k}"][data-id="${key}"]`); if (el) el.value = fmt3(s.place[k]); });
  const el = document.querySelector(`[data-pl="rot"][data-id="${key}"]`); if (el) el.value = num(s.place.rot);
}
function sceneChange(t) {
  if (t.dataset.pl) {
    const p = curProject(); const o = p && sceneObjects(p).find((x) => x.key === t.dataset.id); if (!o) return true; const s = o.holder;
    s.place[t.dataset.pl] = t.dataset.pl === 'rot' ? Math.max(-180, Math.min(180, num(t.value))) : Math.round(num(t.value) * 1000);
    if (t.dataset.pl === 'z') s.place.z = Math.max(0, s.place.z);
    ui.sceneSel = o.key; Store.save(); const y = $main().scrollTop; render(); $main().scrollTop = y; return true;
  }
  if (t.dataset.sceneLabels !== undefined) { ui.sceneView.labels = t.checked; render(); return true; }
  return false;
}
function sceneImage(p, w, h) {
  const c = document.createElement('canvas'); drawScene(c, p, Object.assign({ yaw: -0.45, pitch: 0.32, zoom: 1, mode: 'damier', labels: true }, ui.sceneView || {}), { w, h });
  return c.toDataURL('image/png');
}
const sceneActions = {
  openScene() { go('scene', { projectId: ui.projectId }); },
  sceneAround() { const p = curProject(); if (!confirm('Disposer les zones de boarding sur les 4 côtés d\'un terrain ?')) return; p.screens.filter((x) => isBoard(x) && !x.deco).forEach((s) => arrangeAroundPitch(s, p)); Store.save(); render(); },
  sceneAlign() { if (!confirm('Replacer tous les écrans côte à côte, face au public ?')) return; alignScreens(curProject()); Store.save(); render(); },
  sceneCam(el) { Object.assign(ui.sceneView, { yaw: num(el.dataset.y), pitch: num(el.dataset.p), zoom: 1 }); render(); },
  sceneMode(el) { ui.sceneView.mode = el.dataset.v; render(); },
  async sceneExport3D() { const p = curProject(); await saveFileBase64(`${safeName(p.name)}_scene-3D.png`, dataURLtoB64(sceneImage(p, 1920, 1080)), 'png', 'Image PNG'); },
  async sceneExportPlan() { const p = curProject(); await saveFileBase64(`${safeName(p.name)}_implantation.png`, dataURLtoB64(await svgToPNG(scenePlanSVG(p, { light: true }).replace('style="width:100%;height:auto;display:block"', 'width="1600" height="' + Math.round(1600 * sceneBounds(p).d / sceneBounds(p).w) + '"'), 1)), 'png', 'Image PNG'); }
};
/* Page du dossier PDF */
function scenePdfPage(p, hdr) {
  if (!p.screens.length) return '';
  ensurePlacement(p);
  const B = sceneBounds(p);
  return `<div class="page">${hdr('Vue d\'ensemble de la scène')}
    <div class="two"><div style="flex:1.4"><img src="${sceneImage(p, 1400, 820)}" style="width:100%;border-radius:6px"></div>
    <div><div class="plan">${scenePlanSVG(p, { light: true })}</div>
    <table><tr><th>Élément</th><th>X</th><th>Prof.</th><th>H. bas</th><th>Rot.</th></tr>${sceneObjects(p).map((o) => { const pl = o.holder.place; return `<tr><td><b>${esc(o.full)}</b></td><td>${fmt(fmt3(pl.x), 2)} m</td><td>${fmt(fmt3(pl.y), 2)} m</td><td>${fmt(fmt3(pl.z), 2)} m</td><td>${num(pl.rot)}°</td></tr>`; }).join('')}</table>
    <div class="muted" style="margin-top:4px">Emprise ${fmt(B.w / 1000, 2)} × ${fmt(B.d / 1000, 2)} m · hauteur max ${fmt(B.mxY / 1000, 2)} m</div></div></div></div>`;
}
