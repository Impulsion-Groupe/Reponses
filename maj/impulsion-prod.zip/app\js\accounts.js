/* =====================================================================
   COMPTES — directeur technique, direction… (même droits pour tous)
   db.users = [{ id, name, title, color, pwd: { salt, hash } | null, createdAt }]
   Ce poste : db.local = { deviceId, userId, remember, sync }   (jamais partagé)
   ===================================================================== */
const USER_COLORS = ['#19a6cc', '#e6007e', '#f5a623', '#3ecf8e', '#9b6bff', '#ff6b4a', '#00c2b8', '#c8d64a'];
const USER_TITLES = ['Directeur technique', 'Direction', 'Chargé de production', 'Régisseur', 'Administratif'];

/* SHA-256 (fonctionne partout, même hors contexte sécurisé) */
function sha256(str) {
  const K = [0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da, 0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85, 0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070, 0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2];
  const bytes = Array.from(new TextEncoder().encode(str)); const l = bytes.length * 8;
  bytes.push(0x80); while (bytes.length % 64 !== 56) bytes.push(0);
  for (let i = 7; i >= 0; i--) bytes.push(i > 3 ? 0 : (l >>> (i * 8)) & 255);
  const H = [0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19];
  const r = (x, n) => (x >>> n) | (x << (32 - n)); const w = new Array(64);
  for (let o = 0; o < bytes.length; o += 64) {
    for (let i = 0; i < 16; i++) w[i] = (bytes[o + i * 4] << 24) | (bytes[o + i * 4 + 1] << 16) | (bytes[o + i * 4 + 2] << 8) | bytes[o + i * 4 + 3];
    for (let i = 16; i < 64; i++) { const s0 = r(w[i - 15], 7) ^ r(w[i - 15], 18) ^ (w[i - 15] >>> 3); const s1 = r(w[i - 2], 17) ^ r(w[i - 2], 19) ^ (w[i - 2] >>> 10); w[i] = (w[i - 16] + s0 + w[i - 7] + s1) | 0; }
    let [a, b, c, d, e, f, g, h] = H;
    for (let i = 0; i < 64; i++) {
      const t1 = (h + (r(e, 6) ^ r(e, 11) ^ r(e, 25)) + ((e & f) ^ (~e & g)) + K[i] + w[i]) | 0;
      const t2 = ((r(a, 2) ^ r(a, 13) ^ r(a, 22)) + ((a & b) ^ (a & c) ^ (b & c))) | 0;
      h = g; g = f; f = e; e = (d + t1) | 0; d = c; c = b; b = a; a = (t1 + t2) | 0;
    }
    [a, b, c, d, e, f, g, h].forEach((v, i) => { H[i] = (H[i] + v) | 0; });
  }
  return H.map((v) => (v >>> 0).toString(16).padStart(8, '0')).join('');
}
const pwdHash = (salt, pwd) => sha256(salt + ':' + pwd);
function makePwd(pwd) { if (!pwd) return null; const salt = randToken(12); return { salt, hash: pwdHash(salt, pwd) }; }
const pwdOk = (u, pwd) => !u.pwd || pwdHash(u.pwd.salt, pwd || '') === u.pwd.hash;

/* ---------- Ce poste ---------- */
function localInfo() {
  const db = Store.db; db.local = db.local || {};
  if (!db.local.deviceId) db.local.deviceId = 'd' + randToken(10);
  return db.local;
}
const users = () => (Store.db.users = Store.db.users || []);
const getUser = (id) => users().find((u) => u.id === id);
const curUser = () => getUser(localInfo().userId) || null;
const curUserName = () => (curUser() ? curUser().name : '');
const initials = (n) => String(n || '?').trim().split(/\s+/).map((x) => x[0]).slice(0, 2).join('').toUpperCase();
const avatar = (u, size = 34) => `<span class="avatar" style="width:${size}px;height:${size}px;font-size:${Math.round(size * 0.4)}px;background:${u ? u.color : '#555'}">${esc(initials(u ? u.name : '?'))}</span>`;
const needLogin = () => users().length > 0 && !curUser();

/* ---------- Écran de connexion ---------- */
/* État des données affiché sous la connexion (diagnostic en cas de souci) */
function loginDiag() {
  const d = Store.db || {}; const n = (k) => (d[k] || []).length; const sy = (d.local && d.local.sync) || {};
  return `Données : ${n('projects')} projet(s) · ${n('techs')} technicien(s) · ${n('products')} référence(s) · partage ${sy.on ? 'actif' : 'inactif'} · v${APP_VERSION}<br><span style="word-break:break-all">${esc(Store.path || '')}</span>`;
}
const loginState = { userId: null, err: '' };
function loginHTML() {
  const list = users(); const sel = getUser(loginState.userId) || (list.length === 1 ? list[0] : null);
  const remember = localInfo().remember !== false;
  return `<div class="login-card">
    <img src="assets/logo-white.png" alt="${esc(Store.db.settings.company)}" class="login-logo"><div class="brand-sub" style="text-align:center">PROD</div>
    <h2 style="text-align:center;margin:18px 0 6px">Qui êtes-vous ?</h2>
    <div class="login-users">${list.map((u) => `<button class="login-user ${sel && sel.id === u.id ? 'on' : ''}" data-act="loginPick" data-id="${u.id}">${avatar(u, 54)}<b>${esc(u.name)}</b><span class="tiny muted">${esc(u.title || '')}</span></button>`).join('')}</div>
    ${sel ? `<form class="login-form" onsubmit="return false">
      ${sel.pwd ? `<input type="password" id="loginPwd" placeholder="Mot de passe de ${esc(sel.name)}" autocomplete="current-password">` : '<div class="tiny muted" style="text-align:center">Pas de mot de passe sur ce compte.</div>'}
      ${loginState.err ? `<div class="alert bad" style="margin-top:8px">${esc(loginState.err)}</div>` : ''}
      <label class="row small" style="gap:8px;justify-content:center;margin-top:10px"><input type="checkbox" id="loginRemember" ${remember ? 'checked' : ''}>Rester connecté sur ce PC</label>
      <button class="primary" data-act="loginGo" style="width:100%;margin-top:12px">Entrer ✨</button>
      ${sel.pwd ? `<div style="text-align:center;margin-top:10px"><a class="tiny" data-act="loginForgot" style="cursor:pointer">Mot de passe oublié ou refusé ?</a></div>` : ''}</form>` : ''}
    <div class="tiny muted" style="text-align:center;margin-top:16px;line-height:1.5">${loginDiag()}</div>
  </div>`;
}
function showLogin() {
  let el = document.getElementById('login');
  if (!el) { el = document.createElement('div'); el.id = 'login'; document.body.appendChild(el); }
  el.innerHTML = loginHTML(); el.classList.remove('hidden');
  const pw = document.getElementById('loginPwd'); if (pw) { pw.focus(); pw.onkeydown = (e) => { if (e.key === 'Enter') accountActions.loginGo(); }; }
}
function hideLogin() { const el = document.getElementById('login'); if (el) el.classList.add('hidden'); }
function userChip() {
  const el = document.getElementById('userChip'); if (!el) return;
  const u = curUser(); const others = typeof syncOthers === 'function' ? syncOthers() : [];
  el.innerHTML = (u ? `<a class="user-chip" data-nav-go="accounts">${avatar(u, 26)}<span><b>${esc(u.name)}</b><br><span class="tiny muted">${esc(u.title || '')}</span></span></a>`
    : `<a class="user-chip" data-nav-go="accounts"><span class="avatar" style="width:26px;height:26px;background:#334">👤</span><span class="small">Comptes</span></a>`)
    + (others.length ? `<div class="tiny" style="margin-top:6px;color:#3ecf8e">● ${others.map((o) => esc(o.name || 'Autre poste')).join(', ')} ${others.length > 1 ? 'connectés' : 'connecté'}</div>` : '')
    + (typeof syncBadge === 'function' ? syncBadge() : '');
}

/* ---------- Page Comptes & synchronisation ---------- */
function vAccounts() {
  const list = users(); const me = curUser();
  const lastAct = (u) => { const e = (Store.db.log || []).find((x) => x.by === u.id); return e ? 'dernière action ' + agoTxt(e.at) : 'aucune action enregistrée'; };
  return `<div class="page-head"><div><h1>Comptes & partage</h1><div class="sub">Plusieurs personnes, plusieurs PC, les mêmes données</div></div>
    ${me ? `<div class="row"><button data-act="logout">⏏ Se déconnecter</button></div>` : ''}</div>
  <div class="grid g2">
  <div class="card"><h3>👥 Comptes</h3>
    ${list.length ? `<div class="acc-list">${list.map((u) => `<div class="acc-row">${avatar(u, 40)}<div style="flex:1"><b>${esc(u.name)}</b> ${me && me.id === u.id ? '<span class="tiny" style="color:#3ecf8e">● c\'est vous</span>' : ''}<div class="tiny muted">${esc(u.title || '')} · ${u.pwd ? '🔒 mot de passe' : '🔓 sans mot de passe'} · ${lastAct(u)}</div></div>
      <button class="sm" data-act="userEdit" data-id="${u.id}">✎ Modifier</button>${me && me.id !== u.id ? `<button class="sm ghost" data-act="userDel" data-id="${u.id}">✕</button>` : ''}</div>`).join('')}</div>
      <div class="row" style="margin-top:12px"><button class="primary" data-act="userNew">＋ Ajouter un compte</button></div>`
    : `<div class="alert">Aucun compte pour l'instant : l'application s'ouvre directement. Créez votre compte, puis celui de votre patron : chaque modification sera signée (historique « qui a fait quoi »).</div>
      <div class="row" style="margin-top:12px"><button class="primary" data-act="userNew">＋ Créer mon compte</button></div>`}
    <div class="tiny muted" style="margin-top:12px">Tous les comptes ont les mêmes droits. Le mot de passe protège l'accès à l'application sur un PC partagé ; il est stocké chiffré (empreinte), jamais en clair.</div>
  </div>
  ${syncCardHTML()}
  </div>`;
}
function userForm(u) {
  const isNew = !u.id;
  return `<h2>${isNew ? 'Nouveau compte' : 'Modifier le compte'}</h2>
  <div class="form" style="grid-template-columns:1fr 1fr">
    <label class="f">Nom affiché<input id="uName" value="${esc(u.name || '')}" placeholder="ex. Marc"></label>
    <label class="f">Fonction<input id="uTitle" list="uTitles" value="${esc(u.title || '')}" placeholder="ex. Direction"><datalist id="uTitles">${USER_TITLES.map((t) => `<option value="${esc(t)}">`).join('')}</datalist></label>
  </div>
  <div class="small muted" style="margin-top:12px">Couleur</div>
  <div class="row" style="gap:6px;margin-top:6px">${USER_COLORS.map((c) => `<button class="swatch ${u.color === c ? 'on' : ''}" style="background:${c}" data-act="userColor" data-v="${c}"></button>`).join('')}</div>
  <div class="form" style="grid-template-columns:1fr 1fr;margin-top:14px">
    <label class="f">${isNew ? 'Mot de passe (facultatif)' : 'Nouveau mot de passe'}<input id="uPwd" type="password" autocomplete="new-password" placeholder="${isNew ? 'laisser vide = sans mot de passe' : u.pwd ? 'laisser vide = inchangé' : 'laisser vide = sans mot de passe'}"></label>
    <label class="f">Confirmer<input id="uPwd2" type="password" autocomplete="new-password"></label>
  </div>
  ${!isNew && u.pwd ? `<label class="row small" style="gap:8px;margin-top:8px"><input type="checkbox" id="uNoPwd">Supprimer le mot de passe</label>` : ''}
  <div class="modal-actions"><button data-act="closeModal">Annuler</button><button class="primary" data-act="userSave">${isNew ? 'Créer le compte' : 'Enregistrer'}</button></div>`;
}
function agoTxt(iso) {
  const s = Math.max(0, (Date.now() - Date.parse(iso)) / 1000);
  if (s < 60) return 'à l\'instant'; if (s < 3600) return `il y a ${Math.round(s / 60)} min`; if (s < 86400) return `il y a ${Math.round(s / 3600)} h`;
  const d = Math.round(s / 86400); return d === 1 ? 'hier' : `il y a ${d} jours`;
}

const accountActions = {
  loginPick(el) { loginState.userId = el.dataset.id; loginState.err = ''; showLogin(); },
  loginGo() {
    const u = getUser(loginState.userId) || (users().length === 1 ? users()[0] : null); if (!u) return;
    const pw = document.getElementById('loginPwd');
    if (!pwdOk(u, pw ? pw.value : '')) { loginState.err = 'Mot de passe incorrect'; showLogin(); return; }
    const L = localInfo(); L.userId = u.id; L.remember = !!(document.getElementById('loginRemember') || {}).checked;
    loginState.err = ''; Store.saveNow(); hideLogin(); userChip(); render(); toast(`Bonjour ${u.name} 👋`);
  },
  loginForgot() {
    const u = getUser(loginState.userId) || (users().length === 1 ? users()[0] : null); if (!u) return;
    const np = prompt(`Nouveau mot de passe pour ${u.name} (au moins 3 caractères).\nAstuce : le navigateur propose parfois un ancien mot de passe enregistré — tapez-le plutôt à la main.`);
    if (np == null) return; if (np.length < 3) { loginState.err = 'Mot de passe trop court'; return showLogin(); }
    u.pwd = makePwd(np); const L = localInfo(); L.userId = u.id; L.remember = true;
    if (typeof journalAdd === 'function') journalAdd({ kind: 'info', type: 'user', ref: u.id, ic: '🔑', text: `mot de passe de ${u.name} réinitialisé sur ce poste` });
    loginState.err = ''; Store.save(); hideLogin(); userChip(); render(); toast(`Mot de passe changé ✔ Bonjour ${u.name} 👋`);
  },
  logout() { const L = localInfo(); journalFlush(); L.userId = null; Store.saveNow(); userChip(); if (needLogin()) showLogin(); else render(); },
  userNew() { ui.uEdit = { name: '', title: users().length ? 'Direction' : 'Directeur technique', color: USER_COLORS[users().length % USER_COLORS.length] }; openModal(userForm(ui.uEdit)); },
  userEdit(el) { ui.uEdit = deepClone(getUser(el.dataset.id)); openModal(userForm(ui.uEdit)); },
  userColor(el) { ui.uEdit.name = document.getElementById('uName').value; ui.uEdit.title = document.getElementById('uTitle').value; ui.uEdit.color = el.dataset.v; openModal(userForm(ui.uEdit)); },
  userSave() {
    const e = ui.uEdit; const name = document.getElementById('uName').value.trim(); const title = document.getElementById('uTitle').value.trim();
    const p1 = document.getElementById('uPwd').value; const p2 = document.getElementById('uPwd2').value; const noPwd = (document.getElementById('uNoPwd') || {}).checked;
    if (!name) return toast('Indiquez un nom', 'warn');
    if (p1 !== p2) return toast('Les deux mots de passe ne correspondent pas', 'warn');
    if (users().some((u) => u.id !== e.id && u.name.toLowerCase() === name.toLowerCase())) return toast('Ce nom est déjà utilisé', 'warn');
    const first = !users().length;
    if (!e.id) {
      const u = { id: uid('usr'), name, title, color: e.color, pwd: makePwd(p1), createdAt: new Date().toISOString() };
      users().push(u); if (first) { localInfo().userId = u.id; localInfo().remember = true; }
    } else {
      const u = getUser(e.id); Object.assign(u, { name, title, color: e.color }); if (noPwd) u.pwd = null; else if (p1) u.pwd = makePwd(p1);
    }
    Store.save(); closeModal(); userChip(); render();
    toast(first ? 'Compte créé — vous êtes connecté ✔' : 'Compte enregistré ✔');
  },
  userDel(el) {
    const u = getUser(el.dataset.id); if (!u || (curUser() && curUser().id === u.id)) return;
    if (!confirm(`Supprimer le compte « ${u.name} » ? Son historique reste visible.`)) return;
    Store.db.users = users().filter((x) => x.id !== u.id); Store.save(); render();
  }
};
