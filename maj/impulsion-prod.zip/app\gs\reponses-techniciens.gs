/**
 * Impulsion LED Manager — réponses des techniciens en 1 clic
 * ----------------------------------------------------------
 * À coller dans un projet Google Apps Script (script.google.com) puis à déployer en « Application Web » :
 *   Exécuter en tant que : Moi   ·   Qui a accès : Tout le monde
 * Les demandes et les réponses sont rangées dans un tableur Google Sheets créé automatiquement
 * dans votre Google Drive : « Impulsion LED – Réponses techniciens ».
 */
var VERSION = 18;
var KEY = '__KEY__';
var COMPANY = '__COMPANY__';

function doGet(e) {
  var q = (e && e.parameter) || {};
  if (q.action) return api_(q);
  if (q.f) return fdrPage_(String(q.f));
  return page_(String(q.t || ''));
}

/* ---------- API utilisée par l'application ---------- */
function api_(q) {
  // Accès publics par jeton (pages hébergées sur GitHub Pages : pas de compte Google côté technicien)
  if (q.action === 'info') { var it = String(q.t || ''); var inf = findInfo_(it); return json_({ ok: true, version: VERSION, info: inf, last: inf ? lastReply_(it) : null, company: (inf && inf.company) || COMPANY }); }
  if (q.action === 'fdr') { var fd = loadFdr_(String(q.f || '')); return json_({ ok: true, version: VERSION, d: fd, company: (fd && fd.company) || COMPANY }); }
  if (q.action === 'indget') { return json_({ ok: true, version: VERSION, ind: indGet_(String(q.e || '')) }); }
  if (q.key !== KEY) return json_({ ok: false, error: 'Clé invalide' });
  if (q.action === 'indlist') {
    var sh0 = book_().getSheetByName('indispos'); var since0 = Number(q.since || 0);
    var rows0 = !sh0 ? [] : sh0.getDataRange().getValues().slice(1).map(function (r) { return { e: String(r[0]), at: new Date(r[1]).getTime(), days: String(r[2] || '').replace(/^j:/, '').split(',').filter(Boolean), note: String(r[3] || '').replace(/^'/, '') }; }).filter(function (r) { return r.at > since0; });
    return json_({ ok: true, version: VERSION, rows: rows0 });
  }
  if (q.action === 'calcheck') { try { return json_({ ok: true, version: VERSION, name: cal_().getName() }); } catch (err) { return json_({ ok: false, error: 'Google Agenda non autorisé : dans Apps Script, exécutez la fonction autoriserAgenda (' + (err && err.message ? err.message : err) + ')' }); } }
  if (q.action === 'ping') { book_(); return json_({ ok: true, version: VERSION, sheet: book_().getUrl() }); }
  if (q.action === 'register') {
    var items = JSON.parse(q.items || '[]');
    var lock = LockService.getScriptLock(); lock.waitLock(20000);
    try {
      var sh = book_().getSheetByName('demandes');
      var data = sh.getDataRange().getValues(); var idx = {};
      for (var i = 1; i < data.length; i++) idx[String(data[i][0])] = i + 1;
      items.forEach(function (it) {
        var row = [String(it.t), new Date(), JSON.stringify(it.info || {})];
        if (idx[it.t]) sh.getRange(idx[it.t], 1, 1, 3).setValues([row]); else sh.appendRow(row);
      });
    } finally { lock.releaseLock(); }
    return json_({ ok: true });
  }
  if (q.action === 'reglist') { // demandes envoyées (pour reconstituer un projet perdu) — q.id : une autre feuille (ancienne)
    var dm = (q.id ? SpreadsheetApp.openById(String(q.id)) : book_()).getSheetByName('demandes').getDataRange().getValues().slice(1).map(function (r) { var inf = null; try { inf = JSON.parse(r[2]); } catch (e) {} return { t: String(r[0]), at: new Date(r[1]).getTime(), info: inf }; });
    return json_({ ok: true, rows: dm, version: VERSION });
  }
  if (q.action === 'list') {
    var since = Number(q.since || 0);
    var rows = (q.id ? SpreadsheetApp.openById(String(q.id)) : book_()).getSheetByName('reponses').getDataRange().getValues().slice(1)
      .map(function (r) { return { t: String(r[0]), at: new Date(r[1]).getTime(), status: String(r[2]), dates: String(r[3] || '').replace(/^j:/, '').split(',').filter(Boolean), comment: String(r[4] || '').replace(/^'/, ''), kind: String(r[5] || '') }; })
      .filter(function (r) { return r.at > since; });
    return json_({ ok: true, rows: rows, version: VERSION });
  }
  return json_({ ok: false, error: 'Action inconnue' });
}

/* ---------- Appelé par la page du technicien ---------- */
function respond(t, status, dates, comment) {
  t = String(t || '');
  if (['valide', 'option', 'indispo', 'confirme'].indexOf(status) < 0) throw new Error('Réponse invalide');
  var info = findInfo_(t); if (!info) throw new Error('Demande introuvable');
  var allowed = (info.days || []).map(function (d) { return d.d; });
  dates = (dates || []).map(String).filter(function (d) { return allowed.indexOf(d) >= 0; });
  comment = String(comment || '').slice(0, 500);
  if (/^[=+\-@]/.test(comment)) comment = "'" + comment;
  var lock = LockService.getScriptLock(); lock.waitLock(20000);
  try { book_().getSheetByName('reponses').appendRow([t, new Date(), status, 'j:' + dates.join(','), comment, info.kind || 'booking']); }
  finally { lock.releaseLock(); }
  return true;
}

/* ---------- Stockage ---------- */
function book_() {
  var props = PropertiesService.getScriptProperties();
  var id = props.getProperty('SHEET_ID'), ss = null;
  if (id) {
    // v16 : si la feuille existe déjà, on ne la remplace JAMAIS par une nouvelle (une erreur passagère de Google
    // créait auparavant une feuille vide, et les données semblaient disparaître)
    for (var k = 0; k < 3 && !ss; k++) { try { ss = SpreadsheetApp.openById(id); } catch (err) { Utilities.sleep(700); } }
    if (!ss) throw new Error('Feuille Google des données momentanément inaccessible : réessayez dans une minute (rien n\'est perdu).');
    return ss;
  }
  if (!ss) {
    ss = SpreadsheetApp.create('Impulsion LED – Réponses techniciens');
    var d = ss.getSheets()[0]; d.setName('demandes'); d.appendRow(['jeton', 'envoyée le', 'infos']);
    ss.insertSheet('reponses').appendRow(['jeton', 'date', 'statut', 'jours', 'commentaire', 'type']);
    props.setProperty('SHEET_ID', ss.getId());
  }
  return ss;
}
function findInfo_(t) {
  if (!t) return null;
  var data = book_().getSheetByName('demandes').getDataRange().getValues();
  for (var i = data.length - 1; i >= 1; i--) if (String(data[i][0]) === t) { try { return JSON.parse(data[i][2]); } catch (e) { return null; } }
  return null;
}
function lastReply_(t) {
  var data = book_().getSheetByName('reponses').getDataRange().getValues();
  for (var i = data.length - 1; i >= 1; i--) if (String(data[i][0]) === t) return { status: String(data[i][2]) };
  return null;
}
function json_(o) { return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON); }
function esc_(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }

/* ---------- Page du technicien ---------- */
function page_(t) {
  var info = t ? findInfo_(t) : null;
  var data = { t: t, info: info, last: info ? lastReply_(t) : null, company: (info && info.company) || COMPANY };
  var json = JSON.stringify(data).replace(/</g, '\\u003c');
  var html = PAGE.replace('__DATA__', function () { return json; }).replace(/__COMPANY__/g, function () { return esc_(data.company); });
  return HtmlService.createHtmlOutput(html).setTitle('Disponibilité – ' + data.company)
    .addMetaTag('viewport', 'width=device-width, initial-scale=1');
}

var PAGE = `<!doctype html><html><head><base target="_top"><meta charset="utf-8">
<style>
body{margin:0;font-family:-apple-system,"Segoe UI",Roboto,Arial,sans-serif;background:#0a1014;color:#e9f0f3}
.wrap{max-width:480px;margin:0 auto;padding:22px 16px 40px}
.brand{font-size:24px;font-weight:300;letter-spacing:.02em}
.sub{font-size:10px;letter-spacing:.42em;color:#19a6cc;margin:4px 0 18px}
.leds{display:flex;gap:3px;margin:8px 0 2px}.leds i{width:9px;height:6px;border-radius:2px;background:#19a6cc;opacity:.25;animation:l 1.4s infinite}
@keyframes l{50%{opacity:1;box-shadow:0 0 6px #19a6cc}}
.card{background:#111a20;border:1px solid #233540;border-radius:16px;padding:18px;margin-bottom:14px}
h1{font-size:21px;margin:2px 0 10px}.muted{color:#8ba2ae;font-size:14px}
.row{margin:7px 0;font-size:15px}
.days{display:flex;flex-wrap:wrap;gap:8px;margin-top:10px}
.day{display:flex;align-items:center;gap:7px;background:#16222a;border:1px solid #2f4552;border-radius:22px;padding:9px 13px;font-size:15px}
.day input{width:20px;height:20px;accent-color:#19a6cc;margin:0}
.btn{display:block;width:100%;border:none;border-radius:14px;padding:17px;font-size:18px;font-weight:700;margin:10px 0;cursor:pointer;color:#06131a}
.btn:disabled{opacity:.5}
.yes{background:#3ccf8e}.opt{background:#5b8cff;color:#fff}.no{background:#ff5d6c;color:#fff}
textarea{width:100%;box-sizing:border-box;background:#0c1418;color:#e9f0f3;border:1px solid #2f4552;border-radius:10px;padding:11px;font:inherit;font-size:15px;min-height:70px;margin-top:6px}
.done{text-align:center;font-size:18px;padding:30px 12px;line-height:1.5}.done .big{font-size:60px}
.chip{background:#16222a;border:1px solid #2f4552;border-radius:22px;padding:8px 13px;font-size:15px}
.note{background:rgba(91,140,255,.12);border:1px solid rgba(91,140,255,.4);border-radius:12px;padding:11px 12px;font-size:14px;margin-top:12px;line-height:1.45}
.prev{background:rgba(25,166,204,.12);border:1px solid rgba(25,166,204,.35);border-radius:12px;padding:12px;font-size:14px;margin-bottom:14px}
</style></head><body><div class="wrap">
<div class="brand">__COMPANY__</div><div class="leds"><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i></div><div class="sub" id="sub">DEMANDE DE DISPONIBILITÉ</div>
<div id="app"></div></div>
<script>
var D = __DATA__;
var app = document.getElementById('app');
var LBL = { valide: '✅ Disponible', option: '🟦 Option acceptée', indispo: '❌ Pas disponible', confirme: '📌 Présence confirmée' };
var KIND = (D.info && D.info.kind) || 'booking';
var SUB = { option: 'DEMANDE D’OPTION', booking: 'DEMANDE DE DISPONIBILITÉ', confirm: 'CONFIRMATION DE BOOKING' };
Array.prototype.forEach.call(document.querySelectorAll('.leds i'), function (x, i) { x.style.animationDelay = (i * 0.1) + 's'; });
document.getElementById('sub').textContent = SUB[KIND] || SUB.booking;
function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
function btns(on) { Array.prototype.forEach.call(document.querySelectorAll('.btn'), function (b) { b.disabled = !on; }); }
function show() {
  if (!D.info) { app.innerHTML = '<div class="card done"><div class="big">🤔</div>Ce lien n’est pas (ou plus) valide.<br><span class="muted">Contactez ' + esc(D.company) + '.</span></div>'; return; }
  var i = D.info, days = i.days || [], h = '<div class="card"><div class="muted">Bonjour ' + esc(i.prenom) + ' 👋</div><h1>' + esc(i.projet) + '</h1>';
  if (i.lieu) h += '<div class="row">📍 ' + esc(i.lieu) + '</div>';
  if (i.role) h += '<div class="row">🛠️ ' + esc(i.role) + '</div>';
  if (KIND === 'confirm') {
    h += '<div class="row">📅 Jours bookés :</div><div class="days">' + days.map(function (d) { return '<span class="chip">' + esc(d.l) + '</span>'; }).join('') + '</div>';
    h += '<div class="note" style="background:rgba(60,207,142,.12);border-color:rgba(60,207,142,.4)">📌 C’est officiel : votre booking est <b>confirmé</b>. Merci de confirmer votre présence.</div>';
  } else {
    h += '<div class="row">📅 Jours demandés :</div><div class="days">' + days.map(function (d) { return '<label class="day"><input type="checkbox" value="' + esc(d.d) + '" checked>' + esc(d.l) + '</label>'; }).join('') + '</div>';
    if (days.length > 1) h += '<div class="muted" style="margin-top:10px">Décochez les jours où vous n’êtes pas disponible.</div>';
    if (KIND === 'option') h += '<div class="note">🟦 Il s’agit d’une <b>option</b> (pré-réservation) : ce n’est pas encore une confirmation. ' + esc(D.company) + ' reviendra vers vous pour valider officiellement le booking.</div>';
  }
  h += '</div>';
  if (D.last && LBL[D.last.status]) h += '<div class="prev">Votre réponse actuelle : <b>' + LBL[D.last.status] + '</b> — vous pouvez la modifier.</div>';
  h += '<div class="card">';
  if (KIND === 'confirm') h += '<button class="btn yes" data-s="confirme">📌 Je confirme ma présence</button><button class="btn no" data-s="indispo">❌ Je ne peux plus venir</button>';
  else if (KIND === 'option') h += '<button class="btn opt" data-s="option">🟦 OK, je bloque ces dates</button><button class="btn no" data-s="indispo">❌ Pas disponible</button>';
  else h += '<button class="btn yes" data-s="valide">✅ Je suis disponible</button><button class="btn no" data-s="indispo">❌ Pas disponible</button>';
  h += '<textarea id="c" placeholder="Un commentaire ? (facultatif)"></textarea></div>';
  app.innerHTML = h;
  Array.prototype.forEach.call(document.querySelectorAll('.btn'), function (b) { b.onclick = function () { send(b.getAttribute('data-s')); }; });
}
function send(s) {
  var days = KIND === 'confirm' ? (D.info.days || []).map(function (d) { return d.d; })
    : Array.prototype.map.call(document.querySelectorAll('.day input:checked'), function (x) { return x.value; });
  if (s !== 'indispo' && !days.length) { alert('Cochez au moins un jour (ou choisissez « Pas disponible »).'); return; }
  if (s === 'indispo' && KIND === 'confirm' && !confirm('Vous ne pourrez plus venir alors que le booking est confirmé ? ' + D.company + ' sera prévenu immédiatement.')) return;
  var c = document.getElementById('c').value; btns(false);
  google.script.run
    .withSuccessHandler(function () {
      var msg = s === 'indispo' ? (KIND === 'confirm' ? 'C’est noté, ' + esc(D.company) + ' est prévenu.' : 'Pas de souci, merci d’avoir répondu.')
        : KIND === 'option' ? 'Les dates sont bloquées en option. Vous recevrez la confirmation officielle du booking.'
        : KIND === 'confirm' ? 'Présence confirmée, à bientôt sur le projet !' : 'Réponse enregistrée : ' + LBL[s];
      app.innerHTML = '<div class="card done"><div class="big">' + (s === 'indispo' ? '👍' : '🎉') + '</div><b>Merci ' + esc(D.info.prenom) + ' !</b><br>' + msg + '<br><br><span class="muted">Vous pouvez fermer cette page.<br>Pour changer d’avis, rouvrez simplement le lien.</span></div>';
    })
    .withFailureHandler(function (e) { alert('Oups, la réponse n’a pas pu être envoyée : ' + (e && e.message ? e.message : e)); btns(true); })
    .respond(D.t, s, days, c);
}
show();
</script></body></html>`;

/* ---------- Feuilles de route (v3) : publiées par l'application, consultées sur téléphone ---------- */
function doPost(e) {
  var q = {};
  try { q = JSON.parse((e && e.postData && e.postData.contents) || '{}'); } catch (err) { return json_({ ok: false, error: 'Données illisibles' }); }
  if (q.action === 'respond') { try { respond(q.t, q.s, q.dates, q.comment); return json_({ ok: true }); } catch (err) { return json_({ ok: false, error: String(err && err.message ? err.message : err) }); } }
  if (q.action === 'indispo') { try { indSet_(q); return json_({ ok: true, version: VERSION }); } catch (err) { return json_({ ok: false, error: String(err && err.message ? err.message : err) }); } }
  if (q.key !== KEY) return json_({ ok: false, error: 'Clé invalide' });
  if (q.action === 'file') return json_(saveFile_(q));
  if (q.action === 'dbget') return json_(dbGet_(q));
  if (q.action === 'dbput') return json_(dbPut_(q));
  if (q.action === 'usesheet') { // reconnecter le relais à une feuille existante (l'ancienne, avec tout l'historique)
    try {
      var nb = SpreadsheetApp.openById(String(q.id || '')); if (!nb.getSheetByName('demandes') || !nb.getSheetByName('reponses')) return json_({ ok: false, error: 'Ce fichier n\'est pas une feuille « Impulsion LED – Réponses techniciens ».' });
      var lk = LockService.getScriptLock(); lk.waitLock(20000);
      try { props_().setProperty('SHEET_ID', nb.getId()); props_().setProperty('dbRev', String(dbRev_() + 1)); } finally { lk.releaseLock(); }
      return json_({ ok: true, version: VERSION, sheet: nb.getName(), url: nb.getUrl() });
    } catch (err) { return json_({ ok: false, error: 'Fichier inaccessible : ' + (err && err.message ? err.message : err) }); }
  }
  if (q.action === 'sheetsall') { // toutes les feuilles « Impulsion LED – Réponses techniciens » du Drive
    var cur = props_().getProperty('SHEET_ID'); var out = []; var it = DriveApp.getFilesByName('Impulsion LED – Réponses techniciens');
    while (it.hasNext()) {
      var f = it.next(); if (f.isTrashed()) continue; var o = { id: f.getId(), url: f.getUrl(), created: f.getDateCreated().getTime(), updated: f.getLastUpdated().getTime(), current: f.getId() === cur };
      try { var b2 = SpreadsheetApp.openById(o.id); var d2 = b2.getSheetByName('demandes'), r2 = b2.getSheetByName('reponses'); o.demandes = d2 ? Math.max(0, d2.getLastRow() - 1) : 0; o.reponses = r2 ? Math.max(0, r2.getLastRow() - 1) : 0;
        var db2 = dbLoad_(b2); o.projects = db2 && db2.projects ? db2.projects.length : 0; } catch (e) { o.error = String(e.message || e); }
      out.push(o);
    }
    out.sort(function (a, b) { return a.created - b.created; });
    return json_({ ok: true, version: VERSION, sheets: out });
  }
  if (q.action === 'consolidate') { // regroupe demandes + réponses de toutes les feuilles dans la feuille choisie, puis l'utilise
    var tgt = SpreadsheetApp.openById(String(q.id || '')); var lk2 = LockService.getScriptLock(); lk2.waitLock(30000); var added = { demandes: 0, reponses: 0 };
    try {
      ['demandes', 'reponses'].forEach(function (nm) {
        var ts = tgt.getSheetByName(nm); if (!ts) { ts = tgt.insertSheet(nm); ts.appendRow(nm === 'demandes' ? ['jeton', 'envoyée le', 'infos'] : ['jeton', 'date', 'statut', 'jours', 'commentaire', 'type']); }
        var have = {}; ts.getDataRange().getValues().slice(1).forEach(function (r) { have[String(r[0]) + '|' + new Date(r[1]).getTime()] = 1; });
        var add = [];
        (q.ids || []).forEach(function (sid) { if (sid === tgt.getId()) return; try { var src = SpreadsheetApp.openById(sid).getSheetByName(nm); if (!src) return;
          src.getDataRange().getValues().slice(1).forEach(function (r) { var k = String(r[0]) + '|' + new Date(r[1]).getTime(); if (!r[0] || have[k]) return; have[k] = 1; add.push(r.slice(0, nm === 'demandes' ? 3 : 6)); }); } catch (e) {} });
        if (add.length) { var w = nm === 'demandes' ? 3 : 6; add = add.map(function (r) { while (r.length < w) r.push(''); return r; }); ts.getRange(ts.getLastRow() + 1, 1, add.length, w).setValues(add); added[nm] = add.length; }
      });
      // la feuille gardée reprend les données partagées actuelles si elle n'en a pas
      var curId = props_().getProperty('SHEET_ID');
      if (curId && curId !== tgt.getId() && dbEmpty_(tgt)) { var curData = dbLoad_(SpreadsheetApp.openById(curId)); if (curData) { props_().setProperty('SHEET_ID', tgt.getId()); dbSave_(JSON.stringify(curData)); } }
      props_().setProperty('SHEET_ID', tgt.getId()); props_().setProperty('dbRev', String(dbRev_() + 1));
    } finally { lk2.releaseLock(); }
    return json_({ ok: true, version: VERSION, added: added, url: tgt.getUrl() });
  }
  if (q.action === 'sheetinfo') { var cb = book_(); return json_({ ok: true, version: VERSION, id: cb.getId(), url: cb.getUrl(), created: DriveApp.getFileById(cb.getId()).getDateCreated().getTime() }); }
  if (q.action === 'dbfrom') { // lecture d'une ancienne version (copie faite depuis l'historique des versions Google Sheets)
    try { var old = dbLoad_(SpreadsheetApp.openById(String(q.id || ''))); return json_(old ? { ok: true, version: VERSION, data: old } : { ok: false, error: 'Aucune donnée dans ce fichier (onglet « donnees » vide ?)' }); }
    catch (err) { return json_({ ok: false, error: 'Fichier inaccessible : ' + (err && err.message ? err.message : err) }); }
  }
  if (q.action === 'cal') { try { return json_({ ok: true, version: VERSION, results: calSync_(q.items || []) }); } catch (err) { return json_({ ok: false, error: 'Agenda : ' + (err && err.message ? err.message : err) }); } }
  var t = String(q.token || '');
  if (!/^[a-z0-9]{8,40}$/.test(t)) return json_({ ok: false, error: 'Jeton invalide' });
  if (q.action === 'publish') { saveFdr_(t, JSON.stringify(q.data || {})); return json_({ ok: true, version: VERSION }); }
  if (q.action === 'unpublish') { saveFdr_(t, null); return json_({ ok: true, version: VERSION }); }
  return json_({ ok: false, error: 'Action inconnue' });
}
/* ---------- Fichiers techniques (RCG…) sur Google Drive (v10) ---------- */
function fileFolder_() { var name = 'Impulsion LED – Fichiers techniques'; var it = DriveApp.getFoldersByName(name); return it.hasNext() ? it.next() : DriveApp.createFolder(name); }
function saveFile_(q) {
  if (q.prev) { try { DriveApp.getFileById(String(q.prev)).setTrashed(true); } catch (e) { /* déjà supprimé */ } }
  var blob = Utilities.newBlob(Utilities.base64Decode(String(q.b64 || '')), String(q.mime || 'application/octet-stream'), String(q.name || 'fichier'));
  var f = fileFolder_().createFile(blob);
  try { f.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW); } catch (e) { /* partage restreint par l'administrateur */ }
  return { ok: true, id: f.getId(), url: 'https://drive.google.com/uc?export=download&id=' + f.getId(), view: f.getUrl(), version: VERSION };
}
/* À exécuter une fois dans l'éditeur (▶) pour autoriser l'accès à Google Drive */
function autoriserFichiers() { var f = fileFolder_(); Logger.log('Accès Google Drive autorisé ✔ — dossier : ' + f.getName()); }

/* ---------- Données partagées entre plusieurs postes (v9) ---------- */
function props_() { return PropertiesService.getScriptProperties(); }
function dbRev_() { return Number(props_().getProperty('dbRev') || 0); }
function dbSheet_() {
  var ss = book_(); var sh = ss.getSheetByName('donnees');
  if (!sh) { sh = ss.insertSheet('donnees'); sh.appendRow(['morceau', 'contenu']); }
  return sh;
}
function dbLoad_(book) {
  var sh = (book || book_()).getSheetByName('donnees'); if (!sh || sh.getLastRow() < 2) return null;
  var rows = sh.getRange(2, 1, sh.getLastRow() - 1, 2).getValues().filter(function (r) { return /^c:/.test(String(r[1])); }).sort(function (a, b) { return Number(a[0]) - Number(b[0]); });
  try { return JSON.parse(rows.map(function (r) { return String(r[1]).replace(/^c:/, ''); }).join('')); } catch (e) { return null; }
}
/* aucune donnée enregistrée dans cette feuille (feuille neuve) ≠ données illisibles */
function dbEmpty_(book) { var sh = (book || book_()).getSheetByName('donnees'); if (!sh || sh.getLastRow() < 2) return true; return !sh.getRange(2, 2, sh.getLastRow() - 1, 1).getValues().some(function (r) { return /^c:/.test(String(r[0])); }); }
function dbSave_(txt) {
  var sh = dbSheet_(); if (sh.getLastRow() > 1) sh.getRange(2, 1, sh.getLastRow() - 1, 2).clearContent();
  var rows = [], size = 40000;
  for (var k = 0, n = 0; k < txt.length; k += size, n++) rows.push([n, 'c:' + txt.substr(k, size)]);
  sh.getRange(2, 1, rows.length, 2).setValues(rows);
}
/* Présence des postes + « poste principal » (celui qui gère l'agenda et les réponses automatiques) */
function presence_(q) {
  var pr = props_(); var now = Date.now(); var dev = String(q.dev || ''); var leader = false;
  var pres = {}; try { pres = JSON.parse(pr.getProperty('presence') || '{}'); } catch (e) { pres = {}; }
  if (dev) pres[dev] = { name: String(q.user || ''), at: now, v: String(q.app || '') };
  for (var d in pres) if (now - pres[d].at > 24 * 3600000) delete pres[d];
  var lease = null; try { lease = JSON.parse(pr.getProperty('lease') || 'null'); } catch (e) { lease = null; }
  var noLease = q.nolease === 1 || q.nolease === '1' || q.nolease === true; // téléphones : jamais poste principal
  if (dev && !noLease && (!lease || lease.until < now || lease.dev === dev)) { lease = { dev: dev, until: now + 120000 }; pr.setProperty('lease', JSON.stringify(lease)); }
  leader = !!(lease && lease.dev === dev);
  pr.setProperty('presence', JSON.stringify(pres));
  return { presence: pres, leader: leader, now: now };
}
function dbGet_(q) {
  var p = presence_(q); var rev = dbRev_();
  var out = { ok: true, version: VERSION, rev: rev, presence: p.presence, leader: p.leader, now: p.now };
  if (Number(q.rev || 0) !== rev && rev > 0) {
    var lock = LockService.getScriptLock(); lock.waitLock(20000);
    try { out.rev = dbRev_(); out.data = dbLoad_(); if (!out.data) out.empty = dbEmpty_(); } finally { lock.releaseLock(); }
  }
  return out;
}
function dbPut_(q) {
  var lock = LockService.getScriptLock(); lock.waitLock(30000);
  try {
    var rev = dbRev_();
    if (Number(q.baseRev || 0) !== rev) return { ok: true, conflict: true, rev: rev, version: VERSION };
    dbSave_(JSON.stringify(q.data || {}));
    rev = rev + 1; props_().setProperty('dbRev', String(rev));
    props_().setProperty('dbBy', String(q.user || '') + ' · ' + new Date().toISOString());
    return { ok: true, rev: rev, version: VERSION };
  } finally { lock.releaseLock(); }
}

function fdrSheet_() {
  var ss = book_(); var sh = ss.getSheetByName('feuilles');
  if (!sh) { sh = ss.insertSheet('feuilles'); sh.appendRow(['jeton', 'mise à jour', 'morceau', 'contenu']); }
  return sh;
}
/* ---------- Indisponibilités déclarées par les techniciens (espace « Mes bookings ») ---------- */
function indSheet_() { var ss = book_(); var sh = ss.getSheetByName('indispos'); if (!sh) { sh = ss.insertSheet('indispos'); sh.appendRow(['espace', 'date', 'jours', 'note']); } return sh; }
function indGet_(e) {
  var sh = book_().getSheetByName('indispos'); if (!sh || !e) return null; var v = sh.getDataRange().getValues();
  for (var i = v.length - 1; i >= 1; i--) if (String(v[i][0]) === e) return { at: new Date(v[i][1]).getTime(), days: String(v[i][2] || '').replace(/^j:/, '').split(',').filter(Boolean), note: String(v[i][3] || '').replace(/^'/, '') };
  return null;
}
function indSet_(q) {
  var e = String(q.e || ''); if (!/^esp[a-z0-9]{8,37}$/.test(e)) throw new Error('Lien invalide');
  var d = loadFdr_(e); if (!d || d.kind !== 'espace') throw new Error('Cet espace n\'existe plus : demandez un nouveau lien.');
  var days = (q.days || []).map(String).filter(function (x) { return /^\d{4}-\d{2}-\d{2}$/.test(x); }).slice(0, 400);
  var note = String(q.note || '').slice(0, 300);
  var lock = LockService.getScriptLock(); lock.waitLock(20000);
  try {
    var sh = indSheet_(); var v = sh.getDataRange().getValues();
    for (var i = v.length - 1; i >= 1; i--) if (String(v[i][0]) === e) sh.deleteRow(i + 1);
    sh.appendRow([e, new Date(), 'j:' + days.join(','), "'" + note]);
  } finally { lock.releaseLock(); }
}
function saveFdr_(t, txt) {
  var lock = LockService.getScriptLock(); lock.waitLock(30000);
  try {
    var sh = fdrSheet_(); var data = sh.getDataRange().getValues();
    for (var i = data.length - 1; i >= 1; i--) if (String(data[i][0]) === t) sh.deleteRow(i + 1);
    if (txt == null) return;
    var rows = [], now = new Date(), size = 40000;
    for (var k = 0, n = 0; k < txt.length; k += size, n++) rows.push([t, now, n, 'c:' + txt.substr(k, size)]);
    if (!rows.length) rows.push([t, now, 0, 'c:{}']);
    sh.getRange(sh.getLastRow() + 1, 1, rows.length, 4).setValues(rows);
  } finally { lock.releaseLock(); }
}
function loadFdr_(t) {
  if (!t) return null; var sh = book_().getSheetByName('feuilles'); if (!sh) return null;
  var parts = sh.getDataRange().getValues().slice(1).filter(function (r) { return String(r[0]) === t; }).sort(function (a, b) { return Number(a[2]) - Number(b[2]); });
  if (!parts.length) return null;
  try { return JSON.parse(parts.map(function (r) { return String(r[3]).replace(/^c:/, ''); }).join('')); } catch (e) { return null; }
}
function fdrPage_(t) {
  var d = loadFdr_(t); var company = (d && d.company) || COMPANY;
  var json = JSON.stringify({ d: d, t: t, company: company }).replace(/</g, '\\u003c');
  var html = PAGE_FDR.replace('__DATA__', function () { return json; }).replace(/__COMPANY__/g, function () { return esc_(company); });
  return HtmlService.createHtmlOutput(html).setTitle('Feuille de route – ' + (d && d.project ? d.project.name : company))
    .addMetaTag('viewport', 'width=device-width, initial-scale=1');
}

var PAGE_FDR = `<!doctype html><html><head><base target="_top"><meta charset="utf-8">
<style>
body{margin:0;font-family:-apple-system,"Segoe UI",Roboto,Arial,sans-serif;background:#0a1014;color:#e9f0f3}
.wrap{max-width:720px;margin:0 auto;padding:18px 14px 50px}
.brand{font-size:22px;font-weight:300}.sub{font-size:10px;letter-spacing:.42em;color:#19a6cc;margin:4px 0 14px}
.leds{display:flex;gap:3px;margin:8px 0 2px}.leds i{width:9px;height:6px;border-radius:2px;background:#19a6cc;opacity:.25;animation:l 1.4s infinite}
@keyframes l{50%{opacity:1;box-shadow:0 0 6px #19a6cc}}
.hero{background:linear-gradient(135deg,#0f3646,#111a20);border:1px solid #233540;border-radius:16px;padding:16px;margin-bottom:12px}
h1{font-size:23px;margin:4px 0}.muted{color:#8ba2ae;font-size:13px}
details.sec{background:#111a20;border:1px solid #233540;border-radius:14px;margin-bottom:10px;overflow:hidden}
details.sec>summary{padding:14px 16px;font-size:16px;font-weight:700;cursor:pointer;list-style:none}
details.sec>summary::-webkit-details-marker{display:none}
details.sec .body{padding:0 16px 14px;font-size:15px;line-height:1.45}
.btn{display:inline-block;background:#19a6cc;color:#00222e;font-weight:700;border-radius:10px;padding:10px 14px;margin:8px 8px 0 0;text-decoration:none}
.btn.alt{background:#16222a;color:#e9f0f3;border:1px solid #2f4552}
.tel{color:#5fd3f0;text-decoration:none;font-weight:600;white-space:nowrap}
.info{background:#16222a;border-radius:10px;padding:10px 12px;margin-top:10px}
.day{color:#19a6cc;font-weight:700;margin:12px 0 4px;text-transform:capitalize}
.step{display:flex;gap:12px;padding:7px 0;border-bottom:1px dashed #233540}.step b{min-width:52px;color:#5fd3f0}
.item{padding:9px 0;border-bottom:1px solid #1c2b35}.item:last-child{border-bottom:none}
.tag{display:inline-block;font-size:11px;padding:2px 8px;border-radius:20px;background:#1c2b35;color:#8ba2ae;margin-left:6px}
.chk{display:flex;gap:10px;align-items:center;padding:8px 0;border-bottom:1px solid #1c2b35}.chk input{width:22px;height:22px;accent-color:#3ccf8e;flex:none}
.chk.done span{text-decoration:line-through;color:#5d7581}
.plan{background:#fff;border-radius:10px;padding:6px;margin-top:8px;overflow:auto}.plan svg{width:100%;height:auto;display:block}
.scr{background:#16222a;border-radius:12px;padding:12px;margin-top:10px}
.kv{display:flex;justify-content:space-between;font-size:14px;padding:3px 0}.kv span{color:#8ba2ae}
img.scene{width:100%;border-radius:10px;margin-top:6px}
.done-box{text-align:center;padding:40px 10px}
</style></head><body><div class="wrap">
<div class="brand">__COMPANY__</div><div class="leds"><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i></div><div class="sub">FEUILLE DE ROUTE</div>
<div id="app"></div></div>
<script>
var X = __DATA__; var d = X.d; var app = document.getElementById('app'); var NL = String.fromCharCode(10);
Array.prototype.forEach.call(document.querySelectorAll('.leds i'), function (x, i) { x.style.animationDelay = (i * 0.1) + 's'; });
function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
function nl(s) { return esc(s).split(NL).join('<br>'); }
function tel(p) { var n = String(p || '').replace(/[^0-9+]/g, ''); return n ? ' <a class="tel" target="_top" href="tel:' + n + '">📞 ' + esc(p) + '</a>' : ''; }
function sec(icon, title, body, closed) { return '<details class="sec"' + (closed ? '' : ' open') + '><summary>' + icon + ' ' + title + '</summary><div class="body">' + body + '</div></details>'; }
function store(k, v) { try { if (v === undefined) return JSON.parse(localStorage.getItem(k) || '{}'); localStorage.setItem(k, JSON.stringify(v)); } catch (e) { return {}; } }
if (!d) { app.innerHTML = '<div class="hero done-box"><div style="font-size:54px">🤔</div>Cette feuille de route n’est pas (ou plus) disponible.<br><span class="muted">Contactez ' + esc(X.company) + '.</span></div>'; }
else {
  var h = '<div class="hero"><div class="muted">' + esc(d.project.status || '') + '</div><h1>' + esc(d.project.name) + '</h1><div>📅 ' + esc(d.project.dates) + '</div>' + (d.project.client ? '<div class="muted">Client : ' + esc(d.project.client) + '</div>' : '') + '</div>';
  var where = d.mapsQuery || d.address || d.project.venue; var place = d.place != null ? d.place : d.project.venue;
  if (where || d.access) {
    var b = '';
    if (place) b += '<div style="font-weight:700">' + esc(place) + '</div>';
    if (d.address) b += '<div>' + nl(d.address) + '</div>';
    if (where) b += '<a class="btn" target="_blank" href="https://www.google.com/maps/search/?api=1&query=' + encodeURIComponent(where) + '">🗺️ Google Maps</a><a class="btn alt" target="_blank" href="https://waze.com/ul?q=' + encodeURIComponent(where) + '&navigate=yes">🚗 Waze</a>';
    if (d.access) b += '<div class="info"><b>Accès / parking</b><br>' + nl(d.access) + '</div>';
    h += sec('📍', 'Lieu & accès', b);
  }
  if ((d.schedule || []).length) {
    var day = null, b2 = '';
    d.schedule.forEach(function (x) { if (x.day !== day) { day = x.day; b2 += '<div class="day">' + esc(day || 'Date à définir') + '</div>'; } b2 += '<div class="step"><b>' + esc(x.time || '--:--') + '</b><div>' + esc(x.label) + (x.note ? '<div class="muted">' + esc(x.note) + '</div>' : '') + '</div></div>'; });
    h += sec('🕐', 'Planning', b2);
  }
  if ((d.contacts || []).length) h += sec('📞', 'Contacts sur site', d.contacts.map(function (c) { return '<div class="item"><b>' + esc(c.name) + '</b>' + (c.role ? ' <span class="muted">' + esc(c.role) + '</span>' : '') + '<br>' + tel(c.phone) + '</div>'; }).join(''));
  if ((d.crew || []).length) h += sec('👷', 'Équipe (' + d.crew.length + ')', d.crew.map(function (c) { return '<div class="item"><b>' + esc(c.name) + '</b>' + (c.status === 'Option' ? '<span class="tag">option</span>' : '') + '<div class="muted">' + esc(c.role || '') + (c.role ? ' · ' : '') + esc(c.dates) + '</div>' + tel(c.phone) + '</div>'; }).join(''));
  if ((d.fleet || []).length) h += sec('🚚', 'Transport', d.fleet.map(function (f) { return '<div class="item"><b>' + esc(f.vehicle) + '</b>' + (f.plate ? '<span class="tag">' + esc(f.plate) + '</span>' : '') + '<div class="muted">' + esc(f.dates) + '</div>' + (f.driver ? '<div>Chauffeur : ' + esc(f.driver) + tel(f.phone) + '</div>' : '') + (f.note ? '<div class="muted">' + esc(f.note) + '</div>' : '') + '</div>'; }).join(''));
  if ((d.screens || []).length || d.sceneImg) {
    var b3 = d.sceneImg ? '<img class="scene" src="' + d.sceneImg + '">' : '';
    (d.screens || []).forEach(function (s) {
      b3 += '<div class="scr"><b style="font-size:16px">' + esc(s.name) + '</b> <span class="muted">' + esc(s.product) + '</span>';
      [['Dimensions', s.dims], ['Surface', s.m2], ['Résolution', s.res], ['Lignes électriques', s.elec], ['Ports data', s.data + (s.proc ? ' · ' + s.proc : '')], ['Puissance max', s.power], ['Poids', s.weight]].forEach(function (kv) { b3 += '<div class="kv"><span>' + kv[0] + '</span><b>' + esc(kv[1]) + '</b></div>'; });
      if ((s.zones || []).length) b3 += '<div class="muted" style="margin-top:6px">' + s.zones.map(esc).join(' · ') + '</div>';
      (s.plans || []).forEach(function (pl) { b3 += '<div style="margin-top:10px;font-weight:700">' + esc(pl.title) + '</div><div class="plan">' + pl.svg + '</div>'; });
      b3 += '</div>';
    });
    h += sec('🖥️', 'Écrans & plans', b3);
  }
  if ((d.material || []).length) {
    var key = 'fdr-' + X.t; var st = store(key);
    h += sec('📦', 'Matériel (' + d.material.length + ' références)', '<div class="muted">Cochez au chargement — mémorisé sur ce téléphone.</div>' + d.material.map(function (m, i) { var on = st[i] ? ' checked' : ''; return '<label class="chk' + (st[i] ? ' done' : '') + '"><input type="checkbox" data-i="' + i + '"' + on + '><span><b>' + m.qty + ' ×</b> ' + esc(m.name) + ' <span class="muted">' + esc(m.ref) + (m.m2 ? ' · ' + esc(m.m2) : '') + '</span></span></label>'; }).join(''), true);
  }
  if ((d.files || []).length) h += sec('💾', 'Fichiers de configuration', d.files.map(function (f) { return '<a class="info" style="display:block;text-decoration:none;color:#7fd3ee" href="' + esc(f.url) + '" target="_blank" rel="noopener"><b>⬇ ' + esc(f.name) + '</b><br><span class="muted">' + esc(f.ref) + ' — ' + esc(f.product) + '</span></a>'; }).join(''));
  var prat = [['🏨 Hébergement', d.lodging], ['🍽️ Repas', d.meals], ['👕 Tenue', d.dress], ['⚠️ Sécurité / EPI', d.safety], ['📝 Notes', d.notes]].filter(function (x) { return x[1]; });
  if (prat.length) h += sec('ℹ️', 'Infos pratiques', prat.map(function (x) { return '<div class="info"><b>' + x[0] + '</b><br>' + nl(x[1]) + '</div>'; }).join(''));
  h += '<div class="muted" style="text-align:center;margin-top:16px">Mise à jour : ' + esc(d.updatedAt) + ' · ' + esc(d.company) + '</div>';
  app.innerHTML = h;
  Array.prototype.forEach.call(document.querySelectorAll('.chk input'), function (c) {
    c.onchange = function () { var key = 'fdr-' + X.t; var st = store(key); st[c.getAttribute('data-i')] = c.checked; store(key, st); c.parentNode.className = 'chk' + (c.checked ? ' done' : ''); };
  });
}
</script></body></html>`;

/* ---------- Agenda des techniciens (v4) : événements + invitation par email ---------- */
/* À lancer une fois depuis l'éditeur (▶ Exécuter) pour autoriser l'accès à Google Agenda */
function autoriserAgenda() {
  Logger.log('Agenda par défaut : ' + CalendarApp.getDefaultCalendar().getName()); // déclenche la demande d'autorisation
  var c = cal_(); Logger.log('✅ Agenda prêt : ' + c.getName() + ' — pensez à Déployer → Gérer les déploiements → Nouvelle version');
}
function cal_() {
  var props = PropertiesService.getScriptProperties(); var id = props.getProperty('CAL_ID'); var c = null;
  if (id) { try { c = CalendarApp.getCalendarById(id); } catch (e) { c = null; } }
  if (!c) {
    var found = CalendarApp.getCalendarsByName('Impulsion – Bookings techniciens');
    c = found && found.length ? found[0] : CalendarApp.createCalendar('Impulsion – Bookings techniciens');
    try { c.setColor('#0b5c78'); } catch (e) { /* couleur facultative */ }
    props.setProperty('CAL_ID', c.getId());
  }
  return c;
}
function dateOf_(iso) { var p = String(iso).split('-'); return new Date(Number(p[0]), Number(p[1]) - 1, Number(p[2])); }
/* v11 : on ne modifie que ce qui a vraiment changé, et jamais un événement déjà terminé (aucun mail inutile) */
function evPast_(ev) { try { return ev.getEndTime().getTime() < Date.now() - 864e5; } catch (e) { return false; } }
function evSet_(ev, title, desc, loc, s, e) {
  if (ev.getTitle() !== title) ev.setTitle(title);
  if ((ev.getDescription() || '') !== (desc || '')) ev.setDescription(desc || '');
  if ((ev.getLocation() || '') !== (loc || '')) ev.setLocation(loc || '');
  var s0 = null, e0 = null; try { s0 = ev.getAllDayStartDate(); e0 = ev.getAllDayEndDate(); } catch (x) {}
  if (!s0 || !e0 || s0.getTime() !== s.getTime() || e0.getTime() !== e.getTime()) ev.setAllDayDates(s, e);
}
function evDel_(ev) { if (!evPast_(ev)) ev.deleteEvent(); }
function calSync_(items) {
  var c = cal_(); var out = [];
  items.forEach(function (it) {
    try {
      var old = (it.ids || []).map(function (id) { try { return c.getEventById(id); } catch (e) { return null; } }).filter(function (x) { return !!x; });
      var d = it.desired;
      if (!d) { old.forEach(evDel_); out.push({ id: it.id, ids: [] }); return; }
      if (d.events) { // v8 : un événement par projet (et par période), plusieurs invités
        var eids = [];
        d.events.forEach(function (x, k) {
          var s1 = dateOf_(x.start), e1 = dateOf_(x.end); var ev1 = old[k]; var want = (x.guests || []).map(function (g) { return String(g).toLowerCase(); });
          if (ev1) {
            if (evPast_(ev1)) { eids.push(ev1.getId()); return; }
            evSet_(ev1, x.title, x.description, x.location, s1, e1);
            var have = ev1.getGuestList().map(function (g) { return g.getEmail().toLowerCase(); });
            have.forEach(function (g) { if (want.indexOf(g) < 0) ev1.removeGuest(g); });
            want.forEach(function (g) { if (have.indexOf(g) < 0) ev1.addGuest(g); });
          } else {
            ev1 = c.createAllDayEvent(x.title, s1, e1, { description: x.description || '', location: x.location || '', guests: want.join(','), sendInvites: true });
          }
          eids.push(ev1.getId());
        });
        old.slice(d.events.length).forEach(evDel_);
        out.push({ id: it.id, ids: eids }); return;
      }
      var mail = String(d.email).toLowerCase(); var ids = [];
      (d.runs || []).forEach(function (run, k) {
        var s = dateOf_(run[0]), e = dateOf_(run[1]); var ev = old[k];
        if (ev) {
          if (evPast_(ev)) { ids.push(ev.getId()); return; }
          evSet_(ev, d.title, d.description, d.location, s, e);
          var guests = ev.getGuestList().map(function (g) { return g.getEmail().toLowerCase(); });
          guests.forEach(function (g) { if (g !== mail) ev.removeGuest(g); });
          if (guests.indexOf(mail) < 0) ev.addGuest(d.email);
        } else {
          ev = c.createAllDayEvent(d.title, s, e, { description: d.description || '', location: d.location || '', guests: d.email, sendInvites: true });
        }
        ids.push(ev.getId());
      });
      old.slice((d.runs || []).length).forEach(evDel_);
      out.push({ id: it.id, ids: ids });
    } catch (err) { out.push({ id: it.id, error: String(err && err.message ? err.message : err) }); }
  });
  return out;
}
