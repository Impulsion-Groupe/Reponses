/* =====================================================================
   LIAISONS ENTRE BLOCS / ZONES (plan data — aussi possible en élec)
   On choisit simplement quels blocs se suivent sur un même port :
   chaîne 1 : Main stage → Totem 1 → Totem 2 · chaîne 2 : Totem 3 → Totem 4 …
   Les blocs hors chaîne ont leur(s) propre(s) port(s).
   ===================================================================== */
function linksCardHTML(s, kind) {
  const cfg = s[kind]; const T = zTerm(s); const plan = resolvePlan(s, kind); const cap = plan.cap.cap; const isE = kind === 'elec';
  const pre = isE ? 'C' : 'P'; const unit = isE ? 'ligne' : 'port';
  const zp = (id) => { const zi = s.zones.findIndex((z) => z.id === id); const z = s.zones[zi]; return { zi, z, n: z ? z.count * zRows(s, z) : 0 }; };
  const color = (id) => { const it = (boardMapCfg(s).items || []).find((x) => x.zid === id); return it ? it.color : zoneColor(zp(id).zi); };
  const G = rawGroups(s, cfg);
  if (!G) {
    return `<div class="card" style="margin-bottom:16px"><h3>🔗 Liaisons entre ${T.many}</h3>
      <div class="small">Mode <b>automatique</b> : ${cfg.joinZones ? `les ${T.many} sont regroupés sur un même ${unit} tant que la capacité le permet (${cap} dalles / ${unit}), dans l'ordre de la liste.` : `chaque ${T.one} a son propre ${unit}.`}</div>
      <button class="primary" data-act="linkManual" data-kind="${kind}" style="width:100%;justify-content:center;margin-top:10px">✋ Choisir moi-même les liaisons</button>
      <div class="tiny muted" style="margin-top:6px">Ex. Main stage seul, Totems 1-2-3-4 en chaîne, Totems 5-6-7-8 en chaîne.</div></div>`;
  }
  const inG = new Set(G.flat()); const free = s.zones.filter((z) => !inG.has(z.id)); const sel = Math.min(ui.linkSel == null ? -1 : ui.linkSel, G.length - 1);
  let portNo = 0;
  const chains = G.map((g, k) => {
    const n = g.reduce((a, id) => a + zp(id).n, 0); const zis = new Set(g.map((id) => zp(id).zi));
    const ls = plan.lines.filter((l) => l.panels.length && l.panels.some((i) => zis.has(zoneOfCol(s, i % s.cols)))).map((l) => l.index + 1);
    const ports = Math.max(1, ls.length); const from = ls.length ? Math.min(...ls) : portNo + 1; portNo = Math.max(portNo, ...ls);
    return `<div class="lk-chain ${sel === k ? 'on' : ''}" data-act="linkSel" data-k="${k}">
      <div class="row" style="justify-content:space-between"><b>Chaîne ${k + 1}</b><span class="tiny ${ports > 1 ? 'warn-t' : 'muted'}">${n} dalles · ${ports > 1 ? `⚠ ${ports} ${unit}s (${ls.map((x) => pre + x).join(', ')}) — capacité dépassée` : `${pre}${from}`}</span></div>
      <div class="bar" style="margin:6px 0"><i class="${ports > 1 ? 'bad' : n / cap > 0.9 ? 'warn' : ''}" style="width:${Math.min(100, n / cap * 100)}%" title="${n} / ${cap} dalles"></i></div>
      <div class="lk-chips">${g.map((id, i) => `${i ? '<span class="lk-arrow">→</span>' : ''}<span class="lk-chip" style="border-color:${color(id)}"><span class="dot" style="background:${color(id)}"></span>${esc(zp(id).z.name)}
        <button class="lk-b" data-act="linkMove" data-kind="${kind}" data-k="${k}" data-i="${i}" data-d="-1" ${i ? '' : 'disabled'} title="Avancer">‹</button><button class="lk-b" data-act="linkMove" data-kind="${kind}" data-k="${k}" data-i="${i}" data-d="1" ${i < g.length - 1 ? '' : 'disabled'} title="Reculer">›</button><button class="lk-b" data-act="linkRemove" data-kind="${kind}" data-k="${k}" data-i="${i}" title="Sortir de la chaîne">✕</button></span>`).join('')}</div></div>`;
  }).join('');
  return `<div class="card" style="margin-bottom:16px"><div class="row" style="justify-content:space-between"><h3 style="margin:0">🔗 Liaisons entre ${T.many}</h3><span class="tag warn">manuel</span></div>
    <div class="tiny muted" style="margin:6px 0 10px">1. Cliquez une chaîne (ou « ＋ Nouvelle chaîne ») · 2. cliquez les ${T.many} à y ajouter, dans l'ordre du câble. Capacité : ${cap} dalles / ${unit}.</div>
    ${chains || `<div class="tiny muted">Aucune chaîne : tous les ${T.many} ont leur propre ${unit}.</div>`}
    <div class="row" style="gap:6px;margin:10px 0"><button class="sm" data-act="linkNew" data-kind="${kind}">＋ Nouvelle chaîne</button><button class="sm ghost" data-act="linkSplit" data-kind="${kind}">Tout séparer</button><button class="sm ghost" data-act="linkAuto" data-kind="${kind}">↺ Automatique</button></div>
    <div class="tiny muted">${T.Many} seuls (un ${unit} chacun) — cliquez pour ${sel >= 0 ? `ajouter à la <b>chaîne ${sel + 1}</b>` : 'créer une chaîne'} :</div>
    <div class="lk-chips" style="margin-top:6px">${free.map((z) => `<button class="lk-chip free" style="border-color:${color(z.id)}" data-act="linkAdd" data-kind="${kind}" data-zid="${z.id}"><span class="dot" style="background:${color(z.id)}"></span>${esc(z.name)} <span class="tiny muted">${z.count * zRows(s, z)}</span></button>`).join('') || `<span class="tiny muted">Tous les ${T.many} sont dans une chaîne.</span>`}</div>
  </div>`;
}
function rawGroups(s, cfg) { if (!Array.isArray(cfg.groups)) return null; const ids = new Set(s.zones.map((z) => z.id)); const seen = new Set(); return cfg.groups.map((g) => (g || []).filter((id) => ids.has(id) && !seen.has(id) && seen.add(id))); }
function linkCfg(el) { const s = curScreen(); const kind = el.dataset.kind || 'data'; const cfg = s[kind]; return { s, kind, cfg }; }
function linkSave(s, kind, cfg, groups) { cfg.groups = groups || null; cfg.assign = null; cfg.orders = {}; ui.sel[kind] = 0; Store.save(); const y = $main().scrollTop; render(); $main().scrollTop = y; }
const linkActions = {
  linkManual(el) { // part des regroupements actuels
    const { s, kind, cfg } = linkCfg(el); const plan = resolvePlan(s, kind); const groups = []; const seen = new Set();
    plan.lines.forEach((l) => { const ids = [...new Set(l.panels.map((i) => s.zones[zoneOfCol(s, i % s.cols)].id))]; if (ids.length > 1) { const g = groups.find((x) => ids.some((id) => x.includes(id))); if (g) ids.forEach((id) => !g.includes(id) && g.push(id)); else groups.push(ids); ids.forEach((id) => seen.add(id)); } });
    ui.linkSel = groups.length ? 0 : null; linkSave(s, kind, cfg, groups);
  },
  linkSel(el) { if (el.closest('button') && el.closest('button') !== el) return; ui.linkSel = +el.dataset.k; render(); },
  linkNew(el) { const { s, kind, cfg } = linkCfg(el); const G = rawGroups(s, cfg) || []; G.push([]); ui.linkSel = G.length - 1; cfg.groups = G; Store.save(); render(); },
  linkAdd(el) {
    const { s, kind, cfg } = linkCfg(el); const G = rawGroups(s, cfg) || [];
    let k = ui.linkSel; if (k == null || k < 0 || !G[k]) { G.push([]); k = G.length - 1; }
    ui.linkSel = k; G[k].push(el.dataset.zid); linkSave(s, kind, cfg, G);
  },
  linkRemove(el) { const { s, kind, cfg } = linkCfg(el); const G = rawGroups(s, cfg); G[+el.dataset.k].splice(+el.dataset.i, 1); const k = +el.dataset.k; const out = G.filter((g, i) => g.length || i === ui.linkSel); if (!G[k].length && ui.linkSel === k) ui.linkSel = null; linkSave(s, kind, cfg, ui.linkSel == null ? G.filter((g) => g.length) : out); },
  linkMove(el) { const { s, kind, cfg } = linkCfg(el); const G = rawGroups(s, cfg); const g = G[+el.dataset.k]; const i = +el.dataset.i, j = i + +el.dataset.d; [g[i], g[j]] = [g[j], g[i]]; linkSave(s, kind, cfg, G); },
  linkSplit(el) { const { s, kind, cfg } = linkCfg(el); ui.linkSel = null; linkSave(s, kind, cfg, []); },
  linkAuto(el) { const { s, kind, cfg } = linkCfg(el); ui.linkSel = null; linkSave(s, kind, cfg, null); }
};
