/* =====================================================================
   PARTAGE ENTRE PLUSIEURS PC — via le relais Google (script v9)
   - chaque poste garde son fichier local (marche hors ligne) ;
   - toutes les 20 s (et après chaque modification) : on récupère la version en ligne,
     on FUSIONNE élément par élément (projets, écrans, techniciens…), puis on envoie ;
   - un seul « poste principal » à la fois gère l'agenda et les réponses automatiques.
   ===================================================================== */
const SYNC_LOCAL_SETTINGS = ['waMode']; // propre à chaque PC (WhatsApp Desktop installé ou non)
const SYNC_EVERY = 20000;
const syncState = { busy: false, timer: null, pushTimer: null, again: false, leader: null, presence: {}, last: null, error: null, conflicts: 0, started: false };

const syncCfg = () => (localInfo().sync = localInfo().sync || { on: false, rev: 0, base: null });
const syncOn = () => !!syncCfg().on && replyActive();
/* Ce poste peut-il lancer les automatismes (agenda, réponses, republication) ? */
const isAutoLeader = () => !IS_WEB && (!syncOn() || syncState.leader === true); // le téléphone ne pilote jamais les automatismes
function syncOthers() {
  const me = localInfo().deviceId; const now = syncState.serverNow || Date.now();
  return Object.entries(syncState.presence || {}).filter(([d, v]) => d !== me && now - v.at < 70000).map(([, v]) => v);
}

/* ---------- Comparaison & fusion ---------- */
const isObj = (x) => x && typeof x === 'object' && !Array.isArray(x);
const isIdArr = (a) => Array.isArray(a) && a.every((x) => isObj(x) && 'id' in x);
function deq(a, b) {
  if (a === b) return true;
  if (Array.isArray(a)) { if (!Array.isArray(b) || a.length !== b.length) return false; for (let i = 0; i < a.length; i++) if (!deq(a[i], b[i])) return false; return true; }
  if (isObj(a)) { if (!isObj(b)) return false; const ka = Object.keys(a).filter((k) => a[k] !== undefined); const kb = Object.keys(b).filter((k) => b[k] !== undefined); if (ka.length !== kb.length) return false; return ka.every((k) => deq(a[k], b[k])); }
  return Number.isNaN(a) && Number.isNaN(b);
}
/* Fusion à 3 voies : base = dernière version commune ; local = ce poste ; remote = en ligne.
   Ce qui n'a changé que d'un côté est repris ; si les deux ont modifié la même valeur, ce poste l'emporte. */
function merge3(b, l, r, path = '') {
  if (deq(l, r)) return l;
  if (deq(b, l)) return r;
  if (deq(b, r)) return l;
  if (isObj(l) && isObj(r)) {
    const out = {}; const bb = isObj(b) ? b : {};
    [...new Set([...Object.keys(r), ...Object.keys(l)])].forEach((k) => {
      const v = pick3(bb[k], l[k], r[k], path + '.' + k); if (v !== undefined) out[k] = v;
    });
    return out;
  }
  if (isIdArr(l) && isIdArr(r)) {
    const bm = new Map((isIdArr(b) ? b : []).map((x) => [x.id, x])); const lm = new Map(l.map((x) => [x.id, x])); const rm = new Map(r.map((x) => [x.id, x]));
    const order = r.map((x) => x.id);
    l.forEach((x, i) => { if (!rm.has(x.id) && !bm.has(x.id)) { const prev = i > 0 ? order.indexOf(l[i - 1].id) : -1; order.splice(prev + 1, 0, x.id); } });
    const out = [];
    order.forEach((id) => { const v = pick3(bm.get(id), lm.get(id), rm.get(id), path + '[' + id + ']'); if (v !== undefined) out.push(v); });
    return out;
  }
  syncState.conflicts++; return l;
}
function pick3(bv, lv, rv, path) {
  if (lv === undefined && rv === undefined) return undefined;
  if (lv === undefined) return deq(bv, rv) ? undefined : rv; // supprimé ici (ou ajouté en ligne)
  if (rv === undefined) return deq(bv, lv) ? undefined : lv; // supprimé en ligne (ou ajouté ici)
  return merge3(bv, lv, rv, path);
}

/* ---------- Protection contre les disparitions ----------
   Un projet (technicien, référence, véhicule, compte) n'est supprimé des autres postes QUE s'il a été
   supprimé volontairement quelque part : la suppression laisse une « pierre tombale » (db.tomb).
   Un poste resté sur d'anciennes données, une sauvegarde restaurée ou des données en ligne réinitialisées
   ne peuvent donc plus faire disparaître un élément : il est conservé et renvoyé.
   Tout élément retiré par la synchronisation part dans la corbeille de ce poste (Historique → Corbeille). */
const SYNC_COLLS = ['projects', 'products', 'techs', 'vehicles', 'users'];
const tombStamp = (e) => Date.parse((e && (e.revived || e.at)) || 0) || 0;
function tombAdd(id, info) { const t = (Store.db.tomb = Store.db.tomb || {}); t[id] = Object.assign({ at: new Date().toISOString() }, info); }
function tombRevive(id) { const t = (Store.db.tomb = Store.db.tomb || {}); if (t[id]) t[id].revived = new Date().toISOString(); }
const tombDead = (t, id) => !!(t && t[id] && !t[id].revived);
function tombMerge(a, b) { const out = Object.assign({}, a || {}); Object.entries(b || {}).forEach(([id, e]) => { if (!out[id] || tombStamp(e) > tombStamp(out[id])) out[id] = e; }); const lim = Date.now() - 400 * 864e5; Object.keys(out).forEach((id) => { if (tombStamp(out[id]) < lim) delete out[id]; }); return out; }
function trashAdd(coll, item, why) {
  if (!item || !Store.db.local) return; const tr = (Store.db.local.trash = Store.db.local.trash || []);
  const T = JOURNAL_TYPES[coll]; tr.unshift({ id: uid('tr'), at: new Date().toISOString(), coll, label: (T && T.label(item)) || item.name || '—', why: why || '', item: deepClone(item) });
  if (tr.length > 80) tr.length = 80;
}
/* Fusion d'une liste principale : suppression acceptée uniquement avec pierre tombale */
function mergeColl(b, l, r, tombs, coll, lost) {
  b = isIdArr(b) ? b : []; l = isIdArr(l) ? l : []; r = isIdArr(r) ? r : [];
  const bm = new Map(b.map((x) => [x.id, x])); const lm = new Map(l.map((x) => [x.id, x])); const rm = new Map(r.map((x) => [x.id, x]));
  const order = r.map((x) => x.id);
  l.forEach((x, i) => { if (!rm.has(x.id)) { const prev = i > 0 ? order.indexOf(l[i - 1].id) : -1; order.splice(prev + 1, 0, x.id); } });
  const out = [];
  order.forEach((id) => {
    const bv = bm.get(id), lv = lm.get(id), rv = rm.get(id); const dead = tombDead(tombs, id);
    if (lv && rv) { if (dead) { lost.push({ coll, item: lv, why: 'supprimé sur un autre poste' }); return; } out.push(merge3(bv, lv, rv, '.' + coll + '[' + id + ']')); return; }
    if (lv) { if (dead) { if (bv) lost.push({ coll, item: lv, why: 'supprimé sur un autre poste' }); return; } out.push(lv); return; } // absent en ligne sans suppression volontaire : on le garde
    if (rv) { if (dead) return; out.push(rv); } // absent ici sans suppression volontaire : on le reprend
  });
  return out;
}
function mergeTop(b, l, r) {
  b = isObj(b) ? b : {}; const tombs = tombMerge(tombMerge(b.tomb, r.tomb), l.tomb); const lost = [];
  const rest = (o) => { const c = Object.assign({}, o); SYNC_COLLS.forEach((k) => delete c[k]); delete c.tomb; return c; };
  const out = merge3(rest(b), rest(l), rest(r));
  SYNC_COLLS.forEach((k) => { if (l[k] !== undefined || r[k] !== undefined) out[k] = mergeColl(b[k], l[k], r[k], tombs, k, lost); });
  out.tomb = tombs; return { merged: out, lost };
}

/* Partie partagée des données (sans ce qui est propre au poste) */
function syncView(db) {
  const v = deepClone(Object.assign({}, db, { local: undefined, updatedAt: undefined, appVersion: undefined }));
  delete v.local; delete v.updatedAt; delete v.appVersion;
  // fichiers RCG déjà en ligne (Google Drive) : seul le lien circule, pas le contenu (partage beaucoup plus léger)
  (v.products || []).forEach((p) => (p.files || []).forEach((f) => { if (f.url && f.up === f.hash) delete f.b64; }));
  SYNC_LOCAL_SETTINGS.forEach((k) => delete v.settings[k]);
  return v;
}
function applyShared(next) {
  const keep = Store.db.local; const st = Store.db.settings; const localSet = {}; SYNC_LOCAL_SETTINGS.forEach((k) => { localSet[k] = st[k]; });
  journalFlush();
  let db = deepClone(next); db.local = keep; db.settings = Object.assign(db.settings || {}, localSet);
  if ((db.schemaVersion || 0) < SCHEMA_VERSION) db = migrate(db);
  Store.db = db; journalResync();
}
const editingNow = () => { const a = document.activeElement; return (a && ['INPUT', 'TEXTAREA', 'SELECT'].includes(a.tagName) && a.closest('#main, #modal')) || !document.getElementById('modal').classList.contains('hidden'); };
function refreshAfterRemote() {
  if (needLogin()) { showLogin(); return; }
  if (!curUser() && localInfo().userId) localInfo().userId = null;
  if (editingNow()) { syncState.renderLater = true; return; }
  syncState.renderLater = false; const y = $main().scrollTop; render(); $main().scrollTop = y;
}

/* ---------- Échanges avec le relais ---------- */
const syncMeta = () => ({ key: ensureReplyKey(), dev: localInfo().deviceId, user: (curUserName() || 'Poste ' + localInfo().deviceId.slice(-4)) + (IS_WEB ? ' (téléphone)' : ''), app: APP_VERSION, nolease: IS_WEB ? 1 : 0 });
function syncErr(e) {
  const m = e && e.message ? e.message : String(e);
  if (/Action inconnue|Jeton invalide/.test(m)) return 'Le script Google doit être mis à jour (v9) : Comptes & partage → « Copier le code du script v9 ».';
  return m;
}
async function syncCycle(manual) {
  if (!syncOn()) return;
  if (syncState.busy) { syncState.again = true; return; }
  syncState.busy = true; clearTimeout(syncState.pushTimer);
  const cfg = syncCfg(); let changed = false;
  try {
    for (let attempt = 0; attempt < 4; attempt++) {
      journalFlush();
      const res = await withTimeout(remotePost(Object.assign({ action: 'dbget', rev: cfg.rev || 0 }, syncMeta())), 150000);
      syncState.leader = !!res.leader; syncState.presence = res.presence || {}; syncState.serverNow = res.now;
      let local = syncView(Store.db);
      if (!res.data && res.rev > 0 && res.rev !== cfg.rev && !res.empty) throw new Error('Données en ligne illisibles pour l\'instant : rien n\'est envoyé, nouvel essai dans 20 s. (Si ça dure : mettez le script Google à jour, ou « Renvoyer les données de ce PC ».)');
      if (!res.data && res.rev !== cfg.rev) { cfg.rev = res.rev; cfg.base = null; } // relais vide : on y renvoie les données de ce poste
      if (res.data && res.rev !== cfg.rev) {
        if ((res.data.schemaVersion || 0) > SCHEMA_VERSION) throw new Error('Les données en ligne viennent d\'une version plus récente de l\'application : installez la dernière version sur ce PC.');
        // base inconnue ou relais revenu en arrière : fusion « union » (rien n'est supprimé sans pierre tombale)
        const base = cfg.base && res.rev > (cfg.rev || 0) ? cfg.base : {};
        const { merged, lost } = mergeTop(base, local, res.data);
        if (!deq(merged, local)) {
          lost.forEach((x) => trashAdd(x.coll, x.item, x.why));
          applyShared(merged); changed = true; local = syncView(Store.db);
          lost.forEach((x) => { const tb = (merged.tomb || {})[x.item.id] || {}; journalAdd({ kind: 'info', type: JOURNAL_TYPES[x.coll] ? JOURNAL_TYPES[x.coll].t : x.coll, ic: '🗑', byName: tb.byName || '', by: tb.by || '', text: `a supprimé ${JOURNAL_TYPES[x.coll] ? JOURNAL_TYPES[x.coll].one : ''} « ${(JOURNAL_TYPES[x.coll] && JOURNAL_TYPES[x.coll].label(x.item)) || x.item.name || ''} » (sur un autre poste — récupérable dans la corbeille)` }); });
          if (lost.length) { journalResync(); local = syncView(Store.db); }
        }
        cfg.base = res.data; cfg.rev = res.rev;
      }
      if (!cfg.base || !deq(local, cfg.base)) {
        syncState.size = JSON.stringify(local).length;
        const put = await withTimeout(remotePost(Object.assign({ action: 'dbput', baseRev: cfg.rev || 0, data: local }, syncMeta())), 240000);
        if (put.conflict) continue; // quelqu'un a enregistré entre-temps : on refusionne
        cfg.rev = put.rev; cfg.base = local;
      }
      break;
    }
    syncState.error = null; syncState.last = Date.now();
    Store.saveNow();
    if (changed) refreshAfterRemote();
    if (syncState.leader && !syncState.wasLeader) { syncState.wasLeader = true; setTimeout(() => { syncReplies(false); scheduleCalSync(); }, 500); }
    if (!syncState.leader) syncState.wasLeader = false;
    if (manual) toast('Synchronisé ✔');
  } catch (e) {
    syncState.error = syncErr(e); if (/Délai dépassé/.test(syncState.error)) syncState.error = 'Délai dépassé : Google ou la connexion répond lentement. Nouvel essai automatique dans 20 s — rien n\'est perdu.'; if (manual) toast(syncState.error, 'bad');
  } finally {
    syncState.busy = false; userChip();
    if (syncState.again) { syncState.again = false; setTimeout(() => syncCycle(false), 300); }
  }
}
function schedulePush() { if (!syncOn()) return; clearTimeout(syncState.pushTimer); syncState.pushTimer = setTimeout(() => syncCycle(false), 3000); }
(function hookSync() { const save = Store.save.bind(Store); Store.save = function () { save(); schedulePush(); }; })();
function startSync() {
  if (syncState.started) return; syncState.started = true;
  setInterval(() => { if (syncOn() && (document.visibilityState === 'visible' || Date.now() - (syncState.last || 0) > 60000)) syncCycle(false); if (syncState.renderLater && !editingNow()) refreshAfterRemote(); }, SYNC_EVERY);
  window.addEventListener('focus', () => { if (syncOn() && Date.now() - (syncState.last || 0) > 5000) syncCycle(false); });
  if (syncOn()) setTimeout(() => syncCycle(false), 800);
}
function syncBadge() {
  if (!syncOn()) return '';
  const st = syncState.error ? `<span style="color:#ff6b4a" title="${esc(syncState.error)}">⚠ Partage en pause</span>` : syncState.last ? `☁ Partagé · ${new Date(syncState.last).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}` : '☁ Connexion…';
  return `<div class="tiny muted" style="margin-top:4px">${st}${syncState.leader ? ' · <span title="Ce poste gère l\'agenda et les réponses automatiques">★</span>' : ''}</div>`;
}

/* ---------- Code de connexion pour un autre PC ---------- */
const syncCode = () => 'ILM1-' + btoa(unescape(encodeURIComponent(JSON.stringify({ u: Store.db.settings.replyUrl.trim(), k: ensureReplyKey(), c: Store.db.settings.company }))));
function parseCode(code) {
  const m = String(code || '').trim().match(/^ILM1-([A-Za-z0-9+/=]+)$/); if (!m) return null;
  try { const o = JSON.parse(decodeURIComponent(escape(atob(m[1])))); return REPLY_URL_RE.test(o.u) && o.k ? o : null; } catch (e) { return null; }
}

function syncCardHTML() {
  const cfg = syncCfg(); const on = syncOn(); const others = syncOthers();
  const devs = Object.entries(syncState.presence || {}).sort((a, b) => b[1].at - a[1].at);
  return `<div class="card"><h3>☁ Partage entre plusieurs PC</h3>
  ${on ? `<div class="alert ${syncState.error ? 'bad' : 'ok'}">${syncState.size ? `<span class="tiny muted" style="float:right">${fmt(syncState.size / 1048576, 1)} Mo</span>` : ''}${syncState.error ? '⚠ ' + esc(syncState.error) + (/illisibles/.test(syncState.error) ? ' <button class="sm" data-act="syncUseLocal" style="margin-left:8px">⇧ Renvoyer les données de ce PC</button>' : '') : `✔ Données partagées${syncState.last ? ' — dernière synchro ' + agoTxt(new Date(syncState.last).toISOString()) : ''}. Chaque modification est envoyée en quelques secondes ; les modifications des autres arrivent toutes seules (toutes les 20 s).`}</div>
    ${devs.length ? `<div class="small muted" style="margin-top:10px">Postes</div>${devs.map(([d, v]) => `<div class="row small" style="gap:8px;margin-top:4px"><span style="color:${(syncState.serverNow || Date.now()) - v.at < 70000 ? '#3ecf8e' : '#667'}">●</span>${esc(v.name || 'Poste')}${d === localInfo().deviceId ? ' <span class="muted">(ce PC)</span>' : ''}<span class="tiny muted">${(syncState.serverNow || Date.now()) - v.at < 70000 ? 'en ligne' : 'vu ' + agoTxt(new Date(v.at).toISOString())}${v.v ? ' · v' + esc(v.v) : ''}</span></div>`).join('')}` : ''}
    <div class="tiny muted" style="margin-top:8px">${syncState.leader ? '★ Ce PC est le <b>poste principal</b> : il gère l\'agenda des techniciens et les réponses en 1 clic.' : 'Le poste principal (agenda, réponses en 1 clic) est l\'autre PC allumé ; si aucun ne l\'est, ce PC prend le relais tout seul.'}</div>
    <div class="row" style="margin-top:12px"><button data-act="syncNow">🔄 Synchroniser maintenant</button><button data-act="syncShowCode">🔑 Ajouter un autre PC</button><button data-act="syncPhone">📱 Installer sur mon téléphone</button><button class="ghost" data-act="syncOff">Arrêter sur ce PC</button></div>`
  : `<div class="small">Votre patron travaille sur son propre PC avec <b>exactement les mêmes données</b> que vous : projets, stock, équipe, véhicules, comptes. Hors connexion, chacun continue sur sa copie ; tout se rassemble au retour.</div>
    <ol class="small" style="line-height:1.7;margin:10px 0 0 18px"><li><b>Sur votre PC</b> : « Activer le partage » (le relais Google des réponses en 1 clic doit être en place, script v9).</li><li>« Ajouter un autre PC » donne un <b>code de connexion</b>.</li><li><b>Sur le PC de votre patron</b> : installez l'application, ouvrez Comptes & partage → « Rejoindre », collez le code.</li></ol>
    ${replyActive() ? '' : '<div class="alert warn" style="margin-top:10px">Mettez d\'abord en place le relais Google : Équipe → Réponses en 1 clic.</div>'}
    <div class="row" style="margin-top:12px"><button class="primary" data-act="syncEnable" ${replyActive() ? '' : 'disabled'}>☁ Activer le partage</button><button data-act="syncJoin">🔑 Rejoindre (code)</button></div>`}
  <hr class="sep"><div class="tiny muted">Le partage passe par le script Google v9. Si votre script est plus ancien : <a data-act="syncCopyScript">copier le code du script v9</a>, le coller dans Apps Script à la place de l'ancien, Ctrl+S, puis Déployer → Gérer les déploiements → ✏️ → Nouvelle version.</div>
  </div>`;
}

async function firstContact() {
  const res = await remotePost(Object.assign({ action: 'dbget', rev: -1 }, syncMeta()));
  if (res.version && res.version < 9) throw new Error('Le script Google doit être mis à jour (v9).');
  return res;
}
async function useRemote(res) {
  if (IS_DESKTOP) { try { await window.desktop.backup('avant-partage'); } catch (e) { /* ignore */ } }
  const cfg = syncCfg(); const mine = syncView(Store.db);
  // rejoindre : ce qui n'existait que sur ce poste part dans sa corbeille (récupérable)
  if (cfg.on) SYNC_COLLS.forEach((k) => (mine[k] || []).forEach((x) => { if (!(res.data[k] || []).some((y) => y.id === x.id)) trashAdd(k, x, 'remplacé par les données partagées'); }));
  applyShared(res.data); Store.db.local.sync = Object.assign(cfg, { on: true, rev: res.rev, base: deepClone(res.data) });
  syncState.leader = !!res.leader; syncState.presence = res.presence || {};
  Store.saveNow(); syncState.last = Date.now(); journalResync(); startSync();
}
async function pushLocal() {
  const cfg = syncCfg(); const g = await remotePost(Object.assign({ action: 'dbget', rev: -1 }, syncMeta()));
  const data = syncView(Store.db); const put = await remotePost(Object.assign({ action: 'dbput', baseRev: g.rev || 0, data }, syncMeta()));
  if (put.conflict) throw new Error('Quelqu\'un a enregistré en même temps : réessayez.');
  Object.assign(cfg, { on: true, rev: put.rev, base: data }); syncState.leader = !!g.leader; syncState.presence = g.presence || {};
  Store.saveNow(); syncState.last = Date.now(); startSync();
}

const syncActions = {
  async syncEnable() {
    if (!users().length) { toast('Créez d\'abord votre compte (à gauche) : les modifications seront signées', 'warn'); }
    try {
      toast('Connexion au relais Google…'); const res = await firstContact();
      if (!res.rev) { await pushLocal(); render(); toast('Partage activé ✔ — ajoutez maintenant le PC de votre patron'); return; }
      ui.syncRemote = res;
      openModal(`<h2>Des données sont déjà en ligne</h2><div class="small">En ligne : ${(res.data && res.data.projects || []).length} projet(s), ${(res.data && res.data.techs || []).length} technicien(s).</div>
        <button class="kind-card" data-act="syncMergeBoth" style="margin-top:14px;width:100%;border-color:var(--accent)"><b>🔀 Fusionner (recommandé)</b><div class="tiny muted">Rien n'est perdu : ce qui est sur ce PC ET ce qui est en ligne est gardé, puis partagé avec tous les postes.</div></button>
        <div class="grid g2" style="margin-top:10px"><button class="kind-card" data-act="syncUseRemote"><b>⇩ Reprendre les données en ligne</b><div class="tiny muted">Ce PC est remplacé par la version partagée (une sauvegarde est faite avant).</div></button>
        <button class="kind-card" data-act="syncUseLocal"><b>⇧ Envoyer les données de ce PC</b><div class="tiny muted">Les données en ligne sont remplacées par celles de ce PC.</div></button></div>
        <div class="modal-actions"><button data-act="closeModal">Annuler</button></div>`);
    } catch (e) { toast(syncErr(e), 'bad'); }
  },
  async syncMergeBoth() {
    try {
      const res = ui.syncRemote; const cfg = syncCfg(); const { merged } = mergeTop({}, syncView(Store.db), res.data);
      if (IS_DESKTOP) { try { await window.desktop.backup('avant-fusion'); } catch (e) { /* */ } }
      applyShared(merged); Object.assign(cfg, { on: true, rev: res.rev, base: deepClone(res.data) });
      syncState.leader = !!res.leader; syncState.presence = res.presence || {}; await Store.saveNow(); journalResync(); startSync();
      closeModal(); userChip(); if (needLogin()) showLogin(); else render();
      await syncCycle(true); toast(`Fusion faite ✔ ${Store.db.projects.length} projet(s)`);
    } catch (e) { toast(syncErr(e), 'bad'); }
  },
  async syncUseRemote() { try { await useRemote(ui.syncRemote); closeModal(); userChip(); if (needLogin()) showLogin(); else render(); toast('Données partagées reprises ✔'); } catch (e) { toast(syncErr(e), 'bad'); } },
  async syncUseLocal() { if (!confirm('Remplacer les données en ligne par celles de ce PC ?')) return; try { await pushLocal(); closeModal(); render(); toast('Données envoyées ✔'); } catch (e) { toast(syncErr(e), 'bad'); } },
  syncJoin() {
    openModal(`<h2>Rejoindre les données partagées</h2><div class="small">Sur le PC où le partage est actif : Comptes & partage → « Ajouter un autre PC » → copiez le code et envoyez-le ici (email, WhatsApp…).</div>
      <textarea id="joinCode" rows="4" style="width:100%;margin-top:12px;font-family:monospace" placeholder="ILM1-…"></textarea>
      <div class="alert warn" style="margin-top:10px">Les données actuelles de ce PC seront remplacées par les données partagées (une sauvegarde est faite avant).</div>
      <div class="modal-actions"><button data-act="closeModal">Annuler</button><button class="primary" data-act="syncJoinGo">Rejoindre</button></div>`);
  },
  async syncJoinGo() {
    const o = parseCode(document.getElementById('joinCode').value); if (!o) return toast('Code invalide : il commence par ILM1-', 'warn');
    const st = Store.db.settings; const old = { u: st.replyUrl, k: st.replyKey };
    st.replyUrl = o.u; st.replyKey = o.k;
    try {
      toast('Connexion…'); const res = await firstContact();
      if (!res.rev || !res.data) throw new Error('Aucune donnée partagée pour l\'instant : activez d\'abord le partage sur l\'autre PC.');
      await useRemote(res); closeModal(); userChip();
      if (needLogin()) showLogin(); else render();
      toast('Ce PC partage maintenant les données ✔');
    } catch (e) { st.replyUrl = old.u; st.replyKey = old.k; toast(syncErr(e), 'bad'); }
  },
  syncShowCode() {
    const code = syncCode();
    openModal(`<h2>🔑 Ajouter un autre PC</h2><div class="small">Sur l'autre PC : installez Impulsion Prod, ouvrez <b>Comptes & partage → Rejoindre</b> et collez ce code.</div>
      <textarea readonly rows="4" style="width:100%;margin-top:12px;font-family:monospace" onclick="this.select()">${esc(code)}</textarea>
      <div class="alert warn" style="margin-top:10px">Ce code donne accès à toutes vos données : envoyez-le uniquement à votre patron (message privé).</div>
      <div class="modal-actions"><button data-act="closeModal">Fermer</button><button class="primary" data-act="syncCopyCode">📋 Copier le code</button></div>`);
  },
  syncPhone() {
    if (!pagesActive() || !Store.db.settings.pagesMobile) return openModal(`<h2>📱 Application téléphone</h2><div class="small">L'application téléphone est hébergée sur votre page GitHub, à côté des pages des techniciens.</div>
      <ol class="small" style="line-height:1.7;margin:10px 0 0 18px"><li>Équipe → Réponses en 1 clic → <b>Liens sans erreur Google</b> : « ⇩ Télécharger le pack (zip) ».</li><li>Dézippez et glissez les 7 fichiers dans votre dépôt GitHub (Add file → Upload files → Commit).</li><li>Cliquez « Tester », puis revenez ici.</li></ol>
      <div class="modal-actions"><button class="primary" data-act="closeModal">OK</button></div>`);
    const link = mobileAppLink();
    openModal(`<h2>📱 Installer sur mon téléphone</h2><div class="small">Ouvrez ce lien <b>sur votre téléphone</b> : il se connecte tout seul aux données partagées, puis vous choisissez votre compte (même mot de passe que sur le PC).</div>
      <textarea readonly rows="3" style="width:100%;margin-top:12px;font-family:monospace;font-size:12px" onclick="this.select()">${esc(link)}</textarea>
      <div class="row" style="margin-top:8px"><button class="primary" data-act="syncPhoneCopy">📋 Copier le lien</button><button class="wa" data-act="syncPhoneWa">💬 Me l'envoyer sur WhatsApp</button></div>
      <div class="small" style="margin-top:14px;line-height:1.6"><b>Ensuite, ajoutez-la à l'écran d'accueil :</b><br>• iPhone : ouvrez le lien dans <b>Safari</b> → bouton Partager ⬆️ → « Sur l'écran d'accueil »<br>• Android : dans <b>Chrome</b> → menu ⋮ → « Installer l'appli » (ou « Ajouter à l'écran d'accueil »)</div>
      <div class="alert warn" style="margin-top:12px">Ce lien contient le code d'accès à toutes vos données : envoyez-le uniquement à vous-même ou à votre patron, en message privé.</div>
      <div class="modal-actions"><button data-act="closeModal">Fermer</button></div>`);
  },
  syncPhoneCopy() { copyText(mobileAppLink()); toast('Lien copié ✔ — ouvrez-le sur votre téléphone'); },
  syncPhoneWa() { openExternal('https://wa.me/?text=' + encodeURIComponent('📱 Impulsion Prod sur mon téléphone : ' + mobileAppLink())); },
  syncCopyCode() { copyText(syncCode()); toast('Code copié ✔'); },
  syncCopyScript() { copyText(replyScript()); toast('Code du script v9 copié ✔ — collez-le dans Apps Script, Ctrl+S, puis Nouvelle version'); },
  syncNow() { syncCycle(true); },
  syncOff() { if (!confirm('Arrêter le partage sur ce PC ? Ce PC garde sa copie des données mais ne recevra plus les modifications des autres.')) return; syncCfg().on = false; Store.saveNow(); render(); userChip(); }
};
