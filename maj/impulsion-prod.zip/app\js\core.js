/* =====================================================================
   CORE — données, sauvegarde, migrations, utilitaires
   ===================================================================== */
const SCHEMA_VERSION = 3;
const APP_VERSION = '3.7.0';
const IS_DESKTOP = !!(window.desktop && window.desktop.isDesktop);
const NATIVE_FILES = IS_DESKTOP && typeof window.desktop.saveFile === 'function';
/* Version téléphone / navigateur (app.html hébergée sur GitHub) : données dans IndexedDB, synchronisées par le partage */
const IS_WEB = !!window.IP_WEB;
const WebDB = {
  _db: null,
  open() { return this._db || (this._db = new Promise((res, rej) => { const r = indexedDB.open('ip-web', 1); r.onupgradeneeded = () => r.result.createObjectStore('kv'); r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); })); },
  async get(k) { const db = await this.open(); return new Promise((res, rej) => { const q = db.transaction('kv').objectStore('kv').get(k); q.onsuccess = () => res(q.result); q.onerror = () => rej(q.error); }); },
  async set(k, v) { const db = await this.open(); return new Promise((res, rej) => { const t = db.transaction('kv', 'readwrite'); t.objectStore('kv').put(v, k); t.oncomplete = () => res(); t.onerror = () => rej(t.error); }); },
  async del(k) { const db = await this.open(); return new Promise((res) => { const t = db.transaction('kv', 'readwrite'); t.objectStore('kv').delete(k); t.oncomplete = () => res(); t.onerror = () => res(); }); }
};

const CATEGORIES = {
  dalle: 'Dalle LED', processeur: 'Processeur / contrôleur', cable: 'Câble', energie: 'Distribution électrique',
  structure: 'Structure / accroche', autre: 'Autre'
};
const STATUSES = { devis: 'Devis / option', confirme: 'Confirmé', encours: 'En cours', termine: 'Terminé', annule: 'Annulé' };
/* Catégories de projet (p.cat) — « Vente » = projet de vente : aucun stock réservé, dalles hors catalogue possibles */
const PROJECT_CATS = { seche: { l: 'Location sèche', ic: '📦', c: '#5b8cff' }, presta: { l: 'Presta', ic: '🎛️', c: '#19a6cc' }, longue: { l: 'Location longue durée', ic: '🗓️', c: '#b07cff' }, vente: { l: 'Vente', ic: '💼', c: '#ffb547' } };
const catOf = (p) => (p && p.cat && PROJECT_CATS[p.cat] ? p.cat : p && p.sale ? 'vente' : '');
const catTag = (p) => { const k = catOf(p); const c = PROJECT_CATS[k]; return c ? `<span class="tag" style="background:${c.c}22;color:${c.c};border:1px solid ${c.c}55" title="${k === 'vente' ? 'Vente : aucun stock réservé' : c.l}">${c.ic} ${c.l}</span>` : ''; };
const ANGLES = [-15, -10, -5, 0, 5, 10, 15];
/* angles proposés à chaque jonction (90° = coin droit : cube, angle de mur, totem 4 faces…) */
const ANGLES_ALL = [-90, -60, -45, -30, -20, -15, -10, -7.5, -5, -2.5, 0, 2.5, 5, 7.5, 10, 15, 20, 30, 45, 60, 90];
const LINE_COLORS = ['#19a6cc', '#ff3d9a', '#ffb547', '#3ccf8e', '#a97bff', '#ff7a45', '#47d7e8', '#f2e14c', '#ff5d6c', '#7fd36a', '#5b8cff', '#e07bd8', '#c9a56b', '#35b5a0', '#ff9db8', '#9fb3ff'];
const PROJECT_COLORS = ['#19a6cc', '#ff3d9a', '#ffb547', '#3ccf8e', '#a97bff', '#ff7a45', '#5b8cff', '#35b5a0'];

const uid = (p = 'id') => p + '_' + Math.random().toString(36).slice(2, 9) + Date.now().toString(36).slice(-4);
const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const num = (v, d = 0) => { const n = parseFloat(String(v).replace(',', '.')); return isFinite(n) ? n : d; };
const fmt = (n, dec = 0) => (isFinite(n) ? Number(n).toLocaleString('fr-FR', { minimumFractionDigits: dec, maximumFractionDigits: dec }) : '—');
const fmtDate = (s) => (s ? new Date(s + 'T00:00:00').toLocaleDateString('fr-FR', { day: '2-digit', month: 'short', year: 'numeric' }) : '—');
const todayISO = () => { const d = new Date(); d.setMinutes(d.getMinutes() - d.getTimezoneOffset()); return d.toISOString().slice(0, 10); };
const addDays = (iso, n) => { const d = new Date(iso + 'T00:00:00'); d.setDate(d.getDate() + n); const z = new Date(d.getTime() - d.getTimezoneOffset() * 60000); return z.toISOString().slice(0, 10); };
const deepClone = (o) => JSON.parse(JSON.stringify(o));

/* ---------- Valeurs par défaut ---------- */
function defaultSettings() {
  return {
    company: 'Impulsion Groupe', voltage: 230, amps: 16, safety: 80, pxPerPort: 655360,
    pixColor1: '#e6007e', pixColor2: '#00a7e1', reserveDevis: true, pdfView: 'both', pdfLight: true,
    waMode: 'auto', waModeV2: true, waPaste: true, calSync: 'off', calRoadmap: false, calGroup: 'tech', pagesUrl: '', pagesApi: '', replyUrl: '', replyYes: 'valide', replySince: 0, countryCode: '33',
    skills: ['Chef d\'équipe', 'Technicien LED', 'Électricien', 'Vidéo / régie', 'Rigger', 'Cariste', 'Chauffeur PL', 'Cadreur'],
    msgDemande: 'Bonjour {prenom} 👋\n\nC\'est {societe}. Serais-tu disponible pour « {projet} » ?\n📅 {dates}\n🕐 Horaires : {horaires}\n📍 {lieu}\n🛠️ Poste : {role}\n\n👉 Répondre en 1 clic : {lien}\n\n✅ OUI – dispo : ton booking est validé, pas besoin d\'autre confirmation\n❌ NON – pas dispo\n\nMerci !',
    msgRelance: 'Bonjour {prenom}, petite relance pour « {projet} »\n📅 {dates}\n\n👉 Répondre en 1 clic : {lien}\n\nPeux-tu me dire si tu es dispo ? (OUI / NON)\nMerci 🙏',
    msgOption: 'Bonjour {prenom} 👋\n\nC\'est {societe}. Je voudrais poser une option sur toi pour « {projet} » :\n📅 {dates}\n🕐 Horaires : {horaires}\n📍 {lieu}\n🛠️ Poste : {role}\n\n⚠️ Ce n\'est pas encore confirmé : je reviens vers toi pour valider officiellement le booking.\n\n👉 Répondre en 1 clic : {lien}\n\nEst-ce que je peux poser l\'option ? (OUI / NON)\nMerci !',
    msgConfirm: 'Bonjour {prenom} ✅\n\nC\'est officiel : ton booking est confirmé pour « {projet} » !\n📅 {dates}\n🕐 Horaires : {horaires}\n📍 {lieu}\n🛠️ Poste : {role}\n\n👉 Confirme ta présence en 1 clic : {lien}\n\nHoraires et infos à suivre. Merci et à bientôt !',
    msgUpdate: 'Bonjour {prenom} 🔄\n\nMise à jour pour « {projet} » :\n{changements}\n\n📅 {dates}\n🕐 Horaires : {horaires}\n📍 {lieu}\n🛠️ Poste : {role}\n\nEs-tu toujours disponible avec ces changements ?\n👉 Réponds en 1 clic : {lien}\n✅ OUI – toujours dispo\n❌ NON – je ne peux plus\n\nMerci !\n{societe}',
    msgGroup: 'Bonjour {prenom} 👋\n\nPour « {projet} » ({dates}), rejoins le groupe WhatsApp de l\'équipe :\n👉 {groupe}\n\nToutes les infos y seront partagées : feuille de route, horaires, plans, changements.\n\nÀ bientôt !\n{societe}',
    msgRelease: 'Bonjour {prenom},\n\nPour « {projet} » ({dates}), je lève l\'option que j\'avais posée sur toi : tu es libre sur ces dates.\nMerci pour ta disponibilité et à bientôt ! 🙏',
    msgRoadmap: 'Bonjour {prenom} 👋\n\nVoici la feuille de route pour « {projet} » :\n📅 {dates}\n📍 {lieu}\n\n👉 Planning, adresse, plans, matériel… tout est ici : {lienfdr}\n\nMerci et à bientôt !',
    lastReqKind: 'option',
    msgTransport: 'Bonjour {prenom} 🚚\n\nPour « {projet} », tu conduis : {vehicule} ({immat}).\n📅 {dates}\n📍 {lieu}\n\nMerci !'
  };
}
function defaultElec(s) {
  return { voltage: s.voltage, amps: s.amps, safety: s.safety, basis: 'max', maxPerLine: 0, phases: 3,
    orient: 'v', pattern: 'snake', start: 'BL', strategy: 'whole', assign: null, orders: {} };
}
function defaultData(s) {
  return { pxPerPort: s.pxPerPort, maxPerPort: 0, processorId: '', orient: 'h', pattern: 'snake', start: 'TL',
    strategy: 'whole', assign: null, orders: {} };
}
function defaultPixmap(s) {
  return { c1: s.pixColor1, c2: s.pixColor2, numbers: true, coords: true, cross: false, circle: false, grid: true, title: true, textColor: '#ffffff' };
}
function newScreen(db, productId) {
  const s = db.settings;
  return { id: uid('scr'), name: 'Écran ' , productId: productId || '', cols: 8, rows: 4, hAngles: [], vAngles: [],
    elec: defaultElec(s), data: defaultData(s), pixmap: defaultPixmap(s), notes: '' };
}
function emptyDB() {
  return { schemaVersion: SCHEMA_VERSION, createdAt: new Date().toISOString(), updatedAt: null, settings: defaultSettings(),
    products: [], projects: [], techs: [], vehicles: [] };
}
function demoDB() {
  const db = emptyDB();
  const p1 = { id: uid('prd'), category: 'dalle', ref: 'IMP-P2.9-500', name: 'Dalle P2.9 500×500', brand: 'Absen', pitch: 2.976,
    widthMm: 500, heightMm: 500, depthMm: 78, pxW: 168, pxH: 168, weightKg: 7.5, powerMax: 180, powerAvg: 60, maxChain: 12, stock: 160, notes: 'Intérieur — courbure ±15°' };
  const p2 = { id: uid('prd'), category: 'dalle', ref: 'IMP-P3.9-1000', name: 'Dalle P3.9 500×1000', brand: 'ROE Visual', pitch: 3.91,
    widthMm: 500, heightMm: 1000, depthMm: 85, pxW: 128, pxH: 256, weightKg: 11.5, powerMax: 260, powerAvg: 90, maxChain: 10, stock: 96, notes: 'Extérieur IP65' };
  const p3 = { id: uid('prd'), category: 'processeur', ref: 'NOVA-MCTRL4K', name: 'Novastar MCTRL4K', brand: 'Novastar', ports: 16, pxPerPort: 655360, stock: 3, notes: '' };
  const p4 = { id: uid('prd'), category: 'processeur', ref: 'NOVA-VX1000', name: 'Novastar VX1000', brand: 'Novastar', ports: 10, pxPerPort: 655360, stock: 4, notes: '' };
  const p5 = { id: uid('prd'), category: 'cable', ref: 'CBL-RJ45-10', name: 'Câble RJ45 Cat6 10 m', brand: '', stock: 80, notes: '' };
  const p6 = { id: uid('prd'), category: 'energie', ref: 'DISTRI-63T', name: 'Distribution 63A tri → 18×16A', brand: '', stock: 6, notes: '' };
  db.products.push(p1, p2, p3, p4, p5, p6);
  const s1 = newScreen(db, p1.id); s1.name = 'Écran principal'; s1.cols = 12; s1.rows = 6; s1.hAngles = Array(11).fill(5); s1.data.processorId = p3.id;
  const s2 = newScreen(db, p1.id); s2.name = 'Latéral jardin'; s2.cols = 4; s2.rows = 6;
  const T = (firstName, lastName, phone, skills, licence) => ({ id: uid('tec'), firstName, lastName, phone, email: '', skills, licence, dailyRate: 0, notes: '', active: true });
  const t1 = T('Karim', 'Exemple', '06 12 34 56 78', ['Chef d\'équipe', 'Technicien LED'], 'B'), t2 = T('Julie', 'Exemple', '06 98 76 54 32', ['Technicien LED', 'Vidéo / régie'], 'B'),
    t3 = T('Thomas', 'Exemple', '07 11 22 33 44', ['Rigger', 'Chauffeur PL'], 'C'), t4 = T('Lucas', 'Exemple', '06 55 44 33 22', ['Électricien'], 'B');
  db.techs.push(t1, t2, t3, t4);
  const v1 = { id: uid('veh'), name: 'Porteur 20 m³ hayon', plate: 'AB-123-CD', type: 'Porteur 20 m³', payloadKg: 1200, volumeM3: 20, licence: 'B', ctDate: addDays(todayISO(), 20), serviceDate: addDays(todayISO(), 90), notes: '', active: true };
  const v2 = { id: uid('veh'), name: 'Camion 19 t', plate: 'EF-456-GH', type: 'PL 19 t', payloadKg: 9000, volumeM3: 45, licence: 'C', ctDate: addDays(todayISO(), 200), serviceDate: addDays(todayISO(), 15), notes: '', active: true };
  db.vehicles.push(v1, v2);
  db.projects.push({ id: uid('prj'), name: 'Salon Auto Lille', client: 'Lille Grand Palais', venue: 'Lille Grand Palais', start: addDays(todayISO(), 6), end: addDays(todayISO(), 12),
    status: 'confirme', color: PROJECT_COLORS[0], notes: 'Montage J-2', screens: [s1, s2], extras: [{ productId: p5.id, qty: 24 }, { productId: p6.id, qty: 2 }], crewNeeded: 3,
    crew: [{ id: uid('req'), techId: t1.id, role: 'Chef d\'équipe', dates: [addDays(todayISO(), 6), addDays(todayISO(), 7), addDays(todayISO(), 12)], status: 'valide', sentAt: new Date().toISOString(), history: [] },
      { id: uid('req'), techId: t2.id, role: 'Technicien LED', dates: [addDays(todayISO(), 6), addDays(todayISO(), 7)], status: 'attente', sentAt: new Date().toISOString(), history: [] }],
    fleet: [{ id: uid('flt'), vehicleId: v2.id, start: addDays(todayISO(), 6), end: addDays(todayISO(), 12), driverId: t3.id, note: '' }] });
  const s3 = newScreen(db, p1.id); s3.name = 'Mur scène'; s3.cols = 14; s3.rows = 7;
  db.projects.push({ id: uid('prj'), name: 'Convention Arras', client: 'Groupe Nord', venue: 'Arras', start: addDays(todayISO(), 9), end: addDays(todayISO(), 11),
    status: 'devis', color: PROJECT_COLORS[1], notes: '', screens: [s3], extras: [], crew: [], fleet: [] });
  return db;
}

/* ---------- Migrations : chaque évolution de l'appli ajoute une étape ici ---------- */
const MIGRATIONS = {
  // v1 -> v2 : ajout pixel map, paramètres data & réglage "vue arrière"
  1: (db) => {
    db.projects.forEach((p) => (p.screens || []).forEach((s) => {
      s.pixmap = Object.assign(defaultPixmap(db.settings), s.pixmap || {});
      s.data = Object.assign(defaultData(db.settings), s.data || {});
    }));
    return db;
  },
  // v2 -> v3 : techniciens, véhicules, équipe & transport par projet (ajoutés par la normalisation)
  2: (db) => db
};
function migrate(db) {
  if (!db || typeof db !== 'object') return emptyDB();
  db.schemaVersion = db.schemaVersion || 1;
  while (db.schemaVersion < SCHEMA_VERSION) {
    const step = MIGRATIONS[db.schemaVersion];
    if (step) db = step(db);
    db.schemaVersion++;
  }
  // Normalisation défensive : tout champ manquant reçoit sa valeur par défaut, rien n'est jamais supprimé.
  const hadV2 = db.settings && db.settings.waModeV2;
  db.settings = Object.assign(defaultSettings(), db.settings || {});
  if (!hadV2) { db.settings.waMode = 'auto'; db.settings.waModeV2 = true; }
  if (typeof db.settings.msgRelance === 'string' && db.settings.msgRelance.includes('» 📅 {dates}.\n')) db.settings.msgRelance = defaultSettings().msgRelance; // v1.1.1 : WhatsApp Desktop en direct par défaut
  db.products = Array.isArray(db.products) ? db.products : [];
  db.projects = Array.isArray(db.projects) ? db.projects : [];
  db.techs = Array.isArray(db.techs) ? db.techs : [];
  if (!db.settings.bookingNoOptV1) { // v1.8.3 : plus de choix « option » dans le booking direct
    db.settings.bookingNoOptV1 = true;
    ['msgDemande', 'msgRelance'].forEach((k) => { if (typeof db.settings[k] === 'string') db.settings[k] = db.settings[k].replace(/\n?🟦 OPTION – à confirmer/g, '').replace(/\(OUI \/ OPTION \/ NON\)/g, '(OUI / NON)'); });
  }
  if (!db.settings.calTechV1) { // v2.8 : un événement par technicien — personne n'est prévenu quand un autre répond
    db.settings.calTechV1 = true; db.settings.calGroup = 'tech';
  }
  if (!db.settings.bookingV2) { // v2.6 : la réponse « dispo » à un booking direct vaut validation officielle
    db.settings.bookingV2 = true;
    const v = db.settings.msgDemande; if (typeof v === 'string' && v.includes('✅ OUI – dispo\n')) db.settings.msgDemande = v.replace('✅ OUI – dispo\n', '✅ OUI – dispo : ton booking est validé, pas besoin d\'autre confirmation\n');
    (db.projects || []).forEach((p) => (p.crew || []).forEach((r) => {
      if (r.status !== 'valide') return;
      if (!r.ack && r.reply && r.reply.phase === 'booking' && r.reply.status !== 'indispo') r.ack = { at: r.reply.at, via: 'booking' };
      if (r.ack && !r.ackSnap) r.ackSnap = { dates: [...(r.dates || [])].sort().join(','), hours: typeof hoursShort === 'function' ? hoursShort(r) : '', role: r.role || '', lieu: p.venue || '' };
    }));
  }
  if (!db.settings.hoursV1) { // v1.9.2 : ligne d'horaires dans les messages
    db.settings.hoursV1 = true;
    ['msgOption', 'msgDemande', 'msgConfirm'].forEach((k) => { const v = db.settings[k]; if (typeof v === 'string' && !v.includes('{horaires}')) db.settings[k] = v.includes('📅 {dates}') ? v.replace('📅 {dates}', '📅 {dates}\n🕐 Horaires : {horaires}') : v; });
  }
  if (!db.settings.skillsV2) { db.settings.skillsV2 = true; if (Array.isArray(db.settings.skills) && !db.settings.skills.includes('Cadreur')) db.settings.skills.push('Cadreur'); }
  db.calTrash = Array.isArray(db.calTrash) ? db.calTrash : [];
  db.vehicles = Array.isArray(db.vehicles) ? db.vehicles : [];
  db.techs.forEach((t) => { t.id = t.id || uid('tec'); t.skills = Array.isArray(t.skills) ? t.skills : []; if (t.active === undefined) t.active = true; });
  db.vehicles.forEach((v) => { v.id = v.id || uid('veh'); if (v.active === undefined) v.active = true; });
  db.products.forEach((p) => { p.id = p.id || uid('prd'); p.stock = num(p.stock); p.category = p.category || 'autre'; });
  db.projects.forEach((p, i) => {
    p.id = p.id || uid('prj'); p.screens = Array.isArray(p.screens) ? p.screens : []; p.extras = Array.isArray(p.extras) ? p.extras : [];
    p.status = p.status || 'confirme'; p.color = p.color || PROJECT_COLORS[i % PROJECT_COLORS.length];
    p.crew = Array.isArray(p.crew) ? p.crew : []; p.fleet = Array.isArray(p.fleet) ? p.fleet : []; p.crewNeeded = num(p.crewNeeded);
    p.crew.forEach((r) => { r.id = r.id || uid('req'); r.dates = Array.isArray(r.dates) ? r.dates : []; r.status = r.status || 'attente'; r.history = Array.isArray(r.history) ? r.history : []; });
    p.fleet.forEach((f) => { f.id = f.id || uid('flt'); });
    p.screens.forEach((s) => {
      s.id = s.id || uid('scr'); s.cols = Math.max(1, num(s.cols, 1) | 0); s.rows = Math.max(1, num(s.rows, 1) | 0);
      if (s.type === 'boarding') {
        s.zones = Array.isArray(s.zones) && s.zones.length ? s.zones : [{ id: uid('zon'), name: 'Zone 1', count: s.cols }];
        s.zones.forEach((z, zi) => { z.id = z.id || uid('zon'); z.name = z.name || 'Zone ' + (zi + 1); z.count = Math.max(1, num(z.count, 1) | 0); z.rows = Math.max(1, Math.round(num(z.rows)) || Math.max(1, num(s.rows) | 0)); });
        s.cols = s.zones.reduce((a, z) => a + z.count, 0); s.rows = Math.max(...s.zones.map((z) => z.rows)); s.tilt = num(s.tilt);
      }
      s.elec = Object.assign(defaultElec(db.settings), s.elec || {}); s.data = Object.assign(defaultData(db.settings), s.data || {});
      s.pixmap = Object.assign(defaultPixmap(db.settings), s.pixmap || {});
      s.elec.orders = s.elec.orders || {}; s.data.orders = s.data.orders || {};
      fitAngles(s);
    });
  });
  return db;
}
function fitAngles(s) {
  const fit = (arr, n) => { arr = Array.isArray(arr) ? arr.slice(0, n) : []; while (arr.length < n) arr.push(0); return arr.map((a) => num(a)); };
  s.hAngles = fit(s.hAngles, Math.max(0, s.cols - 1));
  s.vAngles = fit(s.vAngles, Math.max(0, s.rows - 1));
}

/* ---------- Stockage ---------- */
const Store = {
  db: null, path: '', dir: '', timer: null, dirty: false,
  async init() {
    let raw = null;
    if (IS_DESKTOP) {
      const r = await window.desktop.load(); raw = r.raw; this.path = r.path; this.dir = r.dir; this.onedrive = !!r.onedrive || /\\OneDrive/i.test(r.path || ''); this.fileExists = !!r.exists; this.readError = r.readError || '';
    } else if (IS_WEB) {
      try { raw = await WebDB.get('db'); } catch (e) { raw = null; } this.path = 'Ce téléphone (données partagées)';
    } else {
      raw = localStorage.getItem('impulsion-led-db'); this.path = 'Navigateur (aperçu) — stockage local';
    }
    let db; let broken = false;
    if (raw) { try { db = JSON.parse(raw); } catch (e) { db = null; broken = true; } }
    if (!db && IS_DESKTOP && (broken || this.fileExists)) {
      // fichier présent mais illisible (OneDrive, coupure…) : JAMAIS de base vide à la place — on reprend la dernière sauvegarde valide
      db = await this.fromLastBackup();
      if (!db) throw new Error('Le fichier de données est illisible pour le moment (' + (this.readError || 'contenu abîmé') + '). Rien n\'a été modifié : fermez et relancez Impulsion Prod. Si OneDrive est en cours de synchronisation, attendez qu\'il ait fini.');
    }
    const fresh = !db;
    if (!db) db = demoDB();
    const before = db.schemaVersion;
    if (before && before < SCHEMA_VERSION && IS_DESKTOP) await window.desktop.backup('avant-migration-v' + before);
    this.db = migrate(db);
    if (fresh || before !== SCHEMA_VERSION) this.saveNow();
    window.addEventListener('beforeunload', () => { if (this.dirty) this.flushSync(); });
    return this.db;
  },
  async fromLastBackup() {
    try {
      const list = await window.desktop.listBackups();
      for (const n of list) { try { const d = JSON.parse(await window.desktop.readBackup(n)); if (d && Array.isArray(d.projects)) { setTimeout(() => toast('Fichier de données illisible : la dernière sauvegarde valide a été reprise (' + n.replace(/^sauvegarde_|\.json$/g, '').replace(/_/g, ' ') + '). Le partage complète avec les données en ligne.', 'warn'), 1500); return d; } } catch (e) { /* suivante */ } }
    } catch (e) { /* pas de sauvegardes */ }
    return null;
  },
  serialize() { this.db.updatedAt = new Date().toISOString(); this.db.appVersion = APP_VERSION; return JSON.stringify(this.db, null, 1); },
  save() {
    this.dirty = true; setSaveState('pending');
    clearTimeout(this.timer); this.timer = setTimeout(() => this.saveNow(), 500);
  },
  async saveNow() {
    clearTimeout(this.timer);
    try {
      const json = this.serialize();
      let st = 'ok';
      if (IS_DESKTOP) st = await window.desktop.save(json); else if (IS_WEB) await WebDB.set('db', json); else localStorage.setItem('impulsion-led-db', json);
      this.dirty = false; clearTimeout(this.retry);
      if (st === 'secours') { setSaveState('secours'); saveTrouble('secours'); this.retry = setTimeout(() => this.saveNow(), 20000); } else { this.warned = false; this.fails = 0; setSaveState('ok'); }
    } catch (e) {
      console.error(e); this.fails = (this.fails || 0) + 1; setSaveState('err'); saveTrouble('err');
      clearTimeout(this.retry); this.retry = setTimeout(() => this.saveNow(), Math.min(30000, 3000 * this.fails)); // nouvel essai automatique
    }
  },
  flushSync() {
    const json = this.serialize();
    if (IS_DESKTOP) window.desktop.saveSync(json); else if (IS_WEB) WebDB.set('db', json).catch(() => {}); else localStorage.setItem('impulsion-led-db', json);
    this.dirty = false;
  },
  replace(db) { const keep = this.db && this.db.local; this.db = migrate(db); if (keep) this.db.local = keep; else delete this.db.local; this.saveNow(); if (typeof journalResync === 'function') journalResync(); }
};
function setSaveState(s) {
  const el = document.getElementById('saveState'); if (!el) return;
  el.className = s === 'ok' ? 'save-ok' : s === 'err' ? 'save-err' : 'save-pending';
  el.textContent = s === 'ok' ? '● Sauvegardé' : s === 'err' ? '● Erreur de sauvegarde — nouvel essai…' : s === 'secours' ? '● Sauvegardé (copie de secours)' : '● Enregistrement…';
  el.title = s === 'secours' ? 'Le fichier principal (OneDrive ?) est bloqué : tout est enregistré dans une copie de secours sur ce PC, et en ligne si le partage est actif.' : '';
}
/* Sauvegarde qui coince (souvent OneDrive) : on propose UNE fois de déplacer les données sur le disque local */
function saveTrouble(kind) {
  if (!IS_DESKTOP || Store.troubleShown) return;
  if (kind === 'err' && (Store.fails || 0) < 2) return;
  Store.troubleShown = true;
  const od = Store.onedrive;
  setTimeout(() => openModal(`<h2>⚠ Le fichier de données est bloqué</h2>
    <div class="small" style="line-height:1.6">${kind === 'secours' ? 'Rien n\'est perdu : l\'application a tout enregistré dans une <b>copie de secours</b> sur ce PC' : 'L\'application réessaie toute seule'}${typeof syncOn === 'function' && syncOn() ? ', et vos données sont aussi en ligne (partage Google)' : ''}.<br>
    ${od ? 'La cause est presque toujours <b>OneDrive</b>, qui verrouille le fichier pendant qu\'il le synchronise. Le partage Google fait déjà la copie en ligne : OneDrive n\'est pas utile pour ces données.' : 'Le dossier des données est verrouillé (synchronisation, antivirus…).'}</div>
    <div class="alert" style="margin-top:12px">✅ Recommandé : <b>mettre les données sur ce PC</b>, hors de OneDrive (<code>${esc('C:\\Users\\…\\Impulsion Prod donnees')}</code>). Vos sauvegardes sont copiées aussi. L'opération prend 2 secondes.</div>
    <div class="modal-actions"><button data-act="closeModal">Plus tard</button><button class="primary" data-act="moveDataLocal">📁 Mettre mes données sur ce PC</button></div>`), 300);
}

/* ---------- Fichiers (export) ---------- */
async function saveFileBase64(defaultName, base64, ext, label) {
  if (NATIVE_FILES) {
    const p = await window.desktop.saveFile({ defaultName, base64, filters: [{ name: label || ext.toUpperCase(), extensions: [ext] }] });
    if (p) toast('Fichier exporté ✔ ' + p.split(/[\\/]/).pop());
  } else {
    const a = document.createElement('a'); a.href = 'data:application/octet-stream;base64,' + base64; a.download = defaultName; a.click();
    toast('Téléchargement : ' + defaultName);
  }
}
async function saveFileText(defaultName, text, ext, label) {
  if (NATIVE_FILES) {
    const p = await window.desktop.saveFile({ defaultName, text, filters: [{ name: label || ext.toUpperCase(), extensions: [ext] }] });
    if (p) toast('Fichier exporté ✔ ' + p.split(/[\\/]/).pop());
  } else {
    const blob = new Blob([text], { type: 'text/plain;charset=utf-8' }); const a = document.createElement('a');
    a.href = URL.createObjectURL(blob); a.download = defaultName; a.click(); toast('Téléchargement : ' + defaultName);
  }
}
async function openTextFile(ext) {
  if (NATIVE_FILES) return window.desktop.openFile({ filters: [{ name: ext.toUpperCase(), extensions: [ext] }] });
  return new Promise((res) => {
    const i = document.createElement('input'); i.type = 'file'; i.accept = '.' + ext;
    i.onchange = () => { const f = i.files[0]; if (!f) return res(null); const r = new FileReader(); r.onload = () => res(r.result); r.readAsText(f); };
    i.click();
  });
}
const dataURLtoB64 = (u) => u.split(',')[1];
const safeName = (s) => String(s || 'export').normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-zA-Z0-9-_]+/g, '_').replace(/_+/g, '_').replace(/^_|_$/g, '');

/* ---------- Toasts & fun ---------- */
function toast(msg, kind) {
  const t = document.createElement('div'); t.className = 'toast ' + (kind || ''); t.textContent = msg;
  document.getElementById('toasts').appendChild(t);
  setTimeout(() => { t.style.transition = '.3s'; t.style.opacity = '0'; setTimeout(() => t.remove(), 300); }, 3200);
}
function confetti() {
  const c = document.getElementById('confetti'); const ctx = c.getContext('2d');
  c.width = innerWidth; c.height = innerHeight;
  const parts = Array.from({ length: 140 }, () => ({ x: innerWidth / 2 + (Math.random() - .5) * 200, y: innerHeight / 3, vx: (Math.random() - .5) * 14, vy: -Math.random() * 12 - 3,
    s: 4 + Math.random() * 6, c: LINE_COLORS[(Math.random() * 8) | 0], r: Math.random() * 6 }));
  let f = 0;
  (function step() {
    ctx.clearRect(0, 0, c.width, c.height);
    parts.forEach((p) => { p.x += p.vx; p.y += p.vy; p.vy += .35; p.r += .1; ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(p.r); ctx.fillStyle = p.c; ctx.fillRect(-p.s / 2, -p.s / 2, p.s, p.s); ctx.restore(); });
    if (++f < 110) requestAnimationFrame(step); else ctx.clearRect(0, 0, c.width, c.height);
  })();
}
function ledStrip() {
  const c = document.getElementById('ledstrip'); if (!c) return; const ctx = c.getContext('2d'); let t = 0;
  (function loop() {
    ctx.clearRect(0, 0, c.width, c.height);
    for (let i = 0; i < 25; i++) {
      const v = (Math.sin(t / 14 - i / 2.5) + 1) / 2;
      ctx.fillStyle = `rgba(${25 + 230 * v * v * 0.2 | 0},${120 + 80 * v | 0},${170 + 70 * v | 0},${0.15 + v * 0.85})`;
      ctx.fillRect(i * 8, 2, 6, 10);
    }
    t++; requestAnimationFrame(loop);
  })();
}
