@echo off
chcp 65001 >nul
title Impulsion Prod - Construction de l installeur
cd /d "%~dp0.."
echo.
echo   ==== IMPULSION PROD ====
echo   Construction de l installeur Windows...
echo.
where node >nul 2>nul
if errorlevel 1 (
  echo [!] Node.js n est pas installe.
  echo     Installez la version LTS depuis https://nodejs.org puis relancez ce fichier.
  start https://nodejs.org/fr/download
  pause
  exit /b 1
)
echo [1/2] Installation des composants (quelques minutes la premiere fois)...
call npm install
if errorlevel 1 ( echo [!] Echec de l installation. & pause & exit /b 1 )
echo [2/2] Creation de l installeur...
call npm run dist:win
if errorlevel 1 ( echo [!] Echec de la construction. & pause & exit /b 1 )
echo.
echo   OK ! Les fichiers sont dans le dossier "dist" :
echo   - ImpulsionLED-Setup-1.0.0.exe  (installeur)
echo   - ImpulsionLED-Portable-1.0.0.exe (sans installation)
start "" "%~dp0..\dist"
pause
