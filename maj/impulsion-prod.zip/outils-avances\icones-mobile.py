"""Génère app/mobile/icon-192.png et icon-512.png à partir du logo (app/js/logo-data.js)."""
import base64, io, os, re
from PIL import Image, ImageDraw, ImageFont
ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'app')
src = open(os.path.join(ROOT, 'js', 'logo-data.js'), encoding='utf-8').read()
logo = Image.open(io.BytesIO(base64.b64decode(re.search(r'base64,([A-Za-z0-9+/=]+)', src).group(1)))).convert('RGBA')
# logo prévu pour fond clair : les parties grises/noires passent en blanc (le « S » bleu reste bleu)
px = logo.load()
for yy in range(logo.height):
    for xx in range(logo.width):
        r, g, b, a = px[xx, yy]
        if a and max(r, g, b) - min(r, g, b) < 60: v = 255 - (r + g + b) // 3; px[xx, yy] = (max(v, 200), max(v, 200), max(v, 200), a)
font = '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
for S in (192, 512):
    im = Image.new('RGBA', (S, S), (10, 16, 20, 255)); d = ImageDraw.Draw(im)
    w = int(S * 0.80); lg = logo.resize((w, int(logo.height * w / logo.width)), Image.LANCZOS)
    y = int(S * 0.20); im.alpha_composite(lg, ((S - w) // 2, y))
    by = y + lg.height + int(S * 0.05); n = 10; gap = S * 0.012; bw = (w - gap * (n - 1)) / n
    for i in range(n):
        x0 = (S - w) / 2 + i * (bw + gap); d.rounded_rectangle([x0, by, x0 + bw, by + S * 0.035], radius=S * 0.008, fill=(25, 166, 204, 255 if i % 3 else 140))
    f = ImageFont.truetype(font, int(S * 0.11)); t = 'PROD'; tw = d.textlength(t, font=f)
    d.text(((S - tw) / 2, by + S * 0.07), t, font=f, fill=(25, 166, 204, 255))
    im.convert('RGB').save(os.path.join(ROOT, 'mobile', f'icon-{S}.png'), optimize=True)
print('ok')
