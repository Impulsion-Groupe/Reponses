@echo off
cd /d "%~dp0.."
where node >nul 2>nul || (echo Installez Node.js depuis https://nodejs.org & pause & exit /b 1)
if not exist node_modules call npm install
call npm start
