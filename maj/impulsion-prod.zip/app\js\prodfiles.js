/* =====================================================================
   FICHIERS PAR RÉFÉRENCE (RCG NovaStar, configurations, notices…)
   product.files = [{ id, name, size, mime, b64, hash, at, url, driveId, up }]
   Publiés sur Google Drive par le relais (script v10) et transmis aux techniciens
   bookés : feuille de route en ligne, résumé WhatsApp, événement d'agenda.
   ===================================================================== */
const PF_MAX = 5 * 1024 * 1024;
const fileB64 = (file) => new Promise((res, rej) => { const fr = new FileReader(); fr.onload = () => res(String(fr.result).split(',')[1] || ''); fr.onerror = () => rej(fr.error); fr.readAsDataURL(file); });
const fmtBytes = (b) => (b > 1048576 ? fmt(b / 1048576, 1) + ' Mo' : Math.max(1, Math.round(b / 1024)) + ' Ko');
function prodFilesHTML(p) {
  const files = p.files || [];
  return `<div class="span4 pf-box"><div class="row" style="justify-content:space-between"><b>💾 Fichiers (RCG, configuration, notice…)</b><button class="sm" data-act="pfAdd">＋ Ajouter</button></div>
    ${files.length ? files.map((f, i) => `<div class="pf-row"><span>📄 <b>${esc(f.name)}</b> <span class="tiny muted">${fmtBytes(f.size)} · ${new Date(f.at).toLocaleDateString('fr-FR')}${f.url && f.up === f.hash ? ' · ☁ en ligne' : ''}</span></span>
      <span><button class="sm ghost" data-act="pfSave" data-i="${i}" title="Enregistrer sur ce PC">⇩</button><button class="sm ghost" data-act="pfDel" data-i="${i}" title="Retirer">✕</button></span></div>`).join('')
    : '<div class="tiny muted" style="margin-top:6px">Ajoutez par exemple le fichier .rcg de cette dalle : il sera transmis automatiquement aux techniciens bookés sur les projets qui l\'utilisent (feuille de route).</div>'}</div>`;
}
const prodFileActions = {
  async pfAdd() {
    const files = await new Promise((res) => { const i = document.createElement('input'); i.type = 'file'; i.multiple = true; i.onchange = () => res([...i.files]); i.click(); }); if (!files.length) return;
    const e = ui.edit; if (!e) return; readForm('[data-pf]', e, 'pf'); e.files = e.files || [];
    for (const f of files) {
      if (f.size > PF_MAX) { toast(`${f.name} : trop lourd (max ${fmtBytes(PF_MAX)})`, 'warn'); continue; }
      const b64 = await fileB64(f); const hash = sha256(b64).slice(0, 16); const old = e.files.find((x) => x.name === f.name);
      const rec = { id: old ? old.id : uid('pf'), name: f.name, size: f.size, mime: f.type || 'application/octet-stream', b64, hash, at: new Date().toISOString(), url: old && old.url, driveId: old && old.driveId, up: old && old.up };
      if (old) Object.assign(old, rec); else e.files.push(rec);
    }
    openModal(productForm(e));
  },
  pfDel(el) { const e = ui.edit; readForm('[data-pf]', e, 'pf'); e.files.splice(+el.dataset.i, 1); openModal(productForm(e)); },
  async pfSave(el) { const f = ui.edit.files[+el.dataset.i]; if (!f.b64 && f.url) return openExternal(f.url); await saveFileBase64(f.name, f.b64, (f.name.split('.').pop() || 'bin').toLowerCase(), 'Fichier'); },
  async rmFilesUpload() { const p = curProject(); try { const n = await uploadProjectFiles(p, true); toast(n ? `${n} fichier(s) mis en ligne ✔` : 'Fichiers déjà en ligne ✔'); render(); } catch (e) { toast(e.message, 'bad'); } }
};
/* Produits du projet ayant des fichiers */
function projectFiles(p) {
  const out = []; [...projectUsage(p).keys()].forEach((pid) => { const x = getProduct(pid); if (x && (x.files || []).length) x.files.forEach((f) => out.push({ prod: x, f })); });
  return out;
}
/* Met en ligne (Drive via le relais) les fichiers nouveaux ou modifiés ; renvoie le nombre envoyé */
async function uploadProjectFiles(p, force) {
  const list = projectFiles(p).filter(({ f }) => force ? !f.url || f.up !== f.hash : !f.url || f.up !== f.hash); if (!list.length) return 0;
  if (!replyActive()) throw new Error('Activez le relais Google pour envoyer les fichiers');
  let n = 0;
  for (const { f } of list) {
    const j = await withTimeout(remotePost({ action: 'file', key: ensureReplyKey(), name: f.name, mime: f.mime, b64: f.b64, prev: f.driveId || '' }), 60000);
    if (!j || !j.url) throw new Error(j && j.error ? j.error : 'Le script Google doit être mis à jour (v10) et autorisé pour Google Drive (fonction autoriserFichiers)');
    f.url = j.url; f.driveId = j.id; f.up = f.hash; n++;
  }
  Store.save(); return n;
}
const roadmapFiles = (p) => projectFiles(p).filter(({ f }) => f.url).map(({ prod, f }) => ({ ref: prod.ref, product: prod.name, name: f.name, url: f.url }));
