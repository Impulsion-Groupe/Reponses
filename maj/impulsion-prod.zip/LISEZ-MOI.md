# Impulsion Prod — v3.7.0

Application de bureau (Windows / Mac) pour gérer le catalogue, le stock par dates et les plans d'écrans LED.

## Lancer l'application (Windows) — un double-clic

1. Clic droit sur le ZIP → **Extraire tout**, et rangez le dossier où vous voulez (ex. `Documents`).
2. Double-cliquez sur **`Impulsion Prod`**. L'application s'ouvre dans sa propre fenêtre.
3. Dès le premier lancement, une icône **Impulsion Prod** est créée sur le Bureau et dans le menu Démarrer : ensuite, c'est elle que vous utilisez.

Rien à installer : le lanceur utilise PowerShell et Microsoft Edge, déjà présents sur Windows 10 / 11.
Si Windows affiche « Windows a protégé votre ordinateur » : **Informations complémentaires → Exécuter quand même** (une seule fois).
Ne déplacez plus le dossier après coup, ou relancez `Impulsion Prod` depuis son nouvel emplacement pour recréer l'icône.

Exports : les PNG / CSV vont dans *Téléchargements* ; pour les PDF, choisissez « Enregistrer au format PDF » dans la fenêtre d'impression.

### Option : installeur .exe classique
Le dossier `outils-avances` permet de fabriquer un vrai installeur (`CONSTRUIRE-INSTALLEUR-EXE.bat`, nécessite Node.js) ou une version Mac. Les deux versions partagent le même fichier de données.

## Vos données
- Fichier : `Documents\Impulsion LED Manager\impulsion-led-data.json`
- Enregistrement automatique à chaque modification (écriture sécurisée).
- Sauvegardes automatiques dans `sauvegardes\` : à chaque démarrage, toutes les heures, avant chaque import / restauration / migration (60 conservées).
- **Mises à jour** : installez simplement la nouvelle version par-dessus. Le fichier de données n'est jamais dans le dossier de l'application ; il est converti automatiquement au nouveau format (après sauvegarde).
- Paramètres → *Changer de dossier* pour mettre les données sur OneDrive / Dropbox / serveur.
  ⚠ Une seule personne à la fois doit modifier le même fichier. Pour travailler à plusieurs, utilisez plutôt le **partage entre plusieurs PC** (v2.0).

## Utilisation rapide
1. **Catalogue** : ajoutez vos dalles (dimensions, résolution, conso, max dalles par ligne), processeurs (ports, px/port), câbles, distribution…
2. **Projets** : nom, dates de sortie / retour, statut. Le stock est vérifié sur la période (projets qui se chevauchent cumulés).
3. **Écrans** dans un projet :
   - *Configuration & courbure* : colonnes × rangées, angle à chaque jonction (−15° à +15°, + = concave). Calcul de largeur, hauteur, profondeur, rayon, diamètre, flèche, arc, vue 3D.
   - *Plan électrique* / *Plan data* : répartition automatique (sens vertical/horizontal, serpentin ou retour, coin de départ, praticité). Modifiable à la main : **Peindre** pour changer les dalles d'une ligne, **Tracer l'ordre** pour imposer le chemin de câblage. Vue de face ou de dos.
   - *Pixel map* : damier bicolore, couleurs au choix. Export PNG au choix (v2.0.1) : **natif** (1 pixel = 1 LED), **ajusté** en 1920 × 1080 / 3840 × 2160 / format libre (centré sur fond noir), ou **dans une sortie vidéo** (pixel map natif placé à X / Y dans une image 1080p, 4K ou libre ; alerte si ça dépasse). Le choix est mémorisé par écran.
   - *Exports* : PNG de chaque plan, fiche PDF écran, dossier PDF complet du projet, liste matériel CSV.

## Équipe & véhicules (v1.1)
- **Équipe** : fiches techniciens (téléphone WhatsApp, compétences, permis), planning de disponibilités, messages types modifiables.
- Dans un projet, **Solliciter des techniciens** : choisir les dates, le poste, cocher les techniciens (les conflits avec d'autres projets sont signalés) → l'envoi guidé ouvre WhatsApp avec le message prêt pour chacun, il suffit d'appuyer sur Envoyer.
- Statuts : En attente / Option / Validé / Indispo. Le bouton 💬 envoie automatiquement le bon message (demande, relance, ou confirmation si validé). SMS et email possibles.
- **Véhicules** : flotte, charge utile, volume, permis, contrôle technique et entretien (alertes). Dans un projet : affectation, chauffeur, contrôle du poids / volume chargé, double réservation, permis du chauffeur, message au chauffeur.
- **WhatsApp** : si WhatsApp Desktop est installé, il s'ouvre directement sur la conversation. Le message est copié : faites **Ctrl+V** puis **Entrée** (c'est ce qui garantit les emojis, WhatsApp les retire d'un texte pré-rempli). Réglable dans Équipe → Messages types.
- Renseignez le *poids* et le *volume unitaire* de vos références dans le Catalogue pour le calcul de chargement.

## Réponses des techniciens en 1 clic (v1.2)
- Chaque demande contient un **lien personnel**. Le technicien le touche sur son téléphone, décoche éventuellement des jours et appuie sur ✅ Dispo / 🟦 Option / ❌ Pas dispo (+ commentaire).
- L'application vérifie les réponses toutes les minutes et met les statuts et les jours à jour toute seule (notification à l'écran).
- Mise en place unique : **Équipe → Réponses en 1 clic** (5 étapes guidées). Le relais est un script Google Apps Script gratuit sur votre compte Google ; les réponses sont aussi visibles dans le Google Sheets « Impulsion LED – Réponses techniciens » de votre Drive.
- Code source du script : `app/gs/reponses-techniciens.gs` (le bouton « Copier le code » de l'application y insère votre clé secrète). Après modification de ce fichier, régénérer `app/js/replygs.js`.

## Option puis booking (v1.3)
- En sollicitant, choisissez **🟦 Demande d'option** (pré-réservation) ou **✅ Booking direct**.
- Option : le technicien répond « OK, je bloque ces dates » / « Pas dispo » → statut **Option** (jamais validé automatiquement).
- **📌 Valider le booking** (ou « Valider les N options ») envoie la confirmation officielle → statut **Validé** ; le technicien confirme sa présence en 1 clic (« présence confirmée » affiché dans le projet). S'il répond « Je ne peux plus venir », il repasse en Indispo avec une alerte.
- **↩ Lever** : prévient le technicien qu'il est libéré et libère ses dates.
- ⚠ Si vous aviez déjà installé le script Google : copiez le nouveau code (Équipe → Réponses en 1 clic), remplacez-le dans Apps Script, Ctrl+S, puis Déployer → Gérer les déploiements → ✏️ → Nouvelle version.

## Booking validé en 1 réponse + mises à jour (v2.6)
- **Booking direct** : quand le technicien répond « ✅ Dispo », le booking est **validé officiellement** (« ✅ Booking validé par le technicien le … ») — plus de confirmation à renvoyer.
- **Option** : inchangé — « 📌 Valider le booking » envoie le passage en booking, le technicien confirme.
- **Changement d'organisation** : si les dates, horaires, poste ou lieu changent après la validation, la ligne affiche « ⚠ Modifié depuis sa validation : … » avec **🔄 Envoyer la mise à jour** (ou « Prévenir N tech(s) du changement » pour toute l'équipe). Le message (modèle « Mise à jour du projet », variable `{changements}`) liste ce qui change et demande s'il est toujours dispo ; sa réponse revalide le booking ou le passe en indispo.

## Groupe WhatsApp de l'équipe (v2.6.1)
- Feuille de route du projet → **👥 Groupe WhatsApp de l'équipe**. WhatsApp ne permet pas à un logiciel de créer un groupe : créez-le une fois dans WhatsApp, puis Infos du groupe → Inviter via un lien → Copier, et collez le lien.
- **📲 Inviter** : envoi guidé du lien d'invitation à chaque technicien validé et chauffeur (modèle « Invitation au groupe », variable `{groupe}`). Suivi de qui a été invité ; les personnes bookées ensuite sont signalées « à inviter ».
- **💬 Poster la feuille de route dans le groupe** : met à jour la version en ligne, copie le résumé et ouvre directement le groupe → Ctrl+V puis Entrée.

## Vue 3D de la scène (v1.4)
- Dans un projet : **🎬 Vue 3D de la scène** — tous les écrans ensemble, avec leur courbure, sur un sol quadrillé (1 m) et une silhouette de 1,80 m pour l'échelle.
- **Implantation** (vue de dessus) : glissez les écrans à la souris, molette = rotation ±5°, ou saisissez X / profondeur / hauteur du bas / rotation.
- Caméras rapides (face, 3/4, dessus, côté), mode « une couleur par écran », exports PNG (3D et implantation) et page « Vue d'ensemble » dans le dossier PDF.

## Boarding — panneaux bord terrain (v1.5)
- Dans un projet : **＋ Boarding** → saisissez la quantité du projet (total de panneaux), le nombre de zones et leurs noms. Ensuite : « Répartir N panneaux en Z zones » (« Répartir 64 panneaux en 4 zones »), ou réglez chaque zone (nom, nombre de panneaux — zones inégales possibles).
- Plans élec / data **zone par zone** : aucune ligne ne traverse deux zones (alerte si une modification manuelle le fait). Plans présentés une bande par zone, avec nom, longueur et lignes de la zone.
- Pixel map : une zone par ligne, une ligne continue, ou repliée sur une largeur de sortie (1920, 2560, 3840, 4096 px). Panneaux numérotés Z1-01…
- Scène 3D : chaque zone est un élément séparé ; « Autour du terrain » place les zones sur les 4 côtés, tournées vers le terrain. Inclinaison des panneaux réglable.

## Fichiers RCG par référence (v2.5)
- Catalogue → une référence → **💾 Fichiers** : ajoutez le .rcg (ou tout fichier de configuration / notice, 5 Mo max).
- Les fichiers des références utilisées dans un projet sont mis en ligne (Google Drive, dossier « Impulsion LED – Fichiers techniques », lien de téléchargement) à la publication de la feuille de route, et transmis aux techniciens bookés : **feuille de route en ligne** (section « Fichiers de configuration »), **résumé WhatsApp** et **agenda**. Carte « 💾 Fichiers de configuration » dans la feuille de route du projet.
- Nécessite le script Google **v10** : copier le nouveau code, Ctrl+S, exécuter une fois la fonction **autoriserFichiers** (accès Google Drive), puis Gérer les déploiements → Nouvelle version. Avec GitHub Pages : retélécharger index.html et le remplacer.

## Implantation au sol dans la 3D (v2.5)
- Vue 3D de la scène → **Implantation au sol** : **terrain de sport** aux cotes officielles (basket FIBA, basket 3×3, volley, beach volley, handball, futsal, football, rugby, tennis, padel, rectangle libre), **plan DXF** de la salle (calques à afficher/masquer, unités) ou **image de plan** à l'échelle (largeur réelle).
- Position, rotation (↻ 90°), opacité ; « Centrer devant les écrans ».
- **Boarding** (v2.5.1) : posé à la **limite de l'aire de jeu** = terrain + zone libre propre au sport (volley 3 m, basket 2 m, hand 1 m côtés / 2 m fonds, foot 3 / 5 m, rugby 5 m, tennis 3,66 / 6,40 m…), modifiable (« Zone libre côtés / fonds », « Recul supplémentaire »). Choix des côtés : 4 côtés, 2 longueurs, en U, 1 longueur côté écrans / côté public, 2 largeurs ; les zones sont réparties selon la longueur disponible, alerte si un côté déborde.
- Fichier **.dwg** : à enregistrer en **.dxf** (AutoCAD, ou gratuitement DWG TrueView / ODA File Converter). Plan PDF : exporter en image.
- Les plans et images importés restent sur le PC qui les a importés.

## Écran en arche (v2.5)
- Dans un projet : **＋ Arche** — plein cintre, arc surbaissé (flèche réglable) ou portique ; ouverture intérieure, hauteur libre, largeur de bande en dalles. Le nombre de dalles le long de l'arche est calculé (ajustement affiché).
- **Dalles rigides** (par défaut, v2.5.2) : dalles carrées jamais déformées. Portique : jambes, coins et traverse en dalles entières (ouverture et hauteur arrondies à la dalle). Plein cintre / surbaissé : dalles jointives sur le bord intérieur, ouvertures en V à l'extérieur, pieds au sol ; « ✨ Ajuster l'ouverture » ferme le jeu éventuel au sommet. **Dalles souples** : la bande épouse la courbe.
- Vue de face de l'arche, 3D (écran et scène), dimensions hors-tout, stock, conso.
- **Plans élec / data et pixel map en forme d'arche** (v2.5.3) : chaque dalle à sa vraie place, vue de face ou de dos, peinture / tracé / point de départ directement sur l'arche. Pixel map arche : contenu de chaque dalle à sa position, toujours dans le même sens (dalles « debout », v2.5.4), titre et mire sur l'arche entière. Bouton **🌈 Arche / ▭ Déroulé** pour revenir à la bande déroulée (pied gauche → pied droit).

## Écran déstructuré (v2.4)
- Dans un projet : **＋ Écran déstructuré** — plusieurs éléments (ex. main stage 12 × 2,5 m + 8 totems 0,5 × 6 m) gérés comme **un seul écran** : un seul pixel map / mapping de sortie, une seule série de matrices.
- Saisie en mètres (arrondie à la dalle) avec quantité (8 « Totem » → Totem 1 … 8). Câblage élec / data bloc par bloc, plans, stock, poids, conso. Dans la scène 3D, le plus grand bloc est au centre, les autres répartis de part et d'autre (déplaçables).
- **Liaisons entre blocs** (v2.4.1) — Plan data → carte « 🔗 Liaisons » : « Choisir moi-même les liaisons », puis on clique une chaîne et les blocs à y ajouter dans l'ordre du câble (ex. Totem 1 → 2 → 3 → 4). ‹ › pour l'ordre, ✕ pour sortir un bloc ; « Tout séparer » / « Automatique ». Chaque chaîne affiche ses dalles, ses ports et alerte si la capacité est dépassée (un bloc entier passe alors sur le port suivant plutôt que d'être coupé). Disponible aussi pour le boarding (plan data). Plans des écrans déstructurés : blocs côte à côte.
- Pixel map / mapping : section **🎯 Calibrage** (carte Options) — **Cercle & croix**, **Diagonales**, au choix **sur chaque bloc** ou **sur tout l'écran** (une seule mire sur l'ensemble, visible uniquement sur les LED). Aussi dans les dispositions classiques (case « Cercle & croix de calibrage »).
- La version de l'application est affichée en bas du menu de gauche : vérifiez-la après une mise à jour (si l'icône du Bureau ouvre une ancienne version, lancez `Impulsion Prod` depuis le nouveau dossier pour recréer l'icône).
- Mapping de sortie (aussi pour le boarding) : placement **Position libre (X / Y)** et **rotation** 0 / 90 / 180 / 270° par bloc (ex. totems couchés pour tenir en 1080 de haut). Le CSV donne la rotation.

## Visuels → matrices (v2.3)
- Boarding → onglet **🎨 Visuels → matrices**. « ⇪ Importer des visuels » : sélectionnez (ou glissez) tous les fichiers des partenaires d'un coup — PNG, JPG, MP4, MOV, WebM.
- Nommez les fichiers **« partenaire largeurxhauteur »** (ex. `molten 1280x80.png`, `molten 1536x80.mp4`) : un **jeu par partenaire** est créé et chaque fichier va dans toutes les zones de cette taille. Pour viser une zone précise : `molten Long JAR 1632x80.png`. Sans taille dans le nom : taille réelle du fichier, puis nom de zone.
- Cadrage par zone : remplir (recadré), ajuster (bandes noires) ou étirer ; alerte si le format du visuel ne correspond pas à la zone.
- Les matrices suivent le **mapping de sortie** (1920 × 1080 / 3840 × 2160). Jeu d'images → **PNG** ; jeu avec vidéo → **MP4 H.264** (24 / 25 / 30 / 50 / 60 i/s, durée auto = vidéo la plus longue, les plus courtes bouclent, les images restent fixes).
- « ⇩ Toutes les matrices » : une matrice par partenaire (PNG regroupés dans un .zip, un MP4 par partenaire). Aperçu avec lecture vidéo.
- **📌 Figer** une zone (v2.3.1) : son visuel est utilisé dans tous les jeux (ex. logo de l'organisateur) ; les imports suivants ne la remplacent pas. « Défiger » rend la zone à chaque jeu.
- **🗑 Gérer / supprimer des médias** : cocher les fichiers ou les jeux (partenaires) sans rapport avec le projet et les supprimer ; « nettoyer » libère les fichiers qui ne servent plus dans aucun projet.
- Les fichiers importés restent sur le PC qui les a importés (base locale) ; sur un autre poste il faut les réimporter.

## Boarding : hauteur par zone (v2.2)
- Configuration du boarding → tableau des zones : **Longueur (pan.)** et **Hauteur (pan.)** pour chaque zone (ex. tribune en 1 panneau de haut, face caméra en 2 ou 3). « Panneaux en hauteur (toutes les zones) » règle toutes les zones d'un coup.
- Total de panneaux, stock, m², poids, conso, câblage élec / data (chaque zone parcourue sur sa propre hauteur), plans, pixel map, mapping de sortie et scène 3D tiennent compte de la hauteur de chaque zone. Les zones moins hautes sont alignées en bas sur les plans.

## Boarding : mapping de sortie pour les créas (v2.1)
- Onglet **Pixel map** d'un boarding : les zones sont posées dans une sortie **1920 × 1080**, **3840 × 2160** ou personnalisée (plusieurs sorties si ça ne tient pas).
- Pour chaque zone : ordre (↑↓), couleur, inclure / exclure, placement **Nouvelle ligne**, **À la suite si elle rentre** ou **À la suite (coupée au bord)**, et **Repli** (ex. une zone de 1536 px repliée à 768 → bloc 768 × 256). Préréglages : une zone par ligne, compact, continu.
- Rendu **blocs couleur** avec nom et taille (« Zone A1 1152x192 px (384+1152=1536) ») ou **damier technique**. Coupe uniquement entre deux panneaux (option).
- Export PNG par sortie + **CSV des positions** (sortie, X, Y, largeur, hauteur de chaque morceau). Le réglage est enregistré avec l'écran, donc propre à chaque événement.

## Câblage : regroupement et point de départ (v1.6)
- Boarding : option **« Regrouper les zones sur un même port / départ »** (activée par défaut en data) — des zones entières partagent un port tant que la capacité pixel le permet ; les liaisons entre zones sont dessinées et listées.
- Écrans et boarding : outil **📍 Point de départ** — cliquez la dalle d'où part le câble, la ligne est recâblée à partir de là. Ou choisissez le départ dans la liste des lignes (« 📍 départ »).

## Feuille de route (v1.7)
- Dans un projet : **📋 Feuille de route**. Saisissez l'adresse, les accès, le planning horaire (étapes en 1 clic), les contacts sur site et les infos pratiques (hébergement, repas, tenue, sécurité). L'équipe validée, le transport, le matériel, les écrans, les plans de câblage et la 3D sont repris automatiquement du projet (cases à cocher pour choisir).
- **⇩ PDF** : feuille de route imprimable (matériel à cocher au départ / au retour, plans en pages paysage).
- **📋 Copier le résumé** / **💬 Groupe WhatsApp** : version texte à coller dans le groupe de l'équipe.
- **🌐 Publier en ligne** + **📲 Envoyer à l'équipe** : chaque technicien validé et chaque chauffeur reçoit sur WhatsApp un lien vers une page mobile (Maps / Waze, appel en 1 clic, plans, matériel à cocher). Re-publier met à jour la même adresse.
- Nécessite le script Google **v3** (Équipe → Réponses en 1 clic → copier le code, remplacer, Ctrl+S, Gérer les déploiements → Nouvelle version). Sans relais, l'envoi WhatsApp contient le résumé texte complet.

## Agenda des techniciens (v1.8)
- Équipe → Réponses en 1 clic → **📅 Agenda des techniciens** : « options et validés » ou « validés uniquement ».
- Le relais Google crée l'événement (journée entière, une plage par période de jours consécutifs) dans un agenda « Impulsion – Bookings techniciens » et **invite le technicien par email** → l'événement apparaît dans son Google Agenda (Outlook / iCloud : invitation classique).
- Mise à jour automatique : 🟦 OPTION → ✅ validé, dates modifiées, lieu / lien de feuille de route ; suppression si option levée, indispo, retiré du projet ou projet annulé / supprimé.
- Nécessite le script Google **v4** + autorisation Google Agenda : dans l'éditeur Apps Script, exécuter une fois la fonction `autoriserAgenda`, puis Gérer les déploiements → Nouvelle version.
- Renseignez l'**email** de chaque technicien (fiche technicien).
- **Un seul événement par projet** avec toute l'équipe invitée (réglable : un événement par technicien). L'événement est découpé seulement si l'équipe présente change d'un jour à l'autre. Titre : ✅ / 🟦 OPTION + nombre de techniciens ; la description liste l'équipe avec poste et statut. Nécessite le script v8.
- La **feuille de route** est intégrée à la description de l'événement (planning, adresse, accès, contacts, équipe, transport, infos pratiques + lien vers la version complète). Une feuille de route publiée en ligne se met à jour automatiquement à chaque modification, tout comme les événements.

## Liens sans erreur Google — GitHub Pages (v1.9)
- Problème réglé : « Impossible d'ouvrir le fichier » chez un technicien connecté à plusieurs comptes Google.
- Équipe → Réponses en 1 clic → **🔗 Liens sans erreur Google** : télécharger `index.html`, le déposer dans un dépôt GitHub public, activer GitHub Pages, coller l'adresse (`https://pseudo.github.io/reponses/`) → « Enregistrer et tester ».
- Les nouveaux liens (réponse en 1 clic et feuille de route) passent alors par cette page, qui interroge le script Google sans compte Google. Les anciens liens restent valables.
- Nécessite le script Google **v7**. Si l'adresse du script change, retéléchargez `index.html` et remplacez-le sur GitHub.
- Après modification de `app/gs/reponses-techniciens.gs` : lancer `outils-avances/generer-pages.py` (régénère `replygs.js` et `replypages.js`).

## Horaires sur les demandes (v1.9.2)
- En sollicitant (option ou booking) ou via ✎ sur les dates d'un technicien (« Dates & horaires ») : une plage commune (ex. 08:00 → 18:00), ou des **horaires différents selon les jours** (case à cocher), plus une précision libre (ex. « RDV dépôt 7h30 »).
- Repris dans le message WhatsApp (variable `{horaires}`, ligne « 🕐 Horaires » ajoutée automatiquement aux messages d'option, de demande et de confirmation), sur la page de réponse du technicien (à côté de chaque jour), dans le tableau de l'équipe, la feuille de route, le PDF et l'agenda.
- La dernière plage utilisée est proposée par défaut à la demande suivante. Aucune mise à jour du script Google n'est nécessaire.

## Comptes & partage entre plusieurs PC (v2.0)
- **Comptes & partage** (menu de gauche) : créez votre compte puis celui de votre patron (nom, fonction, couleur, mot de passe facultatif). Au démarrage : « Qui êtes-vous ? » (option « Rester connecté sur ce PC »). Tous les comptes ont les mêmes droits.
- **Historique** : chaque création / modification / suppression est signée (« Patrick a modifié le projet « Salon Auto » — équipe »), réponses des techniciens incluses. Filtres par personne et par type. Sur chaque projet : « Modifié par … il y a … ».
- **Partage** : chaque PC garde sa copie (fonctionne hors ligne) ; les modifications sont envoyées en quelques secondes et celles des autres arrivent toutes les 20 s. Fusion élément par élément : deux personnes peuvent modifier en même temps des projets différents, ou des champs différents d'un même projet, sans rien perdre.
- Mise en place : sur votre PC « ☁ Activer le partage » → « 🔑 Ajouter un autre PC » → envoyez le code à votre patron ; sur son PC (application installée) : Comptes & partage → « Rejoindre » → collez le code → connexion avec son compte.
- Un seul **poste principal** (★) gère l'agenda des techniciens et les réponses en 1 clic, pour éviter les doublons ; si ce PC est éteint, un autre prend le relais automatiquement.
- Nécessite le script Google **v9** (copier le code, remplacer dans Apps Script, Ctrl+S, Gérer les déploiements → ✏️ → Nouvelle version). Les données partagées sont rangées dans l'onglet « donnees » du Google Sheets du relais.

## Structure
- `main.js` / `preload.js` : moteur bureau (fichiers, sauvegardes, PDF)
- `app/` : interface (`js/core.js` données & migrations, `js/engine.js` calculs, `js/render.js` plans, `js/views.js` écrans)
- Évolutions : incrémenter `version` dans `package.json` ; si le format change, `SCHEMA_VERSION` + une étape dans `MIGRATIONS` (core.js).


## Projets de vente / étude et dalles hors catalogue (v2.7)
- Dans la fiche projet, cochez **💼 Projet de vente / étude** : le projet ne réserve aucun stock, n'affiche pas de manque de matériel et porte l'étiquette « Vente ».
- Dans un écran, menu **Dalle → ＋ Dalle hors catalogue…** : saisissez nom, pitch, dimensions (les pixels se calculent avec le pitch), poids, consommation. La dalle n'existe que dans ce projet et sert à tous les rendus : plans élec/data, pixel map, 3D, dossier PDF. Ça marche aussi pour le boarding, l'écran déstructuré et l'arche.
- Sans aucune dalle au catalogue, « Ajouter un écran » ouvre directement la fiche de dalle hors catalogue.
- **✎ Modifier les caractéristiques de cette dalle** permet de corriger la dalle ; **⇪ Ajouter au catalogue** la transforme en vraie référence (stock 0) si vous achetez le produit.


## Nouveau nom : Impulsion Prod (v2.7.1)
- L'application s'appelle désormais **Impulsion Prod** (fenêtre, menu, icône du Bureau et du menu Démarrer). Le fichier de lancement est `Impulsion Prod`.
- Au premier lancement, l'ancienne icône « Impulsion LED » est supprimée et remplacée par « Impulsion Prod ».
- Les données ne bougent pas : elles restent dans `Documents\Impulsion LED Manager` (ou le dossier que vous avez choisi). Le script Google, le relais et le partage entre PC restent inchangés.


## Angles à 90° et formes cubiques (v2.8)
- Chaque jonction propose maintenant de -90° à +90° (2,5 / 5 / 7,5 / 10 / 15 / 20 / 30 / 45 / 60 / 90°), plus **Autre…** pour une valeur libre.
- Raccourcis **Formes à 90°** : *Coin en L*, *3 faces*, *Cube 4 faces* (faces égales ; cochez « vers l'intérieur » pour +90°). Le nombre de colonnes doit être un multiple du nombre de faces (16 colonnes = cube de 4 × 4 dalles).
- La 3D, la vue de dessus et la scène affichent la forme réelle ; les plans élec / data marquent les coins en pointillés orange.

## Agenda : chacun n'est prévenu que de ce qui le concerne (v2.8)
- Les événements d'agenda sont désormais **un par technicien** (et non plus un événement commun à toute l'équipe) : quand un collègue valide ou refuse, les autres ne reçoivent plus de mail.
- L'événement d'un technicien n'est modifié que si **ses** dates, horaires, poste ou les infos du projet changent ; la liste d'équipe n'est plus copiée dans l'agenda (elle reste sur la feuille de route en ligne).
- Au passage à cette version, l'ancien événement commun est remplacé une seule fois par un événement individuel pour chacun.


## Agenda : fini les mails à répétition (v2.9)
- Un événement terminé n'est plus jamais modifié ni supprimé : plus aucun mail sur les projets passés.
- Un événement n'est mis à jour que si ce qui concerne le technicien change : ses dates, ses horaires, son poste, le lieu ou son statut (option → validé). Les modifications de la feuille de route (planning, notes, transport, fichiers…) ne touchent plus l'agenda : l'événement contient le lien vers la feuille de route en ligne, qui est toujours à jour.
- Le texte complet de la feuille de route n'est plus copié dans l'événement (option désactivée, réactivable dans Équipe → Agenda, déconseillé).
- Script Google v11 (conseillé) : il ne modifie que ce qui a vraiment changé et ne touche jamais un événement terminé. Copiez le nouveau code, Ctrl+S, puis Déployer → Gérer les déploiements → ✏️ → Nouvelle version → Déployer.

- v2.9.1 : si vous collez l'adresse du dépôt GitHub (github.com/Compte/Depot), elle est convertie automatiquement en adresse GitHub Pages (compte.github.io/Depot/).


## 📱 Application téléphone (v3.0)
Deux applis téléphone, hébergées sur votre page GitHub (iPhone et Android, sans App Store) :

**1. Impulsion Prod (vous et votre patron)** — mêmes données que les PC, mêmes comptes et mots de passe.
- Accueil : projets en cours, à venir (14 jours), choses à traiter (techs sans réponse, manque de matériel, feuille de route non publiée), dernières modifications.
- Planning, projets (recherche, filtres), fiche projet : équipe, écrans, matériel, transport, feuille de route, historique.
- Modifier depuis le téléphone : statut, dates, lieu et notes du projet ; statut d'un technicien (en attente / option / validé / indispo). Les PC reçoivent la modification en quelques secondes (signée « Prénom (mobile) » dans l'historique).
- Appeler / WhatsApp un technicien, le relancer avec son lien de réponse, lui envoyer la feuille de route.
- Stock : disponibilité de chaque référence sur une période.
- Le téléphone ne devient jamais « poste principal » : l'agenda et les réponses automatiques restent gérés par un PC.

**2. Mes bookings (les techniciens)** — chaque technicien reçoit un lien personnel et ne voit QUE ses bookings : à répondre, options, validés, avec horaires, adresse, itinéraire, feuille de route et groupe WhatsApp. Mise à jour automatique dès que vous modifiez quelque chose.

**Mise en place (une fois)**
1. Équipe → Réponses en 1 clic → Liens sans erreur Google → **⇩ Télécharger le pack (zip)**. Dézippez-le.
2. Sur GitHub, dans votre dépôt : Add file → Upload files → glissez **les 7 fichiers** → Commit changes. Attendez 1 à 2 minutes puis cliquez « Tester » dans l'application.
3. Pour vous : Comptes & partage → **📱 Installer sur mon téléphone** → envoyez-vous le lien, ouvrez-le sur le téléphone, choisissez votre compte, puis ajoutez-le à l'écran d'accueil (iPhone : Safari → Partager → « Sur l'écran d'accueil » ; Android : Chrome → ⋮ → « Installer l'appli »).
4. Pour les techniciens : Équipe → **📱 Espace mobile des techs** → « Envoyer » pour chacun (message WhatsApp avec son lien et la marche à suivre).

À chaque nouvelle version de l'application, retéléchargez le pack et redéposez les fichiers sur GitHub (l'application vous le rappelle si besoin).

Note technique : après une modification des modules du moteur, relancer `outils-avances/generer-pages.py` (régénère la page technicien, l'application téléphone et le script Google).


## 🚫 Indisponibilités déclarées par les techniciens (v3.1)
- Dans « Mes bookings », chaque technicien a une section **Mes indisponibilités** : il touche les jours où il n'est pas disponible sur un calendrier (12 mois), ajoute un petit mot s'il veut, et envoie. Il peut les retirer de la même façon.
- L'espace technicien est en **lecture seule** : bookings, horaires, adresse, feuille de route en ligne (plans élec, data, vue 3D, infos, contacts). Il ne peut rien modifier, à part ses indisponibilités et ses réponses aux demandes.
- Le PC principal récupère les indisponibilités avec les réponses (toutes les quelques minutes) : message à l'écran + ligne dans l'Historique, avec alerte si le technicien était déjà prévu ces jours-là.
- Dans « Solliciter des techniciens », un technicien indisponible sur **toutes** les dates choisies est grisé et ne peut pas être coché ; s'il l'est sur une partie des dates, une étiquette rouge l'indique.
- Les indisponibilités apparaissent aussi dans la liste de l'équipe (🚫 n j.), la grille des disponibilités, la ligne d'équipe d'un projet et l'application téléphone.
- Nécessite le **script Google v12** (Copier le code → remplacer dans Apps Script → Ctrl+S → Nouvelle version) et le **pack GitHub** à jour.


## 📱 L'application complète sur téléphone (v3.2)
- `app.html` (dans le pack GitHub) est désormais **toute l'application**, comme sur PC : catalogue, stock, planning, projets, écrans, plans élec / data, pixel map, 3D, implantation, équipe, sollicitations WhatsApp, feuilles de route, véhicules, historique, comptes et paramètres.
- Mise en page adaptée au téléphone : menu ☰ en haut à gauche, une colonne, tableaux qui défilent sur le côté, fenêtres plein écran. Au doigt : glisser pour tourner la 3D, pincer pour zoomer, glisser les écrans sur l'implantation, peindre les dalles.
- Les données restent sur le téléphone et se synchronisent avec les PC par le partage (comme un PC de plus). Le téléphone n'est jamais le « poste principal » : l'agenda, les réponses automatiques et les espaces techniciens restent gérés par un PC.
- Installation : Comptes & partage → 📱 Installer sur mon téléphone, puis ajout à l'écran d'accueil.
- Script Google **v13** conseillé (le téléphone ne prend alors jamais le rôle de poste principal).

## Espace technicien (v3.2)
- Bouton **‹ Mes bookings** en haut de la feuille de route et de la page de réponse : indispensable dans l'appli installée, qui n'a pas de bouton « précédent ».
- Barre d'état iPhone corrigée (le haut de la page n'est plus caché sous l'heure / la batterie).

- v3.2.1 : l'icône de l'écran d'accueil se connecte toute seule au premier lancement (sur iPhone, l'icône a sa propre mémoire, séparée de Safari).

- v3.2.2 : sur l'écran de connexion du téléphone, on peut coller le lien d'installation complet (pas seulement le code), avec un bouton « Coller ».

- v3.2.3 : l'icône « Mes bookings » des techniciens rouvre directement leur espace personnel (le lien personnel est inscrit dans l'icône), même sur iPhone où l'icône n'a pas la mémoire du navigateur. Idem pour l'application de la direction.


## 🛡 Sécurité des données (v3.3)
**Plus aucun élément ne peut disparaître « tout seul ».**
- Un projet, technicien, référence, véhicule ou compte n'est retiré des autres postes **que s'il a été supprimé volontairement** quelque part (l'application garde la trace de chaque suppression). Un poste resté sur d'anciennes données, une sauvegarde restaurée, un changement de dossier de données ou un script Google réinitialisé ne peuvent plus effacer quoi que ce soit : l'élément est conservé et renvoyé partout.
- Si les données en ligne sont illisibles un instant, rien n'est envoyé (nouvel essai 20 s plus tard).
- **Corbeille** (Historique → 🗑 Corbeille) : tout ce qui est supprimé ici ou retiré par la synchronisation y est gardé (80 derniers éléments), avec un bouton ♻ Restaurer — l'élément revient aussi sur les autres postes.
- **♻ Récupérer depuis une sauvegarde** (Historique) : choisissez une sauvegarde automatique, l'application liste ce qu'elle contient et qui n'existe plus aujourd'hui ; cochez et récupérez, **sans rien modifier d'autre**.
- Une suppression faite sur un autre poste apparaît dans l'Historique (« … a supprimé le projet X (sur un autre poste — récupérable dans la corbeille) »).
- Pour que ces protections jouent partout, **installez cette version sur tous les PC** (et redéposez le pack GitHub pour les téléphones).

**Fini les « Erreur de sauvegarde ».**
- Quand le fichier est bloqué (OneDrive, antivirus), l'application réessaie plusieurs fois, puis enregistre une **copie de secours complète sur le disque local** ; au démarrage, la copie la plus récente est reprise. L'indicateur affiche alors « Sauvegardé (copie de secours) ».
- En cas d'erreur, nouvel essai automatique toutes les quelques secondes.
- Si vos données sont dans OneDrive, l'application propose (une fois, et dans Paramètres) **📁 Mettre mes données sur ce PC** : elles sont déplacées dans `C:\Users\<vous>\Impulsion Prod donnees` avec les sauvegardes. Le partage Google fait déjà la copie en ligne, OneDrive n'est pas nécessaire.
- Journal des incidents de sauvegarde : `%APPDATA%\ImpulsionLED\sauvegarde.log`.

- v3.3.1 : « ♻ Récupérer » peut chercher dans **toutes les sauvegardes d'un coup** (version la plus récente de chaque élément manquant). Les sauvegardes sont gardées plus longtemps : les 60 dernières + une par jour pendant 120 jours.

- v3.3.2 : écran de connexion — lien « Mot de passe oublié ou refusé ? » (nouveau mot de passe, noté dans l'Historique) et état des données affiché en dessous (nombre de projets, partage, chemin du fichier).

- v3.4.0 : **🧩 Reconstituer depuis les demandes** (Historique) — recrée un projet perdu à partir des demandes WhatsApp déjà envoyées : nom, lieu, dates, techniciens, postes et réponses déjà reçues, avec les mêmes liens (inutile de redemander). Écrans et matériel à refaire. Nécessite le script Google v14.

- v3.4.1 : si le fichier de données est momentanément illisible (OneDrive), l'application ne démarre plus jamais « à vide » : elle reprend la dernière sauvegarde valide, ou affiche un écran « Réessayer » sans rien modifier. Activer le partage propose **🔀 Fusionner (recommandé)** : ce qui est sur le PC et ce qui est en ligne est gardé.

- v3.4.2 : **🕘 Récupérer depuis l'historique Google** (Historique) — Google garde toutes les anciennes versions des données partagées : faites une copie d'une ancienne version de la feuille « Impulsion LED – Réponses techniciens » (Fichier → Historique des versions → ⋮ → Créer une copie), collez son adresse, cochez ce qui manque. Nécessite le script Google v15.

- v3.4.3 / script v16 : **cause trouvée** — sur une erreur passagère de Google, l'ancien script créait une nouvelle feuille vide « Impulsion LED – Réponses techniciens » et y basculait (les données semblaient disparaître). Le script v16 ne remplace plus jamais la feuille existante. Dans « 🕘 Récupérer depuis l'historique Google » : reconstituer depuis les demandes d'un ancien fichier, et **🔗 Reconnecter le partage** à l'ancien fichier.

- v3.5.0 / script v17 : **🗂 Tout récupérer (toutes les feuilles Google)** dans l'Historique — retrouve toutes les feuilles « Impulsion LED – Réponses techniciens » de votre Drive, récupère ce qui manque (projets complets, sinon reconstitués depuis les demandes), puis regroupe demandes et réponses des techniciens dans une seule feuille utilisée par tous les postes.

- v3.5.1 / script v18 : une feuille gardée sans données partagées n'est plus vue comme « illisible » (le PC y renvoie ses données) ; le regroupement y recopie les données partagées actuelles ; bouton « Renvoyer les données de ce PC » si le partage reste en pause.

- v3.5.2 : partage plus patient (jusqu'à 4 min pour un envoi au lieu de 1) et plus léger (les fichiers RCG déjà sur Google Drive ne circulent plus qu'en lien) ; taille des données partagées affichée dans Comptes & partage.

## Catégories de projets (v3.6)
- Chaque projet peut être classé : **📦 Location sèche**, **🎛️ Presta**, **🗓️ Location longue durée**, **💼 Vente** (fiche projet → Catégorie).
- Étiquette de couleur sur les cartes et l'en-tête du projet ; liste Projets filtrable par catégorie, avec le nombre de projets par catégorie.
- « Vente » = projet de vente : aucun stock réservé, dalles hors catalogue possibles (les anciens projets de vente sont classés automatiquement).


## 🔄 Mises à jour automatiques (v3.7)
**Plus de pack à déposer à la main, plus de zip à installer sur chaque PC.**
- **Publication automatique sur GitHub** (Paramètres → Mises à jour automatiques) : collez une fois une « clé GitHub » (instructions dans l'application, 2 min). Dès qu'une nouvelle version est installée sur votre PC, l'application publie toute seule sur votre dépôt GitHub : pages des techniciens, application téléphone et mise à jour des autres PC. Bouton « Publier maintenant » si besoin.
- **Autres PC** : l'application voit qu'une version plus récente est publiée (au démarrage puis toutes les 30 min) et affiche « 🎁 Nouvelle version disponible → Mettre à jour ». Un clic : téléchargement, installation, redémarrage. Les données ne sont jamais touchées (sauvegarde faite avant).
- **Téléphones** (vous, votre patron) : bandeau « Nouvelle version — Actualiser » dès qu'une version plus récente est en ligne. Plus besoin de renvoyer le lien d'installation.
- **Techniciens** : rien à faire, ils ont toujours la dernière version en rouvrant « Mes bookings ».
- Correctif : la page n'est plus servie depuis une ancienne copie en cache du téléphone.
