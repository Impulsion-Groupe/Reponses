/* =====================================================================
   ÉCRAN DÉSTRUCTURÉ — plusieurs éléments (main stage, totems, bandeaux…)
   gérés comme UN SEUL écran dans le mapping (une seule sortie / un seul pixel map).
   Techniquement : un « boarding » dont chaque zone est un bloc (largeur × hauteur en dalles),
   câblé bloc par bloc, placé librement dans la sortie et dans la scène 3D.
   ===================================================================== */
const isDeco = (s) => isBoard(s) && !!s.deco;
const zTerm = (s) => (isDeco(s) ? { one: 'bloc', One: 'Bloc', many: 'blocs', Many: 'Blocs', type: 'Écran déstructuré', len: 'Largeur (dalles)', hgt: 'Hauteur (dalles)' } : { one: 'zone', One: 'Zone', many: 'zones', Many: 'Zones', type: 'Boarding', len: 'Longueur (pan.)', hgt: 'Hauteur (pan.)' });

function decoNewHTML() {
  const prods = projectDalles(curProject()); const d = ui.decoNew;
  const p = getProduct(d.prod) || prods[0] || {}; const w = num(p.widthMm) || 500, h = num(p.heightMm) || 500;
  const rows = d.blocks.map((b, i) => { const c = Math.max(1, Math.round(num(b.wm) * 1000 / w)), r = Math.max(1, Math.round(num(b.hm) * 1000 / h));
    return `<tr><td><input data-dn="name" data-i="${i}" value="${esc(b.name)}" style="width:100%"></td>
      <td><input type="number" min="1" data-dn="qty" data-i="${i}" value="${b.qty}" style="width:64px"></td>
      <td><input type="number" min="0" step="0.1" data-dn="wm" data-i="${i}" value="${b.wm}" style="width:80px"></td>
      <td><input type="number" min="0" step="0.1" data-dn="hm" data-i="${i}" value="${b.hm}" style="width:80px"></td>
      <td class="num"><b>${c} × ${r}</b><div class="tiny muted">${fmt(c * w / 1000, 2)} × ${fmt(r * h / 1000, 2)} m · ${c * num(p.pxW)} × ${r * num(p.pxH)} px</div></td>
      <td class="num"><b>${c * r * num(b.qty)}</b></td><td><button class="sm ghost" data-act="decoDelRow" data-i="${i}" ${d.blocks.length < 2 ? 'disabled' : ''}>✕</button></td></tr>`; }).join('');
  const total = d.blocks.reduce((a, b) => a + Math.max(1, Math.round(num(b.wm) * 1000 / w)) * Math.max(1, Math.round(num(b.hm) * 1000 / h)) * Math.max(1, num(b.qty) | 0), 0);
  return `<div id="decoNew"><h2>Nouvel écran déstructuré</h2>
    <div class="small muted">Plusieurs éléments physiques (main stage, totems, bandeaux…) gérés comme <b>un seul écran</b> : un seul pixel map / mapping de sortie, câblage bloc par bloc, chaque bloc placé librement dans la scène 3D.</div>
    <div class="form" style="margin-top:12px"><label class="f span2">Nom<input data-dn="title" value="${esc(d.title)}"></label>
      <label class="f span2">Dalle LED (la même pour tous les blocs)<select data-dn="prod">${prods.map((x) => `<option value="${x.id}" ${x.id === p.id ? 'selected' : ''}>${esc(x.ref)} — ${esc(x.name)} (${num(x.widthMm)}×${num(x.heightMm)} mm)</option>`).join('')}</select></label></div>
    <table class="tbl" style="margin-top:12px"><thead><tr><th>Élément</th><th>Quantité</th><th>Largeur (m)</th><th>Hauteur (m)</th><th class="num">Dalles</th><th class="num">Total</th><th></th></tr></thead><tbody>${rows}</tbody></table>
    <div class="row" style="justify-content:space-between;margin-top:8px"><button class="sm" data-act="decoAddRow">＋ Élément</button><span class="small">Total : <b>${total} dalles</b></span></div>
    <div class="tiny muted" style="margin-top:6px">Les dimensions sont arrondies à la dalle. Quantité 8 « Totem » → Totem 1 … Totem 8.</div>
    <div class="modal-actions"><button data-act="closeModal">Annuler</button><button class="primary" data-act="decoCreate">Créer l'écran</button></div></div>`;
}
const decoActions = {
  addDeco() {
    const prods = projectDalles(curProject()); if (!prods.length) return customActions.cpNew({ dataset: { target: 'addDeco' } });
    ui.decoNew = { title: 'Écran déstructuré', prod: prods[0].id, blocks: [{ name: 'Main stage', qty: 1, wm: 12, hm: 2.5 }, { name: 'Totem', qty: 8, wm: 0.5, hm: 6 }] };
    openModal(decoNewHTML());
  },
  decoAddRow() { ui.decoNew.blocks.push({ name: 'Élément ' + (ui.decoNew.blocks.length + 1), qty: 1, wm: 1, hm: 1 }); openModal(decoNewHTML()); },
  decoDelRow(el) { ui.decoNew.blocks.splice(+el.dataset.i, 1); openModal(decoNewHTML()); },
  decoCreate() {
    const d = ui.decoNew; const p = curProject(); const s = newScreen(Store.db, d.prod); const pr = getProduct(d.prod) || {}; const w = num(pr.widthMm) || 500, h = num(pr.heightMm) || 500;
    s.type = 'boarding'; s.deco = true; s.name = d.title.trim() || 'Écran déstructuré'; s.tilt = 0; s.zones = [];
    d.blocks.forEach((b) => { const q = Math.max(1, num(b.qty) | 0); for (let k = 0; k < q; k++) s.zones.push({ id: uid('zon'), name: q > 1 ? `${b.name} ${k + 1}` : b.name, count: Math.max(1, Math.round(num(b.wm) * 1000 / w)), rows: Math.max(1, Math.round(num(b.hm) * 1000 / h)) }); });
    ['elec', 'data'].forEach((k) => Object.assign(s[k], { orient: 'h', pattern: 'snake', start: 'BL', strategy: 'balanced', joinZones: k === 'data' }));
    boardReset(s); decoArrange(s, w); p.screens.push(s);
    s.pixmap.board = 'map'; boardMapCfg(s); s.pixmap.map.items.forEach((it) => { it.place = 'auto'; });
    Store.save(); closeModal(); go('screen', { screenId: s.id, tab: 'config' }); toast(`Écran déstructuré créé : ${s.zones.length} blocs, ${panelCount(s)} dalles`);
  }
};
/* Scène 3D : le plus grand bloc au centre, les autres répartis à gauche / à droite */
function decoArrange(s, w) {
  const z = [...s.zones].sort((a, b) => b.count * b.rows - a.count * a.rows); const main = z[0]; const gap = 1500;
  main.place = { x: 0, y: 0, z: 0, rot: 0 }; let L = -main.count * w / 2, R = main.count * w / 2;
  z.slice(1).forEach((b, i) => { const bw = b.count * w; if (i % 2 === 0) { L -= gap + bw; b.place = { x: Math.round(L + bw / 2), y: 0, z: 0, rot: 0 }; } else { R += gap; b.place = { x: Math.round(R + bw / 2), y: 0, z: 0, rot: 0 }; R += bw; } });
}
function decoChange(t) {
  if (!t.dataset.dn || !ui.decoNew) return false; const d = ui.decoNew; const k = t.dataset.dn;
  if (k === 'title') d.title = t.value; else if (k === 'prod') d.prod = t.value; else d.blocks[+t.dataset.i][k] = k === 'name' ? t.value : num(t.value);
  if (k !== 'title' && k !== 'name') openModal(decoNewHTML()); return true;
}
