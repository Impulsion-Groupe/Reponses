/* =====================================================================
   HORAIRES des demandes (option / booking) : plage commune ou par jour + précision
   r.hours = { from, to, perDay, days: { 'AAAA-MM-JJ': { from, to } }, note }
   ===================================================================== */
const emptyHours = () => ({ from: '', to: '', perDay: false, days: {}, note: '' });
function hoursFor(h, d) { if (!h) return { from: '', to: '' }; const x = h.perDay && h.days && h.days[d] ? h.days[d] : h; return { from: x.from || '', to: x.to || '' }; }
const fmtRange = (x) => (x.from && x.to ? `${x.from}–${x.to}` : x.from ? `dès ${x.from}` : x.to ? `jusqu'à ${x.to}` : '');
function hoursHas(h) { return !!h && (!!h.note || !!(h.from || h.to) || (h.perDay && Object.values(h.days || {}).some((x) => x.from || x.to))); }
/* Plage la plus fréquente + jours qui diffèrent */
function hoursSplit(r) {
  const per = [...r.dates].sort().map((d) => [d, fmtRange(hoursFor(r.hours, d))]); const cnt = {};
  per.forEach(([, t]) => { if (t) cnt[t] = (cnt[t] || 0) + 1; });
  const base = Object.keys(cnt).sort((x, y) => cnt[y] - cnt[x])[0] || '';
  return { base, ex: per.filter(([, t]) => t !== base), per };
}
/* Résumé court (tableau, agenda, feuille de route) */
function hoursShort(r) {
  const h = r.hours; if (!hoursHas(h)) return '';
  const { base, ex } = hoursSplit(r);
  let s = base + (ex.length ? ` (${ex.map(([d, t]) => `${dayLabel(d).replace(/\.$/, '')} ${t || 'libre'}`).join(', ')})` : '');
  if (h.note) s = s ? `${s} — ${h.note}` : h.note; return s.trim();
}
/* Pour les messages : {horaires} */
function hoursMsg(r) {
  const h = r.hours; if (!hoursHas(h)) return '';
  const { base, ex, per } = hoursSplit(r); const arrow = (t) => t.replace('–', ' → ');
  let s;
  if (!ex.length) s = arrow(base);
  else if (ex.length * 2 <= per.length) s = `${arrow(base)}\n` + ex.map(([d, t]) => `   • sauf ${dayLabel(d)} : ${t ? arrow(t) : 'non précisé'}`).join('\n');
  else s = '\n' + per.filter(([, t]) => t).map(([d, t]) => `   • ${dayLabel(d)} : ${arrow(t)}`).join('\n');
  if (h.note) s = !s ? h.note : s.includes('\n') ? `${s}\n   ${h.note}` : `${s} — ${h.note}`;
  return s;
}
const dayWithHours = (r, d) => { const t = fmtRange(hoursFor(r.hours, d)); return dayLabel(d) + (t ? ' · ' + t : ''); };

/* Éditeur d'horaires (modale de demande et modale des dates) */
function hoursEditorHTML(h, dates, ctx) {
  h = h || emptyHours();
  const tin = (k, v, extra = '') => `<input type="time" data-hx="${k}" data-hctx="${ctx}" ${extra} value="${esc(v || '')}" style="width:130px">`;
  return `<div class="hours-box">
    <div class="row" style="gap:8px"><span class="small">🕐 De</span>${tin('from', h.from)}<span class="small">à</span>${tin('to', h.to)}
      <label class="row small" style="gap:6px;margin-left:8px"><input type="checkbox" data-hx="perDay" data-hctx="${ctx}" ${h.perDay ? 'checked' : ''}>Horaires différents selon les jours</label></div>
    ${h.perDay ? `<div class="hours-days">${[...dates].sort().map((d) => { const x = h.days[d] || {}; return `<div class="row" style="gap:6px"><span class="small" style="width:120px">${dayLabel(d)}</span>${tin('dfrom', x.from || h.from, `data-d="${d}"`)}<span class="small">→</span>${tin('dto', x.to || h.to, `data-d="${d}"`)}</div>`; }).join('') || '<div class="tiny muted">Choisissez d\'abord les dates.</div>'}</div>` : ''}
    <input data-hx="note" data-hctx="${ctx}" value="${esc(h.note || '')}" placeholder="Précision (facultatif) : ex. RDV dépôt 7h30, fin selon show…" style="width:100%;margin-top:8px">
  </div>`;
}
/* Champs modifiés : renvoie true si traité */
function hoursChange(t) {
  if (!t.dataset.hx) return false;
  const ctx = t.dataset.hctx; const holder = ctx === 'sol' ? ui.sol : ui.edDates; if (!holder) return true;
  holder.hours = holder.hours || emptyHours(); const h = holder.hours; const k = t.dataset.hx;
  if (k === 'perDay') { h.perDay = t.checked; openModal(ctx === 'sol' ? solicitHTML() : datesHTML()); return true; }
  if (k === 'dfrom' || k === 'dto') { const d = t.dataset.d; h.days[d] = h.days[d] || { from: h.from, to: h.to }; h.days[d][k === 'dfrom' ? 'from' : 'to'] = t.value; return true; }
  h[k] = t.value;
  return true;
}
const cleanHours = (h, dates) => { if (!hoursHas(h)) return null; const c = deepClone(h); c.days = {}; if (c.perDay) dates.forEach((d) => { if (h.days[d]) c.days[d] = h.days[d]; }); return c; };
