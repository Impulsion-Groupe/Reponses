/* Pont vers le lanceur Windows (serveur local PowerShell sur 127.0.0.1).
   Donne à l'application le même accès disque que la version installée :
   fichier de données, sauvegardes, dossier configurable. */
(function () {
  if (window.desktop || window.IP_WEB || location.protocol !== 'http:' || location.hostname !== '127.0.0.1') return;
  const MIRROR = 'impulsion-led-db-mirror';
  const call = async (url, opt) => { const r = await fetch(url, opt); if (!r.ok) throw new Error('HTTP ' + r.status); return r; };
  const mirror = (json) => { try { localStorage.setItem(MIRROR, json); } catch (e) { /* plein */ } };
  const ping = () => fetch('/api/ping', { method: 'POST', keepalive: true }).catch(() => {});
  setInterval(ping, 10000);
  document.addEventListener('visibilitychange', ping);
  window.desktop = {
    isDesktop: true, launcher: true,
    async load() {
      const r = await (await call('/api/load')).json();
      // filet de sécurité : si la copie locale est plus récente (fermeture brutale), on la reprend
      try {
        const m = localStorage.getItem(MIRROR);
        if (m) { const mu = JSON.parse(m).updatedAt || ''; const ru = r.raw ? (JSON.parse(r.raw).updatedAt || '') : ''; if (mu > ru) r.raw = m; }
      } catch (e) { /* ignore */ }
      return r;
    },
    async save(json) { mirror(json); const r = await (await call('/api/save', { method: 'POST', body: json, headers: { 'Content-Type': 'application/json' } })).json().catch(() => ({ ok: true })); return r && r.state ? r.state : 'ok'; },
    async moveData(json) { return (await call('/api/movedata', { method: 'POST', body: json || '' })).json(); },
    saveSync(json) { mirror(json); if (json.length < 60000) fetch('/api/save', { method: 'POST', body: json, keepalive: true }).catch(() => {}); return true; },
    async backup(reason) { return (await (await call('/api/backup?reason=' + encodeURIComponent(reason || 'manuelle'), { method: 'POST' })).json()).path; },
    async listBackups() { return (await call('/api/backups')).json(); },
    async readBackup(name) { return (await call('/api/backup?name=' + encodeURIComponent(name))).text(); },
    async openFolder(which) { await call('/api/openfolder?which=' + (which || 'data'), { method: 'POST' }); },
    async chooseFolder() { return (await call('/api/choosefolder', { method: 'POST' })).json(); },
    async openExternal(url) { await call('/api/open', { method: 'POST', body: url }); return true; },
    async remotePost(url, body) { return (await call('/api/remotepost?url=' + encodeURIComponent(url), { method: 'POST', body })).text(); },
    async remoteGet(url) { return (await call('/api/remote', { method: 'POST', body: url })).text(); },
    async github(o) { return (await call('/api/github', { method: 'POST', body: JSON.stringify(o) })).json(); },
    async selfZip() { return (await call('/api/selfzip', { method: 'POST' })).json(); },
    async update(url) { return (await call('/api/update', { method: 'POST', body: url })).json(); },
    async hasWhatsApp() { return (await (await call('/api/haswhatsapp')).json()).ok; }
  };
})();
