﻿# Impulsion Prod - lanceur Windows sans installation
# Demarre un petit serveur local (127.0.0.1 uniquement) qui lit/ecrit vos donnees sur le disque,
# puis ouvre l'application dans une fenetre Edge en mode application.
$ErrorActionPreference = 'Stop'
trap {
  $msg = "Impulsion Prod n'a pas pu demarrer :`r`n`r`n" + $_.Exception.Message
  try { New-Item -ItemType Directory -Force -Path (Join-Path $env:APPDATA 'ImpulsionLED') | Out-Null; Add-Content (Join-Path $env:APPDATA 'ImpulsionLED\erreur.log') ((Get-Date).ToString() + ' ' + $_.Exception.ToString()) } catch {}
  try { Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.MessageBox]::Show($msg, 'Impulsion Prod') | Out-Null } catch {}
  exit 1
}
$Port = 47321
try { [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12 } catch {}
$ScriptPath = $MyInvocation.MyCommand.Path
$LauncherDir = Split-Path -Parent $ScriptPath
$BaseDir = Split-Path -Parent $LauncherDir
$AppDir = Join-Path $BaseDir 'app'
$Url = "http://127.0.0.1:$Port/"
$Utf8 = New-Object System.Text.UTF8Encoding $false

$AppVersion = '1.0.0'
try { $AppVersion = (Get-Content (Join-Path $BaseDir 'package.json') -Raw -Encoding UTF8 | ConvertFrom-Json).version } catch {}

$CfgDir = Join-Path $env:APPDATA 'ImpulsionLED'
$CfgFile = Join-Path $CfgDir 'config.json'
New-Item -ItemType Directory -Force -Path $CfgDir | Out-Null

function Get-DataDir {
  $dir = $null
  if (Test-Path $CfgFile) { try { $dir = (Get-Content $CfgFile -Raw -Encoding UTF8 | ConvertFrom-Json).dataDir } catch {} }
  if (-not $dir -or -not (Test-Path $dir)) { $dir = Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'Impulsion LED Manager' }
  New-Item -ItemType Directory -Force -Path $dir | Out-Null
  New-Item -ItemType Directory -Force -Path (Join-Path $dir 'sauvegardes') | Out-Null
  return $dir
}
function Get-DataFile { Join-Path (Get-DataDir) 'impulsion-led-data.json' }
function Get-BackupDir { Join-Path (Get-DataDir) 'sauvegardes' }

function New-Backup([string]$reason) {
  $f = Get-DataFile
  if (-not (Test-Path $f)) { return $null }
  $safe = ($reason -replace '[^a-zA-Z0-9\.\-]', '-')
  $dest = Join-Path (Get-BackupDir) ("sauvegarde_" + (Get-Date -Format 'yyyy-MM-dd_HH\hmm\mss\s') + "_" + $safe + ".json")
  Copy-Item $f $dest -Force
  $all = @(Get-ChildItem (Get-BackupDir) -Filter '*.json' | Sort-Object Name)
  # on garde les 60 plus recentes + une par jour pendant 120 jours
  if ($all.Count -gt 60) {
    $old = $all | Select-Object -First ($all.Count - 60); $limit = (Get-Date).AddDays(-120).ToString('yyyy-MM-dd')
    $old | Group-Object { $_.Name.Substring(11, 10) } | ForEach-Object {
      $g = @($_.Group | Sort-Object Name)
      if ($_.Name -lt $limit) { $g | Remove-Item -Force } elseif ($g.Count -gt 1) { $g | Select-Object -First ($g.Count - 1) | Remove-Item -Force }
    }
  }
  return $dest
}
$script:LastHourly = [DateTime]::MinValue
# Copie de secours hors OneDrive (disque local) : utilisee si le fichier principal est bloque
$SecoursDir = Join-Path $env:LOCALAPPDATA 'ImpulsionProd'
New-Item -ItemType Directory -Force -Path $SecoursDir | Out-Null
$SecoursFile = Join-Path $SecoursDir 'secours-donnees.json'
function Write-Log([string]$m) { try { Add-Content (Join-Path $CfgDir 'sauvegarde.log') ((Get-Date).ToString('yyyy-MM-dd HH:mm:ss') + ' ' + $m) } catch {} }
function Save-Data([string]$json) {
  $f = Get-DataFile
  if (((Get-Date) - $script:LastHourly).TotalMinutes -gt 60) { try { New-Backup 'auto' | Out-Null } catch {}; $script:LastHourly = Get-Date }
  $tmp = "$f.tmp"; $err = ''
  # OneDrive / antivirus bloquent parfois le fichier quelques instants : on reessaie, puis on ecrit autrement
  for ($i = 0; $i -lt 6; $i++) {
    try {
      [IO.File]::WriteAllText($tmp, $json, $Utf8)
      if (Test-Path $f) {
        try { [IO.File]::Replace($tmp, $f, $null) } catch { [IO.File]::Copy($tmp, $f, $true); try { Remove-Item $tmp -Force -ErrorAction SilentlyContinue } catch {} }
      } else { [IO.File]::Move($tmp, $f) }
      if (Test-Path $SecoursFile) { try { Remove-Item $SecoursFile -Force } catch {} }
      return 'ok'
    } catch { $err = $_.Exception.Message; Start-Sleep -Milliseconds (100 + 100 * $i) }
  }
  Write-Log ('Fichier principal bloque (' + $f + ') : ' + $err)
  [IO.File]::WriteAllText($SecoursFile, $json, $Utf8)   # rien n'est perdu : copie complete sur le disque local
  return 'secours'
}
function Read-Data {
  $f = Get-DataFile; $raw = $null; $script:ReadErr = ''
  if (Test-Path $f) {
    for ($i = 0; $i -lt 8 -and -not $raw; $i++) {   # OneDrive peut bloquer (ou telecharger) le fichier quelques instants
      try { $raw = [IO.File]::ReadAllText($f, $Utf8) } catch { $script:ReadErr = $_.Exception.Message; Start-Sleep -Milliseconds (200 + 200 * $i) }
    }
    if (-not $raw) { Write-Log ('Lecture impossible : ' + $script:ReadErr) }
  }
  if ((Test-Path $SecoursFile) -and (-not $raw -or -not (Test-Path $f) -or (Get-Item $SecoursFile).LastWriteTime -gt (Get-Item $f).LastWriteTime)) {
    $raw = [IO.File]::ReadAllText($SecoursFile, $Utf8); Write-Log 'Copie de secours reprise au demarrage'
  }
  return $raw
}

# --- WhatsApp Desktop installe ? (application classique ou Microsoft Store) ---
$script:HasWA = $null
function Test-WhatsApp {
  if ($null -ne $script:HasWA) { return $script:HasWA }
  $ok = $false
  foreach ($k in @('Registry::HKEY_CLASSES_ROOT\whatsapp', 'Registry::HKEY_CURRENT_USER\Software\Classes\whatsapp')) { if (Test-Path $k) { $ok = $true } }
  if (-not $ok) { try { if (Get-AppxPackage -Name '*WhatsApp*' -ErrorAction SilentlyContinue) { $ok = $true } } catch {} }
  $script:HasWA = $ok
  return $ok
}
function Convert-WaLink([string]$u) {
  # https://wa.me/33612345678?text=...  ->  whatsapp://send?phone=33612345678&text=...
  if ($u -match '^https://wa\.me/(\d+)(\?text=(.*))?$') {
    $num = $Matches[1]; $txt = $Matches[3]
    if (Test-WhatsApp) { if ($txt) { return "whatsapp://send?phone=$num&text=$txt" } else { return "whatsapp://send?phone=$num" } }
    # pas d'application : api.whatsapp.com conserve mieux les emojis que wa.me
    if ($txt) { return "https://api.whatsapp.com/send?phone=$num&text=$txt" } else { return "https://api.whatsapp.com/send?phone=$num" }
  }
  # lien de groupe -> ouvre le groupe dans WhatsApp Desktop
  if ($u -match '^https://chat\.whatsapp\.com/([A-Za-z0-9]+)$') { if (Test-WhatsApp) { return "whatsapp://chat?code=$($Matches[1])" } }
  return $u
}

function Open-AppWindow {
  $profileDir = Join-Path $env:LOCALAPPDATA 'ImpulsionLED\fenetre'
  $args1 = @("--app=$Url", "--user-data-dir=`"$profileDir`"", '--window-size=1480,920', '--no-first-run', '--no-default-browser-check')
  try { Start-Process 'msedge' -ArgumentList $args1; return } catch {}
  try { Start-Process 'chrome' -ArgumentList $args1; return } catch {}
  Start-Process $Url
}

function New-Shortcuts {
  try {
    $ws = New-Object -ComObject WScript.Shell
    $targets = @(
      (Join-Path ([Environment]::GetFolderPath('Desktop')) 'Impulsion Prod.lnk'),
      (Join-Path ([Environment]::GetFolderPath('Programs')) 'Impulsion Prod.lnk')
    )
    # anciens raccourcis (avant le renommage) supprimes
    foreach ($old in @((Join-Path ([Environment]::GetFolderPath('Desktop')) 'Impulsion LED.lnk'), (Join-Path ([Environment]::GetFolderPath('Programs')) 'Impulsion LED.lnk'))) { try { if (Test-Path $old) { Remove-Item $old -Force } } catch {} }
    foreach ($lnk in $targets) {
      $s = $ws.CreateShortcut($lnk)
      $s.TargetPath = Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe'
      $s.Arguments = "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$ScriptPath`""
      $s.WorkingDirectory = $LauncherDir
      $s.IconLocation = (Join-Path $LauncherDir 'icon.ico') + ',0'
      $s.Description = 'Impulsion Prod'
      $s.WindowStyle = 7
      $s.Save()
    }
  } catch {}
}

# --- deja lance ? on ouvre juste une fenetre ---
$listener = New-Object System.Net.Sockets.TcpListener ([System.Net.IPAddress]::Loopback, $Port)
try { $listener.Start() } catch { Open-AppWindow; exit }

# fichiers telecharges : on les debloque, et on cree les raccourcis
try { Get-ChildItem $BaseDir -Recurse -File | Unblock-File } catch {}
New-Shortcuts
try { New-Backup ("demarrage-v" + $AppVersion) | Out-Null } catch {}
Open-AppWindow

$Mime = @{ '.html' = 'text/html; charset=utf-8'; '.js' = 'application/javascript; charset=utf-8'; '.css' = 'text/css; charset=utf-8';
  '.png' = 'image/png'; '.ico' = 'image/x-icon'; '.svg' = 'image/svg+xml'; '.json' = 'application/json; charset=utf-8' }

function Send-Response($stream, [int]$code, [string]$ctype, [byte[]]$body) {
  if ($null -eq $body) { $body = [byte[]]@() }
  $status = @{ 200 = 'OK'; 204 = 'No Content'; 400 = 'Bad Request'; 404 = 'Not Found'; 500 = 'Internal Server Error' }[$code]
  $head = "HTTP/1.1 $code $status`r`nContent-Type: $ctype`r`nContent-Length: $($body.Length)`r`nCache-Control: no-store`r`nConnection: close`r`n`r`n"
  $hb = [Text.Encoding]::ASCII.GetBytes($head)
  $stream.Write($hb, 0, $hb.Length)
  if ($body.Length -gt 0) { $stream.Write($body, 0, $body.Length) }
  $stream.Flush()
}
function Send-Json($stream, $obj) { Send-Response $stream 200 'application/json; charset=utf-8' ($Utf8.GetBytes(($obj | ConvertTo-Json -Depth 5 -Compress))) }
function Send-Text($stream, [string]$txt) { Send-Response $stream 200 'application/json; charset=utf-8' ($Utf8.GetBytes($txt)) }

function Get-Query([string]$q) {
  $h = @{}
  if ($q) { foreach ($p in $q.TrimStart('?').Split('&')) { if ($p) { $kv = $p.Split('=', 2); $h[[Uri]::UnescapeDataString($kv[0])] = if ($kv.Count -gt 1) { [Uri]::UnescapeDataString($kv[1].Replace('+', ' ')) } else { '' } } } }
  return $h
}

function Invoke-Request($client) {
  $client.ReceiveTimeout = 3000
  $stream = $client.GetStream()
  $buf = New-Object byte[] 65536
  $ms = New-Object IO.MemoryStream
  $headerEnd = -1
  while ($headerEnd -lt 0) {
    $n = $stream.Read($buf, 0, $buf.Length)
    if ($n -le 0) { return }
    $ms.Write($buf, 0, $n)
    $headerEnd = [Text.Encoding]::ASCII.GetString($ms.ToArray()).IndexOf("`r`n`r`n")
    if ($ms.Length -gt 1MB -and $headerEnd -lt 0) { return }
  }
  $all = $ms.ToArray()
  $headerText = [Text.Encoding]::ASCII.GetString($all, 0, $headerEnd)
  $lines = $headerText -split "`r`n"
  $parts = $lines[0].Split(' ')
  $method = $parts[0]; $target = $parts[1]
  $len = 0
  foreach ($l in $lines) { if ($l -match '^(?i)content-length:\s*(\d+)') { $len = [int]$Matches[1] } }
  $bodyMs = New-Object IO.MemoryStream
  $already = $all.Length - ($headerEnd + 4)
  if ($already -gt 0) { $bodyMs.Write($all, $headerEnd + 4, $already) }
  while ($bodyMs.Length -lt $len) { $n = $stream.Read($buf, 0, $buf.Length); if ($n -le 0) { break }; $bodyMs.Write($buf, 0, $n) }
  $body = $Utf8.GetString($bodyMs.ToArray())

  $qi = $target.IndexOf('?')
  if ($qi -ge 0) { $path = $target.Substring(0, $qi); $query = Get-Query $target.Substring($qi + 1) } else { $path = $target; $query = @{} }
  $path = [Uri]::UnescapeDataString($path)

  if ($path.StartsWith('/api/')) {
    $script:LastPing = Get-Date; $script:Started = $true
    switch ($path) {
      '/api/ping' { Send-Response $stream 204 'text/plain' $null; return }
      '/api/load' {
        $f = Get-DataFile; $raw = Read-Data
        Send-Json $stream @{ raw = $raw; path = $f; dir = (Get-DataDir); version = $AppVersion; onedrive = ($f -match '(?i)\\OneDrive'); exists = (Test-Path $f); readError = $script:ReadErr }; return }
      '/api/save' { $st = Save-Data $body; Send-Json $stream @{ ok = $true; state = $st }; return }
      '/api/movedata' {
        # deplace les donnees hors de OneDrive (le partage Google fait deja la copie en ligne)
        $old = Get-DataFile; $oldDir = Get-DataDir
        $newDir = Join-Path $env:USERPROFILE 'Impulsion Prod donnees'
        New-Item -ItemType Directory -Force -Path (Join-Path $newDir 'sauvegardes') | Out-Null
        $newFile = Join-Path $newDir 'impulsion-led-data.json'
        if ($body) { [IO.File]::WriteAllText($newFile, $body, $Utf8) } elseif (Test-Path $old) { Copy-Item $old $newFile -Force }
        try { Get-ChildItem (Join-Path $oldDir 'sauvegardes') -Filter '*.json' | Copy-Item -Destination (Join-Path $newDir 'sauvegardes') -Force } catch {}
        [IO.File]::WriteAllText($CfgFile, (@{ dataDir = $newDir } | ConvertTo-Json), $Utf8)
        if (Test-Path $SecoursFile) { try { Remove-Item $SecoursFile -Force } catch {} }
        Write-Log ('Donnees deplacees vers ' + $newDir)
        Send-Json $stream @{ ok = $true; dir = $newDir; path = $newFile }; return }
      '/api/backup' {
        if ($method -eq 'GET') {
          $name = [IO.Path]::GetFileName($query['name'])
          Send-Text $stream ([IO.File]::ReadAllText((Join-Path (Get-BackupDir) $name), $Utf8)); return
        }
        $p = New-Backup $query['reason']; Send-Json $stream @{ path = $p }; return }
      '/api/backups' {
        $names = @(Get-ChildItem (Get-BackupDir) -Filter '*.json' | Sort-Object Name -Descending | ForEach-Object { $_.Name })
        Send-Text $stream (ConvertTo-Json -InputObject $names -Compress); return }
      '/api/openfolder' {
        $d = if ($query['which'] -eq 'backups') { Get-BackupDir } else { Get-DataDir }
        Start-Process explorer.exe $d; Send-Json $stream @{ ok = $true }; return }
      '/api/choosefolder' {
        Add-Type -AssemblyName System.Windows.Forms
        $form = New-Object System.Windows.Forms.Form; $form.TopMost = $true; $form.ShowInTaskbar = $false
        $dlg = New-Object System.Windows.Forms.FolderBrowserDialog
        $dlg.Description = 'Dossier des donnees Impulsion Prod (OneDrive, Dropbox, serveur...)'
        $res = $dlg.ShowDialog($form); $form.Dispose()
        if ($res -ne [System.Windows.Forms.DialogResult]::OK) { Send-Text $stream 'null'; return }
        $old = Get-DataFile; $newDir = $dlg.SelectedPath; $newFile = Join-Path $newDir 'impulsion-led-data.json'
        if (-not (Test-Path $newFile) -and (Test-Path $old)) { Copy-Item $old $newFile }
        [IO.File]::WriteAllText($CfgFile, (@{ dataDir = $newDir } | ConvertTo-Json), $Utf8)
        Get-DataDir | Out-Null
        $raw = $null; if (Test-Path $newFile) { $raw = [IO.File]::ReadAllText($newFile, $Utf8) }
        Send-Json $stream @{ dir = $newDir; raw = $raw }; return }
      '/api/open' {
        if ($body -match '^(https://(wa\.me|api\.whatsapp\.com|web\.whatsapp\.com|chat\.whatsapp\.com|script\.google\.com|drive\.google\.com|docs\.google\.com|github\.com|[\w-]+\.github\.io)/|whatsapp:|sms:|mailto:|tel:)') { Start-Process (Convert-WaLink $body) }
        Send-Json $stream @{ ok = $true }; return }
      '/api/remote' {
        if ($body -notmatch '^https://(script\.google\.com/macros/s/[\w-]+/exec\?|[\w-]+\.github\.io/)') { Send-Response $stream 400 'text/plain' $null; return }
        $r = Invoke-WebRequest -Uri $body -UseBasicParsing -MaximumRedirection 5 -TimeoutSec 90
        Send-Response $stream 200 'application/json; charset=utf-8' ($r.RawContentStream.ToArray()); return }
      '/api/remotepost' {
        $u = [string]$query['url']
        if ($u -notmatch '^https://script\.google\.com/macros/s/[\w-]+/exec$') { Send-Response $stream 400 'text/plain' $null; return }
        $r = Invoke-WebRequest -Uri $u -Method Post -Body ($Utf8.GetBytes($body)) -ContentType 'text/plain; charset=utf-8' -UseBasicParsing -MaximumRedirection 5 -TimeoutSec 240
        Send-Response $stream 200 'application/json; charset=utf-8' ($r.RawContentStream.ToArray()); return }
      '/api/haswhatsapp' { Send-Json $stream @{ ok = (Test-WhatsApp) }; return }
      '/api/github' {
        # appel a l'API GitHub (publication automatique du pack) : { method, path, token, data }
        $q = $body | ConvertFrom-Json
        if ([string]$q.path -notmatch '^/repos/[\w.-]+/[\w.-]+/contents/[\w./-]+(\?ref=[\w.-]+)?$') { Send-Response $stream 400 'text/plain' $null; return }
        $h = @{ Authorization = ('Bearer ' + [string]$q.token); Accept = 'application/vnd.github+json'; 'User-Agent' = 'ImpulsionProd'; 'X-GitHub-Api-Version' = '2022-11-28' }
        $code = 0; $out = ''
        try {
          if ($q.method -eq 'PUT') { $r = Invoke-WebRequest -Uri ('https://api.github.com' + $q.path) -Method Put -Headers $h -Body ($Utf8.GetBytes(($q.data | ConvertTo-Json -Depth 5 -Compress))) -ContentType 'application/json' -UseBasicParsing -TimeoutSec 120 }
          else { $r = Invoke-WebRequest -Uri ('https://api.github.com' + $q.path) -Headers $h -UseBasicParsing -TimeoutSec 60 }
          $code = [int]$r.StatusCode; $out = $r.Content
        } catch {
          $code = 0; try { $code = [int]$_.Exception.Response.StatusCode } catch {}
          try { $sr = New-Object IO.StreamReader($_.Exception.Response.GetResponseStream()); $out = $sr.ReadToEnd() } catch { $out = $_.Exception.Message }
        }
        Send-Json $stream @{ status = $code; body = [string]$out }; return }
      '/api/selfzip' {
        # zip de l'application installee (pour publier la mise a jour des autres PC)
        $tmpDir = Join-Path $env:TEMP ('ip-zip-' + [guid]::NewGuid().ToString('N')); New-Item -ItemType Directory -Force $tmpDir | Out-Null
        $zip = Join-Path $env:TEMP ('impulsion-prod-' + [guid]::NewGuid().ToString('N') + '.zip')
        Get-ChildItem $BaseDir -Force | Where-Object { $_.Name -notin @('node_modules', '.git', 'build') } | ForEach-Object { Copy-Item $_.FullName (Join-Path $tmpDir $_.Name) -Recurse -Force }
        Compress-Archive -Path (Join-Path $tmpDir '*') -DestinationPath $zip -Force
        $b64 = [Convert]::ToBase64String([IO.File]::ReadAllBytes($zip)); Remove-Item $zip -Force; Remove-Item $tmpDir -Recurse -Force
        Send-Json $stream @{ b64 = $b64 }; return }
      '/api/update' {
        # mise a jour : telecharge le zip publie, remplace les fichiers de l'application (pas les donnees), relance
        $u = [string]$body
        if ($u -notmatch '^https://[\w-]+\.github\.io/[\w.-]+/maj/impulsion-prod\.zip$') { Send-Response $stream 400 'text/plain' $null; return }
        try { New-Backup 'avant-mise-a-jour' | Out-Null } catch {}
        $zip = Join-Path $env:TEMP ('ip-maj-' + [guid]::NewGuid().ToString('N') + '.zip'); $dir = $zip + '.d'
        Invoke-WebRequest -Uri ($u + '?t=' + [DateTime]::Now.Ticks) -OutFile $zip -UseBasicParsing -TimeoutSec 180
        Expand-Archive -Path $zip -DestinationPath $dir -Force
        $root = $dir; if (-not (Test-Path (Join-Path $root 'package.json'))) { $sub = Get-ChildItem $dir -Directory | Select-Object -First 1; if ($sub) { $root = $sub.FullName } }
        if (-not (Test-Path (Join-Path $root 'app\index.html')) -or -not (Test-Path (Join-Path $root 'lanceur\server.ps1'))) { Send-Json $stream @{ ok = $false; error = 'Archive de mise a jour incomplete' }; return }
        $ver = ''; try { $ver = (Get-Content (Join-Path $root 'package.json') -Raw -Encoding UTF8 | ConvertFrom-Json).version } catch {}
        Get-ChildItem $root -Force | ForEach-Object { Copy-Item $_.FullName (Join-Path $BaseDir $_.Name) -Recurse -Force }
        try { Remove-Item $zip -Force; Remove-Item $dir -Recurse -Force } catch {}
        Write-Log ('Mise a jour installee : ' + $ver)
        $bat = Join-Path $BaseDir 'Impulsion Prod.bat'
        Start-Process powershell.exe -WindowStyle Hidden -ArgumentList @('-NoProfile', '-Command', ("Start-Sleep -Seconds 3; Start-Process -FilePath '" + $bat.Replace("'", "''") + "'"))
        Send-Json $stream @{ ok = $true; version = $ver }; $script:Quit = $true; return }
      '/api/quit' { Send-Json $stream @{ ok = $true }; $script:Quit = $true; return }
    }
    Send-Response $stream 404 'text/plain' $null; return
  }

  if ($path -eq '/') { $path = '/index.html' }
  $full = [IO.Path]::GetFullPath((Join-Path $AppDir ($path.TrimStart('/').Replace('/', '\'))))
  if (-not $full.StartsWith([IO.Path]::GetFullPath($AppDir)) -or -not (Test-Path $full -PathType Leaf)) { Send-Response $stream 404 'text/plain' $null; return }
  $ext = [IO.Path]::GetExtension($full).ToLower()
  $ct = $Mime[$ext]; if (-not $ct) { $ct = 'application/octet-stream' }
  Send-Response $stream 200 $ct ([IO.File]::ReadAllBytes($full))
}

# --- boucle principale : s'arrete seule quelques minutes apres la fermeture de la fenetre ---
$script:LastPing = Get-Date
$script:Started = $false
$script:Quit = $false
while (-not $script:Quit) {
  if (-not $listener.Pending()) {
    Start-Sleep -Milliseconds 25
    $idle = ((Get-Date) - $script:LastPing).TotalSeconds
    if ($script:Started -and $idle -gt 180) { break }
    if (-not $script:Started -and $idle -gt 300) { break }
    continue
  }
  $client = $listener.AcceptTcpClient()
  try { Invoke-Request $client }
  catch {
    try { Send-Response $client.GetStream() 500 'text/plain; charset=utf-8' ($Utf8.GetBytes($_.Exception.Message)) } catch {}
  }
  finally { $client.Close() }
}
$listener.Stop()
