/* =====================================================================
   BOARDING — panneaux LED bord terrain : N panneaux répartis en zones indépendantes
   (ex. 64 = 4 zones de 16). Câblage élec / data zone par zone, plans par zone,
   pixel map en ligne / par zone / replié, zones placées séparément dans la scène 3D.
   ===================================================================== */
function splitCounts(total, n) { total = Math.max(1, total | 0); n = Math.max(1, Math.min(total, n | 0)); const b = Math.floor(total / n), e = total % n; return Array.from({ length: n }, (_, i) => b + (i < e ? 1 : 0)); }
function boardReset(s) {
  s.zones.forEach((z) => { z.rows = zRows(s, z); });
  s.cols = s.zones.reduce((a, z) => a + Math.max(1, num(z.count) | 0), 0); s.rows = Math.max(...s.zones.map((z) => z.rows));
  ['elec', 'data'].forEach((k) => { s[k].assign = null; s[k].orders = {}; });
  fitAngles(s);
}
const zoneColor = (zi) => LINE_COLORS[(zi + 3) % LINE_COLORS.length];

/* ---------- Plan de câblage (une bande par zone) ---------- */
function boardPlanSVG(s, kind, opts = {}) {
  const plan = resolvePlan(s, kind); const T = THEMES[opts.light ? 'light' : 'dark']; const exp = !!opts.export;
  const p = getProduct(s.productId) || {}; const st = zoneStarts(s); const zs = s.zones;
  const maxN = Math.max(...zs.map((z) => z.count));
  const ratio = (num(p.heightMm) || 500) / (num(p.widthMm) || 500);
  const cw = Math.max(40, Math.min(92, 1300 / maxN)); const ch = Math.min(cw * ratio, 110);
  const mx = 34, top = exp ? 96 : 34, titleH = 30, gap = 24;
  const zy = [], zx = []; let acc = 0;
  if (isDeco(s)) { // écran déstructuré : blocs côte à côte (retour à la ligne si trop large)
    const Wmax = Math.max(maxN * cw, 1100), hg = 64; let x = 0, y = 0, lh = 0;
    zs.forEach((z) => { const bw = z.count * cw, bh = titleH + zRows(s, z) * ch; if (x > 0 && x + bw > Wmax) { y += lh + gap; x = 0; lh = 0; } zx.push(x); zy.push(y); x += bw + hg; lh = Math.max(lh, bh); });
    acc = y + lh + gap;
  } else zs.forEach((z) => { zx.push(0); zy.push(acc); acc += titleH + zRows(s, z) * ch + gap; });
  const W = Math.max(Math.max(...zs.map((z, zi) => zx[zi] + z.count * cw)) + mx * 2, 640);
  const legendRows = exp ? Math.ceil(plan.lines.length / 6) : 0;
  const H = top + acc + (exp ? 16 + legendRows * 26 : 0);
  const prefix = kind === 'elec' ? 'C' : 'P'; const fs = Math.max(9, Math.min(17, cw / 4.8));
  const pos = (i) => { const r = Math.floor(i / s.cols), c = i % s.cols; const zi = zoneOfCol(s, c); const n = zs[zi].count; const lc = c - st[zi]; const dc = opts.rear ? n - 1 - lc : lc; return { x: mx + zx[zi] + dc * cw, y: top + zy[zi] + titleH + (r - zOff(s, zs[zi])) * ch, zi, lc, rl: r - zOff(s, zs[zi]) }; };
  const posInLine = new Map(); plan.lines.forEach((l) => l.panels.forEach((idx, k) => posInLine.set(idx, k + 1)));
  let o = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${W} ${H}" width="${W}" height="${H}" font-family="Segoe UI, Arial, sans-serif">`;
  o += `<defs>${plan.lines.map((l) => `<marker id="ar${kind}${l.index}" viewBox="0 0 10 10" refX="7" refY="5" markerWidth="5.5" markerHeight="5.5" orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z" fill="${lineColor(l.index)}"/></marker>`).join('')}
    <pattern id="hatch" width="8" height="8" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><rect width="8" height="8" fill="${T.hatch}"/><line x1="0" y1="0" x2="0" y2="8" stroke="${T.grid}" stroke-width="3"/></pattern></defs>`;
  o += `<rect width="${W}" height="${H}" fill="${T.bg}"/>`;
  if (exp) {
    o += `<text x="${mx}" y="38" fill="${T.txt}" font-size="22" font-weight="700">${esc((opts.project ? opts.project.name + ' — ' : '') + s.name)}</text>`;
    o += `<text x="${mx}" y="62" fill="${T.mut}" font-size="13">${kind === 'elec' ? 'PLAN ÉLECTRIQUE' : 'PLAN DATA'} · ${zTerm(s).type.toUpperCase()} ${panelCount(s)} ${isDeco(s) ? 'dalles' : 'panneaux'} en ${zs.length} zones · ${opts.rear ? 'VUE DE DOS (côté câblage)' : 'VUE DE FACE (côté terrain)'} · ${esc(Store.db.settings.company)}</text>`;
  }
  o += `<text x="${W / 2}" y="${top - 12}" fill="${T.dim}" font-size="11" text-anchor="middle" letter-spacing="2">${opts.rear ? '◀ VUE DE DOS ▶' : isDeco(s) ? 'VUE DE FACE' : 'VUE DE FACE (CÔTÉ TERRAIN)'}</text>`;
  // titres de zones
  zs.forEach((z, zi) => {
    const y = top + zy[zi]; const X0 = mx + zx[zi]; const bw = z.count * cw; const narrow = isDeco(s) && bw < 420; const ls = plan.lines.filter((l) => l.panels.some((i) => zoneOfCol(s, i % s.cols) === zi));
    o += `<rect x="${X0}" y="${y + 4}" width="5" height="18" rx="2" fill="${zoneColor(zi)}"/>`;
    o += `<text x="${X0 + 12}" y="${y + 18}" fill="${T.txt}" font-size="${narrow ? 12 : 14}" font-weight="700">${narrow ? esc(z.name) : `${zTerm(s).One.toUpperCase()} ${zi + 1} — ${esc(z.name)}`}</text>`;
    if (!narrow) o += `<text x="${isDeco(s) ? X0 + bw : W - mx}" y="${y + 18}" fill="${T.mut}" font-size="12" text-anchor="end">${z.count * zRows(s, z)} panneaux${zRows(s, z) > 1 ? ` (${z.count} × ${zRows(s, z)})` : ''} · ${fmt(z.count * (num(p.widthMm) || 500) / 1000, 2)} m · ${ls.length} ${kind === 'elec' ? 'ligne(s)' : 'port(s)'} ${ls.length ? `(${prefix}${ls[0].index + 1}${ls.length > 1 ? '–' + prefix + (ls[ls.length - 1].index + 1) : ''})` : ''}</text>`;
  });
  // dalles
  for (let i = 0; i < s.cols * s.rows; i++) {
    if (!panelExists(s, i)) continue;
    const a = plan.assign[i]; const line = plan.lines[a]; const q = pos(i);
    const color = a >= 0 ? lineColor(a) : null; const dim = opts.sel != null && opts.sel !== a ? 0.55 : 1; const over = line && line.over;
    o += `<g opacity="${dim}"><rect data-idx="${i}" x="${q.x + 1.5}" y="${q.y + 1.5}" width="${cw - 3}" height="${ch - 3}" rx="3" fill="${color ? color + '33' : 'url(#hatch)'}" stroke="${over ? '#ff5d6c' : color || T.grid}" stroke-width="${opts.sel === a ? 2.6 : 1.4}" ${over ? 'stroke-dasharray="5 3"' : ''}/>`;
    if (a >= 0) {
      o += `<text x="${q.x + cw / 2}" y="${q.y + ch * 0.42}" fill="${T.txt}" font-size="${fs}" font-weight="700" text-anchor="middle" pointer-events="none">${prefix}${a + 1}</text>`;
      o += `<text x="${q.x + cw / 2}" y="${q.y + ch * 0.86}" fill="${color}" font-size="${fs * 0.72}" font-weight="600" text-anchor="middle" pointer-events="none">#${posInLine.get(i)}</text>`;
    } else o += `<text x="${q.x + cw / 2}" y="${q.y + ch / 2 + 4}" fill="${T.mut}" font-size="${fs * 0.75}" text-anchor="middle" pointer-events="none">libre</text>`;
    if (cw > 44) o += `<text x="${q.x + 5}" y="${q.y + 12}" fill="${T.dim}" font-size="9" pointer-events="none">${q.lc + 1}${zRows(s, zs[q.zi]) > 1 ? '·' + (q.rl + 1) : ''}</text>`;
    o += '</g>';
  }
  // chemins
  plan.lines.forEach((l) => {
    if (!l.panels.length) return; const c = lineColor(l.index); const dim = opts.sel != null && opts.sel !== l.index ? 0.5 : 1;
    o += `<g opacity="${dim}" pointer-events="none">`;
    for (let k = 0; k < l.panels.length - 1; k++) {
      const A = pos(l.panels[k]), B = pos(l.panels[k + 1]);
      const x1 = A.x + cw / 2, y1 = A.y + ch * 0.58, x2 = B.x + cw / 2, y2 = B.y + ch * 0.58;
      if (A.zi !== B.zi) {
        const ok = kind === 'data' || s[kind].joinZones; const cc = ok ? c : '#ff5d6c'; const mxp = (x1 + x2) / 2 + 40, myp = (y1 + y2) / 2;
        o += `<path d="M${x1},${y1} C${x1 + 80},${y1} ${x2 + 80},${y2} ${x2},${y2}" fill="none" stroke="${cc}" stroke-width="2.2" stroke-dasharray="7 5" marker-end="url(#ar${kind}${l.index})"/>`;
        const lx = Math.min(W - mx - 330, Math.max(mx + 330, (x1 + x2) / 2)); const lt = `🔗 liaison Z${A.zi + 1}→Z${B.zi + 1}`;
        o += `<rect x="${lx - 66}" y="${myp - 11}" width="132" height="18" rx="9" fill="${T.bg}" stroke="${cc}" stroke-width="1"/><text x="${lx}" y="${myp + 2}" fill="${cc}" font-size="11" font-weight="700" text-anchor="middle">${lt}</text>`; void mxp; continue;
      }
      const dx = x2 - x1, dy = y2 - y1, L = Math.hypot(dx, dy) || 1; const sh = Math.min(12, L * 0.16);
      o += `<line x1="${x1 + dx / L * sh}" y1="${y1 + dy / L * sh}" x2="${x2 - dx / L * sh}" y2="${y2 - dy / L * sh}" stroke="${c}" stroke-width="2.4" marker-end="url(#ar${kind}${l.index})"/>`;
    }
    const F = pos(l.panels[0]);
    o += `<circle cx="${F.x + cw / 2}" cy="${F.y + ch * 0.58}" r="${Math.max(6, fs * 0.5)}" fill="${c}" stroke="${T.bg}" stroke-width="2"/><text x="${F.x + cw / 2}" y="${F.y + ch * 0.58 + 3.5}" font-size="${Math.max(8, fs * 0.5)}" text-anchor="middle" fill="#00141c" font-weight="800">${kind === 'elec' ? '⚡' : '▶'}</text></g>`;
  });
  if (exp) {
    const sum = kind === 'elec' ? elecSummary(s, plan) : dataSummary(s, plan); const y0 = top + acc + 14;
    sum.rows.forEach((r, k) => {
      const x = mx + (k % 6) * Math.max(150, (W - 2 * mx) / 6); const y = y0 + Math.floor(k / 6) * 26;
      const z = r.line.zones && r.line.zones.length === 1 ? ` · Z${r.line.zones[0] + 1}` : '';
      const extra = kind === 'elec' ? `${r.n} pan. · ${fmt(r.A, 1)} A · ${r.phase}${z}` : `${r.n} pan. · ${fmt(r.pct, 0)} %${z}`;
      o += `<rect x="${x}" y="${y - 11}" width="12" height="12" rx="3" fill="${lineColor(r.line.index)}"/><text x="${x + 18}" y="${y}" fill="${T.txt2}" font-size="12"><tspan font-weight="700">${r.name}</tspan> ${extra}</text>`;
    });
  }
  return o + '</svg>';
}

function boardThumbSVG(s) {
  const maxN = Math.max(...s.zones.map((z) => z.count)); const cw = 10, ch = 7, gap = 6;
  const tot = s.zones.reduce((a, z) => a + ch * zRows(s, z) + gap, 0) - gap; let yz = 0;
  let o = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${maxN * cw} ${tot}">`;
  let g = 0;
  s.zones.forEach((z, zi) => { const y0 = yz; yz += ch * zRows(s, z) + gap; for (let r = 0; r < zRows(s, z); r++) for (let k = 0; k < z.count; k++) o += `<rect x="${k * cw + .5}" y="${y0 + r * ch + .5}" width="${cw - 1}" height="${ch - 1}" fill="${(g + k + r) % 2 ? s.pixmap.c1 : s.pixmap.c2}"/>`; g += z.count; });
  return o + '</svg>';
}

/* ---------- Pixel map ---------- */
function boardPixLayout(s) {
  const p = getProduct(s.productId) || {}; const pw = num(p.pxW) || 128, ph = num(p.pxH) || 128; const H1 = s.rows * ph; const zh = (zi) => zRows(s, s.zones[zi]) * ph;
  const mode = s.pixmap.board || 'zones'; const wrapW = Math.max(pw, num(s.pixmap.wrapW) || 1920);
  const cells = []; let W = 0, H = 0;
  if (mode === 'line') { let x = 0; s.zones.forEach((z, zi) => { for (let k = 0; k < z.count; k++) { cells.push({ zi, lc: k, x, y: 0 }); x += pw; } }); W = x; H = H1; }
  else if (mode === 'wrap') { const per = Math.max(1, Math.floor(wrapW / pw)); let i = 0; s.zones.forEach((z, zi) => { for (let k = 0; k < z.count; k++) { cells.push({ zi, lc: k, x: (i % per) * pw, y: Math.floor(i / per) * H1 }); i++; } }); W = Math.min(per, i) * pw; H = Math.ceil(i / per) * H1; }
  else { let y = 0; s.zones.forEach((z, zi) => { for (let k = 0; k < z.count; k++) cells.push({ zi, lc: k, x: k * pw, y }); y += zh(zi); }); W = Math.max(...s.zones.map((z) => z.count)) * pw; H = y; }
  return { cells, W, H, pw, ph };
}
function drawBoardPixmap(canvas, s) {
  if (isMapMode(s)) return drawBoardMap(canvas, s, -1);
  const L = boardPixLayout(s); const pm = s.pixmap; canvas.width = L.W; canvas.height = L.H; const ctx = canvas.getContext('2d');
  const fsz = Math.max(8, Math.floor(Math.min(L.pw, L.ph) * 0.2));
  L.cells.forEach((cell, gi) => {
    const zr = zRows(s, s.zones[cell.zi]);
    for (let r = 0; r < zr; r++) {
      const x = cell.x, y = cell.y + r * L.ph;
      ctx.fillStyle = (gi + r) % 2 === 0 ? pm.c1 : pm.c2; ctx.fillRect(x, y, L.pw, L.ph);
      if (pm.cross) { ctx.strokeStyle = 'rgba(255,255,255,.35)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + L.pw, y + L.ph); ctx.moveTo(x + L.pw, y); ctx.lineTo(x, y + L.ph); ctx.stroke(); }
      if (pm.grid) { ctx.strokeStyle = 'rgba(255,255,255,.55)'; ctx.lineWidth = 1; ctx.strokeRect(x + .5, y + .5, L.pw - 1, L.ph - 1); }
      ctx.fillStyle = pm.textColor; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      if (pm.numbers) { ctx.font = `bold ${fsz}px Segoe UI, Arial`; ctx.fillText(`Z${cell.zi + 1}-${cell.lc + 1}${zr > 1 ? '·' + (r + 1) : ''}`, x + L.pw / 2, y + L.ph / 2 - (pm.coords ? fsz * 0.35 : 0)); }
      if (pm.coords) { ctx.font = `${Math.max(7, fsz * 0.5)}px Segoe UI, Arial`; ctx.fillText(`x${x} y${y}`, x + L.pw / 2, y + L.ph / 2 + fsz * 0.55); }
    }
    if (pm.title && cell.lc === 0) { // étiquette de zone au début de chaque zone
      const t = `${zTerm(s).One.toUpperCase()} ${cell.zi + 1} · ${s.zones[cell.zi].name}`; ctx.font = `bold ${Math.max(9, fsz * 0.7)}px Segoe UI, Arial`;
      const w = ctx.measureText(t).width + 10; ctx.fillStyle = 'rgba(0,0,0,.75)'; ctx.fillRect(cell.x + 2, cell.y + 2, w, fsz + 4);
      ctx.fillStyle = '#fff'; ctx.textAlign = 'left'; ctx.textBaseline = 'top'; ctx.fillText(t, cell.x + 7, cell.y + 4);
    }
  });
  if (pm.circle) s.zones.forEach((z, zi) => { // cercle & croix de calibrage sur chaque zone / bloc
    const cs = L.cells.filter((c) => c.zi === zi); if (!cs.length) return; const zr = zRows(s, z);
    const x0 = Math.min(...cs.map((c) => c.x)), y0 = Math.min(...cs.map((c) => c.y)), x1 = Math.max(...cs.map((c) => c.x)) + L.pw, y1 = Math.max(...cs.map((c) => c.y)) + zr * L.ph;
    const bw = x1 - x0, bh = y1 - y0; const lw = Math.max(1, Math.min(bw, bh) / 150); const cx = x0 + bw / 2, cy = y0 + bh / 2, r = Math.min(bw, bh) / 2 - lw;
    ctx.save(); ctx.beginPath(); cs.forEach((c) => ctx.rect(c.x, c.y, L.pw, zr * L.ph)); ctx.clip();
    ctx.strokeStyle = '#fff'; ctx.lineWidth = lw; ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, y1); ctx.moveTo(x1, y0); ctx.lineTo(x0, y1); ctx.moveTo(x0, cy); ctx.lineTo(x1, cy); ctx.moveTo(cx, y0); ctx.lineTo(cx, y1); ctx.moveTo(cx + r, cy); ctx.arc(cx, cy, r, 0, Math.PI * 2); ctx.stroke(); ctx.restore();
  });
  return { W: L.W, H: L.H };
}
function boardPixOptions(s) {
  const pm = s.pixmap; const L = boardPixLayout(s);
  return `<div class="tiny muted" style="margin:12px 0 6px">Disposition du boarding dans le pixel map</div>
    <select data-pm="board" style="width:100%"><option value="map">Mapping de sortie 1920×1080 / 3840×2160 (créa)</option><option value="zones" ${pm.board === 'zones' ? 'selected' : ''}>Une zone par ligne (empilées)</option>
      <option value="line" ${pm.board === 'line' ? 'selected' : ''}>Une seule ligne continue</option>
      <option value="wrap" ${pm.board === 'wrap' ? 'selected' : ''}>Repliée sur une largeur de sortie</option></select>
    ${pm.board === 'wrap' ? `<label class="f" style="margin-top:8px">Largeur de sortie (px)<select data-pm="wrapW">${[1920, 2560, 3840, 4096].map((w) => `<option ${num(pm.wrapW || 1920) === w ? 'selected' : ''}>${w}</option>`).join('')}</select></label>` : ''}
    <div class="tiny muted" style="margin-top:6px">Canevas : <b>${L.W} × ${L.H} px</b></div>`;
}

/* ---------- Onglet configuration ---------- */
function boardConfigHTML(s) {
  const prods = projectDalles(curProject()); const p = getProduct(s.productId) || {}; const g = screenGeometry(s);
  const w = num(p.widthMm) || 500, h = num(p.heightMm) || 500, pw = num(p.pxW), ph = num(p.pxH);
  const pe = resolvePlan(s, 'elec'), pd = resolvePlan(s, 'data');
  const linesOf = (plan, zi) => plan.lines.filter((l) => l.panels.some((i) => zoneOfCol(s, i % s.cols) === zi)).length;
  return `<div class="editor"><div>
    <div class="card" style="margin-bottom:16px"><div class="form">
      <label class="f span2">Panneau LED<select data-sf="productId">${prods.map((x) => `<option value="${x.id}" ${x.id === s.productId ? 'selected' : ''}>${esc(prodOptionLabel(x))}</option>`).join('')}</select></label>
      ${isDeco(s) ? '' : `<label class="f">Panneaux en hauteur (toutes les zones)<input type="number" min="1" max="10" data-bf="rowsAll" value="${s.zones.every((z) => zRows(s, z) === zRows(s, s.zones[0])) ? zRows(s, s.zones[0]) : ''}" placeholder="variable"></label>`}
      ${isDeco(s) ? '' : `<label class="f">Inclinaison vers l'arrière (°)<input type="number" min="0" max="45" step="1" data-bf="tilt" value="${num(s.tilt)}"></label>`}</div></div>
    <div class="card" style="margin-bottom:16px"><h3>${isDeco(s) ? 'Blocs (éléments de l\'écran)' : 'Répartition en zones'}</h3>
      <div class="row" style="margin-bottom:14px;gap:8px;${isDeco(s) ? 'display:none' : ''}"><span class="small">Répartir</span><input type="number" min="1" id="bdTotal" value="${s.cols}" style="width:84px"><span class="small">panneaux (en longueur) en</span><input type="number" min="1" id="bdZones" value="${s.zones.length}" style="width:64px"><span class="small">zones égales</span><button class="primary" data-act="boardSplit">Répartir</button></div>
      <div class="card flat" style="border-radius:10px"><table><tr><th>${zTerm(s).One}</th><th>Nom (emplacement)</th><th class="num">${zTerm(s).len}</th><th class="num">${zTerm(s).hgt}</th><th class="num">Total</th><th class="num">Longueur</th><th class="num">Résolution</th><th class="num">Élec / data</th><th></th></tr>
      ${s.zones.map((z, zi) => `<tr><td><span class="dot" style="background:${zoneColor(zi)}"></span><b>Z${zi + 1}</b></td>
        <td><input data-zf="name" data-zi="${zi}" value="${esc(z.name)}" placeholder="ex. Tribune Nord" style="width:100%"></td>
        <td class="num"><input type="number" min="1" data-zf="count" data-zi="${zi}" value="${z.count}" style="width:76px"></td>
        <td class="num"><input type="number" min="1" max="10" data-zf="rows" data-zi="${zi}" value="${zRows(s, z)}" style="width:64px"></td>
        <td class="num"><b>${z.count * zRows(s, z)}</b></td>
        <td class="num">${fmt(z.count * w / 1000, 2)} m${zRows(s, z) > 1 ? ` × ${fmt(zRows(s, z) * h / 1000, 2)} m` : ''}</td><td class="num">${z.count * pw} × ${zRows(s, z) * ph} px</td>
        <td class="num">${linesOf(pe, zi)} ⚡ · ${linesOf(pd, zi)} ▶</td>
        <td class="num"><button class="sm ghost danger" data-act="boardDelZone" data-zi="${zi}" ${s.zones.length < 2 ? 'disabled' : ''}>✕</button></td></tr>`).join('')}
      <tr><td></td><td><b>Total</b></td><td class="num"><b>${s.cols}</b></td><td></td><td class="num"><b>${panelCount(s)}</b></td><td class="num"><b>${fmt(g.width / 1000, 2)} m</b></td><td class="num">${fmt(panelCount(s) * pw * ph)} px</td><td class="num">${pe.lines.length} ⚡ · ${pd.lines.length} ▶</td><td></td></tr></table></div>
      <div class="row" style="margin-top:10px;justify-content:space-between"><button class="sm" data-act="boardAddZone">＋ Ajouter ${isDeco(s) ? 'un bloc' : 'une zone'}</button>
      <span class="tiny muted">${isDeco(s) ? 'Chaque bloc est câblé séparément : aucune ligne élec ou data ne passe d\'un bloc à l\'autre (sauf regroupement data activé).' : 'Chaque zone est câblée séparément : aucune ligne élec ou data ne passe d\'une zone à l\'autre.'}</span></div></div>
  </div><div>
    <div class="card" style="position:sticky;top:0"><h3>${zTerm(s).type}</h3>
      <div class="big-stats" style="margin-bottom:12px"><div><span>Panneaux</span><b>${panelCount(s)}</b></div><div><span>${isDeco(s) ? 'Surface' : 'Linéaire'}</span><b>${isDeco(s) ? fmt(g.surface, 2) + ' m²' : fmt(g.width / 1000, 2) + ' m'}</b></div><div><span>Hauteur</span><b>${s.zones.every((z) => zRows(s, z) === s.rows) ? fmt(s.rows * h / 1000, 2) + ' m' : `${fmt(Math.min(...s.zones.map((z) => zRows(s, z))) * h / 1000, 2)} – ${fmt(s.rows * h / 1000, 2)} m`}</b></div></div>
      <div class="stat"><span>${zTerm(s).Many}</span><b>${s.zones.length}</b></div>
      <div class="stat"><span>Surface</span><b>${fmt(g.surface, 2)} m²</b></div>
      <div class="stat"><span>Pixels total</span><b>${fmt(panelCount(s) * pw * ph)}</b></div>
      <div class="stat"><span>Lignes électriques</span><b>${pe.lines.length}</b></div>
      <div class="stat"><span>Ports data</span><b>${pd.lines.length}</b></div>
      <div class="stat"><span>Poids</span><b>${fmt(g.weight, 1)} kg</b></div>
      <div class="stat"><span>Conso max / moy.</span><b>${fmt(g.pMax / 1000, 2)} / ${fmt(g.pAvg / 1000, 2)} kW</b></div>
      ${isDeco(s) ? '' : `<div class="stat"><span>Inclinaison</span><b>${num(s.tilt)}°</b></div>`}
      <hr class="sep"><div class="row"><button data-act="openScene">🎬 Voir dans la scène 3D</button>${isDeco(s) ? '' : `<button data-act="boardAround" title="Place les zones sur les 4 côtés d'un terrain">⬚ Autour du terrain</button>`}</div>
    </div></div></div>`;
}
function boardZonesTable(s) {
  const p = getProduct(s.productId) || {}; const pe = resolvePlan(s, 'elec'), pd = resolvePlan(s, 'data');
  const ln = (plan, zi, pre) => plan.lines.filter((l) => l.panels.some((i) => zoneOfCol(s, i % s.cols) === zi)).map((l) => pre + (l.index + 1)).join(', ');
  return `<table><tr><th>${zTerm(s).One}</th><th>Nom</th><th class="n">Panneaux</th><th class="n">Longueur</th><th>Lignes élec</th><th>Ports data</th></tr>
    ${s.zones.map((z, zi) => `<tr><td><b>Z${zi + 1}</b></td><td>${esc(z.name)}</td><td class="n">${z.count * zRows(s, z)}${zRows(s, z) > 1 ? ` <span class="muted">(${z.count}×${zRows(s, z)})</span>` : ''}</td><td class="n">${fmt(z.count * (num(p.widthMm) || 500) / 1000, 2)} m</td><td>${ln(pe, zi, 'C')}</td><td>${ln(pd, zi, 'P')}</td></tr>`).join('')}</table>`;
}

/* ---------- Actions & champs ---------- */
/* ---------- Création : quantité et zones saisies pour chaque projet ---------- */
function boardNewHTML() {
  const prods = projectDalles(curProject());
  return `<div id="bdNew"><h2>Nouveau boarding</h2><div class="form">
    <label class="f span2">Nom<input id="bnName" value="Boarding"></label>
    <label class="f span2">Panneau LED<select id="bnProd">${prods.map((x) => `<option value="${x.id}">${esc(prodOptionLabel(x))}</option>`).join('')}</select></label>
    <label class="f">Nombre total de panneaux *<input type="number" min="1" id="bnTotal" placeholder="ex. 96"></label>
    <label class="f">Nombre de zones *<input type="number" min="1" id="bnZones" value="4"></label>
    <label class="f">Panneaux en hauteur<input type="number" min="1" max="10" id="bnRows" value="1"></label>
    <label class="f">Inclinaison (°)<input type="number" min="0" max="45" id="bnTilt" value="15"></label>
    <label class="f span4">Noms des zones (facultatif, un par ligne — sinon Zone 1, Zone 2…)<textarea id="bnNames" placeholder="Tribune Nord&#10;Virage Est&#10;Tribune Sud&#10;Virage Ouest"></textarea></label>
    <div class="span4 alert ok" id="bnPreview" style="margin:0">Indiquez le nombre de panneaux et de zones.</div></div>
    <div class="tiny muted" style="margin-top:8px">Les zones sont réparties à parts égales ; vous pourrez ensuite ajuster chaque zone (nombre de panneaux, nom) dans l'onglet Configuration.</div>
    <div class="modal-actions"><button data-act="closeModal">Annuler</button><button class="primary" data-act="boardCreate">Créer le boarding</button></div></div>`;
}
function boardNewPreview() {
  const el = document.getElementById('bnPreview'); if (!el) return;
  const total = num(document.getElementById('bnTotal').value); const names = document.getElementById('bnNames').value.split('\n').map((x) => x.trim()).filter(Boolean);
  let n = num(document.getElementById('bnZones').value); if (names.length > n) n = names.length;
  const p = getProduct(document.getElementById('bnProd').value) || {}; const w = num(p.widthMm) || 500;
  if (total < 1 || n < 1) { el.textContent = 'Indiquez le nombre de panneaux et de zones.'; return; }
  const c = splitCounts(total, n);
  el.innerHTML = `→ <b>${c.length} zone(s)</b> : ${c.map((x, i) => `${esc(names[i] || 'Zone ' + (i + 1))} <b>${x}</b>`).join(' · ')} — linéaire total <b>${fmt(total * w / 1000, 2)} m</b>`;
}
document.addEventListener('input', (e) => { if (e.target.closest && e.target.closest('#bdNew')) boardNewPreview(); });
document.addEventListener('change', (e) => { if (e.target.closest && e.target.closest('#bdNew')) boardNewPreview(); });

/* ---------- Point de départ d'une ligne (écrans et boarding) ---------- */
function startOrder(s, seq, start) {
  if (!seq.includes(start) || seq[0] === start) return seq.slice();
  if (seq[seq.length - 1] === start) return seq.slice().reverse();
  const rank = new Map(seq.map((v, i) => [v, i]));
  const at = (i) => { const r = Math.floor(i / s.cols), c = i % s.cols; return { r, c, z: isBoard(s) ? zoneOfCol(s, c) : 0 }; };
  const d = (a, b) => { const A = at(a), B = at(b); return Math.abs(A.c - B.c) + Math.abs(A.r - B.r) + (A.z !== B.z ? 1000 : 0); };
  const left = new Set(seq); left.delete(start); const out = [start]; let cur = start;
  while (left.size) {
    let best = null, bd = Infinity, br = Infinity;
    left.forEach((v) => { const dv = d(cur, v); const rv = Math.abs(rank.get(v) - rank.get(cur)); if (dv < bd || (dv === bd && rv < br)) { best = v; bd = dv; br = rv; } });
    out.push(best); left.delete(best); cur = best;
  }
  return out;
}
function setLineStart(s, kind, line, start) {
  materialize(s, kind); const plan = resolvePlan(s, kind); const l = plan.lines[line]; if (!l) return;
  s[kind].orders[line] = startOrder(s, l.panels, start);
}

const boardActions = {
  addBoarding() { if (!projectDalles(curProject()).length) return customActions.cpNew({ dataset: { target: 'addBoarding' } }); openModal(boardNewHTML()); setTimeout(() => { const i = document.getElementById('bnTotal'); if (i) i.focus(); }, 50); },
  boardCreate() {
    const total = parseInt(document.getElementById('bnTotal').value, 10); const names = document.getElementById('bnNames').value.split('\n').map((x) => x.trim()).filter(Boolean);
    let n = parseInt(document.getElementById('bnZones').value, 10) || 1; if (names.length > n) n = names.length;
    if (!(total >= 1)) return toast('Indiquez le nombre total de panneaux', 'warn');
    if (n > total) return toast('Plus de zones que de panneaux', 'warn');
    const p = curProject(); const s = newScreen(Store.db, document.getElementById('bnProd').value);
    s.type = 'boarding'; s.name = document.getElementById('bnName').value.trim() || 'Boarding';
    s.rows = Math.max(1, parseInt(document.getElementById('bnRows').value, 10) || 1); s.tilt = num(document.getElementById('bnTilt').value);
    s.zones = splitCounts(total, n).map((c, i) => ({ id: uid('zon'), name: names[i] || 'Zone ' + (i + 1), count: c, rows: s.rows }));
    ['elec', 'data'].forEach((k) => Object.assign(s[k], { orient: 'h', pattern: 'snake', start: 'BL', strategy: 'balanced', joinZones: k === 'data' }));
    boardReset(s); p.screens.push(s); Store.save(); closeModal();
    go('screen', { screenId: s.id, tab: 'config' }); toast(`Boarding créé : ${panelCount(s)} panneaux en ${n} zone(s)`);
  },
  boardSplit() {
    const s = curScreen(); const total = num(document.getElementById('bdTotal').value); const n = num(document.getElementById('bdZones').value);
    if (total < 1 || n < 1) return toast('Indiquez un nombre de panneaux et de zones', 'warn');
    s.zones = splitCounts(total, n).map((c, i) => Object.assign({ id: uid('zon'), name: 'Zone ' + (i + 1) }, s.zones[i] ? { id: s.zones[i].id, name: s.zones[i].name, place: s.zones[i].place, rows: s.zones[i].rows } : {}, { count: c }));
    boardReset(s); Store.save(); render(); toast(`${total} panneaux répartis en ${s.zones.length} zone(s)`);
  },
  boardAddZone() { const s = curScreen(); const last = s.zones[s.zones.length - 1]; s.zones.push({ id: uid('zon'), name: 'Zone ' + (s.zones.length + 1), count: last ? last.count : 16, rows: last ? zRows(s, last) : 1 }); boardReset(s); Store.save(); render(); },
  boardDelZone(el) { const s = curScreen(); if (s.zones.length < 2) return; const z = s.zones[+el.dataset.zi]; if (!confirm(`Supprimer la zone « ${z.name} » (${z.count} panneaux) ?`)) return; s.zones.splice(+el.dataset.zi, 1); boardReset(s); Store.save(); render(); },
  boardAround() { const s = curScreen(); arrangeAroundPitch(s, curProject()); Store.save(); toast('Zones disposées autour du terrain — ouvrez la scène 3D pour ajuster ⬚'); }
};
function boardChange(t) {
  const s = curScreen(); if (!s || !isBoard(s)) return false;
  if (t.dataset.zf) {
    const z = s.zones[+t.dataset.zi]; if (!z) return true;
    if (t.dataset.zf === 'count') { z.count = Math.max(1, parseInt(t.value, 10) || 1); boardReset(s); }
    else if (t.dataset.zf === 'rows') { z.rows = Math.max(1, Math.min(10, parseInt(t.value, 10) || 1)); boardReset(s); }
    else z.name = t.value.trim() || z.name;
    Store.save(); render(); return true;
  }
  if (t.dataset.bf === 'rowsAll') { const v = Math.max(1, Math.min(10, parseInt(t.value, 10) || 0)); if (v) { s.zones.forEach((z) => { z.rows = v; }); boardReset(s); Store.save(); } render(); return true; }
  if (t.dataset.bf === 'tilt') { s.tilt = Math.max(0, Math.min(60, num(t.value))); Store.save(); render(); return true; }
  return false;
}
