/* =====================================================================
   ESPACE TECHNICIEN SUR TÉLÉPHONE
   Chaque technicien reçoit un lien personnel (…github.io/…/?e=jeton) qu'il ajoute à son écran
   d'accueil : il y voit UNIQUEMENT ses bookings (à répondre, options, validés), avec horaires,
   lieu, feuille de route et groupe WhatsApp. Le poste principal publie ces espaces via le relais
   Google (action « publish », même stockage que les feuilles de route) dès qu'ils changent.
   ===================================================================== */
const espaceOn = () => pagesActive();
function espaceToken(t) { if (!t.espace) { t.espace = 'esp' + randToken(20); Store.save(); } return t.espace; }
const espaceLink = (t) => `${pagesBase()}?e=${espaceToken(t)}`;
const espaceState = { timer: null, busy: false, error: null, last: null };
const espaceHashes = () => (localInfo().espace = localInfo().espace || {});

function espaceData(t) {
  const st = Store.db.settings; const from = addDays(todayISO(), -1); const items = [];
  Store.db.projects.filter((p) => p.status !== 'annule').forEach((p) => (p.crew || []).filter((r) => r.techId === t.id && r.status !== 'indispo').forEach((r) => {
    const dates = [...(r.dates || [])].sort(); const last = dates[dates.length - 1] || p.end || p.start || '';
    if (!last || last < from) return;
    const rm = p.roadmap || {}; const ok = r.status === 'valide';
    items.push({
      id: r.id, project: p.name, client: p.client || '', status: r.status, role: r.role || '',
      first: dates[0] || p.start || '', datesTxt: fmtDays(dates), days: dates.map((d) => ({ d, l: dayWithHours(r, d) })), note: (r.hours && r.hours.note) || '',
      lieu: p.venue || '', address: ok ? (rm.address || p.venue || '') : (p.venue || ''),
      reply: r.status === 'attente' && r.token && r.regHash ? `${pagesBase()}?t=${r.token}` : '',
      fdr: ok && rm.token && rm.publishedAt ? `${pagesBase()}?f=${rm.token}` : '',
      group: ok && rm.groupLink ? rm.groupLink : ''
    });
  }));
  items.sort((a, b) => (a.first || '').localeCompare(b.first || ''));
  const ind = techIndispo(t).filter((d) => d >= todayISO());
  return { kind: 'espace', v: 1, company: st.company || 'Impulsion', name: t.firstName || techName(t), items, indispo: { days: ind, note: (t.indispo && t.indispo.note) || '' } };
}
/* Publie les espaces qui ont changé (poste principal uniquement) */
async function espaceSync(force) {
  if (!espaceOn() || espaceState.busy || (!force && !isAutoLeader())) return 0;
  espaceState.busy = true; let n = 0;
  try {
    const H = espaceHashes();
    for (const t of Store.db.techs.filter((x) => x.espace)) {
      const d = espaceData(t); const h = JSON.stringify(d); if (!force && H[t.id] === h) continue;
      await withTimeout(remotePost({ action: 'publish', key: ensureReplyKey(), token: t.espace, data: Object.assign({ updatedAt: new Date().toISOString() }, d) }), 45000);
      H[t.id] = h; n++;
    }
    espaceState.error = null; espaceState.last = Date.now(); if (n) Store.saveNow();
  } catch (e) { espaceState.error = e.message || String(e); } finally { espaceState.busy = false; }
  return n;
}
function scheduleEspace() { clearTimeout(espaceState.timer); espaceState.timer = setTimeout(() => espaceSync(false), 8000); }
(function hookEspace() { const save = Store.save.bind(Store); Store.save = function () { save(); if (espaceOn() && Store.db.techs.some((t) => t.espace)) scheduleEspace(); }; })();
setInterval(() => { if (espaceOn()) espaceSync(false); }, 10 * 60000); // passage de date (un booking terminé disparaît)

const espaceMsg = (t) => `Salut ${t.firstName || ''} 👋\nVoici ton espace ${Store.db.settings.company || 'Impulsion'} : tous tes bookings (dates, horaires, lieu, feuille de route) au même endroit.\n👉 ${espaceLink(t)}\n\n📱 Ajoute-le à ton écran d'accueil pour l'avoir comme une appli :\n• iPhone : bouton Partager ⬆️ puis « Sur l'écran d'accueil »\n• Android : menu ⋮ puis « Ajouter à l'écran d'accueil » / « Installer l'appli »`;
const espaceActions = {
  async espaceSend(el) {
    const t = getTech(el.dataset.id); if (!t) return;
    if (!espaceOn()) return toast('Mettez d\'abord en place la page GitHub (Équipe → Réponses en 1 clic → Liens sans erreur Google)', 'warn');
    espaceToken(t); Store.saveNow(); toast('Publication de son espace…');
    try { const H = espaceHashes(); delete H[t.id]; await espaceSync(true); if (espaceState.error) throw new Error(espaceState.error); } catch (e) { return toast(e.message, 'bad'); }
    if (!normPhone(t.phone)) { await copyText(espaceMsg(t)); return toast('Pas de numéro valide : message copié, envoyez-le vous-même', 'warn'); }
    if (waPaste()) await copyText(espaceMsg(t), true);
    openExternal(waLink(t.phone, espaceMsg(t))); toast(waPaste() ? 'Message copié : collez-le (Ctrl+V) dans WhatsApp puis Entrée' : 'WhatsApp ouvert ✔');
  },
  espaceAll() {
    if (!espaceOn()) return toast('Mettez d\'abord en place la page GitHub (Équipe → Réponses en 1 clic → Liens sans erreur Google)', 'warn');
    const list = Store.db.techs.filter((t) => t.active !== false);
    openModal(`<h2>📱 Espace mobile des techniciens</h2><div class="small muted">Chaque technicien reçoit un lien personnel vers ses propres bookings (personne ne voit ceux des autres). Il l'ajoute à son écran d'accueil comme une appli ; tout se met à jour automatiquement.</div>
      <table style="margin-top:12px">${list.map((t) => `<tr><td><b>${esc(techName(t))}</b><div class="tiny muted">${t.espace ? '✔ espace créé' : 'pas encore envoyé'}</div></td><td class="num"><button class="sm ${t.espace ? '' : 'primary'}" data-act="espaceSend" data-id="${t.id}">${t.espace ? 'Renvoyer' : 'Envoyer'} 📱</button></td></tr>`).join('')}</table>
      ${espaceState.error ? `<div class="alert bad" style="margin-top:10px">${esc(espaceState.error)}</div>` : ''}
      <div class="modal-actions"><button data-act="closeModal">Fermer</button></div>`);
  }
};

/* ---------- Indisponibilités déclarées depuis « Mes bookings » (script v12) ---------- */
async function indispoPull(manual) {
  if (!replyActive() || (replyState.version || 0) < 12) return 0;
  const st = Store.db.settings; const t0 = todayISO();
  const j = await withTimeout(remoteGet({ action: 'indlist', key: ensureReplyKey(), since: st.indSince || 0 }), 25000);
  let n = 0;
  (j.rows || []).sort((a, b) => a.at - b.at).forEach((row) => {
    st.indSince = Math.max(st.indSince || 0, row.at);
    const t = Store.db.techs.find((x) => x.espace && x.espace === row.e); if (!t) return;
    const before = techIndispo(t).filter((d) => d >= t0); const days = [...new Set(row.days || [])].filter((d) => d >= t0).sort();
    t.indispo = { days, note: row.note || '', at: new Date(row.at).toISOString() };
    const added = days.filter((d) => !before.includes(d)); const removed = before.filter((d) => !days.includes(d));
    if (!added.length && !removed.length) return;
    const clash = []; activeProjects().forEach((p) => p.crew.forEach((r) => { if (r.techId === t.id && r.status !== 'indispo' && r.dates.some((d) => added.includes(d))) clash.push(p); }));
    const txt = [added.length ? `s'est déclaré indisponible : ${fmtDays(added)}` : '', removed.length ? `est de nouveau disponible : ${fmtDays(removed)}` : ''].filter(Boolean).join(' · ') + (t.indispo.note ? ` (« ${t.indispo.note} »)` : '');
    if (typeof journalAdd === 'function') journalAdd({ kind: 'info', type: 'reply', ic: '🚫', byName: '', by: '', ref: clash[0] ? clash[0].id : '', text: `${techName(t)} ${txt}${clash.length ? ` — ⚠ déjà prévu sur ${clash.map((p) => p.name).join(', ')}` : ''}` });
    toast(`🚫 ${techName(t)} ${txt}${clash.length ? ` — ⚠ déjà prévu sur ${clash.map((p) => p.name).join(', ')}` : ''}`, clash.length ? 'bad' : ''); n++;
  });
  if (n || (j.rows || []).length) Store.save();
  if (manual && !n) toast('Aucune nouvelle indisponibilité');
  return n;
}
