@echo off
if not exist "%~dp0lanceur\server.ps1" (
  echo.
  echo  Le dossier n est pas dezippe.
  echo  Fermez cette fenetre, faites clic droit sur le fichier ZIP puis "Extraire tout",
  echo  et double-cliquez sur "Impulsion Prod" dans le dossier extrait.
  echo.
  pause
  exit /b 1
)
start "" powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0lanceur\server.ps1"
