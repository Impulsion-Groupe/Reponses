/* =====================================================================
   VIEWS — interface, navigation, actions
   ===================================================================== */
const ui = {
  view: 'home', projectId: null, screenId: null, tab: 'config', tool: 'paint', sel: { elec: 0, data: 0 }, rear: false, zoom: false,
  v3d: { yaw: -0.55, pitch: 0.28, zoom: 1 }, stockFrom: todayISO(), stockTo: addDays(todayISO(), 30), cat: 'all', search: '',
  planStart: addDays(todayISO(), -3), projFilter: 'actifs', edit: null, painting: false
};
const db = () => Store.db;
const curProject = () => getProject(ui.projectId);
const curScreen = () => { const p = curProject(); return p && p.screens.find((s) => s.id === ui.screenId); };
const $main = () => document.getElementById('main');

function go(view, params = {}) { Object.assign(ui, { view }, params); render(); $main().scrollTop = 0; }

function render() {
  document.querySelectorAll('#nav a').forEach((a) => {
    const v = a.dataset.nav; a.classList.toggle('on', v === ui.view || (v === 'projects' && (ui.view === 'project' || ui.view === 'screen' || ui.view === 'scene' || ui.view === 'roadmap')));
  });
  const V = { home: vHome, catalog: vCatalog, stock: vStock, planning: vPlanning, projects: vProjects, project: vProject, screen: vScreen, settings: vSettings, team: vTeam, vehicles: vVehicles, scene: vScene, roadmap: vRoadmap, accounts: vAccounts, journal: vJournal }[ui.view] || vHome;
  $main().innerHTML = V();
  afterRender();
}

/* ---------- Surfaces (m²) des dalles ---------- */
const panelM2 = (p) => (p && p.category === 'dalle' ? (num(p.widthMm) * num(p.heightMm)) / 1e6 : 0);
const m2 = (p, qty) => panelM2(p) * num(qty);
const m2txt = (p, qty) => (panelM2(p) ? `${fmt(m2(p, qty), 2)} m²` : '');
const m2sub = (p, qty) => (panelM2(p) ? `<div class="tiny muted">${fmt(m2(p, qty), 2)} m²</div>` : '');
const screenM2 = (s) => m2(getProduct(s.productId), panelCount(s));

/* ---------------- ACCUEIL ---------------- */
function vHome() {
  const d = db(); const t = todayISO();
  const upcoming = d.projects.filter((p) => p.status !== 'annule' && (p.end || p.start) >= t).sort((a, b) => (a.start || '').localeCompare(b.start || ''));
  const dalles = d.products.filter((p) => p.category === 'dalle').reduce((s, p) => s + num(p.stock), 0);
  const dallesM2 = d.products.filter((p) => p.category === 'dalle').reduce((s, p) => s + m2(p, p.stock), 0);
  const alerts = upcoming.map((p) => ({ p, sh: projectShortages(p) })).filter((x) => x.sh.length);
  const h = new Date().getHours(); const hello = h < 12 ? 'Bonjour' : h < 18 ? 'Bon après-midi' : 'Bonsoir';
  const quips = ['Prêt à faire briller la prochaine scène ?', 'Les dalles sont chaudes, les câbles sont prêts.', 'Encore un écran géant à imaginer ?', 'On allume tout ? ✨'];
  return `<div class="page-head"><div><div class="hello">${hello} 👋</div><h1>${quips[new Date().getDate() % quips.length]}</h1></div>
    <div class="row"><button data-act="newProduct">＋ Produit</button><button class="primary" data-act="newProject">✦ Nouveau projet</button></div></div>
  <div class="grid g4" style="margin-bottom:16px">
    <div class="card kpi"><div class="l">Références</div><div class="v">${d.products.length}</div></div>
    <div class="card kpi"><div class="l">Dalles en stock</div><div class="v">${fmt(dalles)}</div><div class="small muted">soit ${fmt(dallesM2, 1)} m² de LED</div></div>
    <div class="card kpi"><div class="l">Projets à venir</div><div class="v">${upcoming.length}</div></div>
    <div class="card kpi"><div class="l">Alertes stock</div><div class="v" style="color:${alerts.length ? 'var(--bad)' : 'var(--ok)'}">${alerts.length}</div></div>
  </div>
  <div class="grid g2">
    <div class="card flat"><div style="padding:16px 18px 6px"><h3>Prochains projets</h3></div>
      ${upcoming.length ? `<table><tr><th>Projet</th><th>Dates</th><th>Écrans</th><th>Statut</th></tr>${upcoming.slice(0, 8).map((p) => `<tr class="click" data-act="openProject" data-id="${p.id}">
        <td><span class="dot" style="background:${p.color}"></span><b>${esc(p.name)}</b><div class="tiny muted">${esc(p.client || '')}</div></td>
        <td class="small">${fmtDate(p.start)} → ${fmtDate(p.end)}</td><td>${p.screens.length}</td><td>${statusTag(p)}</td></tr>`).join('')}</table>` : `<div class="empty"><div class="e">🎬</div>Aucun projet à venir. Le calme avant le show !</div>`}
    </div>
    <div class="card"><h3>Alertes de disponibilité</h3>
      ${alerts.length ? alerts.map((x) => `<div class="alert bad"><b>${esc(x.p.name)}</b> (${fmtDate(x.p.start)}) — ${x.sh.map((s) => `il manque <b>${s.missing}</b> × ${esc(s.prod.name)}${panelM2(s.prod) ? ' (' + m2txt(s.prod, s.missing) + ')' : ''}`).join(', ')} <a data-act="openProject" data-id="${x.p.id}">Voir →</a></div>`).join('')
        : `<div class="alert ok">Tout est disponible pour les projets à venir. 👌</div>`}
      ${todoHTML()}
      <hr class="sep"><h3>Raccourcis</h3>
      <div class="row"><button data-nav-go="stock">▤ Disponibilités</button><button data-nav-go="planning">▭ Planning</button><button data-nav-go="catalog">▦ Catalogue</button><button data-nav-go="team">☺ Équipe</button><button data-nav-go="vehicles">⛟ Véhicules</button></div>
    </div>
  </div>`;
}
function statusTag(p) {
  const cls = { devis: 'warn', confirme: 'info', encours: 'ok', termine: '', annule: 'bad' }[p.status] || '';
  return `<span class="tag ${cls}">${STATUSES[p.status] || p.status}</span>${catOf(p) ? ' ' + catTag(p) : ''}`;
}

/* ---------------- CATALOGUE ---------------- */
function productSpecs(p) {
  if (p.category === 'dalle') return `${fmt(p.widthMm)}×${fmt(p.heightMm)}×${fmt(p.depthMm)} mm · ${p.pxW}×${p.pxH} px · ${fmt(panelM2(p), 3)} m²/dalle · P${fmt(p.pitch, 2)} · ${fmt(p.powerMax)} W max · ${fmt(p.weightKg, 1)} kg`;
  if (p.category === 'processeur') return `${p.ports || '?'} ports · ${fmt(p.pxPerPort)} px/port`;
  return esc(p.notes || '');
}
function vCatalog() {
  const q = ui.search.toLowerCase();
  const list = db().products.filter((p) => (ui.cat === 'all' || p.category === ui.cat) && (!q || [p.ref, p.name, p.brand].join(' ').toLowerCase().includes(q)))
    .sort((a, b) => a.category.localeCompare(b.category) || (a.ref || '').localeCompare(b.ref || ''));
  return `<div class="page-head"><div><h1>Catalogue</h1><div class="sub">Toutes vos références produits</div></div>
    <div class="row"><button data-act="exportCatalogCSV">⇩ Export CSV</button><button data-act="importCatalogCSV">⇧ Import CSV</button><button class="primary" data-act="newProduct">＋ Nouvelle référence</button></div></div>
  <div class="toolbar"><div class="seg">${[['all', 'Tout'], ...Object.entries(CATEGORIES)].map(([k, v]) => `<button class="${ui.cat === k ? 'on' : ''}" data-act="setCat" data-v="${k}">${v}</button>`).join('')}</div>
    <input class="grow" placeholder="🔎 Rechercher une référence, un nom, une marque…" value="${esc(ui.search)}" data-ui="search" style="max-width:360px"></div>
  <div class="card flat">${list.length ? `<table><tr><th>Référence</th><th>Désignation</th><th>Catégorie</th><th>Caractéristiques</th><th class="num">Stock</th><th></th></tr>
  ${list.map((p) => `<tr class="click" data-act="editProduct" data-id="${p.id}"><td><b>${esc(p.ref)}</b></td><td>${esc(p.name)}<div class="tiny muted">${esc(p.brand || '')}</div></td>
   <td><span class="tag">${CATEGORIES[p.category]}</span></td><td class="small muted">${productSpecs(p)}</td><td class="num"><b>${fmt(p.stock)}</b>${m2sub(p, p.stock)}</td>
   <td class="num"><button class="sm ghost" data-act="dupProduct" data-id="${p.id}" title="Dupliquer">⧉</button></td></tr>`).join('')}</table>`
    : `<div class="empty"><div class="e">📦</div>Aucune référence ici. Ajoutez votre première dalle !</div>`}</div>`;
}
function productForm(p) {
  const f = (k, label, type = 'text', cls = '') => `<label class="f ${cls}">${label}<input data-pf="${k}" type="${type}" value="${esc(p[k] == null ? '' : p[k])}" ${type === 'number' ? 'step="any"' : ''}></label>`;
  let h = `<h2>${p._new ? 'Nouvelle référence' : 'Modifier la référence'}</h2><div class="form">
    <label class="f">Catégorie<select data-pf="category">${Object.entries(CATEGORIES).map(([k, v]) => `<option value="${k}" ${p.category === k ? 'selected' : ''}>${v}</option>`).join('')}</select></label>
    ${f('ref', 'Référence *')}${f('name', 'Désignation *', 'text', 'span2')}${f('brand', 'Marque')}${f('stock', 'Quantité en stock', 'number')}
    ${p.category !== 'dalle' ? f('weightKg', 'Poids unitaire (kg)', 'number') : ''}${f('volumeM3', 'Volume unitaire transport (m³)', 'number')}`;
  if (p.category === 'dalle') {
    h += `${f('pitch', 'Pitch (mm)', 'number')}${f('widthMm', 'Largeur (mm)', 'number')}${f('heightMm', 'Hauteur (mm)', 'number')}${f('depthMm', 'Profondeur (mm)', 'number')}
    ${f('pxW', 'Résolution largeur (px)', 'number')}${f('pxH', 'Résolution hauteur (px)', 'number')}${f('weightKg', 'Poids (kg)', 'number')}
    ${f('powerMax', 'Conso max (W)', 'number')}${f('powerAvg', 'Conso moyenne (W)', 'number')}${f('maxChain', 'Max dalles / ligne élec (fabricant)', 'number')}
    <div class="span4 small" id="m2info">${m2Info(p)}</div>`;
  } else if (p.category === 'processeur') {
    h += `${f('ports', 'Nombre de ports', 'number')}${f('pxPerPort', 'Pixels max / port', 'number')}`;
  }
  h += prodFilesHTML(p) + `<label class="f span4">Notes<textarea data-pf="notes">${esc(p.notes || '')}</textarea></label></div>
  <div class="modal-actions">${p._new ? '' : `<button class="danger" data-act="deleteProduct" style="margin-right:auto">Supprimer</button>`}<button data-act="closeModal">Annuler</button><button class="primary" data-act="saveProduct">Enregistrer</button></div>`;
  return h;
}
function m2Info(p) {
  const a = (num(p.widthMm) * num(p.heightMm)) / 1e6;
  return a ? `🟦 Surface : <b>${fmt(a, 3)} m²</b> par dalle · stock <b>${fmt(a * num(p.stock), 2)} m²</b> · ${fmt(1 / a, 2)} dalles au m²` : '';
}
function openModal(html) { document.getElementById('modalBody').innerHTML = html; document.getElementById('modal').classList.remove('hidden'); }
function closeModal() { document.getElementById('modal').classList.add('hidden'); ui.edit = null; }

/* ---------------- STOCK ---------------- */
function vStock() {
  const rows = db().products.map((p) => { const u = peakUsage(p.id, ui.stockFrom, ui.stockTo); return { p, used: u.peak, free: num(p.stock) - u.peak, projects: u.projects }; })
    .sort((a, b) => a.free - b.free);
  return `<div class="page-head"><div><h1>Stock & disponibilités</h1><div class="sub">Pic d'utilisation sur la période (projets qui se chevauchent cumulés) · quantités et surfaces en m²</div></div>
    <div class="row"><label class="f">Du<input type="date" data-ui="stockFrom" value="${ui.stockFrom}"></label><label class="f">Au<input type="date" data-ui="stockTo" value="${ui.stockTo}"></label></div></div>
  <div class="card flat"><table><tr><th>Référence</th><th>Désignation</th><th class="num">Stock</th><th class="num">Sortis (pic)</th><th class="num">Disponible</th><th>Occupation</th><th>Projets</th></tr>
  ${rows.map((r) => { const pct = num(r.p.stock) ? Math.min(100, r.used / num(r.p.stock) * 100) : (r.used ? 100 : 0);
    return `<tr class="click" data-act="editProduct" data-id="${r.p.id}"><td><b>${esc(r.p.ref)}</b></td><td>${esc(r.p.name)}</td><td class="num">${fmt(r.p.stock)}${m2sub(r.p, r.p.stock)}</td><td class="num">${fmt(r.used)}${m2sub(r.p, r.used)}</td>
    <td class="num"><b style="color:${r.free < 0 ? 'var(--bad)' : r.free === 0 ? 'var(--warn)' : 'var(--ok)'}">${fmt(r.free)}</b>${m2sub(r.p, r.free)}</td>
    <td><div class="bar"><i class="${r.free < 0 ? 'bad' : pct > 85 ? 'warn' : ''}" style="width:${pct}%"></i></div></td>
    <td class="small">${r.projects.map((x) => `<span class="tag" style="border-color:${x.p.color}">${esc(x.p.name)} ×${x.q}</span>`).join(' ') || '<span class="dim">—</span>'}</td></tr>`; }).join('')}
  </table></div>`;
}

/* ---------------- PLANNING ---------------- */
function vPlanning() {
  const days = 42; const start = ui.planStart; const end = addDays(start, days - 1); const t = todayISO();
  const projs = db().projects.filter((p) => p.status !== 'annule' && p.start && overlaps(start, end, p.start, p.end)).sort((a, b) => a.start.localeCompare(b.start));
  const dayIdx = (iso) => Math.round((new Date(iso + 'T00:00:00') - new Date(start + 'T00:00:00')) / 864e5);
  const head = Array.from({ length: days }, (_, i) => { const d = addDays(start, i); const dt = new Date(d + 'T00:00:00'); const we = dt.getDay() === 0 || dt.getDay() === 6;
    return `<div class="g-day ${we ? 'we' : ''} ${d === t ? 'today' : ''}">${dt.getDate() === 1 || i === 0 ? dt.toLocaleDateString('fr-FR', { month: 'short' }) + '<br>' : ''}${dt.getDate()}</div>`; }).join('');
  const ti = dayIdx(t);
  return `<div class="page-head"><div><h1>Planning</h1><div class="sub">Sorties et retours de matériel — ${fmtDate(start)} → ${fmtDate(end)}</div></div>
    <div class="row"><button data-act="planShift" data-v="-14">◀ 2 sem.</button><button data-act="planToday">Aujourd'hui</button><button data-act="planShift" data-v="14">2 sem. ▶</button><button class="primary" data-act="newProject">✦ Nouveau projet</button></div></div>
  <div class="card flat gantt"><div style="min-width:1100px">
    <div class="g-head"><div class="g-label" style="background:var(--panel2)"><b>Projet</b></div><div style="display:flex;flex:1">${head}</div></div>
    ${projs.length ? projs.map((p) => { const a = Math.max(0, dayIdx(p.start)), b = Math.min(days - 1, dayIdx(p.end || p.start)); const sh = projectShortages(p).length;
      return `<div class="g-row"><div class="g-label"><b>${esc(p.name)}</b><span class="tiny muted">${esc(p.venue || p.client || '')}</span></div>
      <div class="g-track">${ti >= 0 && ti < days ? `<div class="g-today" style="left:${(ti + .5) / days * 100}%"></div>` : ''}
      <div class="g-bar ${p.status === 'devis' ? 'devis' : ''}" data-act="openProject" data-id="${p.id}" style="left:${a / days * 100}%;width:${(b - a + 1) / days * 100}%;background:${p.color}">${sh ? '⚠ ' : ''}${esc(p.name)} · ${p.screens.reduce((s, x) => s + panelCount(x), 0)} dalles · ${fmt(p.screens.reduce((a, x) => a + screenM2(x), 0), 1)} m²</div></div></div>`; }).join('')
      : `<div class="empty"><div class="e">🗓️</div>Aucun projet sur cette période.</div>`}
  </div></div><p class="tiny muted">Barres en pointillés : devis / options. ⚠ : il manque du matériel sur la période.</p>`;
}

/* ---------------- PROJETS ---------------- */
function vProjects() {
  const t = todayISO(); const f = ui.projFilter; const fc = ui.projCat || 'all';
  const list = db().projects.filter((p) => fc === 'all' || (fc === 'none' ? !catOf(p) : catOf(p) === fc)).filter((p) => f === 'tous' || (f === 'actifs' ? p.status !== 'annule' && (p.end || p.start || t) >= t : f === 'passes' ? (p.end || p.start || t) < t : true))
    .sort((a, b) => (a.start || '').localeCompare(b.start || ''));
  return `<div class="page-head"><div><h1>Projets</h1><div class="sub">${db().projects.length} projets au total</div></div>
   <div class="row"><div class="seg">${[['actifs', 'À venir / en cours'], ['passes', 'Passés'], ['tous', 'Tous']].map(([k, v]) => `<button class="${f === k ? 'on' : ''}" data-act="projFilter" data-v="${k}">${v}</button>`).join('')}</div>
   <select data-ui-sel="projCat" title="Catégorie"><option value="all">Toutes catégories</option>${Object.entries(PROJECT_CATS).map(([k, c]) => `<option value="${k}" ${fc === k ? 'selected' : ''}>${c.ic} ${c.l}</option>`).join('')}<option value="none" ${fc === 'none' ? 'selected' : ''}>Sans catégorie</option></select>
   <button class="primary" data-act="newProject">✦ Nouveau projet</button></div></div>
   ${(() => { const cnt = {}; db().projects.forEach((p) => { const k = catOf(p) || 'none'; cnt[k] = (cnt[k] || 0) + 1; }); return `<div class="row" style="gap:6px;margin:-6px 0 14px">${Object.entries(PROJECT_CATS).map(([k, c]) => `<span class="tiny muted">${c.ic} ${c.l} : <b>${cnt[k] || 0}</b></span>`).join('<span class="tiny muted">·</span>')}</div>`; })()}
  ${list.length ? `<div class="grid g3">${list.map((p) => { const sh = projectShortages(p); const n = p.screens.reduce((s, x) => s + panelCount(x), 0);
    return `<div class="card screen-card" data-act="openProject" data-id="${p.id}" style="border-top:3px solid ${p.color}">
     <div class="row" style="justify-content:space-between"><h2 style="margin:0">${esc(p.name)}</h2>${statusTag(p)}</div>
     <div class="muted small" style="margin:6px 0 12px">${esc(p.client || '')}${p.venue ? ' · ' + esc(p.venue) : ''}</div>
     <div class="small">📅 ${fmtDate(p.start)} → ${fmtDate(p.end)}</div>
     <div class="small" style="margin-top:4px">🖥️ ${p.screens.length} écran(s) · ${n} dalles · ${fmt(p.screens.reduce((a, x) => a + screenM2(x), 0), 1)} m²</div>
     ${sh.length ? `<div class="alert bad" style="margin:12px 0 0">⚠ Matériel manquant</div>` : ''}</div>`; }).join('')}</div>`
    : `<div class="card empty"><div class="e">✦</div>Aucun projet ici. Créez-en un pour commencer !</div>`}`;
}
function projectForm(p) {
  return `<h2>${p._new ? 'Nouveau projet' : 'Infos du projet'}</h2><div class="form">
   <label class="f span2">Nom du projet *<input data-jf="name" value="${esc(p.name)}"></label><label class="f">Client<input data-jf="client" value="${esc(p.client || '')}"></label><label class="f">Lieu<input data-jf="venue" value="${esc(p.venue || '')}"></label>
   <label class="f">Date de sortie<input type="date" data-jf="start" value="${p.start || ''}"></label><label class="f">Date de retour<input type="date" data-jf="end" value="${p.end || ''}"></label>
   <label class="f">Catégorie<select data-jf="cat"><option value="">— Choisir —</option>${Object.entries(PROJECT_CATS).map(([k, c]) => `<option value="${k}" ${catOf(p) === k ? 'selected' : ''}>${c.ic} ${c.l}</option>`).join('')}</select></label>
   <label class="f">Statut<select data-jf="status">${Object.entries(STATUSES).map(([k, v]) => `<option value="${k}" ${p.status === k ? 'selected' : ''}>${v}</option>`).join('')}</select></label>
   <label class="f">Couleur<input type="color" data-jf="color" value="${p.color}"></label>
   <label class="f span4 row" style="gap:10px;align-items:center;flex-direction:row"><input type="checkbox" id="pjSale" ${p.sale ? 'checked' : ''} style="width:auto"><span><b>💼 Projet de vente / étude</b> — ne réserve aucun stock ; dalles hors catalogue autorisées pour les rendus (plans, pixel map, 3D, PDF)</span></label>
   <label class="f span4">Notes<textarea data-jf="notes">${esc(p.notes || '')}</textarea></label></div>
   <div class="modal-actions"><button data-act="closeModal">Annuler</button><button class="primary" data-act="saveProject">${p._new ? 'Créer le projet ✦' : 'Enregistrer'}</button></div>`;
}
function vProject() {
  const p = curProject(); if (!p) return vProjects();
  const sh = projectShortages(p); const usage = projectUsage(p);
  const dalleProducts = p.sale ? [...projectDalles(p), { id: '_any' }] : projectDalles(p); // en vente : création possible même sans dalle au catalogue
  return `<div class="crumbs"><a data-nav-go="projects">Projets</a> › ${esc(p.name)}</div>
  <div class="page-head"><div><h1><span class="dot" style="background:${p.color};width:14px;height:14px"></span>${esc(p.name)}</h1>
    <div class="sub">${esc(p.client || '—')}${p.venue ? ' · ' + esc(p.venue) : ''} · 📅 ${fmtDate(p.start)} → ${fmtDate(p.end)} · ${statusTag(p)}</div>
    ${p._mod ? `<div class="tiny muted" style="margin-top:4px">🕘 ${modTxt(p)}</div>` : ''}
    ${p.screens.length ? `<div class="small" style="margin-top:6px">🟦 Surface LED totale : <b>${fmt(p.screens.reduce((a, x) => a + screenM2(x), 0), 2)} m²</b> · ${p.screens.reduce((a, x) => a + panelCount(x), 0)} dalles</div>` : ''}</div>
    <div class="row"><button data-act="openRoadmap">📋 Feuille de route</button>${p.screens.length ? '<button data-act="openScene">🎬 Vue 3D de la scène</button>' : ''}<button data-act="editProjectInfo">✎ Infos</button><button data-act="dupProject">⧉ Dupliquer</button><button data-act="exportMaterialCSV">⇩ Matériel CSV</button><button class="primary" data-act="exportProjectPDF">⇩ Dossier PDF équipes</button></div></div>
  ${p.sale ? `<div class="alert">💼 <b>Projet de vente / étude</b> : aucun stock n'est réservé. Vous pouvez utiliser des dalles hors catalogue pour les rendus.</div>` : sh.length ? `<div class="alert bad"><b>⚠ Stock insuffisant sur la période :</b><br>${sh.map((s) => `${esc(s.prod.name)} : besoin ${s.need}, disponible ${Math.max(0, s.free)} → <b>manque ${s.missing}${panelM2(s.prod) ? ' (' + m2txt(s.prod, s.missing) + ')' : ''}</b>${s.others.length ? ` <span class="tiny">(déjà sorti sur : ${s.others.map((o) => esc(o.p.name) + ' ×' + o.q).join(', ')})</span>` : ''}`).join('<br>')}</div>`
    : p.start ? `<div class="alert ok">✔ Tout le matériel est disponible sur la période.</div>` : `<div class="alert">Renseignez les dates de sortie et de retour pour vérifier le stock.</div>`}
  <div class="row" style="justify-content:space-between;margin:22px 0 12px"><h2 style="margin:0">Écrans</h2>${p.screens.length > 1 ? '<button class="sm" data-act="openScene" style="margin-left:12px">🎬 Vue 3D de l\'ensemble</button>' : ''}
    <div class="row">${dalleProducts.length ? '' : '<span class="small muted">Ajoutez d\'abord une dalle au catalogue, ou cochez « Projet de vente / étude » pour utiliser une dalle hors catalogue.</span>'}<button data-act="addBoarding" ${dalleProducts.length ? '' : 'disabled'} title="Panneaux LED bord terrain répartis en zones">＋ Boarding</button><button data-act="addDeco" ${dalleProducts.length ? '' : 'disabled'} title="Main stage + totems… gérés comme un seul écran dans le mapping">＋ Écran déstructuré</button><button data-act="addArch" ${dalleProducts.length ? '' : 'disabled'}>＋ Arche</button><button class="primary" data-act="addScreen" ${dalleProducts.length ? '' : 'disabled'}>＋ Ajouter un écran</button></div></div>
  ${p.screens.length ? `<div class="grid g4">${p.screens.map((s) => { const g = screenGeometry(s); const prod = getProduct(s.productId);
    return `<div class="card screen-card" data-act="openScreen" data-id="${s.id}"><div class="thumb">${thumbSVG(s)}</div>
     <div class="row" style="justify-content:space-between"><b>${esc(s.name)}</b><span class="small muted">${isBoard(s) ? `${panelCount(s)} pan. · ${s.zones.length} ${zTerm(s).many}` : `${s.cols}×${s.rows}`}</span></div>
     <div class="tiny muted" style="margin-top:4px">${esc(prod ? prod.name : 'Produit ?')}</div>
     <div class="small" style="margin-top:8px">${isBoard(s) ? `<span class="tag info">Boarding</span> ${fmt(g.width / 1000, 1)} m linéaires · <b>${fmt(g.surface, 2)} m²</b>` : `${fmt(g.width / 1000, 2)} × ${fmt(g.height / 1000, 2)} m · <b>${fmt(g.surface, 2)} m²</b> · ${g.resW}×${g.resH} px`}</div>
     <div class="row" style="margin-top:10px"><button class="sm ghost" data-act="dupScreen" data-id="${s.id}">⧉ Dupliquer</button><button class="sm ghost danger" data-act="delScreen" data-id="${s.id}">✕</button></div></div>`; }).join('')}</div>`
    : `<div class="card empty"><div class="e">🖥️</div>Pas encore d'écran. Ajoutez-en un pour générer les plans.</div>`}
  <div class="row" style="justify-content:space-between;margin:26px 0 12px"><h2 style="margin:0">Liste de matériel</h2></div>
  <div class="card flat"><table><tr><th>Référence</th><th>Désignation</th><th>Origine</th><th class="num">Quantité</th><th class="num">Stock</th><th class="num">Dispo période</th><th></th></tr>
    ${[...usage.entries()].map(([pid, u]) => { const prod = getProduct(pid); if (!prod) return ''; const other = p.start ? peakUsage(pid, p.start, p.end || p.start, p.id).peak : 0; const free = num(prod.stock) - other;
      const extra = p.extras.find((x) => x.productId === pid);
      return `<tr><td><b>${esc(prod.ref)}</b></td><td>${esc(prod.name)}</td><td class="small">${u.auto ? `<span class="tag info">Écrans : ${u.auto}</span> ` : ''}${u.manual ? `<span class="tag">Ajout : ${u.manual}</span>` : ''}</td>
      <td class="num"><b>${u.qty}</b>${m2sub(prod, u.qty)}</td>${prod.custom ? '<td class="num" colspan="2"><span class="tag warn">Hors catalogue</span></td>' : `<td class="num">${fmt(prod.stock)}${m2sub(prod, prod.stock)}</td>${p.sale ? '<td class="num small muted">non réservé</td>' : `<td class="num" style="color:${free < u.qty ? 'var(--bad)' : 'var(--ok)'}">${fmt(free)}${m2sub(prod, free)}</td>`}`}
      <td class="num">${extra ? `<input type="number" min="0" style="width:70px" data-extra="${pid}" value="${extra.qty}"> <button class="sm ghost" data-act="delExtra" data-id="${pid}">✕</button>` : ''}</td></tr>`; }).join('')}
    <tr><td colspan="7"><div class="row"><select id="extraProd" style="min-width:300px"><option value="">＋ Ajouter du matériel (câbles, processeurs, distribution…)</option>
      ${db().products.map((x) => `<option value="${x.id}">${esc(CATEGORIES[x.category])} — ${esc(x.ref)} ${esc(x.name)}</option>`).join('')}</select>
      <input id="extraQty" type="number" min="1" value="1" style="width:80px"><button data-act="addExtra">Ajouter</button></div></td></tr></table></div>
  ${p.screens.length ? `<div class="card" style="margin-top:16px"><h3>Estimation câblage (tous écrans)</h3><div class="grid g4">${(() => { const t = p.screens.map(cableEstimate).reduce((a, c) => ({ powerIn: a.powerIn + c.powerIn, powerJumpers: a.powerJumpers + c.powerJumpers, dataIn: a.dataIn + c.dataIn, dataJumpers: a.dataJumpers + c.dataJumpers }), { powerIn: 0, powerJumpers: 0, dataIn: 0, dataJumpers: 0 });
      return `<div><span class="muted small">Arrivées 16A</span><h2>${t.powerIn}</h2></div><div><span class="muted small">Cordons power link</span><h2>${t.powerJumpers}</h2></div><div><span class="muted small">Départs data (ports)</span><h2>${t.dataIn}</h2></div><div><span class="muted small">Cordons data dalle→dalle</span><h2>${t.dataJumpers}</h2></div>`; })()}</div></div>` : ''}
  ${crewSection(p)}${fleetSection(p)}
  ${p.notes ? `<div class="card" style="margin-top:16px"><h3>Notes</h3><div style="white-space:pre-wrap">${esc(p.notes)}</div></div>` : ''}
  <div style="margin-top:30px"><button class="danger" data-act="delProject">Supprimer ce projet</button></div>`;
}

/* ---------------- ÉDITEUR D'ÉCRAN ---------------- */
function vScreen() {
  const p = curProject(), s = curScreen(); if (!s) return vProject();
  const tabs = [['config', 'Configuration & courbure'], ['elec', '⚡ Plan électrique'], ['data', '⇄ Plan data'], ['pixmap', '▦ Pixel map'], ...(isBoard(s) ? [['visuals', '🎨 Visuels → matrices']] : []), ['export', '⇩ Exports']];
  let body = '';
  if (ui.tab === 'config') body = isBoard(s) ? boardConfigHTML(s) : tabConfig(s);
  else if (ui.tab === 'elec' || ui.tab === 'data') body = tabPlan(s, ui.tab);
  else if (ui.tab === 'pixmap') body = tabPixmap(s);
  else if (ui.tab === 'visuals' && isBoard(s)) body = visualsTab(s);
  else body = tabExport(s, p);
  return `<div class="crumbs"><a data-nav-go="projects">Projets</a> › <a data-act="openProject" data-id="${p.id}">${esc(p.name)}</a> › ${esc(s.name)}</div>
  <div class="page-head"><div class="row"><input data-sf="name" value="${esc(s.name)}" style="font-size:22px;font-weight:700;background:transparent;border-color:transparent;padding:2px 6px;width:380px"></div>
    <div class="row small muted">${isBoard(s) ? `<span class="tag info">${zTerm(s).type}</span> ${panelCount(s)} ${isDeco(s) ? 'dalles' : 'panneaux'} en ${s.zones.length} ${zTerm(s).many}` : `${s.cols}×${s.rows} dalles`} · ${esc((getProduct(s.productId) || {}).name || '')}</div></div>
  <div class="tabs">${tabs.map(([k, v]) => `<a class="${ui.tab === k ? 'on' : ''}" data-act="tab" data-v="${k}">${v}</a>`).join('')}</div>${body}`;
}
function angleSelect(axis, j, v) {
  const list = ANGLES_ALL.includes(num(v)) ? ANGLES_ALL : [...ANGLES_ALL, num(v)].sort((a, b) => a - b);
  return `<div class="j${Math.abs(num(v)) >= 45 ? ' corner' : ''}"><select data-angle="${axis}" data-j="${j}" ${Math.abs(num(v)) >= 45 ? 'style="border-color:var(--accent);color:var(--accent)"' : ''}>${list.map((a) => `<option value="${a}" ${num(v) === a ? 'selected' : ''}>${a > 0 ? '+' : ''}${String(a).replace('.', ',')}°</option>`).join('')}<option value="__other">Autre…</option></select>${j + 1}|${j + 2}</div>`;
}
function tabConfig(s) {
  const g = screenGeometry(s); const prods = projectDalles(curProject());
  const R = (pr) => (pr.corner ? '— (angles droits)' : isFinite(pr.R) ? `${fmt(pr.R / 1000, 3)} m${pr.uniform ? '' : ' <span class="tiny muted">(moyen)</span>'}` : '∞ (plat)');
  const D = (pr) => (!pr.corner && isFinite(pr.R) ? `${fmt(2 * pr.R / 1000, 3)} m` : '—');
  const quick = (axis) => `<div class="row" style="margin:6px 0 10px"><span class="tiny muted">Tout régler à :</span>${ANGLES.map((a) => `<button class="sm" data-act="allAngles" data-axis="${axis}" data-v="${a}">${a > 0 ? '+' : ''}${a}°</button>`).join('')}</div>`
    + `<div class="row" style="margin:-4px 0 10px"><span class="tiny muted">Formes à 90° :</span><button class="sm" data-act="cornerPreset" data-axis="${axis}" data-v="2" title="Un coin droit au milieu (écran en L)">⌐ Coin en L</button><button class="sm" data-act="cornerPreset" data-axis="${axis}" data-v="3" title="Trois faces (U)">⊓ 3 faces</button><button class="sm" data-act="cornerPreset" data-axis="${axis}" data-v="4" title="Quatre faces fermées : cube / totem carré">▢ Cube 4 faces</button><label class="tiny" style="display:flex;gap:4px;align-items:center"><input type="checkbox" id="cornerIn" style="width:auto"> vers l'intérieur (+90°)</label></div>`;
  const hasV = s.vAngles.some((a) => num(a) !== 0);
  return `<div class="editor"><div>
    <div class="card" style="margin-bottom:16px"><div class="form">
      <label class="f span2">Dalle<select data-sf="productId">${prods.map((x) => `<option value="${x.id}" ${x.id === s.productId ? 'selected' : ''}>${esc(prodOptionLabel(x))}</option>`).join('')}<option value="__custom">＋ Dalle hors catalogue…</option></select>
        ${isCustomProd(getProduct(s.productId)) ? '<a class="tiny" data-act="cpEdit" style="margin-top:4px">✎ Modifier les caractéristiques de cette dalle</a>' : ''}</label>
      ${isArch(s) ? `<div class="f span2 small muted">Arche : ${s.cols} dalles le long × ${s.rows} de large — réglages ci-dessous.</div>` : `<label class="f">Colonnes (largeur)<input type="number" min="1" max="200" data-sf="cols" data-type="int" value="${s.cols}"></label>
      <label class="f">Rangées (hauteur)<input type="number" min="1" max="200" data-sf="rows" data-type="int" value="${s.rows}"></label>`}</div></div>
    ${isArch(s) ? archCardHTML(s) : ''}
    <div class="card" style="margin-bottom:16px"><div class="row" style="justify-content:space-between;margin-bottom:10px"><h3 style="margin:0">Vue 3D de l'écran</h3><button class="sm" data-act="openScene">🎬 Voir toute la scène</button></div><canvas id="view3d"></canvas></div>
    ${isArch(s) ? '' : `<div class="card" style="margin-bottom:16px"><h3>Angles horizontaux — entre colonnes</h3><div class="tiny muted">+ = concave (les bords viennent vers le public) · − = convexe</div>
      ${s.cols > 1 ? quick('h') + `<div class="angles">${s.hAngles.map((a, j) => angleSelect('h', j, a)).join('')}</div>` : '<div class="muted small">Une seule colonne.</div>'}
      <div class="canvas-wrap" style="margin-top:14px;min-height:0">${profileSVG(s, 'h')}</div></div>
    <div class="card"><h3>Angles verticaux — entre rangées</h3><div class="tiny muted">+ = concave (haut et bas vers le public) · − = convexe</div>
      ${s.rows > 1 ? quick('v') + `<div class="angles">${s.vAngles.map((a, j) => angleSelect('v', j, a)).join('')}</div>` : '<div class="muted small">Une seule rangée.</div>'}
      ${hasV ? `<div class="canvas-wrap" style="margin-top:14px;min-height:0">${profileSVG(s, 'v')}</div>` : ''}</div>`}
  </div><div>
    <div class="card" style="margin-bottom:16px;position:sticky;top:0"><h3>Dimensions</h3>
      <div class="big-stats" style="margin-bottom:12px"><div><span>Largeur</span><b>${fmt(g.width / 1000, 3)} m</b></div><div><span>Hauteur</span><b>${fmt(g.height / 1000, 3)} m</b></div><div><span>Profondeur</span><b>${fmt(g.depth / 1000, 3)} m</b></div></div>
      ${isArch(s) ? `<div class="stat"><span>Forme</span><b>${(ARCH_SHAPES.find((x) => x[0] === s.arch.shape) || [, ''])[1]}</b></div><div class="stat"><span>Ouverture intérieure</span><b>${fmt(g.arch.P.S / 1000, 2)} m</b></div><div class="stat"><span>Hauteur libre</span><b>${fmt(g.arch.P.Hc / 1000, 2)} m</b></div><div class="stat"><span>Longueur développée</span><b>${fmt(g.arch.P.L / 1000, 2)} m</b></div><div class="stat"><span>Largeur de bande</span><b>${fmt(g.arch.P.B / 1000, 2)} m</b></div><div class="stat"><span>Épaisseur dalle</span><b>${fmt(g.d)} mm</b></div><hr class="sep">` : `
      ${g.H.closed ? '<div class="alert bad">L\'écran fait un tour complet (≥ 360°) !</div>' : ''}
      <div class="stat"><span>Rayon horizontal</span><b>${R(g.H)}</b></div><div class="stat"><span>Diamètre horizontal</span><b>${D(g.H)}</b></div>
      <div class="stat"><span>Somme des angles (jonctions)</span><b>${fmt(g.H.total)}°</b></div><div class="stat"><span>Angle d'arc couvert</span><b>${fmt(g.H.arc, 1)}°</b></div><div class="stat"><span>Longueur développée</span><b>${fmt(g.H.developed / 1000, 3)} m</b></div>
      <div class="stat"><span>Corde (bord à bord)</span><b>${fmt(g.H.chord / 1000, 3)} m</b></div><div class="stat"><span>Flèche horizontale</span><b>${fmt(g.H.sag / 1000, 3)} m</b></div>
      <hr class="sep">
      <div class="stat"><span>Rayon vertical</span><b>${R(g.V)}</b></div><div class="stat"><span>Diamètre vertical</span><b>${D(g.V)}</b></div>
      <div class="stat"><span>Somme des angles (jonctions)</span><b>${fmt(g.V.total)}°</b></div><div class="stat"><span>Angle d'arc couvert</span><b>${fmt(g.V.arc, 1)}°</b></div><div class="stat"><span>Hauteur développée</span><b>${fmt(g.V.developed / 1000, 3)} m</b></div>
      <div class="stat"><span>Flèche verticale</span><b>${fmt(g.V.sag / 1000, 3)} m</b></div><div class="stat"><span>Épaisseur dalle</span><b>${fmt(g.d)} mm</b></div>
      <hr class="sep">
      `}
      <div class="stat"><span>Résolution</span><b>${g.resW} × ${g.resH} px</b></div><div class="stat"><span>Pixels</span><b>${fmt(g.resW * g.resH)}</b></div>
      <div class="stat"><span>Surface</span><b>${fmt(g.surface, 2)} m²</b></div><div class="stat"><span>Dalles</span><b>${g.panels}</b></div>
      <div class="stat"><span>Poids écran</span><b>${fmt(g.weight, 1)} kg</b></div><div class="stat"><span>Conso max / moy.</span><b>${fmt(g.pMax / 1000, 2)} / ${fmt(g.pAvg / 1000, 2)} kW</b></div>
    </div></div></div>`;
}
function tabPlan(s, kind) {
  const cfg = s[kind]; const plan = resolvePlan(s, kind); const isE = kind === 'elec';
  const sum = isE ? elecSummary(s, plan) : dataSummary(s, plan);
  const sel = ui.sel[kind]; const prefix = isE ? 'C' : 'P';
  const nL = Math.max(plan.lines.length, sel + 1);
  const seg = (field, opts) => `<div class="seg">${opts.map(([v, l]) => `<button class="${cfg[field] === v ? 'on' : ''}" data-act="planSet" data-kind="${kind}" data-f="${field}" data-v="${v}">${l}</button>`).join('')}</div>`;
  const corner = ['TL', 'TR', 'BL', 'BR'].map((c) => `<button class="sm ${cfg.start === c ? 'on' : ''}" data-act="planSet" data-kind="${kind}" data-f="start" data-v="${c}" title="Départ">${{ TL: '↖ Haut-G', TR: 'Haut-D ↗', BL: '↙ Bas-G', BR: 'Bas-D ↘' }[c]}</button>`).join('');
  const lineRow = (l) => {
    const r = sum.rows.find((x) => x.line.index === l);
    const info = !r ? '<span class="dim">vide</span>' : isE ? `${r.n} dalles · ${fmt(r.A, 1)} A · ${r.phase}` : `${r.n} dalles · ${fmt(r.pct, 0)} %`;
    const pct = r ? (isE ? r.pct : r.pct) : 0; const over = r && r.line.over;
    return `<div class="line-item ${sel === l ? 'sel' : ''} ${over ? 'over' : ''}" data-act="selLine" data-kind="${kind}" data-v="${l}"><span class="sw" style="background:${lineColor(l)}"></span><b>${prefix}${l + 1}</b><span class="grow">${info}${r && r.line.manualOrder ? ' · <span class="tag info">ordre manuel</span>' : ''}${r && r.line.cross ? ' · <span class="tag">🔗 ' + r.line.zones.map((z) => 'Z' + (z + 1)).join('+') + '</span>' : ''}
      ${r ? `<br><span class="tiny muted">📍 départ</span> <select class="start-sel" data-linestart="${l}" data-kind="${kind}" title="Choisir d'où part ce câble">${r.line.panels.map((i, k) => `<option value="${i}" ${k === 0 ? 'selected' : ''}>${panelLabel(s, i)}</option>`).join('')}</select>` : ''}</span>
      <div class="bar" style="min-width:50px;width:50px"><i class="${over ? 'bad' : pct > 90 ? 'warn' : ''}" style="width:${Math.min(100, pct)}%"></i></div></div>`;
  };
  const capTxt = isE ? `${plan.cap.cap} dalles max / ligne <span class="tiny muted">(puissance : ${plan.cap.byPower} — ${fmt(plan.cap.watt)} W/dalle, ${fmt(plan.cap.usable)} W utiles${num((getProduct(s.productId) || {}).maxChain) ? ' · limite fabricant ' + num(getProduct(s.productId).maxChain) : ''})</span>`
    : `${plan.cap.cap} dalles max / port <span class="tiny muted">(${fmt(plan.cap.pxPort)} px/port ÷ ${fmt(plan.cap.px)} px/dalle)</span>`;
  const procs = db().products.filter((x) => x.category === 'processeur');
  return `<div class="editor"><div>
    <div class="toolbar">
      <div class="seg"><button class="${ui.tool === 'paint' ? 'on' : ''}" data-act="tool" data-v="paint">🖌 Peindre (assigner)</button><button class="${ui.tool === 'trace' ? 'on' : ''}" data-act="tool" data-v="trace">➰ Tracer l'ordre</button><button class="${ui.tool === 'start' ? 'on' : ''}" data-act="tool" data-v="start">📍 Point de départ</button></div>
      <div class="seg"><button class="${!ui.rear ? 'on' : ''}" data-act="rear" data-v="0">Vue de face</button><button class="${ui.rear ? 'on' : ''}" data-act="rear" data-v="1">Vue de dos</button></div>${isArch(s) ? `<div class="seg"><button class="${s.pixmap.archView !== 'flat' ? 'on' : ''}" data-act="archView" data-v="arch">🌈 Arche</button><button class="${s.pixmap.archView === 'flat' ? 'on' : ''}" data-act="archView" data-v="flat">▭ Déroulé</button></div>` : ''}
      <button data-act="zoom">${ui.zoom ? '⤡ Ajuster' : '⤢ Zoom 100 %'}</button>
      <span class="grow"></span>
      ${plan.manual ? `<span class="tag warn">Modifié à la main</span>` : `<span class="tag ok">Automatique</span>`}
      <button data-act="autoPlan" data-kind="${kind}">↻ Recalculer auto</button>
    </div>
    ${isBoard(s) ? `<div class="alert ok" style="margin-bottom:10px">${zTerm(s).type} ${panelCount(s)} ${isDeco(s) ? 'dalles' : 'panneaux'} — ${s.zones.map((z, i) => `Z${i + 1} ${esc(z.name)} : ${z.count}${zRows(s, z) > 1 ? "×" + zRows(s, z) : ""}`).join(' · ')}. ${Array.isArray(cfg.groups) ? 'Liaisons choisies à la main (voir « Liaisons » à droite).' : cfg.joinZones ? 'Zones regroupées sur un même départ quand la capacité le permet.' : 'Chaque zone a ses propres départs.'}</div>` : ''}
    ${plan.lines.some((l) => l.cross) ? (kind === 'data' || cfg.joinZones
      ? `<div class="alert" style="background:rgba(25,166,204,.1);border-color:rgba(25,166,204,.35);color:#bfeaf7">🔗 ${plan.lines.filter((l) => l.cross).map((l) => `${prefix}${l.index + 1} relie ${l.zones.map((z) => 'Z' + (z + 1)).join(' → ')}`).join(' · ')} — prévoir un câble de liaison entre zones (longueur selon l'implantation).</div>`
      : `<div class="alert">⚠ ${plan.lines.filter((l) => l.cross).map((l) => prefix + (l.index + 1)).join(', ')} passe(nt) d'une zone à l'autre — prévoir une rallonge entre zones, ou activez « Regrouper les zones ».</div>`) : ''}
    ${plan.unassigned ? `<div class="alert">${plan.unassigned} dalle(s) non câblée(s).</div>` : ''}${plan.lines.some((l) => l.over) ? `<div class="alert bad">Une ou plusieurs lignes dépassent la capacité (${plan.cap.cap} dalles).</div>` : ''}
    <div class="canvas-wrap ${ui.zoom ? 'zoom' : ''}" id="planArea" data-kind="${kind}">${planSVG(s, kind, { rear: ui.rear, sel })}</div>
    <p class="tiny muted">${ui.tool === 'start' ? `📍 Cliquez sur la dalle d'où part le câble ${isE ? 'électrique' : 'data'} : sa ligne est recâblée à partir de ce point (vous pouvez aussi choisir le départ dans la liste à droite).` : ui.tool === 'paint' ? `🖌 Sélectionnez une ligne à droite puis cliquez / glissez sur les dalles pour les y affecter.` : `➰ Cliquez les dalles dans l'ordre de câblage voulu pour la ligne sélectionnée (${prefix}${sel + 1}).`}</p>
  </div><div>
    ${isBoard(s) && (!isE || isDeco(s) || Array.isArray(cfg.groups)) ? linksCardHTML(s, kind) : ''}
    <div class="card" style="margin-bottom:16px"><h3>Répartition automatique</h3>
      <div class="tiny muted" style="margin-bottom:6px">Sens des lignes</div>${seg('orient', [['v', '⇅ Verticale'], ['h', '⇆ Horizontale']])}
      <div class="tiny muted" style="margin:10px 0 6px">Parcours</div>${seg('pattern', [['snake', '〰 Serpentin'], ['raster', '↩ Retour au début']])}
      <div class="tiny muted" style="margin:10px 0 6px">Coin de départ (vue de face)</div><div class="row" style="gap:4px">${corner}</div>
      ${isBoard(s) && !Array.isArray(cfg.groups) ? `<label class="row small" style="margin-top:12px;gap:8px;align-items:flex-start"><input type="checkbox" data-pc="joinZones" data-kind="${kind}" ${cfg.joinZones ? 'checked' : ''} style="margin-top:2px"><span>Regrouper les zones sur un même ${isE ? 'départ' : 'port'} quand la capacité ${isE ? 'électrique' : 'pixel'} le permet<br><span class="tiny muted">Les zones restent entières ; une zone trop grande est découpée.</span></span></label>` : ''}
      <label class="f" style="margin-top:10px">Praticité de câblage<select data-pc="strategy" data-kind="${kind}">
        <option value="whole" ${cfg.strategy === 'whole' ? 'selected' : ''}>Colonnes / rangées entières (le plus pratique)</option>
        <option value="balanced" ${cfg.strategy === 'balanced' ? 'selected' : ''}>Charge équilibrée entre lignes</option>
        <option value="fill" ${cfg.strategy === 'fill' ? 'selected' : ''}>Remplir chaque ligne au maximum</option></select></label>
      <hr class="sep">
      ${isE ? `<div class="form" style="grid-template-columns:1fr 1fr">
        <label class="f">Tension (V)<input type="number" data-pc="voltage" data-kind="elec" value="${cfg.voltage}"></label>
        <label class="f">Disjoncteur (A)<select data-pc="amps" data-kind="elec">${[10, 16, 20, 32].map((a) => `<option ${num(cfg.amps) === a ? 'selected' : ''}>${a}</option>`).join('')}</select></label>
        <label class="f">Charge max (%)<input type="number" data-pc="safety" data-kind="elec" value="${cfg.safety}"></label>
        <label class="f">Base de calcul<select data-pc="basis" data-kind="elec"><option value="max" ${cfg.basis === 'max' ? 'selected' : ''}>Conso max</option><option value="avg" ${cfg.basis === 'avg' ? 'selected' : ''}>Conso moyenne</option></select></label>
        <label class="f">Max dalles / ligne<input type="number" data-pc="maxPerLine" data-kind="elec" value="${cfg.maxPerLine}" placeholder="0 = auto"></label>
        <label class="f">Réseau<select data-pc="phases" data-kind="elec"><option value="3" ${num(cfg.phases) === 3 ? 'selected' : ''}>Triphasé (L1/L2/L3)</option><option value="1" ${num(cfg.phases) === 1 ? 'selected' : ''}>Monophasé</option></select></label></div>`
      : `<div class="form" style="grid-template-columns:1fr 1fr">
        <label class="f" style="grid-column:span 2">Processeur<select data-pc="processorId" data-kind="data"><option value="">— Aucun / saisie manuelle —</option>${procs.map((x) => `<option value="${x.id}" ${cfg.processorId === x.id ? 'selected' : ''}>${esc(x.name)} (${x.ports} ports)</option>`).join('')}</select></label>
        <label class="f">Pixels / port<input type="number" data-pc="pxPerPort" data-kind="data" value="${cfg.pxPerPort}" ${cfg.processorId ? 'disabled' : ''}></label>
        <label class="f">Max dalles / port<input type="number" data-pc="maxPerPort" data-kind="data" value="${cfg.maxPerPort}" placeholder="0 = auto"></label></div>`}
      <div class="small" style="margin-top:12px">Capacité : <b>${capTxt}</b></div>
    </div>
    <div class="card" style="margin-bottom:16px"><div class="row" style="justify-content:space-between;margin-bottom:8px"><h3 style="margin:0">${isE ? 'Lignes électriques' : 'Ports data'}</h3>
      <div class="row" style="gap:4px"><button class="sm" data-act="newLine" data-kind="${kind}">＋ Ligne</button>${ui.tool === 'trace' ? `<button class="sm" data-act="clearTrace" data-kind="${kind}">Effacer tracé</button>` : ''}<button class="sm ghost" data-act="renumber" data-kind="${kind}" title="Renuméroter">1‥n</button></div></div>
      <div class="lines-list">${Array.from({ length: nL }, (_, l) => lineRow(l)).join('')}</div></div>
    <div class="card"><h3>Bilan</h3>
      ${isE ? `<div class="stat"><span>Lignes 16A</span><b>${sum.rows.length}</b></div><div class="stat"><span>Puissance totale</span><b>${fmt(sum.totalW / 1000, 2)} kW</b></div>
        ${sum.phaseA.map((a, i) => `<div class="stat"><span>Phase L${i + 1}</span><b>${fmt(sum.phaseW[i] / 1000, 2)} kW · ${fmt(a, 1)} A</b></div>`).join('')}
        <div class="stat"><span>Arrivée conseillée</span><b>${sum.phases === 3 ? 'Tri' : 'Mono'} ${sum.feed} A</b></div>`
      : `<div class="stat"><span>Ports utilisés</span><b>${sum.ports}</b></div><div class="stat"><span>Pixels total</span><b>${fmt(sum.totalPx)}</b></div>
        ${sum.proc ? `<div class="stat"><span>${esc(sum.proc.name)}</span><b>× ${sum.procs}</b></div>` : '<div class="stat"><span>Processeur</span><b class="muted">non choisi</b></div>'}`}
    </div></div></div>`;
}
const PALETTES = [['Impulsion', '#0b5c78', '#1d1d1b'], ['Magenta / Cyan', '#e6007e', '#00a7e1'], ['Rouge / Bleu', '#e3262f', '#1f4fd8'], ['Vert / Violet', '#24c25e', '#7a2fd8'], ['Orange / Turquoise', '#ff8a00', '#00b3a4'], ['Gris', '#5a5a5a', '#9a9a9a']];
function tabPixmap(s) {
  if (isMapMode(s)) return boardMapTab(s);
  const pm = s.pixmap; const p = getProduct(s.productId) || {};
  const chk = (k, l) => `<label class="row small" style="gap:8px;margin:6px 0"><input type="checkbox" data-pm="${k}" ${pm[k] ? 'checked' : ''}>${l}</label>`;
  return `<div class="editor"><div><div class="canvas-wrap" style="padding:20px"><canvas id="pixCanvas" class="pixmap-preview"></canvas></div>
    <p class="tiny muted" id="pixInfo"></p></div>
   <div>${isArch(s) ? `<div class="card" style="margin-bottom:16px"><h3>Forme du pixel map</h3><div class="seg"><button class="${s.pixmap.archView !== 'flat' ? 'on' : ''}" data-act="archView" data-v="arch">🌈 Arche</button><button class="${s.pixmap.archView === 'flat' ? 'on' : ''}" data-act="archView" data-v="flat">▭ Déroulé</button></div><div class="tiny muted" style="margin-top:8px">Arche : le contenu de chaque dalle à sa vraie place (vue de face). Déroulé : une bande ${s.cols} × ${s.rows} dalles, pied gauche → pied droit.</div></div>` : ''}<div class="card" style="margin-bottom:16px"><h3>Damier bicolore</h3>
     <div class="row"><label class="f">Couleur 1<input type="color" data-pm="c1" value="${pm.c1}"></label><label class="f">Couleur 2<input type="color" data-pm="c2" value="${pm.c2}"></label><label class="f">Texte<input type="color" data-pm="textColor" value="${pm.textColor}"></label></div>
     <div class="tiny muted" style="margin:12px 0 6px">Palettes express</div>
     <div class="row" style="gap:6px">${PALETTES.map(([n, a, b], i) => `<button class="sm" data-act="palette" data-v="${i}" title="${n}"><span class="dot" style="background:${a};margin:0"></span><span class="dot" style="background:${b};margin:0"></span>${n}</button>`).join('')}<button class="sm" data-act="palette" data-v="swap">⇄ Inverser</button></div>
     ${isBoard(s) ? boardPixOptions(s) : ''}
     <hr class="sep">${chk('numbers', isBoard(s) ? 'Numéro de panneau (zone-numéro)' : 'Numéro de dalle (colonne.rangée)')}${chk('coords', 'Coordonnées en pixels')}${chk('grid', 'Contour des dalles')}${chk('cross', 'Diagonales par dalle')}${chk('circle', 'Cercle & croix de calibrage')}${chk('title', isBoard(s) ? 'Nom des zones au début de chaque zone' : 'Nom de l\'écran & résolution au centre')}
   </div>${pixExportCard(s)}</div></div>`;
}
function pixExportCard(s) {
  const o = pixOut(s); const p = getProduct(s.productId) || {};
  const mw = isBoard(s) ? boardPixLayout(s).W : s.cols * num(p.pxW || 128), mh = isBoard(s) ? boardPixLayout(s).H : s.rows * num(p.pxH || 128);
  const modeBtn = (m, l, sub) => `<button class="kind-card ${o.mode === m ? 'on' : ''}" data-act="pmoMode" data-v="${m}" style="flex:1"><b>${l}</b><span>${sub}</span></button>`;
  const sizeSel = `<label class="f">Format de sortie<select data-pmo="size">${PIX_SIZES.map(([v, l]) => `<option value="${v}" ${o.size === v ? 'selected' : ''}>${l}</option>`).join('')}</select></label>
    ${o.size === 'custom' ? `<div class="row" style="gap:8px"><label class="f">Largeur<input type="number" data-pmo="w" value="${o.w}" style="width:110px"></label><label class="f">Hauteur<input type="number" data-pmo="h" value="${o.h}" style="width:110px"></label></div>` : ''}`;
  let extra = '';
  if (o.mode === 'fit') { const sc = Math.min(o.w / mw, o.h / mh); extra = sizeSel + `<div class="tiny muted" style="margin-top:6px">Pixel map ${mw} × ${mh} mis à l'échelle ×${fmt(sc, sc < 1 ? 3 : 2)} → ${Math.round(mw * sc)} × ${Math.round(mh * sc)} px, centré sur fond noir.${sc < 1 ? ' ⚠ Réduit : 1 pixel ≠ 1 LED (aperçu / présentation uniquement).' : ''}</div>`; }
  if (o.mode === 'place') {
    const ov = { r: o.x + mw - o.w, b: o.y + mh - o.h };
    extra = sizeSel + `<div class="row" style="gap:8px;margin-top:8px"><label class="f">Position X (px)<input type="number" data-pmo="x" value="${o.x}" style="width:110px"></label><label class="f">Position Y (px)<input type="number" data-pmo="y" value="${o.y}" style="width:110px"></label></div>
      <div class="row" style="gap:6px;margin-top:8px">${[['tl', '↖ Haut gauche'], ['tc', '↑ Haut centre'], ['c', '✛ Centré'], ['bl', '↙ Bas gauche']].map(([v, l]) => `<button class="sm" data-act="pmoPlace" data-v="${v}">${l}</button>`).join('')}</div>
      <div class="tiny muted" style="margin-top:8px">Pixel map en natif ${mw} × ${mh} (1 pixel = 1 LED) posé à X ${o.x} / Y ${o.y} dans une sortie ${o.w} × ${o.h}, le reste en noir.</div>
      ${ov.r > 0 || ov.b > 0 || o.x < 0 || o.y < 0 ? `<div class="alert warn" style="margin-top:8px">⚠ Le pixel map dépasse de la sortie${ov.r > 0 ? ` (${ov.r} px à droite)` : ''}${ov.b > 0 ? ` (${ov.b} px en bas)` : ''}${o.x < 0 || o.y < 0 ? ' (position négative)' : ''} : la partie hors cadre sera coupée. Choisissez une sortie plus grande ou plusieurs sorties.</div>` : ''}`;
  }
  return `<div class="card" style="margin-top:16px"><h3>Format d'export</h3>
    <div class="row" style="gap:8px;align-items:stretch">${modeBtn('native', 'Natif', `${mw} × ${mh} px`)}${modeBtn('fit', 'Ajusté', '1080p / 4K')}${modeBtn('place', 'Dans une sortie vidéo', 'Natif, positionné')}</div>
    <div style="margin-top:10px">${extra}</div>
    <button class="primary" data-act="exportPixmap" style="width:100%;justify-content:center;margin-top:14px">⇩ Exporter le pixel map — ${esc(pixOutLabel(s))}</button></div>`;
}
function tabExport(s, p) {
  const b = (act, label, sub) => `<button data-act="${act}" style="flex-direction:column;align-items:flex-start;padding:14px 16px;height:auto;white-space:normal;text-align:left"><b>${label}</b><span class="tiny muted">${sub}</span></button>`;
  return `<div class="grid g2"><div class="card"><h3>Images PNG — cet écran</h3><div class="grid g2">
    ${b('exElecFront', '⚡ Plan élec — face', 'Côté public, avec légende')}${b('exElecRear', '⚡ Plan élec — dos', 'Côté câblage (miroir)')}
    ${b('exDataFront', '⇄ Plan data — face', 'Côté public, avec légende')}${b('exDataRear', '⇄ Plan data — dos', 'Côté câblage (miroir)')}
    ${b('exportPixmap', '▦ Pixel map', esc(pixOutLabel(s)))}${b('exTop', '◠ Vue de dessus / côté', 'Cotes de courbure')}</div>
    <label class="row small" style="margin-top:14px;gap:8px"><input type="checkbox" data-ui-chk="printLight" ${ui.printLight ? 'checked' : ''}>Fond blanc (économie d'encre à l'impression)</label></div>
   <div class="card"><h3>Documents</h3><div class="grid">
    ${b('exportScreenPDF', '📄 Fiche PDF de cet écran', 'Dimensions, plans élec & data, pixel map')}
    ${b('exportProjectPDF', '📚 Dossier PDF complet du projet', `${p.screens.length} écran(s) + liste de matériel`)}
    ${b('exportMaterialCSV', '⇩ Liste de matériel (CSV / Excel)', 'Pour la préparation au dépôt')}</div>
    <div class="tiny muted" style="margin-top:12px">Les vues incluses dans les PDF se règlent dans Paramètres (face, dos ou les deux).</div></div></div>`;
}

/* ---------------- PARAMÈTRES ---------------- */
function vSettings() {
  const st = db().settings;
  const f = (k, l, type = 'text') => `<label class="f">${l}<input type="${type}" data-set="${k}" value="${esc(st[k])}"></label>`;
  return `<div class="page-head"><div><h1>Paramètres</h1><div class="sub">Version ${APP_VERSION} · format de données v${SCHEMA_VERSION}</div></div></div>
  <div class="grid g2"><div class="card"><h3>Valeurs par défaut (nouveaux écrans)</h3><div class="form" style="grid-template-columns:1fr 1fr">
    ${f('company', 'Nom de la société (exports)')}${f('voltage', 'Tension (V)', 'number')}${f('amps', 'Disjoncteur (A)', 'number')}${f('safety', 'Charge max (%)', 'number')}${f('pxPerPort', 'Pixels / port data', 'number')}
    <label class="f">Couleur pixel map 1<input type="color" data-set="pixColor1" value="${st.pixColor1}"></label><label class="f">Couleur pixel map 2<input type="color" data-set="pixColor2" value="${st.pixColor2}"></label>
    <label class="f">Vues dans les PDF<select data-set="pdfView"><option value="face" ${st.pdfView === 'face' ? 'selected' : ''}>Vue de face</option><option value="dos" ${st.pdfView === 'dos' ? 'selected' : ''}>Vue de dos</option><option value="both" ${st.pdfView !== 'face' && st.pdfView !== 'dos' ? 'selected' : ''}>Face + dos</option></select></label>
    <label class="f">Fond des PDF<select data-set="pdfLight"><option value="1" ${st.pdfLight !== false ? 'selected' : ''}>Blanc (impression)</option><option value="0" ${st.pdfLight === false ? 'selected' : ''}>Sombre</option></select></label></div>
    <label class="row small" style="margin-top:14px;gap:8px"><input type="checkbox" data-set-chk="reserveDevis" ${st.reserveDevis ? 'checked' : ''}>Les devis / options réservent le stock</label></div>
  ${updateCardHTML()}
  <div class="card"><h3>Données & sauvegardes</h3>
    <div class="small muted">Fichier de données</div><div style="word-break:break-all;margin:4px 0 14px"><code>${esc(Store.path)}</code></div>
    <div class="alert ok">Enregistrement automatique à chaque modification, sauvegarde horaire et à chaque démarrage (60 dernières + une par jour pendant 120 jours). Les mises à jour de l'application conservent et convertissent vos données automatiquement.</div>
    ${IS_DESKTOP && Store.onedrive && window.desktop.moveData ? `<div class="alert warn" style="margin:8px 0">Vos données sont dans <b>OneDrive</b>, qui bloque parfois le fichier (« Erreur de sauvegarde »). Le partage Google fait déjà la copie en ligne : mieux vaut les garder sur ce PC. <button class="sm primary" data-act="moveDataLocal" style="margin-left:6px">📁 Mettre mes données sur ce PC</button></div>` : ''}
    <div class="row">${IS_DESKTOP ? `<button data-act="chooseFolder">📁 Changer de dossier (serveur, clé…)</button><button data-act="openFolder">Ouvrir le dossier</button>` : ''}
      <button data-act="backupNow">💾 Sauvegarder maintenant</button><button data-act="exportBackup">⇩ Exporter (.json)</button><button data-act="importBackup">⇧ Importer (.json)</button></div>
    ${IS_DESKTOP ? `<hr class="sep"><h3>Restaurer une sauvegarde automatique</h3><div id="backupList" class="small muted">Chargement…</div>` : ''}
  </div></div>`;
}

/* =====================================================================
   APRÈS RENDU (canvas, 3D, pixel map, peinture)
   ===================================================================== */
function afterRender() {
  if (ui.view === 'scene') setupScene(curProject());
  if (ui.view === 'screen') {
    const s = curScreen();
    if (ui.tab === 'config') setup3D(s);
    if (ui.tab === 'pixmap' && isMapMode(s)) drawBoardMapPreviews(s);
    if (ui.tab === 'visuals' && isBoard(s)) visDrawPreview(s);
    if (ui.tab === 'pixmap') { const c = document.getElementById('pixCanvas'); if (c) { const r = composePixmap(c, s); c.style.width = Math.min(c.width, 1000) + 'px'; const i = document.getElementById('pixInfo'); if (i) i.textContent = `Aperçu réduit de l'image exportée : ${r.W} × ${r.H} px${r.o.mode === 'native' ? ' (1 pixel = 1 LED)' : r.o.mode === 'place' ? ` — pixel map natif ${r.mapW} × ${r.mapH} à X ${r.o.x} / Y ${r.o.y}` : ` — pixel map ${r.mapW} × ${r.mapH} ajusté`}.`; } }
    if (ui.tab === 'elec' || ui.tab === 'data') setupPaint(s, ui.tab);
  }
  if (ui.view === 'team' && ui.teamTab === 'messages') showWaDetect();
  if (ui.view === 'settings' && IS_DESKTOP) {
    window.desktop.listBackups().then((list) => {
      const el = document.getElementById('backupList'); if (!el) return;
      el.innerHTML = list.length ? `<div style="max-height:220px;overflow:auto">${list.slice(0, 40).map((n) => `<div class="row" style="justify-content:space-between;padding:4px 0;border-bottom:1px solid var(--line)"><span>${esc(n)}</span><button class="sm" data-act="restoreBackup" data-v="${esc(n)}">Restaurer</button></div>`).join('')}</div>` : 'Aucune sauvegarde pour le moment.';
    });
  }
}
function setup3D(s) {
  const c = document.getElementById('view3d'); if (!c) return;
  const redraw = () => draw3D(c, s, ui.v3d); redraw();
  let drag = null;
  c.onmousedown = (e) => { drag = { x: e.clientX, y: e.clientY, yaw: ui.v3d.yaw, pitch: ui.v3d.pitch }; };
  window.onmousemove = (e) => { if (!drag) return; ui.v3d.yaw = drag.yaw + (e.clientX - drag.x) / 160; ui.v3d.pitch = Math.max(-1.4, Math.min(1.4, drag.pitch + (e.clientY - drag.y) / 160)); redraw(); };
  window.onmouseup = () => { drag = null; };
  c.onwheel = (e) => { e.preventDefault(); ui.v3d.zoom = Math.max(0.3, Math.min(4, ui.v3d.zoom * (e.deltaY < 0 ? 1.1 : 0.9))); redraw(); };
  c.ondblclick = () => { ui.v3d = { yaw: 0, pitch: 0, zoom: 1 }; redraw(); };
}
function materialize(s, kind) {
  const cfg = s[kind];
  if (!Array.isArray(cfg.assign) || cfg.assign.length !== s.cols * s.rows) { cfg.assign = resolvePlan(s, kind).assign.slice(); cfg.orders = {}; }
}
function setupPaint(s, kind) {
  const area = document.getElementById('planArea'); if (!area) return;
  const refreshPlan = () => { area.innerHTML = planSVG(s, kind, { rear: ui.rear, sel: ui.sel[kind] }); };
  const apply = (idx) => {
    materialize(s, kind); const cfg = s[kind]; const sel = ui.sel[kind]; const old = cfg.assign[idx];
    if (ui.tool === 'start') { if (old < 0) return false; ui.sel[kind] = old; setLineStart(s, kind, old, idx); return true; }
    if (ui.tool === 'paint') {
      if (old === sel) return false;
      cfg.assign[idx] = sel; if (cfg.orders[old]) cfg.orders[old] = cfg.orders[old].filter((i) => i !== idx);
    } else {
      cfg.orders[sel] = cfg.orders[sel] || [];
      if (cfg.orders[sel].includes(idx)) return false;
      if (old !== sel && cfg.orders[old]) cfg.orders[old] = cfg.orders[old].filter((i) => i !== idx);
      cfg.assign[idx] = sel; cfg.orders[sel].push(idx);
    }
    return true;
  };
  const idxOf = (e) => { const t = e.target.closest('[data-idx]'); return t ? +t.dataset.idx : null; };
  area.onmousedown = (e) => { const i = idxOf(e); if (i == null) return; e.preventDefault(); ui.painting = true; if (apply(i)) refreshPlan(); };
  area.onmouseover = (e) => { if (!ui.painting || ui.tool !== 'paint') return; const i = idxOf(e); if (i != null && apply(i)) refreshPlan(); };
  window.onmouseup = () => { if (ui.painting) { ui.painting = false; Store.save(); render(); } };
}

/* =====================================================================
   ACTIONS
   ===================================================================== */
function setPlanField(s, kind, f, v) {
  const cfg = s[kind];
  cfg[f] = v; cfg.assign = null; cfg.orders = {}; ui.sel[kind] = 0;
}
const actions = {
  newProduct() { ui.edit = { _new: true, id: uid('prd'), category: ui.cat !== 'all' ? ui.cat : 'dalle', ref: '', name: '', brand: '', stock: 0, notes: '', widthMm: 500, heightMm: 500, depthMm: 80, pxW: 128, pxH: 128, powerMax: 150, powerAvg: 50, maxChain: 0, weightKg: 8, pitch: 3.9, ports: 4, pxPerPort: 655360 }; openModal(productForm(ui.edit)); },
  editProduct(el) { const p = getProduct(el.dataset.id); if (!p) return; ui.edit = deepClone(p); openModal(productForm(ui.edit)); },
  dupProduct(el, e) { e.stopPropagation(); const p = deepClone(getProduct(el.dataset.id)); p.id = uid('prd'); p.ref += '-COPIE'; db().products.push(p); Store.save(); render(); toast('Référence dupliquée'); },
  saveProduct() {
    const p = ui.edit; readForm('[data-pf]', p, 'pf');
    if (!p.ref || !p.name) return toast('Référence et désignation obligatoires', 'warn');
    ['stock', 'pitch', 'widthMm', 'heightMm', 'depthMm', 'pxW', 'pxH', 'weightKg', 'volumeM3', 'powerMax', 'powerAvg', 'maxChain', 'ports', 'pxPerPort'].forEach((k) => { if (p[k] !== undefined) p[k] = num(p[k]); });
    const isNew = p._new; delete p._new;
    if (isNew) db().products.push(p); else { const i = db().products.findIndex((x) => x.id === p.id); db().products[i] = p; }
    Store.save(); closeModal(); render(); toast(isNew ? 'Référence ajoutée au catalogue ✨' : 'Référence mise à jour');
  },
  deleteProduct() {
    const id = ui.edit.id; const used = db().projects.filter((p) => p.screens.some((s) => s.productId === id || s.data.processorId === id) || p.extras.some((x) => x.productId === id));
    if (used.length) return toast('Utilisée dans : ' + used.map((p) => p.name).join(', ') + ' — retirez-la d\'abord.', 'bad');
    if (!confirm('Supprimer cette référence ?')) return;
    db().products = db().products.filter((p) => p.id !== id); Store.save(); closeModal(); render();
  },
  closeModal,
  setCat(el) { ui.cat = el.dataset.v; render(); },
  newProject() { ui.edit = { _new: true, id: uid('prj'), name: '', client: '', venue: '', start: todayISO(), end: addDays(todayISO(), 3), status: 'confirme', color: PROJECT_COLORS[db().projects.length % PROJECT_COLORS.length], notes: '', screens: [], extras: [], crew: [], fleet: [], crewNeeded: 0 }; openModal(projectForm(ui.edit)); },
  editProjectInfo() { ui.edit = deepClone(curProject()); openModal(projectForm(ui.edit)); },
  saveProject() {
    const p = ui.edit; readForm('[data-jf]', p, 'jf'); p.sale = !!(document.getElementById('pjSale') || {}).checked || p.cat === 'vente'; if (p.sale && !p.cat) p.cat = 'vente'; if (!p.name) return toast('Donnez un nom au projet', 'warn');
    if (p.end && p.start && p.end < p.start) return toast('La date de retour est avant la date de sortie', 'warn');
    const isNew = p._new; delete p._new;
    if (isNew) db().projects.push(p); else { const i = db().projects.findIndex((x) => x.id === p.id); db().projects[i] = p; }
    Store.save(); closeModal(); go('project', { projectId: p.id }); if (isNew) { confetti(); toast('Projet créé — que le show commence ! 🎉'); }
  },
  openProject(el) { go('project', { projectId: el.dataset.id }); },
  projFilter(el) { ui.projFilter = el.dataset.v; render(); },
  dupProject() {
    const p = deepClone(curProject()); p.id = uid('prj'); p.name += ' (copie)'; p.screens.forEach((s) => { s.id = uid('scr'); }); p.crew = []; p.fleet = [];
    db().projects.push(p); Store.save(); go('project', { projectId: p.id }); toast('Projet dupliqué');
  },
  delProject() { if (!confirm('Supprimer définitivement ce projet ? (une sauvegarde automatique reste disponible)')) return; (curProject().crew || []).forEach(calTrashReq); if (curProject().cal && !calPast(projectCalDays(curProject()))) Store.db.calTrash = (Store.db.calTrash || []).concat(curProject().cal.ids || []); db().projects = db().projects.filter((p) => p.id !== ui.projectId); Store.save(); go('projects'); },
  addScreen() {
    const p = curProject(); const prod = projectDalles(p)[0];
    if (!prod) { ui.cpTarget = 'addScreen'; return customActions.cpNew({ dataset: { target: 'addScreen' } }); }
    const s = newScreen(db(), prod && prod.id); s.name = 'Écran ' + (p.screens.length + 1); fitAngles(s);
    p.screens.push(s); Store.save(); go('screen', { screenId: s.id, tab: 'config' }); toast('Nouvel écran — réglez la taille et la courbure');
  },
  openScreen(el) { go('screen', { screenId: el.dataset.id, tab: 'config', sel: { elec: 0, data: 0 } }); },
  dupScreen(el, e) { e.stopPropagation(); const p = curProject(); const s = deepClone(p.screens.find((x) => x.id === el.dataset.id)); s.id = uid('scr'); s.name += ' (copie)'; if (s.place) s.place.x = num(s.place.x) + screenGeometry(s).width + 1000; if (s.zones) s.zones.forEach((z) => { z.id = uid('zon'); delete z.place; }); p.screens.push(s); Store.save(); render(); },
  delScreen(el, e) { e.stopPropagation(); if (!confirm('Supprimer cet écran ?')) return; const p = curProject(); p.screens = p.screens.filter((x) => x.id !== el.dataset.id); Store.save(); render(); },
  addExtra() {
    const pid = document.getElementById('extraProd').value; const q = num(document.getElementById('extraQty').value, 1); if (!pid) return;
    const p = curProject(); const ex = p.extras.find((x) => x.productId === pid); if (ex) ex.qty += q; else p.extras.push({ productId: pid, qty: q });
    Store.save(); render();
  },
  delExtra(el) { const p = curProject(); p.extras = p.extras.filter((x) => x.productId !== el.dataset.id); Store.save(); render(); },
  tab(el) { ui.tab = el.dataset.v; render(); },
  cornerPreset(el) {
    const s = curScreen(); const n = +el.dataset.v; const ax = el.dataset.axis; const len = ax === 'h' ? s.cols : s.rows; const arr = ax === 'h' ? s.hAngles : s.vAngles;
    if (len % n) return toast(`Pour ${n} faces égales, il faut un nombre de ${ax === 'h' ? 'colonnes' : 'rangées'} multiple de ${n} (actuellement ${len})`, 'warn');
    const a = (document.getElementById('cornerIn') || {}).checked ? 90 : -90; const f = len / n; arr.fill(0); for (let k = 1; k < n; k++) arr[k * f - 1] = a;
    Store.save(); render(); toast(n === 4 ? `Cube : 4 faces de ${f} dalles, coins à ${a > 0 ? '+' : ''}${a}°` : `${n} faces de ${f} dalles, coins à ${a > 0 ? '+' : ''}${a}°`);
  },
  allAngles(el) { const s = curScreen(); const arr = el.dataset.axis === 'h' ? s.hAngles : s.vAngles; arr.fill(num(el.dataset.v)); Store.save(); render(); },
  planSet(el) { setPlanField(curScreen(), el.dataset.kind, el.dataset.f, el.dataset.v); Store.save(); render(); },
  tool(el) { ui.tool = el.dataset.v; render(); },
  rear(el) { ui.rear = el.dataset.v === '1'; render(); },
  zoom() { ui.zoom = !ui.zoom; render(); },
  autoPlan(el) {
    const s = curScreen(); const k = el.dataset.kind;
    if (Array.isArray(s[k].assign) && !confirm('Remplacer vos modifications manuelles par la répartition automatique ?')) return;
    s[k].assign = null; s[k].orders = {}; ui.sel[k] = 0; Store.save(); render(); toast('Répartition recalculée ⚡');
  },
  selLine(el) { ui.sel[el.dataset.kind] = +el.dataset.v; render(); },
  newLine(el) { const s = curScreen(); const k = el.dataset.kind; const plan = resolvePlan(s, k); ui.sel[k] = plan.lines.length; render(); toast('Nouvelle ligne sélectionnée — peignez ses dalles'); },
  clearTrace(el) { const s = curScreen(); const k = el.dataset.kind; materialize(s, k); s[k].orders[ui.sel[k]] = []; Store.save(); render(); },
  renumber(el) {
    const s = curScreen(); const k = el.dataset.kind; materialize(s, k); const cfg = s[k];
    const used = [...new Set(cfg.assign.filter((a) => a >= 0))].sort((a, b) => a - b); const map = new Map(used.map((a, i) => [a, i]));
    cfg.assign = cfg.assign.map((a) => (a >= 0 ? map.get(a) : a)); const no = {}; Object.entries(cfg.orders).forEach(([l, o]) => { if (map.has(+l)) no[map.get(+l)] = o; }); cfg.orders = no;
    ui.sel[k] = 0; Store.save(); render();
  },
  palette(el) { const pm = curScreen().pixmap; if (el.dataset.v === 'swap') [pm.c1, pm.c2] = [pm.c2, pm.c1]; else { const pl = PALETTES[+el.dataset.v]; pm.c1 = pl[1]; pm.c2 = pl[2]; } Store.save(); render(); },
  planShift(el) { ui.planStart = addDays(ui.planStart, num(el.dataset.v)); render(); },
  planToday() { ui.planStart = addDays(todayISO(), -3); render(); },
  // ---- exports ----
  exElecFront() { exportPlanPNG('elec', false); }, exElecRear() { exportPlanPNG('elec', true); },
  exDataFront() { exportPlanPNG('data', false); }, exDataRear() { exportPlanPNG('data', true); },
  async exTop() {
    const s = curScreen(); const svg = profileSVG(s, 'h', { width: 1400, light: ui.printLight });
    await saveFileBase64(`${safeName(s.name)}_vue-dessus.png`, dataURLtoB64(await svgToPNG(svg, 2)), 'png', 'Image PNG');
    if (s.vAngles.some((a) => num(a))) await saveFileBase64(`${safeName(s.name)}_vue-cote.png`, dataURLtoB64(await svgToPNG(profileSVG(s, 'v', { height: 900, light: ui.printLight }), 2)), 'png', 'Image PNG');
  },
  async exportPixmap() {
    const s = curScreen(); const c = document.createElement('canvas'); const r = composePixmap(c, s);
    if (r.over) toast('⚠ Le pixel map dépasse de la sortie : la partie hors cadre est coupée', 'warn');
    await saveFileBase64(pixFileName(s, r), dataURLtoB64(c.toDataURL('image/png')), 'png', 'Image PNG');
  },
  pmoMode(el) { const s = curScreen(); s.pixmap.out = Object.assign(pixOut(s), { mode: el.dataset.v }); Store.save(); render(); },
  pmoPlace(el) {
    const s = curScreen(); const o = pixOut(s); const t = document.createElement('canvas'); const { W, H } = drawPixmap(t, s); const v = el.dataset.v;
    o.x = v === 'c' || v === 'tc' ? Math.round((o.w - W) / 2) : 0; o.y = v === 'c' ? Math.round((o.h - H) / 2) : v === 'bl' ? o.h - H : 0;
    o.x = Math.max(0, o.x); o.y = Math.max(0, o.y); s.pixmap.out = o; Store.save(); render();
  },
  exportScreenPDF() { exportPDF(curProject(), [curScreen()]); },
  exportProjectPDF() { exportPDF(curProject(), curProject().screens); },
  exportMaterialCSV() {
    const p = curProject(); const lines = [['Référence', 'Désignation', 'Catégorie', 'Quantité', 'Surface (m²)', 'Dont écrans', 'Dont ajouts', 'Stock total'].join(';')];
    projectUsage(p).forEach((u, pid) => { const x = getProduct(pid); if (x) lines.push([x.ref, x.name, CATEGORIES[x.category], u.qty, panelM2(x) ? fmt(m2(x, u.qty), 2) : '', u.auto, u.manual, x.stock].map(csvCell).join(';')); });
    p.screens.forEach((s) => { const c = cableEstimate(s); lines.push(['', `Câblage ${s.name}`, 'Info', '', '', `${c.powerIn} arrivées 16A / ${c.powerJumpers} power link`, `${c.dataIn} ports / ${c.dataJumpers} cordons data`, ''].map(csvCell).join(';')); });
    saveFileText(`${safeName(p.name)}_materiel.csv`, '﻿' + lines.join('\r\n'), 'csv', 'CSV');
  },
  exportCatalogCSV() {
    const cols = ['category', 'ref', 'name', 'brand', 'stock', 'pitch', 'widthMm', 'heightMm', 'depthMm', 'pxW', 'pxH', 'weightKg', 'volumeM3', 'volumeM3', 'powerMax', 'powerAvg', 'maxChain', 'ports', 'pxPerPort', 'notes'];
    const lines = [cols.join(';'), ...db().products.map((p) => cols.map((k) => csvCell(p[k] == null ? '' : p[k])).join(';'))];
    saveFileText('catalogue_impulsion.csv', '﻿' + lines.join('\r\n'), 'csv', 'CSV');
  },
  async importCatalogCSV() {
    const txt = await openTextFile('csv'); if (!txt) return;
    const rows = txt.replace(/^﻿/, '').split(/\r?\n/).filter((l) => l.trim()); const sep = rows[0].includes(';') ? ';' : ',';
    const head = parseCSVLine(rows[0], sep); let added = 0, updated = 0;
    rows.slice(1).forEach((l) => {
      const v = parseCSVLine(l, sep); const o = {}; head.forEach((h, i) => { o[h.trim()] = v[i]; }); if (!o.ref) return;
      ['stock', 'pitch', 'widthMm', 'heightMm', 'depthMm', 'pxW', 'pxH', 'weightKg', 'volumeM3', 'powerMax', 'powerAvg', 'maxChain', 'ports', 'pxPerPort'].forEach((k) => { if (o[k] !== undefined && o[k] !== '') o[k] = num(o[k]); else delete o[k]; });
      if (!CATEGORIES[o.category]) o.category = 'autre';
      const ex = db().products.find((p) => p.ref === o.ref); if (ex) { Object.assign(ex, o); updated++; } else { o.id = uid('prd'); o.name = o.name || o.ref; db().products.push(o); added++; }
    });
    Store.save(); render(); toast(`Import : ${added} ajoutée(s), ${updated} mise(s) à jour`);
  },
  // ---- données ----
  async chooseFolder() { const r = await window.desktop.chooseFolder(); if (!r) return; if (r.raw) Store.replace(JSON.parse(r.raw)); const info = await window.desktop.load(); Store.path = info.path; document.getElementById('dataPath').textContent = Store.path; render(); toast('Dossier de données changé ✔'); },
  openFolder() { window.desktop.openFolder('data'); },
  async backupNow() { await Store.saveNow(); if (IS_DESKTOP) { await window.desktop.backup('manuelle'); render(); } else actions.exportBackup(); toast('Sauvegarde créée 💾'); },
  exportBackup() { saveFileText(`impulsion-led-sauvegarde_${todayISO()}.json`, Store.serialize(), 'json', 'Sauvegarde JSON'); },
  async importBackup() {
    const txt = await openTextFile('json'); if (!txt) return; let d; try { d = JSON.parse(txt); } catch (e) { return toast('Fichier invalide', 'bad'); }
    if (!d.products || !d.projects) return toast('Ce fichier n\'est pas une sauvegarde Impulsion Prod', 'bad');
    if (!confirm(`Remplacer les données actuelles par cette sauvegarde ? (${d.products.length} références, ${d.projects.length} projets)`)) return;
    if (IS_DESKTOP) await window.desktop.backup('avant-import'); Store.replace(d); render(); toast('Sauvegarde importée ✔');
  },
  async restoreBackup(el) {
    if (!confirm('Restaurer ' + el.dataset.v + ' ? Les données actuelles seront sauvegardées avant.')) return;
    const txt = await window.desktop.readBackup(el.dataset.v); await window.desktop.backup('avant-restauration'); Store.replace(JSON.parse(txt)); render(); toast('Sauvegarde restaurée ✔');
  }
};
const csvCell = (v) => { const s = String(v == null ? '' : v); return /[;"\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; };
function parseCSVLine(l, sep) { const out = []; let cur = '', q = false; for (let i = 0; i < l.length; i++) { const c = l[i]; if (q) { if (c === '"' && l[i + 1] === '"') { cur += '"'; i++; } else if (c === '"') q = false; else cur += c; } else if (c === '"') q = true; else if (c === sep) { out.push(cur); cur = ''; } else cur += c; } out.push(cur); return out; }
function readForm(sel, obj, key) { document.querySelectorAll(sel).forEach((el) => { obj[el.dataset[key]] = el.value; }); }

async function exportPlanPNG(kind, rear) {
  const s = curScreen(); const svg = planSVG(s, kind, { rear, export: true, project: curProject(), light: ui.printLight });
  const png = await svgToPNG(svg, 2);
  await saveFileBase64(`${safeName(s.name)}_plan-${kind === 'elec' ? 'electrique' : 'data'}_${rear ? 'dos' : 'face'}.png`, dataURLtoB64(png), 'png', 'Image PNG');
}

/* ---------------- Rapport PDF ---------------- */
function exportPDF(p, screens) {
  const st = db().settings; const light = st.pdfLight !== false; const views = st.pdfView === 'face' ? [false] : st.pdfView === 'dos' ? [true] : [false, true];
  const usage = projectUsage(p);
  const css = `@page{size:A4 landscape;margin:10mm}body{font-family:Segoe UI,Arial,sans-serif;color:#0d1a20;margin:0;font-size:11px}
   .page{page-break-after:always;padding:4mm 2mm;position:relative;min-height:180mm}.page:last-child{page-break-after:auto}
   .hdr{display:flex;justify-content:space-between;align-items:center;border-bottom:2px solid #0b5c78;padding-bottom:6px;margin-bottom:10px}.hdr img{height:34px}
   h1{font-size:26px;margin:0 0 4px}h2{font-size:16px;margin:0 0 8px;color:#0b5c78}table{border-collapse:collapse;width:100%;margin-top:6px}
   th,td{border:1px solid #c7d3d9;padding:4px 7px;text-align:left}th{background:#e8f1f4;font-size:10px;text-transform:uppercase}td.n{text-align:right}
   .plan{text-align:center}.plan svg,.plan img{max-width:100%;max-height:118mm;height:auto}.two{display:flex;gap:12px}.two>div{flex:1}.muted{color:#5b6b73}
   .cover{display:flex;flex-direction:column;justify-content:center;min-height:170mm}.cover img{width:320px;margin-bottom:30px}.sw{display:inline-block;width:10px;height:10px;border-radius:2px;margin-right:5px;vertical-align:middle}
   .foot{position:absolute;bottom:0;right:2mm;font-size:9px;color:#7a8b94}`;
  const hdr = (t) => `<div class="hdr"><div><b style="font-size:15px">${esc(p.name)}</b> <span class="muted">— ${esc(t)}</span></div><img src="${LOGO_DATA}"></div>`;
  let html = `<!doctype html><html><head><meta charset="utf-8"><title>${esc(p.name)}</title><style>${css}</style></head><body>`;
  html += `<div class="page"><div class="cover"><img src="${LOGO_DATA}"><h1>${esc(p.name)}</h1><div style="font-size:15px">${esc(p.client || '')}${p.venue ? ' · ' + esc(p.venue) : ''}</div>
    <div style="font-size:14px;margin-top:8px">Surface LED totale : <b>${fmt(screens.reduce((a, x) => a + screenM2(x), 0), 2)} m²</b></div>
    <div style="font-size:14px;margin-top:8px">Sortie : <b>${fmtDate(p.start)}</b> · Retour : <b>${fmtDate(p.end)}</b> · ${STATUSES[p.status]}</div>
    <div class="muted" style="margin-top:20px">Dossier d'installation · ${screens.length} écran(s) · édité le ${new Date().toLocaleString('fr-FR')} · ${esc(st.company)}</div>
    ${p.notes ? `<div style="margin-top:16px;white-space:pre-wrap;border-left:3px solid #0b5c78;padding-left:10px">${esc(p.notes)}</div>` : ''}</div></div>`;
  html += `<div class="page">${hdr('Récapitulatif')}<h2>Écrans</h2><table><tr><th>Écran</th><th>Dalle</th><th>Dalles</th><th>L × H × P (m)</th><th>Rayon H</th><th>Angle H</th><th>Surface</th><th>Résolution</th><th>Puissance max</th><th>Lignes élec</th><th>Ports data</th><th>Poids</th></tr>
    ${screens.map((s) => { const g = screenGeometry(s); const ce = cableEstimate(s); return `<tr><td><b>${esc(s.name)}</b></td><td>${esc((getProduct(s.productId) || {}).name || '')}</td><td>${s.cols}×${s.rows} = ${g.panels}</td><td>${fmt(g.width / 1000, 2)} × ${fmt(g.height / 1000, 2)} × ${fmt(g.depth / 1000, 2)}</td><td>${isFinite(g.H.R) ? fmt(g.H.R / 1000, 2) + ' m' : 'plat'}</td><td>${fmt(g.H.total)}°</td><td><b>${fmt(g.surface, 2)} m²</b></td><td>${g.resW}×${g.resH}</td><td>${fmt(g.pMax / 1000, 2)} kW</td><td>${ce.powerIn}</td><td>${ce.dataIn}</td><td>${fmt(g.weight)} kg</td></tr>`; }).join('')}</table>
    <h2 style="margin-top:16px">Liste de matériel</h2><table><tr><th>Référence</th><th>Désignation</th><th>Catégorie</th><th class="n">Quantité</th><th class="n">Surface</th><th>Préparé ✓</th></tr>
    ${[...usage.entries()].map(([pid, u]) => { const x = getProduct(pid); return x ? `<tr><td>${esc(x.ref)}</td><td>${esc(x.name)}</td><td>${CATEGORIES[x.category]}</td><td class="n"><b>${u.qty}</b></td><td class="n">${m2txt(x, u.qty)}</td><td></td></tr>` : ''; }).join('')}</table></div>`;
  html += scenePdfPage(p, hdr);
  html += crewPdfPage(p, hdr);
  screens.forEach((s) => {
    const g = screenGeometry(s); const pe = resolvePlan(s, 'elec'), pd = resolvePlan(s, 'data'); const es = elecSummary(s, pe), ds = dataSummary(s, pd);
    html += `<div class="page">${hdr(s.name + ' — fiche technique')}<div class="two"><div><h2>Dimensions</h2><table>
      ${[['Dalles', `${s.cols} × ${s.rows} = ${g.panels}`], ['Largeur', fmt(g.width / 1000, 3) + ' m'], ['Hauteur', fmt(g.height / 1000, 3) + ' m'], ['Profondeur', fmt(g.depth / 1000, 3) + ' m'],
        ['Rayon horizontal', isFinite(g.H.R) ? fmt(g.H.R / 1000, 3) + ' m' : 'plat'], ['Diamètre horizontal', isFinite(g.H.R) ? fmt(2 * g.H.R / 1000, 3) + ' m' : '—'], ['Angles H (somme / arc)', fmt(g.H.total) + '° / ' + fmt(g.H.arc, 1) + '°'], ['Longueur développée', fmt(g.H.developed / 1000, 3) + ' m'], ['Flèche H', fmt(g.H.sag / 1000, 3) + ' m'],
        ['Rayon vertical', isFinite(g.V.R) ? fmt(g.V.R / 1000, 3) + ' m' : 'plat'], ['Angle total V', fmt(g.V.total) + '°'], ['Résolution', `${g.resW} × ${g.resH} px`], ['Surface', fmt(g.surface, 2) + ' m²'], ['Poids', fmt(g.weight, 1) + ' kg'], ['Puissance max / moy.', `${fmt(g.pMax / 1000, 2)} / ${fmt(g.pAvg / 1000, 2)} kW`]]
        .filter(([a]) => !isBoard(s) || !/Rayon|Diamètre|Angle|Flèche|développée/.test(a)).map(([a, b]) => `<tr><th style="width:45%">${isBoard(s) && a === 'Largeur' ? 'Linéaire total' : a}</th><td>${b}</td></tr>`).join('')}</table>
      ${s.cols > 1 && !isBoard(s) ? `<div class="muted" style="margin-top:6px">Angles H (jonctions 1→${s.cols}) : ${s.hAngles.map((a) => (a > 0 ? '+' : '') + a + '°').join(' · ')}</div>` : ''}
      ${s.vAngles.some((a) => num(a)) ? `<div class="muted">Angles V : ${s.vAngles.map((a) => (a > 0 ? '+' : '') + a + '°').join(' · ')}</div>` : ''}</div>
      <div class="plan">${isBoard(s) ? boardZonesTable(s) : isArch(s) ? archSVG(s, { light, maxH: 380 }) : profileSVG(s, 'h', { width: 640, light }) + (s.vAngles.some((a) => num(a)) ? profileSVG(s, 'v', { height: 300, light }) : '')}</div></div></div>`;
    views.forEach((rear) => {
      html += `<div class="page">${hdr(s.name + ' — plan électrique' + (rear ? ' (vue de dos)' : ' (vue de face)'))}<div class="plan">${planSVG(s, 'elec', { rear, light })}</div>
      <table><tr><th>Ligne</th><th>Phase</th><th class="n">Dalles</th><th class="n">Puissance</th><th class="n">Intensité</th><th class="n">Charge</th><th>Ordre (colonne·rangée)</th></tr>
      ${es.rows.map((r) => `<tr><td><span class="sw" style="background:${lineColor(r.line.index)}"></span><b>${r.name}</b></td><td>${r.phase}</td><td class="n">${r.n}</td><td class="n">${fmt(r.W)} W</td><td class="n">${fmt(r.A, 1)} A</td><td class="n">${fmt(r.pct)} %</td><td>${r.line.panels.map((i) => `${panelLabel(s, i)}`).join(' → ')}</td></tr>`).join('')}</table>
      <div class="muted" style="margin-top:4px">Total ${fmt(es.totalW / 1000, 2)} kW · ${es.phaseA.map((a, i) => `L${i + 1} : ${fmt(a, 1)} A`).join(' · ')} · Arrivée conseillée : ${es.phases === 3 ? 'tri' : 'mono'} ${es.feed} A · Disjoncteurs ${s.elec.amps} A, charge max ${s.elec.safety} %</div></div>`;
    });
    views.forEach((rear) => {
      html += `<div class="page">${hdr(s.name + ' — plan data' + (rear ? ' (vue de dos)' : ' (vue de face)'))}<div class="plan">${planSVG(s, 'data', { rear, light })}</div>
      <table><tr><th>Port</th><th class="n">Dalles</th><th class="n">Pixels</th><th class="n">Charge</th><th>Ordre (colonne·rangée)</th></tr>
      ${ds.rows.map((r) => `<tr><td><span class="sw" style="background:${lineColor(r.line.index)}"></span><b>${r.name}</b></td><td class="n">${r.n}</td><td class="n">${fmt(r.px)}</td><td class="n">${fmt(r.pct)} %</td><td>${r.line.panels.map((i) => `${panelLabel(s, i)}`).join(' → ')}</td></tr>`).join('')}</table>
      <div class="muted" style="margin-top:4px">${ds.ports} port(s)${ds.proc ? ` · ${esc(ds.proc.name)} × ${ds.procs}` : ''} · ${fmt(pd.cap.pxPort)} px/port</div></div>`;
    });
    const c = document.createElement('canvas'); const { W, H } = drawPixmap(c, s);
    html += `<div class="page">${hdr(s.name + ' — pixel map')}<div class="plan"><img src="${c.toDataURL('image/png')}" style="image-rendering:pixelated;border:1px solid #c7d3d9;max-height:150mm"></div><div class="muted" style="text-align:center;margin-top:6px">${W} × ${H} px · dalle ${(getProduct(s.productId) || {}).pxW}×${(getProduct(s.productId) || {}).pxH} px</div></div>`;
  });
  html += `</body></html>`;
  const name = `${safeName(p.name)}${screens.length === 1 ? '_' + safeName(screens[0].name) : ''}_dossier.pdf`;
  if (NATIVE_FILES) { toast('Génération du PDF…'); window.desktop.makePdf({ html, defaultName: name }).then((r) => r && toast('PDF prêt ✔')); }
  else { const w = window.open('', '_blank', 'width=1200,height=850'); if (!w) return toast('Autorisez les fenêtres pop-up pour exporter', 'warn'); w.document.write(html); w.document.close(); toast('Choisissez « Enregistrer au format PDF » dans la fenêtre d\'impression'); setTimeout(() => w.print(), 700); }
  return html;
}

/* =====================================================================
   ÉVÉNEMENTS GLOBAUX
   ===================================================================== */Object.assign(actions, teamActions, replyActions, sceneActions, boardActions, boardMapActions, visualsActions, decoActions, linkActions, archActions, venueActions, prodFileActions, customActions, espaceActions, journalRecoverActions, updateActions, { async moveDataLocal() { try { const r = await window.desktop.moveData(Store.serialize()); Store.path = r.path; Store.onedrive = false; document.getElementById('dataPath').textContent = r.path; closeModal(); await Store.saveNow(); render(); toast('Données déplacées sur ce PC ✔ ' + r.dir); } catch (e) { toast('Déplacement impossible : ' + e.message, 'bad'); } } }, roadmapActions, calActions, pagesActions, accountActions, syncActions);

function bindEvents() {
  document.addEventListener('click', (e) => {
    const nav = e.target.closest('[data-nav]'); if (nav) return go(nav.dataset.nav);
    const ng = e.target.closest('[data-nav-go]'); if (ng) return go(ng.dataset.navGo);
    const a = e.target.closest('[data-act]'); const formEl = ['SELECT', 'INPUT', 'TEXTAREA', 'OPTION'].includes(e.target.tagName) && a !== e.target;
    if (a && actions[a.dataset.act] && !formEl) { actions[a.dataset.act](a, e); }
    if (e.target.id === 'modal') closeModal();
  });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeModal(); });
  document.addEventListener('input', (e) => {
    const t = e.target;
    if (t.dataset.pf && ui.edit && document.getElementById('m2info')) { const tmp = Object.assign({}, ui.edit); readForm('[data-pf]', tmp, 'pf'); document.getElementById('m2info').innerHTML = m2Info(tmp); }
    if (t.dataset.ui === 'teamSearch') { ui.teamSearch = t.value; const pos = t.selectionStart; render(); const n = document.querySelector('[data-ui=teamSearch]'); n.focus(); n.setSelectionRange(pos, pos); return; }
    if (t.dataset.ui === 'search') { ui.search = t.value; const pos = t.selectionStart; render(); const n = document.querySelector('[data-ui=search]'); n.focus(); n.setSelectionRange(pos, pos); }
  });
  document.addEventListener('change', (e) => {
    const t = e.target; const s = curScreen();
    if (teamChange(t)) return;
    if (sceneChange(t)) return;
    if (decoChange(t)) return;
    if (archChange(t)) return;
    if (venueChange(t)) return;
    if (customChange(t)) return;
    if (updChange(t)) return;
    if (boardMapChange(t)) return;
    if (visualsChange(t)) return;
    if (boardChange(t)) return;
    if (roadmapChange(t)) return;
    if (t.dataset.pf === 'category' && ui.edit) { readForm('[data-pf]', ui.edit, 'pf'); openModal(productForm(ui.edit)); return; }
    if (t.dataset.ui === 'stockFrom' || t.dataset.ui === 'stockTo') { ui[t.dataset.ui] = t.value; if (ui.stockTo < ui.stockFrom) ui.stockTo = ui.stockFrom; return render(); }
    if (t.dataset.uiChk) { ui[t.dataset.uiChk] = t.checked; return; }
    if (t.dataset.uiSel) { ui[t.dataset.uiSel] = t.value; return render(); }
    if (t.dataset.sf && s) {
      const k = t.dataset.sf; let v = t.value;
      if (k === 'productId' && v === '__custom') { t.value = s.productId; return customActions.cpNew({ dataset: { target: 'screen' } }); }
      if ((k === 'cols' || k === 'rows') && isArch(s)) { s.rows = Math.max(1, parseInt(v, 10) || 1); archFit(s); Store.save(); return render(); }
      if (k === 'cols' || k === 'rows') { v = Math.max(1, Math.min(200, parseInt(v, 10) || 1)); s[k] = v; fitAngles(s); ['elec', 'data'].forEach((kk) => { s[kk].assign = null; s[kk].orders = {}; }); }
      else { s[k] = v; if (k === 'productId') { ['elec', 'data'].forEach((kk) => { s[kk].assign = null; s[kk].orders = {}; }); if (isArch(s)) archFit(s); } }
      Store.save(); return render();
    }
    if (t.dataset.angle && s) { let v = t.value; if (v === '__other') { const r = prompt('Angle à cette jonction (en degrés, de -180 à +180) :', '90'); if (r == null) return render(); v = Math.max(-180, Math.min(180, num(String(r).replace(',', '.')))); } (t.dataset.angle === 'h' ? s.hAngles : s.vAngles)[+t.dataset.j] = num(v); Store.save(); return render(); }
    if (t.dataset.linestart && s) { setLineStart(s, t.dataset.kind, +t.dataset.linestart, +t.value); ui.sel[t.dataset.kind] = +t.dataset.linestart; Store.save(); return render(); }
    if (t.dataset.pc && s) { const k = t.dataset.pc; const v = t.type === 'checkbox' ? t.checked : ['strategy', 'basis', 'processorId'].includes(k) ? t.value : num(t.value); setPlanField(s, t.dataset.kind, k, v); Store.save(); return render(); }
    if (t.dataset.pmo && s) { const o = pixOut(s); const k = t.dataset.pmo; o[k] = k === 'size' ? t.value : num(t.value); if (k === 'size' && t.value === 'custom') { o.w = pixOut(s).w; o.h = pixOut(s).h; } s.pixmap.out = o; Store.save(); return render(); }
    if (t.dataset.pm && s) { s.pixmap[t.dataset.pm] = t.type === 'checkbox' ? t.checked : t.value; Store.save(); return render(); }
    if (t.dataset.extra) { const ex = curProject().extras.find((x) => x.productId === t.dataset.extra); if (ex) ex.qty = Math.max(0, num(t.value)); Store.save(); return render(); }
    if (t.dataset.set) { const k = t.dataset.set; const st = db().settings; st[k] = t.type === 'number' ? num(t.value) : (k === 'pdfLight' || k === 'waPaste') ? t.value === '1' : t.value; Store.save(); if (ui.view === 'team') { const y = $main().scrollTop; render(); $main().scrollTop = y; } return; }
    if (t.dataset.setChk) { db().settings[t.dataset.setChk] = t.checked; Store.save(); return render(); }
  });
}

/* =====================================================================
   DÉMARRAGE
   ===================================================================== */
(async function start() {
  const dots = document.querySelector('.splash-dots'); dots.innerHTML = Array.from({ length: 16 }, (_, i) => `<i style="animation-delay:${i * 0.07}s"></i>`).join('');
  try { await Store.init(); } catch (e) {
    const sp = document.getElementById('splash');
    if (sp) sp.innerHTML = `<div style="max-width:520px;margin:18vh auto;padding:0 20px;text-align:center;line-height:1.6"><div style="font-size:40px">⚠️</div><h2>Données momentanément illisibles</h2><div class="small">${esc(e.message)}</div><button class="primary" style="margin-top:16px" onclick="location.reload()">↻ Réessayer</button></div>`;
    return;
  }
  document.getElementById('dataPath').textContent = IS_DESKTOP ? Store.path : 'Mode aperçu navigateur';
  if (IS_WEB) { await new Promise((r) => setTimeout(r, 0)); if (!(await webBoot())) return; } // version téléphone : connexion par code
  upgradeTemplatesForLink(); ensureReplyKey();
  localInfo(); if (localInfo().remember === false) localInfo().userId = null; if (localInfo().userId && !curUser()) localInfo().userId = null;
  journalResync();
  { const v = document.getElementById('appVer'); if (v) v.textContent = 'Version ' + APP_VERSION; }
  bindEvents(); ledStrip(); render(); userChip(); startReplySync(); startSync();
  if (needLogin()) showLogin();
  setInterval(userChip, 30000);
  setTimeout(() => document.getElementById('splash').classList.add('out'), 900);
})();
