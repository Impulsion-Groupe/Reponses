/* =====================================================================
   BOARDING — MAPPING DE SORTIE (fichier pour les créas / serveur média)
   Les zones sont posées dans une ou plusieurs sorties 1920×1080 / 3840×2160 :
   chacune « nouvelle ligne », « à la suite si elle rentre » ou « à la suite (coupée au bord) »,
   éventuellement repliée sur une largeur donnée. Rendu en blocs couleur (créa) ou damier technique.
   s.pixmap.map = { size, w, h, style, snap, labels, items: [{ zid, on, place, fold, color }] }
   ===================================================================== */
const MAP_COLORS = ['#2600e6', '#0b8a00', '#f7f01f', '#7a58e6', '#e655b8', '#f5843c', '#7a35c2', '#e8790e', '#33d15c', '#ff2200', '#1eaed6', '#cdb92f', '#00ffff', '#ee2222', '#ffffff', '#cc8f44'];
const MAP_PLACES = [['auto', 'À la suite si elle rentre'], ['next', 'À la suite (coupée au bord)'], ['new', 'Nouvelle ligne'], ['free', 'Position libre (X / Y)']];
const MAP_FONT = '"Rockwell Extra Bold", Rockwell, "Arial Black", Arial, sans-serif';
const isMapMode = (s) => isBoard(s) && (s.pixmap.board || 'map') === 'map';

function boardMapCfg(s) {
  if (!s.pixmap.map) s.pixmap.map = {}; const m = s.pixmap.map; Object.entries({ size: '3840x2160', w: 3840, h: 2160, style: 'color', snap: true, labels: true }).forEach(([k, v]) => { if (m[k] === undefined) m[k] = v; }); if (!Array.isArray(m.items)) m.items = [];
  if (m.size !== 'custom') { const [w, h] = m.size.split('x').map(Number); m.w = w; m.h = h; }
  m.w = Math.max(64, Math.min(16384, Math.round(num(m.w)) || 3840)); m.h = Math.max(32, Math.min(16384, Math.round(num(m.h)) || 2160));
  const ids = new Set(s.zones.map((z) => z.id));
  m.items = m.items.filter((it) => ids.has(it.zid));
  s.zones.forEach((z, zi) => { if (!m.items.some((it) => it.zid === z.id)) m.items.push({ zid: z.id, on: true, place: 'auto', fold: 0, color: MAP_COLORS[zi % MAP_COLORS.length] }); });
  return m;
}
/* Calcule la position de chaque morceau de zone dans les sorties */
function boardMap(s) {
  const p = getProduct(s.productId) || {}; const pw = num(p.pxW) || 128, ph = num(p.pxH) || 128; const rowH = s.rows * ph;
  const m = boardMapCfg(s); const W = m.w, H = m.h; const snap = (v) => (m.snap ? Math.floor(v / pw) * pw : v);
  const segs = []; const warn = []; let x = 0, y = 0, out = 0, blockBottom = 0, lineH = 0;
  if (s.zones.every((z) => { const it = m.items.find((x) => x.zid === z.id); return !it || !it.rot; }) && rowH > H) warn.push(`Une zone (${rowH} px de haut) est plus haute que la sortie (${H} px).`);
  // hauteur de la ligne = la zone la plus haute posée dessus ; nouvelle sortie si la suivante ne tient pas
  const newLine = (next = 0) => { x = 0; y = Math.max(y + lineH, blockBottom); lineH = 0; blockBottom = 0; if (next && y + next > H) { out++; y = 0; } };
  const fitOut = (h) => { if (x === 0 && y > 0 && y + h > H) { out++; y = 0; } };
  m.items.forEach((it) => {
    if (!it.on) return; const zi = s.zones.findIndex((z) => z.id === it.zid); const z = s.zones[zi]; if (!z) return;
    const zh = zRows(s, z) * ph; const Wz = z.count * pw; const rot = [90, 180, 270].includes(num(it.rot)) ? num(it.rot) : 0; const parts = [];
    const fold = !rot && it.place !== 'free' && num(it.fold) > 0 ? Math.min(W, snap(Math.max(pw, num(it.fold)))) : 0;
    const bw = rot % 180 ? zh : Wz, bh = rot % 180 ? Wz : zh; // dimensions dans la sortie (tourné de 90° : largeur ↔ hauteur)
    if (it.place === 'free') { // position libre : n'influence pas les autres
      const fx = Math.round(num(it.x)), fy = Math.round(num(it.y)), fo = Math.max(0, (num(it.out) || 1) - 1);
      parts.push({ x: fx, y: fy, w: bw, h: bh, out: fo, off: 0, rot });
      if (fx < 0 || fy < 0 || fx + bw > W || fy + bh > H) warn.push(`« ${z.name} » dépasse de la sortie à X ${fx} / Y ${fy} (${bw} × ${bh} px).`);
    } else if (rot) { // bloc tourné : jamais coupé
      if (x > 0 && (it.place === 'new' || x + bw > W)) newLine(bh); fitOut(bh); if (x === 0 && y > 0 && y + bh > H) { out++; y = 0; }
      parts.push({ x, y, w: bw, h: bh, out, off: 0, rot }); x += bw; lineH = Math.max(lineH, bh); if (x >= W) newLine(rowH);
      if (bw > W || bh > H) warn.push(`« ${z.name} » tourné (${bw} × ${bh} px) ne tient pas dans la sortie.`);
    } else if (fold) { // zone repliée : bloc de « fold » px de large, morceaux empilés
      if (x > 0 && (x + fold > W || it.place === 'new')) newLine(zh); fitOut(zh);
      const x0 = x; let rem = Wz, off = 0, yy = y;
      while (rem > 0) { if (yy + zh > H) { out++; yy = 0; } const w = Math.min(rem, fold); parts.push({ x: x0, y: yy, w, h: zh, out, off }); rem -= w; off += w; yy += zh; }
      x = x0 + fold; lineH = Math.max(lineH, zh); blockBottom = Math.max(blockBottom, yy); if (x >= W) newLine(rowH);
    } else {
      if (x > 0 && (it.place === 'new' || (it.place !== 'next' && Wz > W - x && Wz <= snap(W)))) newLine(zh);
      if (x > 0 && y + zh > H) newLine(zh); fitOut(zh);
      let rem = Wz, off = 0, guard = 0;
      while (rem > 0 && guard++ < 500) {
        const avail = snap(W - x); if (avail <= 0) { newLine(zh); continue; }
        const w = Math.min(rem, avail); parts.push({ x, y, w, h: zh, out, off }); x += w; rem -= w; off += w; lineH = Math.max(lineH, zh);
        if (rem > 0 || x >= W) newLine(zh);
      }
    }
    parts.forEach((pt, k) => segs.push(Object.assign({ rot: 0 }, pt, { zi, z, it, k, n: parts.length, Wz, zh, widths: parts.map((q) => q.w) })));
  });
  const outs = segs.length ? Math.max(...segs.map((g) => g.out)) + 1 : 1;
  if (outs > 1) warn.push(`Le mapping ne tient pas dans une seule sortie : ${outs} sorties de ${W} × ${H} px.`);
  if (!m.snap && segs.some((g) => g.n > 1 && g.off % pw)) warn.push('Certaines zones sont coupées au milieu d\'un panneau.');
  return { W, H, pw, ph, rowH, segs, outs, warn, m };
}
const lumi = (hex) => { const c = String(hex).replace('#', ''); const v = (i) => parseInt(c.substr(i, 2), 16) / 255; return 0.2126 * v(0) + 0.7152 * v(2) + 0.0722 * v(4); };
function mapLabel(ctx, lines, cx, cy, maxW, maxH, color) {
  let size = Math.min(maxH * (lines.length > 1 ? 0.36 : 0.55), 160);
  const fit = () => { ctx.font = `italic 900 ${size}px ${MAP_FONT}`; return Math.max(...lines.map((l) => ctx.measureText(l).width)); };
  while (size > 6 && (fit() > maxW * 0.94 || size * lines.length * 1.1 > maxH * 0.92)) size *= 0.92;
  ctx.fillStyle = color; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  lines.forEach((l, i) => ctx.fillText(l, cx, cy + (i - (lines.length - 1) / 2) * size * 1.08));
}
/* Dessine une sortie (index o) ; o = -1 : toutes les sorties empilées (PDF) */
function drawBoardMap(canvas, s, o = 0) {
  const L = boardMap(s); const pm = s.pixmap; const all = o < 0;
  canvas.width = L.W; canvas.height = all ? L.H * L.outs : L.H; const ctx = canvas.getContext('2d');
  ctx.fillStyle = '#000'; ctx.fillRect(0, 0, canvas.width, canvas.height);
  L.segs.filter((g) => all || g.out === o).forEach((g) => {
    const oy = all ? g.out * L.H : 0;
    if (g.rot) { // bloc tourné : dessiné à plat puis pivoté
      const t = document.createElement('canvas'); t.width = g.Wz; t.height = g.zh; paintSeg(t.getContext('2d'), s, L, Object.assign({}, g, { x: 0, y: 0, w: g.Wz, h: g.zh, off: 0, rot: 0 }), 0, 0);
      blitRot(ctx, t, 0, 0, g.Wz, g.zh, g.x, g.y + oy, g.w, g.h, g.rot); return;
    }
    paintSeg(ctx, s, L, g, g.x, g.y + oy);
  });
  if ((L.m.calib || L.m.diag) && L.m.calibMode === 'global') { // une seule mire sur tout l'écran (visible uniquement sur les LED)
    const outs = all ? [...Array(L.outs).keys()] : [o];
    outs.forEach((oo) => {
      const gs = L.segs.filter((g) => g.out === oo); if (!gs.length) return; const oy = all ? oo * L.H : 0;
      const x0 = Math.min(...gs.map((g) => g.x)), y0 = Math.min(...gs.map((g) => g.y)) + oy, x1 = Math.max(...gs.map((g) => g.x + g.w)), y1 = Math.max(...gs.map((g) => g.y + g.h)) + oy;
      const bw = x1 - x0, bh = y1 - y0; const lw = Math.max(2, Math.round(Math.min(bw, bh) / 200));
      ctx.save(); ctx.beginPath(); gs.forEach((g) => ctx.rect(g.x, g.y + oy, g.w, g.h)); ctx.clip();
      ctx.strokeStyle = '#ffffff'; ctx.lineWidth = lw; ctx.shadowColor = 'rgba(0,0,0,.8)'; ctx.shadowBlur = lw * 2; ctx.beginPath();
      if (L.m.diag) { ctx.moveTo(x0, y0); ctx.lineTo(x1, y1); ctx.moveTo(x1, y0); ctx.lineTo(x0, y1); }
      if (L.m.calib) { const cx = x0 + bw / 2, cy = y0 + bh / 2, r = Math.min(bw, bh) / 2 - lw; ctx.moveTo(x0, cy); ctx.lineTo(x1, cy); ctx.moveTo(cx, y0); ctx.lineTo(cx, y1); ctx.moveTo(cx + r, cy); ctx.arc(cx, cy, r, 0, Math.PI * 2); }
      ctx.stroke(); ctx.restore();
    });
  }
  drawFoldLabels(ctx, s, L, o, all);
  if (all && L.outs > 1) for (let k = 1; k < L.outs; k++) { ctx.fillStyle = '#ff2d55'; ctx.fillRect(0, k * L.H - 2, L.W, 4); }
  return { W: canvas.width, H: canvas.height };
}
/* Copie src (sx,sy,sw,sh) dans le rectangle (dx,dy,dw,dh) de la sortie en le tournant de rot degrés (sens horaire) */
function blitRot(ctx, src, sx, sy, sw, sh, dx, dy, dw, dh, rot) {
  if (!rot) return ctx.drawImage(src, sx, sy, sw, sh, dx, dy, dw, dh);
  ctx.save(); ctx.translate(dx + dw / 2, dy + dh / 2); ctx.rotate(rot * Math.PI / 180); ctx.drawImage(src, sx, sy, sw, sh, -sw / 2, -sh / 2, sw, sh); ctx.restore();
}
function paintSeg(ctx, s, L, g, X, Y) {
  const pm = s.pixmap;
  {
    ctx.save(); ctx.beginPath(); ctx.rect(X, Y, g.w, g.h); ctx.clip();
    if (L.m.style === 'damier') {
      const fsz = Math.max(8, Math.floor(Math.min(L.pw, L.ph) * 0.2));
      for (let px = g.off - (g.off % L.pw); px < g.off + g.w; px += L.pw) {
        const k = Math.floor(px / L.pw); const cx = X + (px - g.off);
        for (let r = 0; r < zRows(s, g.z); r++) {
          const cy = Y + r * L.ph; ctx.fillStyle = (k + r + g.zi) % 2 === 0 ? pm.c1 : pm.c2; ctx.fillRect(cx, cy, L.pw, L.ph);
          if (pm.grid) { ctx.strokeStyle = 'rgba(255,255,255,.55)'; ctx.lineWidth = 1; ctx.strokeRect(cx + .5, cy + .5, L.pw - 1, L.ph - 1); }
          if (pm.cross) { ctx.strokeStyle = 'rgba(255,255,255,.35)'; ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(cx + L.pw, cy + L.ph); ctx.moveTo(cx + L.pw, cy); ctx.lineTo(cx, cy + L.ph); ctx.stroke(); }
          if (pm.numbers) { ctx.fillStyle = pm.textColor; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.font = `bold ${fsz}px Segoe UI, Arial`; ctx.fillText(`Z${g.zi + 1}-${k + 1}${zRows(s, g.z) > 1 ? '·' + (r + 1) : ''}`, cx + L.pw / 2, cy + L.ph / 2); }
        }
      }
      ctx.strokeStyle = g.it.color; ctx.lineWidth = Math.max(2, L.ph * 0.04); ctx.strokeRect(X + ctx.lineWidth / 2, Y + ctx.lineWidth / 2, g.w - ctx.lineWidth, g.h - ctx.lineWidth);
    } else { ctx.fillStyle = g.it.color; ctx.fillRect(X, Y, g.w, g.h); }
    if ((L.m.calib || L.m.diag) && L.m.calibMode !== 'global') { // calibrage sur le bloc entier (même s'il est coupé en morceaux)
      const bx = X - g.off, by = Y, bw = g.Wz, bh = g.zh; const lw = Math.max(2, Math.round(Math.min(bw, bh) / 120));
      const col = L.m.style === 'damier' ? '#ffffff' : lumi(g.it.color) < 0.18 ? '#ffffff' : '#000000';
      ctx.strokeStyle = col; ctx.lineWidth = lw; ctx.beginPath();
      if (L.m.diag) { ctx.moveTo(bx, by); ctx.lineTo(bx + bw, by + bh); ctx.moveTo(bx + bw, by); ctx.lineTo(bx, by + bh); }
      if (L.m.calib) { const cx = bx + bw / 2, cy = by + bh / 2, r = Math.min(bw, bh) / 2 - lw;
        ctx.moveTo(bx, cy); ctx.lineTo(bx + bw, cy); ctx.moveTo(cx, by); ctx.lineTo(cx, by + bh); ctx.moveTo(cx + r, cy); ctx.arc(cx, cy, r, 0, Math.PI * 2);
        if (bw > bh * 1.8 || bh > bw * 1.8) { const r2 = Math.min(bw, bh) / 2 - lw; const n = Math.max(bw, bh) / Math.min(bw, bh); // bloc allongé : cercles aux extrémités aussi
          [0.5, n - 0.5].forEach((k) => { const ex = bw >= bh ? bx + k * bh : cx, ey = bw >= bh ? cy : by + k * bw; ctx.moveTo(ex + r2, ey); ctx.arc(ex, ey, r2, 0, Math.PI * 2); }); } }
      ctx.stroke();
    }
    if (L.m.labels && !(num(g.it.fold) > 0 && g.n > 1)) {
      const size = `${g.w}x${g.h} px`; const name = g.z.name; const extra = g.n > 1 && g.k === g.n - 1 ? ` (${g.widths.join('+')}=${g.Wz})` : '';
      const txt = L.m.style === 'damier' ? '#ffffff' : lumi(g.it.color) < 0.18 ? '#ffffff' : '#000000';
      if (L.m.style === 'damier') { ctx.fillStyle = 'rgba(0,0,0,.55)'; }
      if (g.h > g.w * 1.6) { // bloc vertical (totem) : texte écrit dans la hauteur
        ctx.save(); ctx.translate(X + g.w / 2, Y + g.h / 2); ctx.rotate(-Math.PI / 2);
        const one = [`${name} ${size}`]; ctx.font = `italic 900 ${g.w * 0.4}px ${MAP_FONT}`;
        mapLabel(ctx, ctx.measureText(one[0]).width > g.h * 0.9 ? [name, size] : one, 0, 0, g.h, g.w, txt); ctx.restore();
      } else {
        const one = [`${name} ${size}${extra}`]; ctx.font = `italic 900 ${g.h * 0.4}px ${MAP_FONT}`;
        const lines = ctx.measureText(one[0]).width > g.w * 0.9 && g.w < g.h * 6 ? [name, size + extra] : one;
        mapLabel(ctx, lines, X + g.w / 2, Y + g.h / 2, g.w, g.h, txt);
      }
    }
    ctx.restore();
  }
}
function drawFoldLabels(ctx, s, L, o, all) {
  // zones repliées : une seule étiquette pour tout le bloc (ex. « Zone F 768x256 px »)
  if (L.m.labels) {
    const groups = new Map(); L.segs.filter((g) => num(g.it.fold) > 0 && g.n > 1 && (all || g.out === o)).forEach((g) => { const k = g.zi + ':' + g.out; if (!groups.has(k)) groups.set(k, []); groups.get(k).push(g); });
    groups.forEach((gs) => {
      const oy = all ? gs[0].out * L.H : 0; const x0 = Math.min(...gs.map((g) => g.x)), y0 = Math.min(...gs.map((g) => g.y)) + oy;
      const bw = Math.max(...gs.map((g) => g.x + g.w)) - x0, bh = Math.max(...gs.map((g) => g.y + g.h)) + oy - y0; const g = gs[0];
      const txt = L.m.style === 'damier' ? '#ffffff' : lumi(g.it.color) < 0.18 ? '#ffffff' : '#000000';
      const one = `${g.z.name} ${bw}x${bh} px`; ctx.font = `italic 900 ${Math.min(bh, g.h) * 0.4}px ${MAP_FONT}`;
      mapLabel(ctx, ctx.measureText(one).width > bw * 0.9 ? [g.z.name, `${bw}x${bh} px`] : [one], x0 + bw / 2, y0 + bh / 2, bw, Math.min(bh, g.h * 1.4), txt);
    });
  }
}

/* ---------- Interface (onglet Pixel map d'un boarding) ---------- */
function boardMapTab(s) {
  const L = boardMap(s); const m = L.m; const pm = s.pixmap;
  const chk = (k, l) => `<label class="row small" style="gap:8px;margin:6px 0"><input type="checkbox" data-pm="${k}" ${pm[k] ? 'checked' : ''}>${l}</label>`;
  const rows = m.items.map((it, i) => {
    const zi = s.zones.findIndex((z) => z.id === it.zid); const z = s.zones[zi]; const segs = L.segs.filter((g) => g.it === it);
    return `<tr class="${it.on ? '' : 'off'}"><td><input type="checkbox" data-bm="on" data-i="${i}" ${it.on ? 'checked' : ''} title="Inclure dans le mapping"></td>
      <td><input type="color" data-bm="color" data-i="${i}" value="${it.color}" class="swatch-in"></td>
      <td><b>${esc(z.name)}</b><div class="tiny muted">${z.count}${zRows(s, z) > 1 ? ' × ' + zRows(s, z) : ''} pan. · ${z.count * L.pw} × ${zRows(s, z) * L.ph} px</div></td>
      <td><select data-bm="place" data-i="${i}">${MAP_PLACES.map(([v, l]) => `<option value="${v}" ${it.place === v ? 'selected' : ''}>${l}</option>`).join('')}</select></td>
      <td>${it.place === 'free' ? `<div class="row" style="gap:4px;flex-wrap:nowrap"><input type="number" data-bm="x" data-i="${i}" value="${num(it.x)}" style="width:72px" title="X (px)"><input type="number" data-bm="y" data-i="${i}" value="${num(it.y)}" style="width:72px" title="Y (px)">${L.outs > 1 || num(it.out) > 1 ? `<input type="number" min="1" data-bm="out" data-i="${i}" value="${num(it.out) || 1}" style="width:48px" title="Sortie n°">` : ''}</div>`
        : `<input type="number" data-bm="fold" data-i="${i}" value="${num(it.fold) || ''}" placeholder="—" step="${L.pw}" style="width:84px" title="Replier la zone sur cette largeur (px)" ${num(it.rot) ? 'disabled' : ''}>`}</td>
      <td><select data-bm="rot" data-i="${i}" style="min-width:0;width:74px" title="Rotation dans la sortie">${[0, 90, 180, 270].map((r) => `<option value="${r}" ${num(it.rot) === r ? 'selected' : ''}>${r}°</option>`).join('')}</select></td>
      <td class="tiny muted" style="white-space:nowrap">${segs.map((g) => `${L.outs > 1 ? 'S' + (g.out + 1) + ' ' : ''}X${g.x} Y${g.y}${g.n > 1 ? ' · ' + g.w + 'px' : ''}`).join('<br>') || '—'}</td>
      <td style="white-space:nowrap"><button class="sm ghost" data-act="bmMove" data-i="${i}" data-d="-1" ${i ? '' : 'disabled'}>↑</button><button class="sm ghost" data-act="bmMove" data-i="${i}" data-d="1" ${i < m.items.length - 1 ? '' : 'disabled'}>↓</button></td></tr>`;
  }).join('');
  return `<div class="bm-wrap">
  <div class="card"><div class="row" style="justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:12px">
     <div><h3 style="margin:0">Mapping de sortie — ${L.W} × ${L.H} px${L.outs > 1 ? ` · ${L.outs} sorties` : ''}</h3><div class="tiny muted">Panneau ${L.pw} × ${L.ph} px · hauteur des zones : ${[...new Set(s.zones.map((z) => zRows(s, z) * L.ph))].join(' / ')} px</div></div>
     <div class="row" style="gap:8px;flex-wrap:wrap">
       <label class="f">Sortie<select data-bm="size">${[['1920x1080', '1920 × 1080'], ['3840x2160', '3840 × 2160'], ['custom', 'Personnalisée']].map(([v, l]) => `<option value="${v}" ${m.size === v ? 'selected' : ''}>${l}</option>`).join('')}</select></label>
       ${m.size === 'custom' ? `<label class="f">Largeur<input type="number" data-bm="w" value="${m.w}" style="width:90px"></label><label class="f">Hauteur<input type="number" data-bm="h" value="${m.h}" style="width:90px"></label>` : ''}
       <label class="f">Rendu<select data-bm="style"><option value="color" ${m.style !== 'damier' ? 'selected' : ''}>Blocs couleur (créa)</option><option value="damier" ${m.style === 'damier' ? 'selected' : ''}>Damier technique</option></select></label>
       <label class="f">Changer de disposition<select data-pm="board"><option value="map" selected>Mapping de sortie</option><option value="zones">Une zone par ligne (natif)</option><option value="line">Ligne continue (natif)</option><option value="wrap">Repliée (natif)</option></select></label>
     </div></div>
     <div id="bmOuts" class="bm-outs">${Array.from({ length: L.outs }, (_, o) => `<div><div class="tiny muted" style="margin:10px 0 4px">${L.outs > 1 ? `Sortie ${o + 1} — ` : ''}${L.W} × ${L.H} px</div><canvas class="bm-canvas" data-o="${o}"></canvas></div>`).join('')}</div>
     ${L.warn.map((w) => `<div class="alert warn" style="margin-top:8px">⚠ ${esc(w)}</div>`).join('')}
  </div>
  <div class="grid" style="grid-template-columns:minmax(0,1fr) 300px;gap:16px;margin-top:16px;align-items:start">
   <div class="card"><h3>${zTerm(s).Many} dans l'ordre du mapping</h3>
     <div class="row" style="gap:6px;flex-wrap:wrap;margin-bottom:10px"><span class="tiny muted">Préréglages :</span>
       <button class="sm" data-act="bmPreset" data-v="new">Une zone par ligne</button><button class="sm" data-act="bmPreset" data-v="auto">Compact (à la suite si ça rentre)</button><button class="sm" data-act="bmPreset" data-v="next">Continu (coupé au bord)</button><button class="sm ghost" data-act="bmPreset" data-v="reset">Ordre & couleurs d'origine</button></div>
     <div style="overflow-x:auto"><table class="tbl bm-tbl"><thead><tr><th></th><th></th><th>${zTerm(s).One}</th><th>Placement</th><th>Repli (px) / X · Y</th><th>Rotation</th><th>Position</th><th></th></tr></thead><tbody>${rows}</tbody></table></div>
     <div class="tiny muted" style="margin-top:8px"><b>Repli</b> : la zone est coupée tous les N px et ses morceaux sont empilés (ex. 1536 px replié à 768 → bloc 768 × 2 lignes). Laisser vide = coupée seulement au bord de la sortie.</div>
   </div>
   <div><div class="card"><h3>Options</h3>
     <label class="bm-opt"><input type="checkbox" data-bm="snap" ${m.snap ? 'checked' : ''}><span>Couper uniquement entre deux panneaux</span></label>
     <label class="bm-opt"><input type="checkbox" data-bm="labels" ${m.labels ? 'checked' : ''}><span>Nom & taille de chaque zone</span></label>
     <hr class="sep"><div class="small" style="font-weight:700;margin-bottom:4px">🎯 Calibrage</div>
     <label class="bm-opt"><input type="checkbox" data-bm="calib" ${m.calib ? 'checked' : ''}><span>Cercle & croix de calibrage</span></label>
     <label class="bm-opt"><input type="checkbox" data-bm="diag" ${m.diag ? 'checked' : ''}><span>Diagonales</span></label>
     <div class="seg" style="margin-top:6px"><button class="${m.calibMode !== 'global' ? 'on' : ''}" data-act="bmCalibMode" data-v="bloc">Sur chaque ${zTerm(s).one}</button><button class="${m.calibMode === 'global' ? 'on' : ''}" data-act="bmCalibMode" data-v="global">Sur tout l'écran</button></div>
     ${m.style === 'damier' ? `<hr class="sep"><div class="row"><label class="f">Couleur 1<input type="color" data-pm="c1" value="${pm.c1}"></label><label class="f">Couleur 2<input type="color" data-pm="c2" value="${pm.c2}"></label><label class="f">Texte<input type="color" data-pm="textColor" value="${pm.textColor}"></label></div>${chk('numbers', 'Numéro de panneau')}${chk('grid', 'Contour des panneaux')}${chk('cross', 'Diagonales')}` : ''}
   </div>
   <div class="card" style="margin-top:16px"><h3>Export</h3>
     <button class="primary" data-act="bmExport" style="width:100%;justify-content:center">⇩ PNG ${L.outs > 1 ? `(${L.outs} sorties)` : L.W + ' × ' + L.H}</button>
     <button data-act="bmCSV" style="width:100%;justify-content:center;margin-top:8px">⇩ Positions des zones (CSV)</button>
     <div class="tiny muted" style="margin-top:8px">Le CSV liste chaque zone / morceau : sortie, X, Y, largeur, hauteur — pour les créas et le serveur média.</div></div></div>
  </div></div>`;
}
function drawBoardMapPreviews(s) {
  document.querySelectorAll('.bm-canvas').forEach((c) => { drawBoardMap(c, s, +c.dataset.o); c.style.width = '100%'; c.style.maxWidth = '1100px'; });
}
const boardMapActions = {
  bmCalibMode(el) { const s = curScreen(); boardMapCfg(s).calibMode = el.dataset.v; if (!boardMapCfg(s).calib && !boardMapCfg(s).diag) boardMapCfg(s).calib = true; Store.save(); const y = $main().scrollTop; render(); $main().scrollTop = y; },
  bmMove(el) { const s = curScreen(); const m = boardMapCfg(s); const i = +el.dataset.i, j = i + +el.dataset.d; if (j < 0 || j >= m.items.length) return; [m.items[i], m.items[j]] = [m.items[j], m.items[i]]; Store.save(); render(); },
  bmPreset(el) {
    const s = curScreen(); const m = boardMapCfg(s); const v = el.dataset.v;
    if (v === 'reset') { m.items = s.zones.map((z, zi) => Object.assign(m.items.find((it) => it.zid === z.id) || {}, { zid: z.id, color: MAP_COLORS[zi % MAP_COLORS.length] })); }
    else m.items.forEach((it) => { it.place = v; it.fold = 0; });
    Store.save(); render();
  },
  async bmExport() {
    const s = curScreen(); const L = boardMap(s); const base = `${safeName(curProject().name)}_${safeName(s.name)}_mapping_${L.W}x${L.H}`;
    for (let o = 0; o < L.outs; o++) {
      const c = document.createElement('canvas'); drawBoardMap(c, s, o);
      await saveFileBase64(`${base}${L.outs > 1 ? '_sortie' + (o + 1) : ''}.png`, dataURLtoB64(c.toDataURL('image/png')), 'png', 'Image PNG');
    }
  },
  async bmCSV() {
    const s = curScreen(); const L = boardMap(s);
    const lines = [['Zone / bloc', 'Morceau', 'Sortie', 'X', 'Y', 'Largeur', 'Hauteur', 'Rotation (°)', 'Panneaux', 'Largeur totale', 'Début dans la zone (px)'].join(';')];
    L.segs.forEach((g) => lines.push([g.z.name, `${g.k + 1}/${g.n}`, g.out + 1, g.x, g.y, g.w, g.h, g.rot || 0, g.rot ? g.z.count * zRows(s, g.z) : Math.round(g.w / L.pw) * zRows(s, g.z), g.Wz, g.off].map(csvCell).join(';')));
    await saveFileText(`${safeName(curProject().name)}_${safeName(s.name)}_mapping_${L.W}x${L.H}.csv`, '﻿' + lines.join('\r\n'), 'csv', 'CSV');
  }
};
function boardMapChange(t) {
  if (!t.dataset.bm) return false; const s = curScreen(); if (!s || !isBoard(s)) return true;
  const m = boardMapCfg(s); const k = t.dataset.bm;
  if (t.dataset.i !== undefined) { const it = m.items[+t.dataset.i]; if (!it) return true;
    if (k === 'place' && t.value === 'free' && it.place !== 'free') { const g = boardMap(s).segs.find((q) => q.it === it); if (g) { it.x = g.x; it.y = g.y; it.out = g.out + 1; } }
    it[k] = t.type === 'checkbox' ? t.checked : k === 'fold' ? Math.max(0, num(t.value)) : ['x', 'y', 'out', 'rot'].includes(k) ? num(t.value) : t.value; }
  else m[k] = t.type === 'checkbox' ? t.checked : (k === 'w' || k === 'h') ? num(t.value) : t.value;
  Store.save(); const y = $main().scrollTop; render(); $main().scrollTop = y; return true;
}
