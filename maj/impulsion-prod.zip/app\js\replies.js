/* =====================================================================
   RÉPONSES EN 1 CLIC — lien personnel dans le message → page de réponse (Google Apps Script)
   → l'application récupère les réponses et met les statuts à jour toute seule.
   ===================================================================== */
const REPLY_URL_RE = /^https:\/\/script\.google\.com\/macros\/s\/[\w-]+\/exec$/;
const replyActive = () => REPLY_URL_RE.test(String(Store.db.settings.replyUrl || '').trim());
const replyState = { busy: false, last: null, error: null, timer: null };

function randToken(n = 16) {
  const a = new Uint8Array(n); (window.crypto || {}).getRandomValues ? crypto.getRandomValues(a) : a.forEach((_, i) => { a[i] = Math.random() * 256; });
  return Array.from(a, (b) => 'abcdefghijkmnopqrstuvwxyz23456789'[b % 33]).join('');
}
function ensureReplyKey() { const st = Store.db.settings; if (!st.replyKey) { st.replyKey = randToken(24); Store.save(); } return st.replyKey; }
function replyScript() {
  return REPLY_GS.replace("'__KEY__'", JSON.stringify(ensureReplyKey()).replace(/"/g, "'"))
    .replace("'__COMPANY__'", "'" + String(Store.db.settings.company || 'Impulsion').replace(/['\\]/g, ' ') + "'");
}
function reqLink(r) {
  if (!replyActive()) return '';
  if (!r.token) { r.token = 'r' + randToken(15); Store.save(); }
  return pagesActive() ? `${pagesBase()}?t=${r.token}` : `${Store.db.settings.replyUrl.trim()}?t=${r.token}`;
}
function reqInfo(r, p, kind) {
  const t = getTech(r.techId) || {};
  return { kind: kind || 'booking', prenom: t.firstName || '', projet: p.name, lieu: p.venue || '', role: r.role || '', company: Store.db.settings.company,
    datesTxt: fmtDays(r.dates), days: [...r.dates].sort().map((d) => ({ d, l: dayWithHours(r, d) })), hoursNote: (r.hours && r.hours.note) || '' };
}

/* ---------- Appels au script (via l'appli de bureau si possible : pas de souci CORS) ---------- */
async function remoteGet(params) {
  const url = Store.db.settings.replyUrl.trim() + '?' + new URLSearchParams(params).toString();
  let txt;
  if (window.desktop && window.desktop.remoteGet) txt = await window.desktop.remoteGet(url);
  else txt = await (await fetch(url, { redirect: 'follow' })).text();
  let j; try { j = JSON.parse(txt); } catch (e) {
    if (/Authorization is required|autorisation est requise|Autorisation requise|requires authorization|needs authorization|Vous devez disposer d'une autorisation/i.test(txt)) throw new Error('Google demande une autorisation : dans l\'éditeur Apps Script, choisissez la fonction « autoriserAgenda », cliquez ▶ Exécuter et acceptez (Paramètres avancés → Accéder), puis Déployer → Gérer les déploiements → ✏️ → Nouvelle version.');
    if (/doGet|introuvable|not found/i.test(txt)) throw new Error('« Fonction de script introuvable » : la version publiée du script ne contient pas le code. Voir l\'encadré d\'aide ci-dessous.');
    if (/accounts\.google\.com|ServiceLogin|signin/i.test(txt)) throw new Error('Google demande une connexion : le déploiement doit être « Qui a accès : Tout le monde ».');
    throw new Error('Réponse inattendue du script (vérifiez le déploiement « Tout le monde »)');
  }
  if (!j.ok) throw new Error(j.error || 'Erreur du script');
  return j;
}
const withTimeout = (p, ms) => Promise.race([p, new Promise((_, rej) => setTimeout(() => rej(new Error('Délai dépassé')), ms))]);

/* Enregistre la demande côté script (pour que la page du technicien affiche le bon projet / les bons jours) */
async function ensureRegistered(r, p, kind) {
  if (!replyActive() || !r) return true;
  reqLink(r);
  const info = reqInfo(r, p, kind); const h = JSON.stringify(info);
  if (r.regHash === h) return true;
  await remoteGet({ action: 'register', key: ensureReplyKey(), items: JSON.stringify([{ t: r.token, info }]) });
  r.regHash = h; Store.save(); return true;
}

/* Récupère les nouvelles réponses et met à jour les statuts */
async function syncReplies(manual) {
  if (!manual && typeof isAutoLeader === 'function' && !isAutoLeader()) return;
  if (!replyActive() || replyState.busy) { if (manual && !replyActive()) toast('Configurez d\'abord les réponses en 1 clic (Équipe → Réponses en 1 clic)', 'warn'); return; }
  replyState.busy = true;
  try {
    const st = Store.db.settings;
    const j = await withTimeout(remoteGet({ action: 'list', key: ensureReplyKey(), since: st.replySince || 0 }), 25000);
    replyState.last = Date.now(); replyState.error = null; replyState.version = j.version || 1;
    if (typeof journalFlush === 'function') journalFlush();
    const changes = applyReplies(j.rows || []);
    if (typeof indispoPull === 'function') { try { await indispoPull(false); } catch (e) { /* script < v12 */ } }
    if (typeof journalAdd === 'function') { changes.forEach((c) => journalAdd({ kind: 'info', type: 'reply', ic: '📲', ref: c.p.id, byName: '', by: '', text: `${techName(c.t)} a répondu : ${replyLabel(c.r.reply)}` })); journalResync(); if (changes.length) Store.saveNow(); }
    if (changes.length) {
      changes.slice(0, 4).forEach((c) => toast(`📱 ${techName(c.t)} : ${replyLabel(c.r.reply)} — ${c.p.name}`, c.r.reply.status === 'indispo' && c.r.reply.phase === 'confirm' ? 'bad' : ''));
      if (changes.length > 4) toast(`… et ${changes.length - 4} autre(s) réponse(s)`);
      if (changes.some((c) => c.r.reply.status !== 'indispo')) confetti();
    } else if (manual) toast('Aucune nouvelle réponse');
    const modalOpen = !document.getElementById('modal').classList.contains('hidden');
    const typing = document.activeElement && ['INPUT', 'TEXTAREA', 'SELECT'].includes(document.activeElement.tagName);
    if (changes.length && !modalOpen && !typing) { const y = $main().scrollTop; render(); $main().scrollTop = y; }
    else updateReplyBadge();
  } catch (e) {
    replyState.error = e.message || String(e); if (manual) toast('Réponses : ' + replyState.error, 'bad');
    if (ui.view === 'team' && ui.teamTab === 'reponses') render(); else updateReplyBadge();
  } finally { replyState.busy = false; }
}
function applyReplies(rows) {
  const st = Store.db.settings; const changes = [];
  const yes = st.replyYes === 'option' ? 'option' : 'valide';
  const byToken = new Map(); Store.db.projects.forEach((p) => p.crew.forEach((r) => { if (r.token) byToken.set(r.token, { p, r }); }));
  rows.sort((a, b) => a.at - b.at).forEach((row) => {
    st.replySince = Math.max(st.replySince || 0, row.at);
    const hit = byToken.get(row.t); if (!hit) return;
    const { p, r } = hit; if ((r.replyAt || 0) >= row.at) return;
    if (!['valide', 'option', 'indispo', 'confirme'].includes(row.status)) return;
    // À quelle étape répond-il ? (le script v2 l'indique ; sinon on le déduit)
    const phase = ['option', 'booking', 'confirm'].includes(row.kind) ? row.kind
      : (r.confirmSentAt && row.at > Date.parse(r.confirmSentAt)) ? 'confirm' : r.kind === 'option' ? 'option' : 'booking';
    r.reply = { status: row.status, phase, dates: row.dates || [], comment: row.comment || '', at: row.at };
    r.replyAt = row.at;
    if (phase === 'confirm') {
      if (row.status === 'indispo') { r.status = 'indispo'; r.ack = null; }
      else { r.status = 'valide'; r.ack = { at: row.at }; r.ackSnap = ackSnap(r, p); r.updateSentAt = null; }
    } else {
      r.status = row.status === 'indispo' ? 'indispo' : phase === 'option' ? 'option' : row.status === 'option' ? 'option' : yes;
      if (row.status !== 'indispo' && row.dates && row.dates.length) { const keep = row.dates.filter((d) => r.dates.includes(d)); if (keep.length) r.dates = keep.sort(); }
      // booking direct : « dispo » du technicien = booking validé officiellement (plus de confirmation à renvoyer)
      if (phase === 'booking' && r.status === 'valide') { r.ack = { at: row.at, via: 'booking' }; r.ackSnap = ackSnap(r, p); r.updateSentAt = null; }
    }
    r.history.push({ at: new Date(row.at).toISOString(), action: 'reponse', via: 'lien', status: row.status, dates: row.dates, comment: row.comment });
    changes.push({ p, r, t: getTech(r.techId) });
  });
  if (rows.length) Store.save();
  return changes;
}
function startReplySync() {
  clearInterval(replyState.timer);
  replyState.timer = setInterval(() => { if (document.visibilityState === 'visible') syncReplies(false); }, 60000);
  window.addEventListener('focus', () => { if (!replyState.last || Date.now() - replyState.last > 20000) syncReplies(false); });
  setTimeout(() => syncReplies(false), 2500);
}
function replyBadgeText() {
  if (!replyActive()) return '';
  if (replyState.error) return `<span style="color:var(--bad)">⚠ ${esc(replyState.error)}</span>`;
  if (replyState.last) return `📱 Réponses vérifiées à ${new Date(replyState.last).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}`;
  return '📱 Réponses en 1 clic actives';
}
function updateReplyBadge() { document.querySelectorAll('.reply-badge').forEach((el) => { el.innerHTML = replyBadgeText(); }); }
function replyLabel(rep) {
  if (!rep) return '';
  if (rep.status === 'indispo') return rep.phase === 'confirm' ? '❌ ne peut plus venir !' : '❌ pas disponible';
  if (rep.phase === 'booking' && rep.status === 'valide') return '✅ booking validé';
  if (rep.phase === 'confirm' || rep.status === 'confirme') return '📌 présence confirmée';
  if (rep.phase === 'option' || rep.status === 'option') return '🟦 OK pour l\'option';
  return '✅ disponible';
}
function replyCell(r) {
  if (!r.reply) return '';
  const col = r.reply.status === 'indispo' ? 'var(--bad)' : r.reply.phase === 'option' || r.reply.status === 'option' ? '#8fb0ff' : 'var(--ok)'; const d = new Date(r.reply.at);
  return `<div class="tiny reply-note">📱 a répondu <b style="color:${col}">${replyLabel(r.reply)}</b> le ${d.toLocaleDateString('fr-FR', { day: '2-digit', month: 'short' })} à ${d.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}${r.reply.status !== 'indispo' && r.reply.dates.length ? ` · ${fmtDaysShort(r.reply.dates)}` : ''}${r.reply.comment ? `<br>« ${esc(r.reply.comment)} »` : ''}</div>`;
}

/* ---------- Onglet de configuration (Équipe → Réponses en 1 clic) ---------- */
function replySetupHTML() {
  const st = Store.db.settings; const ok = replyActive();
  const step = (n, title, body) => `<div class="setup-step"><div class="num">${n}</div><div class="grow"><b>${title}</b><div class="small muted" style="margin-top:4px">${body}</div></div></div>`;
  return `<div class="grid g2" style="align-items:start">
  <div class="card"><h3>Comment ça marche</h3>
    <div class="small" style="line-height:1.6">Chaque demande envoyée contient un <b>lien personnel</b>. Le technicien le touche sur son téléphone, coche ses jours et appuie sur
    <span class="tag ok">✅ Dispo</span> <span class="tag info">🟦 Option</span> ou <span class="tag bad">❌ Pas dispo</span>.
    L'application récupère la réponse <b>toute seule</b> (toutes les minutes) et met le statut à jour.</div>
    <div class="small muted" style="margin-top:10px">Gratuit : le relais tourne sur <b>votre</b> compte Google (Apps Script) et les réponses sont rangées dans un Google Sheets de votre Drive. Aucun compte n'est demandé aux techniciens.</div>
    <hr class="sep">
    <div class="row" style="justify-content:space-between"><div>${!ok ? '<span class="tag warn">● Pas encore configuré</span>' : replyState.error ? '<span class="tag bad">● Erreur</span>' : '<span class="tag ok">● Actif</span>'} <span class="small reply-badge">${replyBadgeText()}</span></div>
    ${ok ? '<div class="row"><button class="sm" data-act="replyTest">Tester</button><button class="sm" data-act="replySync">🔄 Vérifier les réponses</button></div>' : ''}</div>
    ${ok && replyState.version && replyState.version < 13 ? (replyState.version >= 10 ? `<div class="alert" style="margin-top:12px"><b>Mise à jour du script nécessaire</b> (v${replyState.version} → v13) : les techniciens pourront <b>déclarer leurs indisponibilités</b> depuis « Mes bookings »${replyState.version < 11 ? ', et ils ne recevront plus de mails d\'agenda inutiles' : ''} :<br>1. Copiez le nouveau code (étape 2), remplacez tout dans Apps Script, <b>Ctrl+S</b>.<br>2. <b>Déployer → Gérer les déploiements → ✏️ → Nouvelle version → Déployer</b>.</div>` : `<div class="alert" style="margin-top:12px"><b>Mise à jour du script nécessaire</b> (v${replyState.version} → v13)${replyState.version < 8 ? ' pour les options, la confirmation de présence, la feuille de route en ligne et l\'agenda des techniciens,' : ''}${replyState.version < 9 ? ' pour le partage entre plusieurs PC,' : ''} pour l'envoi des fichiers RCG aux techniciens :<br>
      1. Copiez le nouveau code (étape 2) et remplacez tout le contenu dans Apps Script, puis <b>Ctrl+S</b>.<br>
      2. Dans l'éditeur, choisissez la fonction <b>autoriserFichiers</b> et cliquez ▶ <b>Exécuter</b> : acceptez l'accès à Google Drive (une seule fois).<br>
      3. <b>Déployer → Gérer les déploiements</b> → ✏️ → Version : <b>Nouvelle version</b> → Déployer. L'adresse ne change pas.<br>
      4. Si vous utilisez les liens GitHub Pages : retéléchargez <b>index.html</b> (« Liens sans erreur Google ») et remplacez-le sur GitHub pour afficher les fichiers sur la feuille de route.</div>`) : ''}
    <hr class="sep">
    <label class="f"><span>Pour un <b>booking direct</b>, quand le technicien répond « disponible », le passer en</span>
      <select data-set="replyYes"><option value="valide" ${st.replyYes !== 'option' ? 'selected' : ''}>✅ Validé directement</option><option value="option" ${st.replyYes === 'option' ? 'selected' : ''}>🟦 Option (je valide moi-même ensuite)</option></select></label>
  </div>
  <div class="card"><h3>Mise en place (une seule fois, 5 min)</h3>
    ${step(1, 'Ouvrir Google Apps Script', `Connecté à votre compte Google. <button class="sm" data-act="replyOpenGas">Ouvrir script.google.com ↗</button>`)}
    ${step(2, 'Créer un projet et coller le code', `Dans l'éditeur, sélectionnez tout le contenu (<b>Ctrl+A</b>), effacez-le puis collez le code (<b>Ctrl+V</b>). <button class="sm primary" data-act="replyCopy">📋 Copier le code</button>
      <details style="margin-top:6px"><summary class="tiny">La copie ne marche pas ? Afficher le code</summary><textarea readonly class="code-box" onclick="this.select()">${esc(replyScript())}</textarea><div class="tiny muted">Cliquez dans la zone, Ctrl+A puis Ctrl+C.</div></details>
      La 1<sup>re</sup> ligne collée doit être <code>/**</code> et le fichier doit contenir <code>function doGet</code>.<br><b>Enregistrez avec Ctrl+S</b> (icône 💾) <u>avant</u> de déployer.`)}
    ${step(3, 'Déployer', `En haut à droite : <b>Déployer → Nouveau déploiement</b> → roue ⚙ → <b>Application Web</b>.<br>Exécuter en tant que : <b>Moi</b> · Qui a accès : <b>Tout le monde</b> → <b>Déployer</b>.`)}
    ${step(4, 'Autoriser', `Google demande l'autorisation : choisissez votre compte → « Paramètres avancés » → « Accéder à Impulsion LED (non sécurisé) » → Autoriser. C'est normal : c'est votre propre script.`)}
    ${step(5, 'Coller l\'adresse de l\'application Web', `Copiez l'URL qui se termine par <code>/exec</code> et collez-la ici :
      <div class="row" style="margin-top:8px"><input class="grow" id="replyUrlInput" value="${esc(st.replyUrl || '')}" placeholder="https://script.google.com/macros/s/…/exec"><button class="primary" data-act="replySave">Enregistrer et tester</button></div>`)}
    <div class="alert" style="margin-top:12px"><b>« Fonction de script introuvable : doGet » ?</b><br>
      Le code n'était pas enregistré au moment du déploiement. Dans l'éditeur Apps Script :<br>
      1. Vérifiez que le code est bien collé (il commence par <code>/**</code>, sinon recollez-le) et faites <b>Ctrl+S</b>.<br>
      2. <b>Déployer → Gérer les déploiements</b> → crayon ✏️ → Version : <b>Nouvelle version</b> → <b>Déployer</b>.<br>
      3. L'adresse <code>/exec</code> ne change pas : revenez ici et cliquez « Enregistrer et tester ».</div>
    <div class="tiny muted" style="margin-top:10px">Ajoutez <code>{lien}</code> dans vos messages types (déjà présent dans « Demande » et « Relance »). Si vous changez le nom de la société, recopiez le code et redéployez (Gérer les déploiements → Modifier → Nouvelle version).</div>
  </div></div>`;
}

const replyActions = {
  replyOpenGas() { openExternal('https://script.google.com/home/projects/create'); },
  replyCopy() { copyText(replyScript(), true); toast('Code copié 📋 — collez-le dans le projet Apps Script (Ctrl+V)'); },
  async replySave() {
    const v = document.getElementById('replyUrlInput').value.trim();
    if (!REPLY_URL_RE.test(v)) return toast('L\'adresse doit ressembler à https://script.google.com/macros/s/…/exec', 'warn');
    Store.db.settings.replyUrl = v; Store.save(); render(); await replyActions.replyTest();
  },
  async replyTest() {
    try {
      toast('Test de la connexion…'); const j = await withTimeout(remoteGet({ action: 'ping', key: ensureReplyKey() }), 25000);
      replyState.error = null; replyState.last = Date.now(); replyState.version = j.version || 1;
      if (replyState.version < 13) toast('Connexion OK, mais le script est une ancienne version : mettez-le à jour (voir l\'encadré) ⚠', 'warn');
      else { toast('Connexion OK ✔ Les réponses en 1 clic sont actives 🎉'); confetti(); }
    }
    catch (e) { replyState.error = e.message; toast('Échec : ' + e.message, 'bad'); }
    if (ui.view === 'team' && ui.teamTab === 'reponses') render(); else updateReplyBadge();
  },
  replySync() { syncReplies(true); }
};

/* Migration douce des messages types : ajout de la ligne {lien} */
function upgradeTemplatesForLink() {
  const st = Store.db.settings;
  if (!st.optionV1) { // v1.3 : confirmation officielle avec lien de confirmation de présence
    st.optionV1 = true;
    const oldConfirm = 'Bonjour {prenom} ✅\n\nC\'est validé pour « {projet} » !\n📅 {dates}\n📍 {lieu}\n🛠️ Poste : {role}\n\nHoraires et infos à suivre. Merci et à bientôt !';
    if (st.msgConfirm === oldConfirm) st.msgConfirm = defaultSettings().msgConfirm;
    else if (!String(st.msgConfirm || '').includes('{lien}')) st.msgConfirm = String(st.msgConfirm || '') + '\n\n👉 Confirme ta présence en 1 clic : {lien}';
    Store.save();
  }
  if (st.lienV1) return; st.lienV1 = true;
  const add = (k) => {
    const s = String(st[k] || ''); if (s.includes('{lien}')) return;
    const line = '👉 Répondre en 1 clic : {lien}';
    const i = s.search(/\n[^\n]*(Merci de me répondre|Peux-tu me dire)/);
    st[k] = i >= 0 ? s.slice(0, i + 1) + line + '\n\n' + s.slice(i + 1) : s + '\n\n' + line;
  };
  add('msgDemande'); add('msgRelance'); Store.save();
}
