/* =====================================================================
   IMPLANTATION AU SOL (scène 3D + vue de dessus)
   p.implant = { kind: 'none' | 'court' | 'dxf' | 'image', x, y (centre, mm), rot (°), opacity,
               court: 'basket', L, W (terrain libre, m),
               dxf: { fid, name, units, layers: [{ name, n }], hidden: [] },
               image: { fid, name, widthM, pw, ph } }
   Terrains dessinés aux cotes officielles ; plans DXF (DWG à enregistrer en DXF) ; image de plan à l'échelle.
   ===================================================================== */
const COURTS = [
  ['basket', 'Basket (FIBA 28 × 15)'], ['basket3x3', 'Basket 3×3 (15 × 11)'], ['volley', 'Volley (18 × 9)'], ['beach', 'Beach volley (16 × 8)'],
  ['hand', 'Handball (40 × 20)'], ['futsal', 'Futsal (40 × 20)'], ['foot', 'Football (105 × 68)'], ['rugby', 'Rugby (100 × 70 + en-buts)'],
  ['tennis', 'Tennis (23,77 × 10,97)'], ['padel', 'Padel (20 × 10)'], ['custom', 'Rectangle libre']
];
const venueCache = { dxf: {}, img: {} };
/* Zone libre autour des lignes (m) : [côtés, fonds] — limite de l'aire de jeu où l'on pose le boarding */
const COURT_RUN = { basket: [2, 2], basket3x3: [2, 2], volley: [3, 3], beach: [3, 3], hand: [1, 2], futsal: [1, 2], foot: [3, 5], rugby: [5, 5], tennis: [3.66, 6.4], padel: [0.5, 0.5], custom: [2, 2] };
const COURT_SURR = { basket: '#8a5a2b', basket3x3: '#2b2f36', volley: '#2f6fb3', beach: '#e9d39b', hand: '#24508f', futsal: '#1f6b4a', foot: '#2f7a36', rugby: '#2f7a36', tennis: '#3c7d5a', padel: '#1f3f73', custom: '#2a343c' };
function courtRun(V) { const d = COURT_RUN[V.court] || [2, 2]; return { side: V.runS != null && V.runS !== '' ? num(V.runS) : d[0], end: V.runE != null && V.runE !== '' ? num(V.runE) : d[1] }; }

/* ---------- Terrains (mètres, centre = 0, x = longueur, y = largeur) ---------- */
function courtShapes(type, L0, W0) {
  const fills = [], lines = [], dash = [];
  const rect = (x0, y0, x1, y1) => [[x0, y0], [x1, y0], [x1, y1], [x0, y1], [x0, y0]];
  const arc = (cx, cy, r, a0, a1, n = 40) => { const o = []; for (let i = 0; i <= n; i++) { const a = (a0 + (a1 - a0) * i / n) * Math.PI / 180; o.push([cx + r * Math.cos(a), cy + r * Math.sin(a)]); } return o; };
  const circle = (cx, cy, r) => arc(cx, cy, r, 0, 360, 64);
  const both = (fn) => { fn(1); fn(-1); }; // symétrie des deux moitiés
  const fill = (pts, color) => fills.push({ pts, color });
  let L, W;
  switch (type) {
    case 'basket': {
      L = 28; W = 15; fill(rect(-16, -9.5, 16, 9.5), '#8a5a2b'); fill(rect(-14, -7.5, 14, 7.5), '#d9a465');
      lines.push(rect(-14, -7.5, 14, 7.5), [[0, -7.5], [0, 7.5]], circle(0, 0, 1.8));
      both((s) => {
        const bx = s * (14 - 1.575); fill(rect(s * 14, -2.45, s * 8.2, 2.45), '#b5472f');
        lines.push(rect(s * 14, -2.45, s * 8.2, 2.45), circle(s * 8.2, 0, 1.8));
        const fm = Math.asin(6.6 / 6.75) * 180 / Math.PI; const dx = Math.sqrt(6.75 * 6.75 - 6.6 * 6.6);
        lines.push([[s * 14, 6.6], [bx - s * dx, 6.6]], [[s * 14, -6.6], [bx - s * dx, -6.6]]);
        lines.push(s > 0 ? arc(bx, 0, 6.75, 180 - fm, 180 + fm) : arc(bx, 0, 6.75, -fm, fm));
        lines.push(s > 0 ? arc(bx, 0, 1.25, 90, 270, 24) : arc(bx, 0, 1.25, -90, 90, 24), [[s * 12.8, -0.9], [s * 12.8, 0.9]]);
      });
      break;
    }
    case 'basket3x3': {
      L = 11; W = 15; fill(rect(-7.5, -9.5, 7.5, 9.5), '#2b2f36'); fill(rect(-5.5, -7.5, 5.5, 7.5), '#e2a33b');
      lines.push(rect(-5.5, -7.5, 5.5, 7.5)); const bx = 5.5 - 1.575; fill(rect(5.5, -2.45, -0.3, 2.45), '#2f6fb3');
      lines.push(rect(5.5, -2.45, -0.3, 2.45), arc(-0.3, 0, 1.8, 90, 270, 24));
      const fm = Math.asin(6.6 / 6.75) * 180 / Math.PI; const dx = Math.sqrt(6.75 * 6.75 - 6.6 * 6.6);
      lines.push([[5.5, 6.6], [bx - dx, 6.6]], [[5.5, -6.6], [bx - dx, -6.6]], arc(bx, 0, 6.75, 180 - fm, 180 + fm), arc(bx, 0, 1.25, 90, 270, 24), [[4.3, -0.9], [4.3, 0.9]]);
      break;
    }
    case 'volley': L = 18; W = 9; fill(rect(-12, -7.5, 12, 7.5), '#2f6fb3'); fill(rect(-9, -4.5, 9, 4.5), '#e0823a'); lines.push(rect(-9, -4.5, 9, 4.5), [[0, -5.5], [0, 5.5]], [[3, -4.5], [3, 4.5]], [[-3, -4.5], [-3, 4.5]]); dash.push([[3, -7.5], [3, -4.5]], [[3, 4.5], [3, 7.5]], [[-3, -7.5], [-3, -4.5]], [[-3, 4.5], [-3, 7.5]]); break;
    case 'beach': L = 16; W = 8; fill(rect(-11, -7, 11, 7), '#e9d39b'); lines.push(rect(-8, -4, 8, 4)); dash.push([[0, -5], [0, 5]]); break;
    case 'hand': case 'futsal': {
      L = 40; W = 20; const hand = type === 'hand'; fill(rect(-22, -12, 22, 12), hand ? '#24508f' : '#1f6b4a'); fill(rect(-20, -10, 20, 10), hand ? '#3b78c9' : '#2f8f62');
      lines.push(rect(-20, -10, 20, 10), [[0, -10], [0, 10]], circle(0, 0, 3));
      both((s) => {
        const gx = s * 20; const a = (c0, c1) => (s > 0 ? arc(gx, c0, 6, c1 > 0 ? 90 : 180, c1 > 0 ? 180 : 270) : arc(gx, c0, 6, c1 > 0 ? 0 : -90, c1 > 0 ? 90 : 0));
        const r9 = (c0, up) => (s > 0 ? arc(gx, c0, 9, up ? 90 : 180, up ? 180 : 270) : arc(gx, c0, 9, up ? 0 : -90, up ? 90 : 0));
        if (hand) { const up = s > 0 ? a(1.5, 1) : a(1.5, 1).reverse(), lo = s > 0 ? a(-1.5, -1) : a(-1.5, -1).reverse(); fill([...up, ...lo], '#e8b04a'); lines.push(a(1.5, 1), a(-1.5, -1), [[s * 14, -1.5], [s * 14, 1.5]], [[s * 13, -0.5], [s * 13, 0.5]]); dash.push(r9(1.5, true).filter((q) => Math.abs(q[1]) <= 10), r9(-1.5, false).filter((q) => Math.abs(q[1]) <= 10), [[s * 11, -1.5], [s * 11, 1.5]]); }
        else { lines.push(a(1.5, 1), a(-1.5, -1), [[s * 14, -1.5], [s * 14, 1.5]], circle(s * 14, 0, 0.1), circle(s * 10, 0, 0.1)); }
        lines.push(rect(gx, -1.5, gx + s * 1, 1.5));
      });
      break;
    }
    case 'foot': {
      L = 105; W = 68; fill(rect(-56.5, -38, 56.5, 38), '#2f7a36'); for (let i = 0; i < 10; i++) fill(rect(-52.5 + i * 10.5, -34, -52.5 + (i + 1) * 10.5, 34), i % 2 ? '#3a8a40' : '#34823a');
      lines.push(rect(-52.5, -34, 52.5, 34), [[0, -34], [0, 34]], circle(0, 0, 9.15), circle(0, 0, 0.15));
      both((s) => {
        const gx = s * 52.5; lines.push(rect(gx, -20.16, s * 36, 20.16), rect(gx, -9.16, s * 47, 9.16), circle(s * 41.5, 0, 0.15), rect(gx, -3.66, s * 54.5, 3.66));
        const am = Math.acos(5.5 / 9.15) * 180 / Math.PI; lines.push(s > 0 ? arc(41.5, 0, 9.15, 180 - am, 180 + am) : arc(-41.5, 0, 9.15, -am, am));
        lines.push(s > 0 ? arc(52.5, 34, 1, 180, 270, 12) : arc(-52.5, 34, 1, 270, 360, 12), s > 0 ? arc(52.5, -34, 1, 90, 180, 12) : arc(-52.5, -34, 1, 0, 90, 12));
      });
      break;
    }
    case 'rugby': {
      L = 120; W = 70; fill(rect(-64, -39, 64, 39), '#2f7a36'); fill(rect(-50, -35, 50, 35), '#3a8a40');
      lines.push(rect(-60, -35, 60, 35), [[0, -35], [0, 35]]);
      both((s) => { lines.push([[s * 50, -35], [s * 50, 35]], [[s * 28, -35], [s * 28, 35]], [[s * 60, -35], [s * 60, 35]]); dash.push([[s * 10, -35], [s * 10, 35]], [[s * 45, -35], [s * 45, 35]], [[-45, s * 30], [45, s * 30]], [[-45, s * 20], [45, s * 20]]); lines.push([[s * 50, -2.8], [s * 52, -2.8]], [[s * 50, 2.8], [s * 52, 2.8]]); });
      break;
    }
    case 'tennis': L = 23.77; W = 10.97; fill(rect(-18.29, -9.14, 18.29, 9.14), '#3c7d5a'); fill(rect(-11.885, -5.485, 11.885, 5.485), '#2d5aa0');
      lines.push(rect(-11.885, -5.485, 11.885, 5.485), [[-11.885, -4.115], [11.885, -4.115]], [[-11.885, 4.115], [11.885, 4.115]], [[-6.4, -4.115], [-6.4, 4.115]], [[6.4, -4.115], [6.4, 4.115]], [[-6.4, 0], [6.4, 0]], [[11.885, 0], [11.785, 0]], [[-11.885, 0], [-11.785, 0]]); dash.push([[0, -6.4], [0, 6.4]]); break;
    case 'padel': L = 20; W = 10; fill(rect(-10, -5, 10, 5), '#2d5aa0'); lines.push(rect(-10, -5, 10, 5), [[-6.95, -5], [-6.95, 5]], [[6.95, -5], [6.95, 5]], [[-6.95, 0], [6.95, 0]]); dash.push([[0, -5], [0, 5]]); break;
    default: L = Math.max(1, num(L0) || 40); W = Math.max(1, num(W0) || 20); fill(rect(-L / 2, -W / 2, L / 2, W / 2), '#3a4650'); lines.push(rect(-L / 2, -W / 2, L / 2, W / 2), [[0, -W / 2], [0, W / 2]]);
  }
  return { L, W, fills, lines, dash };
}

/* ---------- Données & transformation ---------- */
function venueCfg(p) { if (!p.implant || typeof p.implant !== 'object') p.implant = { kind: 'none', x: 0, y: 0, rot: 0, opacity: 0.85, court: 'basket' }; return p.implant; }
const venueT = (V) => { const th = num(V.rot) * Math.PI / 180, c = Math.cos(th), s = Math.sin(th); return ([x, y]) => [num(V.x) + x * c - y * s, num(V.y) + x * s + y * c]; };
/* Primitives en coordonnées de la scène (mm) : { fills, lines, dash, image } */
function venuePrims(p) {
  const V = p.implant; if (!V || V.kind === 'none') return null; const T = venueT(V);
  if (V.kind === 'court') { const C = courtShapes(V.court, V.L, V.W); const R = courtRun(V); const m = (pts) => pts.map(([x, y]) => T([x * 1000, y * 1000]));
    const ex = C.L / 2 + R.end, ey = C.W / 2 + R.side; const surr = { pts: [[-ex, -ey], [ex, -ey], [ex, ey], [-ex, ey]], color: COURT_SURR[V.court] || '#2a343c' };
    const own = C.fills.length > 1 ? C.fills.slice(1) : C.fills; C.fills = [surr, ...own]; return { fills: C.fills.map((f) => ({ pts: m(f.pts), color: f.color })), lines: C.lines.map(m), dash: C.dash.map(m), lineColor: V.court === 'beach' ? '#1e63c6' : '#ffffff' }; }
  if (V.kind === 'dxf' && V.dxf) { const D = venueCache.dxf[V.dxf.fid]; if (!D) return { fills: [], lines: [], dash: [], missing: !venueCache.dxf.hasOwnProperty(V.dxf.fid) ? 'loading' : 'absent' }; const hid = new Set(V.dxf.hidden || []); const f = D.factor * (num(V.dxf.scale) || 1); const out = []; D.layers.forEach((ly) => { if (!hid.has(ly.name)) ly.polys.forEach((pl) => { const o = []; for (let i = 0; i < pl.length; i += 2) o.push(T([(pl[i] - D.cx) * f, -(pl[i + 1] - D.cy) * f])); out.push(o); }); }); return { fills: [], lines: out, dash: [], lineColor: '#cfe3ee', thin: true }; }
  if (V.kind === 'image' && V.image) { const im = venueCache.img[V.image.fid]; const w = num(V.image.widthM) * 1000 || 20000; const h = w * (num(V.image.ph) || 1) / (num(V.image.pw) || 1); const corners = [[-w / 2, -h / 2], [w / 2, -h / 2], [w / 2, h / 2], [-w / 2, h / 2]].map(T); return { fills: [], lines: [], dash: [], image: im ? { im, corners, w, h } : null, missing: im ? null : 'absent' }; }
  return null;
}
function venueBounds(p) {
  const P = venuePrims(p); if (!P) return null; const pts = [...P.fills.flatMap((f) => f.pts), ...P.lines.flat(), ...(P.image ? P.image.corners : [])]; if (!pts.length) return null;
  return { mnX: Math.min(...pts.map((q) => q[0])), mxX: Math.max(...pts.map((q) => q[0])), mnZ: Math.min(...pts.map((q) => q[1])), mxZ: Math.max(...pts.map((q) => q[1])) };
}
async function venueEnsureLoaded(p) {
  const V = p.implant; if (!V) return false; let changed = false;
  if (V.kind === 'dxf' && V.dxf && !venueCache.dxf.hasOwnProperty(V.dxf.fid)) { const rec = await visGet(V.dxf.fid); const D = rec ? JSON.parse(await rec.blob.text()) : null; if (D) D.factor = unitFactor(V.dxf.units); venueCache.dxf[V.dxf.fid] = D; changed = true; }
  if (V.kind === 'image' && V.image && !venueCache.img[V.image.fid]) { const rec = await visGet(V.image.fid); if (rec) { const url = await new Promise((res) => { const fr = new FileReader(); fr.onload = () => res(fr.result); fr.readAsDataURL(rec.blob); }); const el = new Image(); el.src = url; await el.decode().catch(() => {}); venueCache.img[V.image.fid] = { url, el }; changed = true; } }
  return changed;
}

/* ---------- Dessin : vue de dessus (SVG) ---------- */
function venueSVG(p, S) {
  const P = venuePrims(p); if (!P) return ''; const V = p.implant; const op = num(V.opacity) || 0.85; let s = `<g opacity="${op}" pointer-events="none">`;
  P.fills.forEach((f) => { s += `<polygon points="${f.pts.map((q) => q.join(',')).join(' ')}" fill="${f.color}"/>`; });
  if (P.image) { const [a, b, , d] = P.image.corners; const ang = Math.atan2(b[1] - a[1], b[0] - a[0]) * 180 / Math.PI; s += `<image href="${P.image.im.url}" x="0" y="0" width="${P.image.w}" height="${P.image.h}" preserveAspectRatio="none" transform="translate(${a[0]},${a[1]}) rotate(${ang})"/>`; }
  const lw = P.thin ? S * 0.8 : Math.max(S * 1.2, 50);
  P.lines.forEach((l) => { s += `<polyline points="${l.map((q) => q.join(',')).join(' ')}" fill="none" stroke="${P.lineColor}" stroke-width="${lw}" stroke-linejoin="round"/>`; });
  P.dash.forEach((l) => { s += `<polyline points="${l.map((q) => q.join(',')).join(' ')}" fill="none" stroke="${P.lineColor}" stroke-width="${lw}" stroke-dasharray="${300},${250}"/>`; });
  return s + '</g>';
}
/* ---------- Dessin : 3D (au sol) ---------- */
function venue3D(ctx, p, P3) {
  const P = venuePrims(p); if (!P) return; const V = p.implant; ctx.save(); ctx.globalAlpha = num(V.opacity) || 0.85;
  const pr = ([x, z]) => P3([x, 0, z]);
  P.fills.forEach((f) => { const q = f.pts.map(pr); ctx.beginPath(); q.forEach((pt, i) => (i ? ctx.lineTo(pt[0], pt[1]) : ctx.moveTo(pt[0], pt[1]))); ctx.closePath(); ctx.fillStyle = f.color; ctx.fill(); });
  if (P.image) groundImage(ctx, P.image.im.el, P.image.corners.map(pr), 14);
  ctx.strokeStyle = P.lineColor; ctx.lineWidth = P.thin ? 0.7 : 1.5; ctx.lineJoin = 'round';
  const poly = (l) => { ctx.beginPath(); l.map(pr).forEach((pt, i) => (i ? ctx.lineTo(pt[0], pt[1]) : ctx.moveTo(pt[0], pt[1]))); ctx.stroke(); };
  P.lines.forEach(poly); ctx.setLineDash([5, 4]); P.dash.forEach(poly); ctx.setLineDash([]); ctx.restore();
}
/* Image plaquée au sol en perspective : maillage de triangles en transformation affine */
function groundImage(ctx, img, q, n) {
  const iw = img.naturalWidth, ih = img.naturalHeight; if (!iw) return;
  const lerp = (a, b, t) => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t]; const at = (u, v) => lerp(lerp(q[0], q[1], u), lerp(q[3], q[2], u), v);
  const tri = (s0, s1, s2, d0, d1, d2) => {
    ctx.save(); ctx.beginPath(); ctx.moveTo(d0[0], d0[1]); ctx.lineTo(d1[0], d1[1]); ctx.lineTo(d2[0], d2[1]); ctx.closePath(); ctx.clip();
    const den = (s1[0] - s0[0]) * (s2[1] - s0[1]) - (s2[0] - s0[0]) * (s1[1] - s0[1]); if (!den) { ctx.restore(); return; }
    const a = ((d1[0] - d0[0]) * (s2[1] - s0[1]) - (d2[0] - d0[0]) * (s1[1] - s0[1])) / den, b = ((d1[1] - d0[1]) * (s2[1] - s0[1]) - (d2[1] - d0[1]) * (s1[1] - s0[1])) / den;
    const c = ((d2[0] - d0[0]) * (s1[0] - s0[0]) - (d1[0] - d0[0]) * (s2[0] - s0[0])) / den, d = ((d2[1] - d0[1]) * (s1[0] - s0[0]) - (d1[1] - d0[1]) * (s2[0] - s0[0])) / den;
    ctx.transform(a, b, c, d, d0[0] - a * s0[0] - c * s0[1], d0[1] - b * s0[0] - d * s0[1]); ctx.drawImage(img, 0, 0); ctx.restore();
  };
  for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) {
    const u0 = i / n, u1 = (i + 1) / n, v0 = j / n, v1 = (j + 1) / n; const S = (u, v) => [u * iw, v * ih];
    const A = at(u0, v0), B = at(u1, v0), C = at(u1, v1), D = at(u0, v1);
    tri(S(u0, v0), S(u1, v0), S(u1, v1), A, B, C); tri(S(u0, v0), S(u1, v1), S(u0, v1), A, C, D);
  }
}

/* ---------- Lecture DXF (ASCII) ---------- */
function parseDXF(text) {
  const L = text.split(/\r?\n/); const pairs = []; for (let i = 0; i + 1 < L.length; i += 2) pairs.push([parseInt(L[i], 10), L[i + 1].trim()]);
  let units = 0; const blocks = {}; const ents = []; let i = 0;
  const readEntity = (k) => { const e = { type: pairs[k][1], c: [] }; k++; while (k < pairs.length && pairs[k][0] !== 0) { e.c.push(pairs[k]); k++; } return [e, k]; };
  while (i < pairs.length) {
    const [c, v] = pairs[i];
    if (c === 9 && v === '$INSUNITS') { units = parseInt(pairs[i + 1][1], 10) || 0; i += 2; continue; }
    if (c === 0 && v === 'SECTION' && pairs[i + 1] && pairs[i + 1][0] === 2) {
      const name = pairs[i + 1][1]; i += 2;
      if (name === 'ENTITIES' || name === 'BLOCKS') {
        let cur = null;
        while (i < pairs.length && !(pairs[i][0] === 0 && pairs[i][1] === 'ENDSEC')) {
          if (pairs[i][0] !== 0) { i++; continue; }
          const [e, k] = readEntity(i); i = k;
          if (name === 'BLOCKS' && e.type === 'BLOCK') { cur = { name: (e.c.find((q) => q[0] === 2) || [])[1], bx: +((e.c.find((q) => q[0] === 10) || [0, 0])[1]), by: +((e.c.find((q) => q[0] === 20) || [0, 0])[1]), ents: [] }; blocks[cur.name] = cur; continue; }
          if (name === 'BLOCKS' && e.type === 'ENDBLK') { cur = null; continue; }
          (name === 'BLOCKS' ? (cur ? cur.ents : []) : ents).push(e);
        }
        continue;
      }
    }
    i++;
  }
  const out = {}; let count = 0; const MAX = 150000;
  const add = (layer, pts) => { if (pts.length < 2 || count > MAX) return; count += pts.length; (out[layer] = out[layer] || []).push(pts); };
  const g = (e, code, d = 0) => { const q = e.c.find((x) => x[0] === code); return q ? parseFloat(q[1]) : d; };
  const all = (e, code) => e.c.filter((x) => x[0] === code).map((x) => parseFloat(x[1]));
  const arcPts = (cx, cy, r, a0, a1) => { if (a1 < a0) a1 += 360; const n = Math.max(8, Math.ceil((a1 - a0) / 6)); const o = []; for (let k = 0; k <= n; k++) { const a = (a0 + (a1 - a0) * k / n) * Math.PI / 180; o.push([cx + r * Math.cos(a), cy + r * Math.sin(a)]); } return o; };
  const bulgePts = (p0, p1, b) => { if (!b) return [p1]; const th = 4 * Math.atan(b); const dx = p1[0] - p0[0], dy = p1[1] - p0[1]; const d = Math.hypot(dx, dy); if (!d) return [p1];
    const h = (d / 2) / Math.tan(th / 2); const cx = (p0[0] + p1[0]) / 2 - (dy / d) * h, cy = (p0[1] + p1[1]) / 2 + (dx / d) * h; const R = Math.hypot(p0[0] - cx, p0[1] - cy); const a0 = Math.atan2(p0[1] - cy, p0[0] - cx);
    const n = Math.max(4, Math.ceil(Math.abs(th) / 0.15)); const o = []; for (let k = 1; k < n; k++) { const a = a0 + th * k / n; o.push([cx + R * Math.cos(a), cy + R * Math.sin(a)]); } o.push(p1); return o; };
  const emit = (list, M, layerIn, depth) => {
    let poly = null;
    list.forEach((e) => {
      const layer = (() => { const l = (e.c.find((q) => q[0] === 8) || [])[1] || '0'; return l === '0' && layerIn ? layerIn : l; })(); const tp = (pts) => pts.map(M);
      switch (e.type) {
        case 'LINE': add(layer, tp([[g(e, 10), g(e, 20)], [g(e, 11), g(e, 21)]])); break;
        case 'LWPOLYLINE': { const xs = all(e, 10), ys = all(e, 20); const bul = []; let vi = -1; e.c.forEach((q) => { if (q[0] === 10) vi++; if (q[0] === 42) bul[vi] = parseFloat(q[1]); }); const closed = (g(e, 70) & 1) === 1; const pts = [[xs[0], ys[0]]]; const n = xs.length; for (let k = 0; k < n - (closed ? 0 : 1); k++) { const p0 = [xs[k], ys[k]], p1 = [xs[(k + 1) % n], ys[(k + 1) % n]]; pts.push(...bulgePts(p0, p1, bul[k] || 0)); } add(layer, tp(pts)); break; }
        case 'POLYLINE': poly = { layer, closed: (g(e, 70) & 1) === 1, skip: (g(e, 70) & 80) !== 0, v: [] }; break;
        case 'VERTEX': if (poly) poly.v.push([g(e, 10), g(e, 20), g(e, 42)]); break;
        case 'SEQEND': if (poly && !poly.skip && poly.v.length) { const v = poly.v; const pts = [[v[0][0], v[0][1]]]; for (let k = 0; k < v.length - (poly.closed ? 0 : 1); k++) pts.push(...bulgePts([v[k][0], v[k][1]], [v[(k + 1) % v.length][0], v[(k + 1) % v.length][1]], v[k][2])); add(poly.layer, tp(pts)); } poly = null; break;
        case 'CIRCLE': add(layer, tp(arcPts(g(e, 10), g(e, 20), g(e, 40), 0, 360))); break;
        case 'ARC': add(layer, tp(arcPts(g(e, 10), g(e, 20), g(e, 40), g(e, 50), g(e, 51)))); break;
        case 'ELLIPSE': { const cx = g(e, 10), cy = g(e, 20), mx = g(e, 11), my = g(e, 21), ra = g(e, 40, 1); let t0 = g(e, 41, 0), t1 = g(e, 42, Math.PI * 2); if (t1 < t0) t1 += Math.PI * 2; const R = Math.hypot(mx, my), a = Math.atan2(my, mx); const n = 48; const o = []; for (let k = 0; k <= n; k++) { const t = t0 + (t1 - t0) * k / n; const x = R * Math.cos(t), y = R * ra * Math.sin(t); o.push([cx + x * Math.cos(a) - y * Math.sin(a), cy + x * Math.sin(a) + y * Math.cos(a)]); } add(layer, tp(o)); break; }
        case 'SPLINE': { let xs = all(e, 11), ys = all(e, 21); if (xs.length < 2) { xs = all(e, 10); ys = all(e, 20); } add(layer, tp(xs.map((x, k) => [x, ys[k]]))); break; }
        case 'INSERT': {
          const b = blocks[(e.c.find((q) => q[0] === 2) || [])[1]]; if (!b || depth > 5) break;
          const ix = g(e, 10), iy = g(e, 20), sx = g(e, 41, 1), sy = g(e, 42, 1), r = g(e, 50, 0) * Math.PI / 180; const cr = Math.cos(r), sr = Math.sin(r);
          const M2 = ([x, y]) => { const lx = (x - b.bx) * sx, ly = (y - b.by) * sy; return M([ix + lx * cr - ly * sr, iy + lx * sr + ly * cr]); };
          emit(b.ents, M2, layer, depth + 1); break;
        }
        default: break;
      }
    });
  };
  emit(ents, (q) => q, null, 0);
  // compactage : tableaux plats arrondis (unités du dessin × 100)
  let mnX = Infinity, mxX = -Infinity, mnY = Infinity, mxY = -Infinity;
  Object.values(out).forEach((ps) => ps.forEach((pl) => pl.forEach(([x, y]) => { if (isFinite(x) && isFinite(y)) { mnX = Math.min(mnX, x); mxX = Math.max(mxX, x); mnY = Math.min(mnY, y); mxY = Math.max(mxY, y); } })));
  const layers = Object.entries(out).map(([name, ps]) => ({ name, polys: ps.map((pl) => pl.flatMap(([x, y]) => [Math.round(x * 100) / 100, Math.round(y * 100) / 100])) })).sort((a, b) => b.polys.length - a.polys.length);
  return { units, layers, cx: (mnX + mxX) / 2, cy: (mnY + mxY) / 2, w: mxX - mnX, h: mxY - mnY, points: count, truncated: count > MAX };
}
const DXF_UNITS = [[4, 'mm', 1], [5, 'cm', 10], [6, 'm', 1000], [1, 'pouce', 25.4], [2, 'pied', 304.8]];
const unitFactor = (u) => (DXF_UNITS.find((x) => x[0] === +u) || [0, '', 1])[2];

/* ---------- Interface (carte dans la vue 3D) ---------- */
function venueCardHTML(p) {
  const V = venueCfg(p); const k = V.kind; const P = venuePrims(p);
  const kinds = [['none', 'Aucune'], ['court', '🏟 Terrain de sport'], ['dxf', '📐 Plan DXF / DWG'], ['image', '🖼 Image de plan']];
  const num3 = (key, label, step, val, w = 90) => `<label class="f">${label}<input type="number" step="${step}" data-venue="${key}" value="${val}" style="width:${w}px"></label>`;
  let body = '';
  if (k === 'court') { const C = courtShapes(V.court, V.L, V.W); body = `<div class="row" style="gap:8px;flex-wrap:wrap;align-items:flex-end"><label class="f">Terrain<select data-venue="court">${COURTS.map(([v, l]) => `<option value="${v}" ${V.court === v ? 'selected' : ''}>${l}</option>`).join('')}</select></label>
      ${V.court === 'custom' ? num3('L', 'Longueur (m)', 0.5, num(V.L) || 40) + num3('W', 'Largeur (m)', 0.5, num(V.W) || 20) : ''}
      ${num3('runS', 'Zone libre côtés (m)', 0.5, courtRun(V).side)}${num3('runE', 'Zone libre fonds (m)', 0.5, courtRun(V).end)}</div>
      <div class="tiny muted" style="margin-top:6px">Terrain ${fmt(C.L, 2)} × ${fmt(C.W, 2)} m · <b>aire de jeu ${fmt(C.L + 2 * courtRun(V).end, 2)} × ${fmt(C.W + 2 * courtRun(V).side, 2)} m</b> (zone libre par défaut du sport, modifiable) — le boarding est posé à la limite de l'aire de jeu.</div>
      ${p.screens.some((x) => isBoard(x) && !x.deco) ? `<div class="row" style="gap:8px;flex-wrap:wrap;align-items:flex-end;margin-top:10px"><label class="f">Boarding sur<select data-venue="boardSides">${BOARD_SIDES.map(([v, l]) => `<option value="${v}" ${(V.boardSides || '4') === v ? 'selected' : ''}>${l}</option>`).join('')}</select></label>${num3('boardGap', 'Recul supplémentaire (m)', 0.1, num(V.boardGap) || 0)}<button class="sm primary" data-act="sceneAroundNow">⬚ Placer le boarding</button></div>` : ''}`; }
  if (k === 'dxf') {
    const D = V.dxf && venueCache.dxf[V.dxf.fid];
    body = `<div class="row" style="gap:8px;flex-wrap:wrap;align-items:flex-end"><button class="sm" data-act="venueDXF">⇪ ${V.dxf ? 'Changer de plan' : 'Importer un plan .dxf'}</button>
      ${V.dxf ? `<span class="small"><b>${esc(V.dxf.name)}</b>${D ? ` · ${fmt(D.w * unitFactor(V.dxf.units) / 1000, 1)} × ${fmt(D.h * unitFactor(V.dxf.units) / 1000, 1)} m` : ''}</span>
      <label class="f">Unités du dessin<select data-venue="units">${DXF_UNITS.map(([u, l]) => `<option value="${u}" ${+V.dxf.units === u ? 'selected' : ''}>${l}</option>`).join('')}</select></label>` : ''}</div>
      ${V.dxf && P && P.missing === 'absent' ? '<div class="alert warn" style="margin-top:8px">Le fichier du plan n\'est pas sur ce PC : réimportez-le.</div>' : ''}
      ${D ? `<div class="tiny muted" style="margin:10px 0 4px">Calques (décochez ce qui encombre : mobilier, cotes…)</div><div class="vn-layers">${D.layers.map((ly) => `<label class="bm-opt"><input type="checkbox" data-venue-layer="${esc(ly.name)}" ${(V.dxf.hidden || []).includes(ly.name) ? '' : 'checked'}><span>${esc(ly.name)} <span class="tiny muted">${ly.polys.length}</span></span></label>`).join('')}</div>${D.truncated ? '<div class="tiny warn-t">Plan très chargé : une partie des éléments n\'est pas affichée.</div>' : ''}` : ''}
      <div class="tiny muted" style="margin-top:8px">Fichier <b>.dwg</b> : ouvrez-le dans AutoCAD ou dans <b>DWG TrueView</b> / <b>ODA File Converter</b> (gratuits) et enregistrez-le en <b>.dxf</b>, puis importez le .dxf ici.</div>`;
  }
  if (k === 'image') body = `<div class="row" style="gap:8px;flex-wrap:wrap;align-items:flex-end"><button class="sm" data-act="venueImg">⇪ ${V.image ? 'Changer d\'image' : 'Importer une image (PNG / JPG)'}</button>
      ${V.image ? `<span class="small"><b>${esc(V.image.name)}</b></span>${num3('widthM', 'Largeur réelle (m)', 0.5, num(V.image.widthM) || 40)}` : ''}</div>${V.image && P && P.missing ? '<div class="alert warn" style="margin-top:8px">L\'image n\'est pas sur ce PC : réimportez-la.</div>' : ''}
      <div class="tiny muted" style="margin-top:6px">Plan PDF : exportez la page en image (PNG) puis importez-la ; indiquez la largeur réelle représentée par l'image.</div>`;
  return `<div class="card" style="margin-bottom:16px"><div class="row" style="justify-content:space-between;flex-wrap:wrap;gap:8px"><h3 style="margin:0">Implantation au sol</h3><div class="seg">${kinds.map(([v, l]) => `<button class="${k === v ? 'on' : ''}" data-act="venueKind" data-v="${v}">${l}</button>`).join('')}</div></div>
    ${k !== 'none' ? `<div style="margin-top:12px">${body}</div>
    <div class="row" style="gap:8px;flex-wrap:wrap;align-items:flex-end;margin-top:12px">${num3('x', 'Centre X (m)', 0.5, fmt3(V.x))}${num3('y', 'Centre profondeur (m)', 0.5, fmt3(V.y))}${num3('rot', 'Rotation (°)', 5, num(V.rot))}
      <label class="f">Opacité<input type="range" min="0.2" max="1" step="0.05" data-venue="opacity" value="${num(V.opacity) || 0.85}" style="width:110px"></label>
      <button class="sm" data-act="venueRot90">↻ 90°</button><button class="sm" data-act="venueCenter">⌖ Centrer devant les écrans</button></div>` : '<div class="tiny muted" style="margin-top:8px">Ajoutez un terrain de sport aux cotes officielles, le plan DXF de la salle ou une image de plan à l\'échelle : ils apparaissent au sol dans la 3D et dans la vue de dessus.</div>'}
  </div>`;
}
function venueDefaultPos(p) {
  const V = venueCfg(p); const objs = sceneObjects(p); let mxZ = 0, cx = 0;
  if (objs.length) { const B = (() => { let a = -Infinity, s = 0, n = 0; objs.forEach((o) => { const W = objW(o); objLocal(o).grid.flat().forEach((q) => { const w = W(q); a = Math.max(a, w[2]); s += w[0]; n++; }); }); return { mxZ: a, cx: s / n }; })(); mxZ = B.mxZ; cx = B.cx; }
  let half = 10000; if (V.kind === 'court') { const C = courtShapes(V.court, V.L, V.W); half = (num(V.rot) % 180 ? C.L + 2 * courtRun(V).end : C.W + 2 * courtRun(V).side) * 500; } else if (V.kind === 'image' && V.image) half = num(V.image.widthM) * 500 * (V.image.ph / V.image.pw); else if (V.kind === 'dxf' && V.dxf && venueCache.dxf[V.dxf.fid]) half = venueCache.dxf[V.dxf.fid].h * unitFactor(V.dxf.units) / 2;
  V.x = Math.round(cx / 100) * 100; V.y = Math.round((V.kind === 'court' ? mxZ + 3000 + half : mxZ + half - 3000) / 100) * 100; // plan de salle : les écrans au fond de la salle
}
const venueActions = {
  sceneAroundNow() { const p = curProject(); p.screens.filter((x) => isBoard(x) && !x.deco).forEach((s) => arrangeAroundPitch(s, p)); Store.save(); render(); toast('Boarding placé à la limite de l\'aire de jeu ✔'); },
  venueKind(el) { const p = curProject(); const V = venueCfg(p); const was = V.kind; V.kind = el.dataset.v; if (V.kind !== 'none' && (was === 'none' || !V.placed)) { venueDefaultPos(p); V.placed = true; } Store.save(); render(); },
  venueRot90() { const p = curProject(); const V = venueCfg(p); V.rot = (num(V.rot) + 90) % 360; Store.save(); render(); },
  venueCenter() { const p = curProject(); venueDefaultPos(p); Store.save(); render(); },
  async venueDXF() {
    const files = await new Promise((res) => { const i = document.createElement('input'); i.type = 'file'; i.accept = '.dxf,.dwg'; i.onchange = () => res([...i.files]); i.click(); }); if (!files.length) return;
    const f = files[0]; if (/\.dwg$/i.test(f.name)) { toast('Fichier DWG : enregistrez-le d\'abord en DXF (AutoCAD, DWG TrueView ou ODA File Converter, gratuits)', 'warn'); return; }
    toast('Lecture du plan…'); let D;
    try { const txt = await f.text(); if (!/SECTION/.test(txt.slice(0, 4000))) throw new Error('DXF binaire ou fichier non reconnu : enregistrez en DXF « ASCII »'); D = parseDXF(txt); } catch (e) { return toast('Plan illisible : ' + e.message, 'bad'); }
    if (!D.layers.length) return toast('Aucun tracé trouvé dans ce DXF', 'warn');
    const units = D.units && unitFactor(D.units) ? D.units : (D.w > 2000 ? 4 : D.w > 200 ? 5 : 6); D.factor = 1;
    const fid = uid('dxf'); await visPut({ id: fid, name: f.name, kind: 'dxf', blob: new Blob([JSON.stringify(D)], { type: 'application/json' }) }); venueCache.dxf[fid] = D;
    const p = curProject(); const V = venueCfg(p); V.kind = 'dxf'; V.dxf = { fid, name: f.name, units, layers: D.layers.map((l) => ({ name: l.name, n: l.polys.length })), hidden: [] }; D.factor = unitFactor(units);
    venueDefaultPos(p); V.placed = true; Store.save(); render(); toast(`Plan importé : ${D.layers.length} calque(s)`);
  },
  async venueImg() {
    const files = await new Promise((res) => { const i = document.createElement('input'); i.type = 'file'; i.accept = 'image/png,image/jpeg,image/webp'; i.onchange = () => res([...i.files]); i.click(); }); if (!files.length) return;
    const f = files[0]; const meta = await readMedia(f); if (!meta || meta.kind !== 'img') return toast('Image illisible', 'bad');
    const fid = uid('vimg'); await visPut({ id: fid, name: f.name, kind: 'img', blob: f, w: meta.w, h: meta.h });
    const p = curProject(); const V = venueCfg(p); V.kind = 'image'; V.image = { fid, name: f.name, widthM: (V.image && V.image.widthM) || 40, pw: meta.w, ph: meta.h }; delete venueCache.img[fid];
    await venueEnsureLoaded(p); venueDefaultPos(p); V.placed = true; Store.save(); render();
  }
};
function venueChange(t) {
  if (!t.dataset.venue && t.dataset.venueLayer === undefined) return false; const p = curProject(); if (!p) return true; const V = venueCfg(p);
  if (t.dataset.venueLayer !== undefined) { const h = new Set(V.dxf.hidden || []); if (t.checked) h.delete(t.dataset.venueLayer); else h.add(t.dataset.venueLayer); V.dxf.hidden = [...h]; }
  else { const k = t.dataset.venue; if (k === 'court') { V.court = t.value; V.runS = null; V.runE = null; } else if (k === 'boardSides') V.boardSides = t.value; else if (k === 'runS' || k === 'runE') V[k] = Math.max(0, num(t.value)); else if (k === 'x' || k === 'y') V[k] = Math.round(num(t.value) * 1000); else if (k === 'units') { V.dxf.units = +t.value; const D = venueCache.dxf[V.dxf.fid]; if (D) D.factor = unitFactor(V.dxf.units); } else if (k === 'widthM') V.image.widthM = Math.max(0.5, num(t.value)); else V[k] = num(t.value); }
  Store.save(); const y = $main().scrollTop; render(); $main().scrollTop = y; return true;
}
