/* =====================================================================
   AGENDA DES TECHNICIENS — le relais Google crée les événements dans un agenda
   « Impulsion – Bookings techniciens » et invite le technicien par email :
   l'événement apparaît dans son Google Agenda (ou Outlook / iCloud) et suit
   les changements (option → validé, dates, levée d'option, retrait).
   ===================================================================== */
const calState = { busy: false, timer: null, again: false, last: null, error: null, check: null };
const calMode = () => Store.db.settings.calSync || 'off';
const calEnabled = () => replyActive() && (calMode() === 'valide' || calMode() === 'all');
/* Événements terminés : figés, on n'y touche plus jamais (ni mise à jour, ni suppression → aucun mail) */
const calPast = (dates) => !!(dates && dates.length) && [...dates].sort().pop() < todayISO();
const calHash = (d) => (d ? d.key || JSON.stringify(d) : '');
const validEmail = (e) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(e || '').trim());

/* Ce que l'agenda du technicien doit contenir pour cette demande (null = rien) */
function calWanted(p, r) {
  const wanted = calMode() === 'all' ? ['option', 'valide'] : ['valide'];
  return wanted.includes(r.status) && !r.released && p.status !== 'annule' && r.dates.length > 0;
}
function calDesired(p, r) {
  if (!calEnabled() || !calWanted(p, r)) return null;
  const t = getTech(r.techId); if (!t || !validEmail(t.email)) return null;
  const st = Store.db.settings; const opt = r.status === 'option';
  const rm = p.roadmap || {}; const link = typeof rmLink === 'function' ? rmLink(p) : '';
  const loc = String(rm.address || '').replace(/\s*\n+\s*/g, ', ') || p.venue || '';
  const desc = [
    `${st.company} — ${opt ? 'OPTION (pas encore confirmé)' : 'Booking confirmé'}`,
    `Projet : ${p.name}${p.client ? ' · ' + p.client : ''}`,
    r.role ? `Poste : ${r.role}` : '',
    hoursShort(r) ? `Horaires : ${hoursShort(r)}` : '',
    `Dates : ${fmtDays(r.dates)}`,
    link ? `Feuille de route : ${link}` : '',
    '', 'Événement géré automatiquement par Impulsion Prod.'
  ].filter((x, i, a) => x || i >= a.length - 2).join('\n');
  let full = desc;
  // sans la liste d'équipe : la réponse d'un autre technicien ne doit pas modifier (ni notifier) cet événement
  if (st.calRoadmap === true && p.roadmap) { full = `${desc}\n\n━━━━━━━━━━━━━━━━\n${roadmapText(p, { noCrew: true })}`; if (full.length > 7500) full = full.slice(0, 7400) + '\n…\n(voir la feuille de route complète)'; }
  const d = { email: t.email.trim(), title: `${opt ? '🟦 OPTION — ' : '✅ '}${p.name}${r.role ? ' · ' + r.role : ''}`, location: loc, description: full,
    runs: dayRuns(r.dates).map(([a, b]) => [a, addDays(b, 1)]) };
  // clé de mise à jour : uniquement ce qui concerne le technicien (dates, horaires, poste, lieu, statut) — pas le contenu de la feuille de route
  d.key = JSON.stringify({ e: d.email, t: d.title, l: d.location, r: d.runs, h: desc }); return d;
}

const calGroup = () => Store.db.settings.calGroup !== 'tech';
/* Un événement par projet : on découpe par périodes où l'équipe présente est identique */
function calProjectDesired(p) {
  if (!calEnabled() || p.status === 'annule') return null;
  const st = Store.db.settings;
  const members = p.crew.filter((r) => calWanted(p, r)).map((r) => ({ r, t: getTech(r.techId) })).filter((m) => m.t && validEmail(m.t.email));
  if (!members.length) return null;
  const mail = (m) => m.t.email.trim().toLowerCase();
  const on = (d) => members.filter((m) => m.r.dates.includes(d));
  const key = (d) => [...new Set(on(d).map(mail))].sort().join(',');
  const days = [...new Set(members.flatMap((m) => m.r.dates))].sort();
  const runs = []; days.forEach((d) => { const last = runs[runs.length - 1]; if (last && addDays(last.end, 1) === d && last.key === key(d)) last.end = d; else runs.push({ start: d, end: d, key: key(d) }); });
  const rm = p.roadmap || {}; const link = typeof rmLink === 'function' ? rmLink(p) : '';
  const loc = String(rm.address || '').replace(/\s*\n+\s*/g, ', ') || p.venue || '';
  const extra = st.calRoadmap === true && p.roadmap ? `\n\n━━━━━━━━━━━━━━━━\n${roadmapText(p)}` : '';
  const evs = runs.map((run) => {
    const ms = on(run.start); const seen = new Set(); const uniq = ms.filter((m) => { const k = mail(m); if (seen.has(k)) return false; seen.add(k); return true; });
    const valid = uniq.some((m) => m.r.status === 'valide'); const nOpt = uniq.filter((m) => m.r.status === 'option').length;
    const team = uniq.map((m) => `${m.r.status === 'option' ? '🟦 OPTION — ' : '✅ '}${techName(m.t)}${m.r.role ? ' — ' + m.r.role : ''}${hoursShort(m.r) ? ' · 🕐 ' + hoursShort(m.r) : ''}${m.r.dates.length && fmtDays(m.r.dates) !== fmtDays(rangeDays(run.start, run.end)) ? ' (' + fmtDays(m.r.dates) + ')' : ''}`);
    const base = [`${st.company} — ${p.name}${p.client ? ' · ' + p.client : ''}`, `Dates : ${fmtDays(rangeDays(run.start, run.end))}`, '', `Équipe (${uniq.length}) :`, ...team,
      link ? `\nFeuille de route : ${link}` : '', '', 'Événement géré automatiquement par Impulsion Prod.'].join('\n').replace(/\n{3,}/g, '\n\n'); let desc = base + extra;
    if (desc.length > 7500) desc = desc.slice(0, 7400) + '\n…\n(voir la feuille de route complète)';
    return { title: `${valid ? '✅ ' : '🟦 OPTION — '}${p.name} · ${uniq.length} tech.${valid && nOpt ? ` (${nOpt} en option)` : ''}`, description: desc, location: loc,
      start: run.start, end: addDays(run.end, 1), guests: uniq.map((m) => m.t.email.trim()), _base: base };
  }) ; const out = { events: evs.map(({ _base, ...x }) => x) }; out.key = JSON.stringify(evs.map((x) => [x.title, x.location, x.start, x.end, x.guests, x._base])); return out;
}
function scheduleCalSync() {
  if (!replyActive()) return;
  if (typeof isAutoLeader === 'function' && !isAutoLeader()) return;
  const pub = Store.db.projects.some((p) => p.roadmap && p.roadmap.publishedAt);
  if (!calEnabled() && !(Store.db.calTrash || []).length && !pub) return;
  clearTimeout(calState.timer); calState.timer = setTimeout(() => syncCalendars(false), 4000);
}
async function syncCalendars(manual) {
  if (!manual && typeof isAutoLeader === 'function' && !isAutoLeader()) return;
  if (!replyActive()) { if (manual) toast('Activez d\'abord le relais Google', 'warn'); return; }
  if (calState.busy) { calState.again = true; return; }
  calState.busy = true; let changed = false;
  try {
    // 1) feuilles de route publiées : la version en ligne suit automatiquement le projet
    for (const p of Store.db.projects) {
      const rm = p.roadmap; if (!rm || !rm.publishedAt || !rm.token) continue;
      try { if (roadmapHash(p) !== rm.pubHash) { await publishRoadmap(p); changed = true; } } catch (e) { calState.pubError = e.message; }
    }
    // 2) agendas des techniciens
    const items = []; const map = new Map();
    // changement de mode : on retire les événements de l'autre mode
    Store.db.calTrash = Store.db.calTrash || [];
    Store.db.projects.forEach((p) => {
      if (calGroup()) p.crew.forEach((r) => { if (r.cal && (r.cal.ids || []).length) { if (!calPast(r.dates)) Store.db.calTrash.push(...r.cal.ids); r.cal = { hash: '', ids: [] }; } });
      else if (p.cal && (p.cal.ids || []).length) { if (!calPast(projectCalDays(p))) Store.db.calTrash.push(...p.cal.ids); p.cal = { hash: '', ids: [] }; }
    });
    calQuietMigration();
    if (calEnabled() && calGroup()) {
      if (replyState.version && replyState.version < 8) throw new Error('Le script Google doit être mis à jour (v8) pour regrouper l\'équipe dans un seul événement.');
      Store.db.projects.forEach((p) => {
        if (calPast(projectCalDays(p))) return; // projet terminé : figé
        const d = calProjectDesired(p); const h = calHash(d); const cur = p.cal || { hash: '', ids: [] };
        if (cur.hash === h && !(manual && p.calError)) return;
        if (!d && !(cur.ids || []).length) { if (cur.hash !== h) p.cal = { hash: h, ids: [] }; return; }
        items.push({ id: 'p:' + p.id, desired: d, ids: cur.ids || [] }); map.set('p:' + p.id, { p, h });
      });
    }
    if (calEnabled() && !calGroup()) Store.db.projects.forEach((p) => p.crew.forEach((r) => {
      if (calPast(r.dates)) return; // booking terminé : figé
      const d = calDesired(p, r); const h = calHash(d);
      const cur = r.cal || { hash: '', ids: [] };
      if (cur.hash === h && !(manual && r.calError)) return;
      if (!d && !(cur.ids || []).length) { if (cur.hash !== h) r.cal = { hash: h, ids: [] }; return; }
      items.push({ id: r.id, desired: d, ids: cur.ids || [] }); map.set(r.id, { r, h });
    }));
    const trash = (Store.db.calTrash || []).slice();
    if (trash.length) items.push({ id: '__trash', desired: null, ids: trash });
    if (!items.length) { if (manual) toast('Agendas déjà à jour ✔'); return; }
    const j = await withTimeout(remotePost({ action: 'cal', key: ensureReplyKey(), items }), 90000);
    let ok = 0, ko = 0; changed = true;
    (j.results || []).forEach((res) => {
      if (res.id === '__trash') { if (!res.error) Store.db.calTrash = (Store.db.calTrash || []).filter((x) => !trash.includes(x)); return; }
      const m = map.get(res.id); if (!m) return;
      const tgt = m.p || m.r;
      if (res.error) { tgt.calError = res.error; ko++; } else { tgt.cal = { hash: m.h, ids: res.ids || [] }; delete tgt.calError; ok++; }
    });
    calState.last = Date.now(); calState.error = null; replyState.version = j.version || replyState.version;
    Store.save();
    if (manual || ko) toast(`📅 Agendas : ${ok} mis à jour${ko ? `, ${ko} en erreur` : ''}`, ko ? 'warn' : '');
  } catch (e) {
    calState.error = e.message || String(e); changed = true;
    if (/Action inconnue|introuvable/i.test(calState.error)) calState.error = 'Le script Google n\'est pas à jour : copiez le nouveau code, Ctrl+S, puis Gérer les déploiements → ✏️ → Nouvelle version.';
    if (manual) toast('📅 ' + calState.error, 'bad');
  } finally {
    calState.busy = false;
    const modalOpen = !document.getElementById('modal').classList.contains('hidden');
    const typing = document.activeElement && ['INPUT', 'TEXTAREA', 'SELECT'].includes(document.activeElement.tagName);
    if (changed && !modalOpen && !typing && ['project', 'roadmap'].includes(ui.view) || (manual && ui.view === 'team')) { const y = $main().scrollTop; render(); $main().scrollTop = y; }
    if (calState.again) { calState.again = false; scheduleCalSync(); }
  }
}
/* Chaque enregistrement relance (en différé) la synchronisation des agendas */
(function hookSave() { const save = Store.save.bind(Store); Store.save = function () { save(); scheduleCalSync(); }; setTimeout(() => { if (Store.db) scheduleCalSync(); }, 6000); })();

function calTrashReq(r) { if (r && r.cal && (r.cal.ids || []).length && !calPast(r.dates)) { Store.db.calTrash = (Store.db.calTrash || []).concat(r.cal.ids); } }

/* Pastille dans le tableau de l'équipe */
function calCell(p, r) {
  if (!calEnabled() || !calWanted(p, r)) return '';
  const t = getTech(r.techId);
  if (!t || !validEmail(t.email)) return '<div class="tiny" style="margin-top:3px"><span class="tag warn" title="Ajoutez son email dans sa fiche (menu Équipe)">📅 pas d\'email</span></div>';
  if (calGroup()) {
    if (p.calError) return `<div class="tiny" style="margin-top:3px;color:var(--bad)">📅 ${esc(p.calError)}</div>`;
    const ok = calPast(projectCalDays(p)) || (p.cal && p.cal.hash === calHash(calProjectDesired(p)));
    return `<div class="tiny" style="margin-top:3px;color:${ok ? 'var(--ok)' : 'var(--muted)'}">📅 ${ok ? `invité à l'événement du projet (${esc(t.email)})` : 'agenda : synchronisation…'}</div>`;
  }
  if (r.calError) return `<div class="tiny" style="margin-top:3px;color:var(--bad)">📅 ${esc(r.calError)}</div>`;
  const d = calDesired(p, r); const done = calPast(r.dates) || (r.cal && r.cal.hash === calHash(d));
  return `<div class="tiny" style="margin-top:3px;color:${done ? 'var(--ok)' : 'var(--muted)'}">📅 ${done ? `dans son agenda (${esc(t.email)})` : 'agenda : synchronisation…'}</div>`;
}

/* Réglages (Équipe → Relais Google) */
function calSetupHTML() {
  const st = Store.db.settings; const on = calEnabled();
  const active = []; Store.db.projects.forEach((p) => p.crew.forEach((r) => { if (calMode() !== 'off' && calWanted(p, r)) active.push(r); }));
  const noMail = [...new Set(active.filter((r) => { const t = getTech(r.techId); return !t || !validEmail(t.email); }).map((r) => r.techId))].map((id) => getTech(id)).filter(Boolean);
  const synced = calGroup() ? Store.db.projects.filter((p) => p.cal && (p.cal.ids || []).length).length : active.filter((r) => r.cal && (r.cal.ids || []).length).length;
  return `<div class="card" style="margin-top:16px"><div class="grid g2" style="align-items:start">
    <div><h3>📅 Agenda des techniciens</h3>
      <div class="small" style="line-height:1.6">Quand un technicien est en option ou validé, un événement est créé dans votre agenda <b>« Impulsion – Bookings techniciens »</b> et il y est <b>invité par email</b> : l'événement apparaît directement dans son Google Agenda (aussi Outlook / iCloud).
      Il suit les changements : <span class="tag info">🟦 OPTION — …</span> → <span class="tag ok">✅ …</span>, dates modifiées, et il est supprimé si l'option est levée, s'il est indispo ou retiré du projet.</div>
      <label class="f" style="margin-top:12px">Créer les événements pour<select data-set="calSync">
        <option value="off" ${calMode() === 'off' ? 'selected' : ''}>Désactivé</option>
        <option value="valide" ${calMode() === 'valide' ? 'selected' : ''}>Les bookings validés uniquement</option>
        <option value="all" ${calMode() === 'all' ? 'selected' : ''}>Les options et les bookings validés</option></select></label>
      <label class="f" style="margin-top:12px">Organisation des événements<select data-set="calGroup">
        <option value="tech" ${!calGroup() ? 'selected' : ''}>Un événement par technicien — chacun n'est prévenu que de ce qui le concerne (recommandé)</option>
        <option value="project" ${calGroup() ? 'selected' : ''}>Un seul événement par projet avec toute l'équipe — chaque réponse prévient tout le monde</option></select></label>
      <label class="row small" style="gap:8px;margin-top:12px;align-items:flex-start"><input type="checkbox" data-set-chk="calRoadmap" ${st.calRoadmap === true ? 'checked' : ''} style="margin-top:2px"><span>Copier aussi le texte de la <b>feuille de route</b> dans l'événement<br><span class="tiny muted">Déconseillé. Par défaut l'événement contient le lien vers la feuille de route en ligne, toujours à jour. Pour éviter les mails à répétition, l'événement n'est modifié que si les dates, horaires, poste, lieu ou statut du technicien changent, et jamais une fois terminé.</span></span></label>
      <div class="row" style="margin-top:12px">${on ? `<span class="tag ${calState.error ? 'bad' : 'ok'}">● ${calState.error ? 'Erreur' : 'Actif'}</span><span class="small muted">${calState.last ? 'Dernière synchro : ' + new Date(calState.last).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }) : ''} · ${synced} ${calGroup() ? 'projet(s)' : 'booking(s)'} dans les agendas</span>` : `<span class="tag">${replyActive() ? 'Désactivé' : 'Relais Google non configuré'}</span>`}</div>
      ${calState.error ? `<div class="alert bad" style="margin-top:10px">${esc(calState.error)}</div>` : ''}
      ${noMail.length ? `<div class="alert" style="margin-top:10px">Sans email, pas d'invitation : ${noMail.map((t) => `<a data-act="editTech" data-id="${t.id}">${esc(techName(t))}</a>`).join(', ')}</div>` : ''}
      <div class="row" style="margin-top:10px"><button class="sm" data-act="calTest" ${replyActive() ? '' : 'disabled'}>Tester l'accès à l'agenda</button><button class="sm" data-act="calSyncNow" ${on ? '' : 'disabled'}>🔄 Synchroniser maintenant</button></div></div>
    <div><h3>Activation (une fois)</h3>
      <div class="small muted" style="line-height:1.6">
      1. Mettez le script à jour : bouton <b>Copier le code</b> ci-dessus, remplacez tout dans Apps Script, <b>Ctrl+S</b>.<br>
      2. Dans l'éditeur, en haut, choisissez la fonction <code>autoriserAgenda</code> dans la liste puis <b>▶ Exécuter</b> : acceptez l'accès à <b>Google Agenda</b> (Paramètres avancés → Accéder).<br>
      3. <b>Déployer → Gérer les déploiements → ✏️ → Nouvelle version → Déployer</b>.<br>
      4. Ici : <b>Tester l'accès à l'agenda</b>, puis choisissez quoi synchroniser.<br><br>
      Les invitations partent de votre compte Google. Chez la plupart des utilisateurs Gmail, l'événement s'ajoute automatiquement à l'agenda ; sinon il apparaît à confirmer dans l'invitation reçue par email.</div></div>
  </div></div>`;
}
const calActions = {
  async calTest() {
    try { toast('Test de l\'agenda…'); const j = await withTimeout(remoteGet({ action: 'calcheck', key: ensureReplyKey() }), 30000); calState.error = null; toast(`📅 Agenda OK : « ${j.name} » ✔`); }
    catch (e) { calState.error = /Action inconnue/.test(e.message) ? 'Le script Google n\'est pas à jour : copiez le nouveau code, Ctrl+S, puis Gérer les déploiements → ✏️ → Nouvelle version.' : e.message; toast('📅 ' + calState.error, 'bad'); }
    render();
  },
  calSyncNow() { syncCalendars(true); }
};

/* jours couverts par les événements d'un projet */
function projectCalDays(p) { const d = (p.crew || []).flatMap((r) => r.dates || []); return d.length ? d : [p.end || p.start].filter(Boolean); }
/* v2.9 : adopte la nouvelle clé sans renvoyer les événements existants (pas de vague de mails) */
function calQuietMigration() {
  const st = Store.db.settings; if (st.calQuietV1) return; st.calQuietV1 = true;
  if (st.calRoadmap !== false && !st.calRoadmapChosen) st.calRoadmap = false;
  Store.db.projects.forEach((p) => {
    if (p.cal && (p.cal.ids || []).length) { const d = calProjectDesired(p); if (d) p.cal.hash = calHash(d); }
    (p.crew || []).forEach((r) => { if (r.cal && (r.cal.ids || []).length) { const d = calDesired(p, r); if (d) r.cal.hash = calHash(d); } });
  });
}
