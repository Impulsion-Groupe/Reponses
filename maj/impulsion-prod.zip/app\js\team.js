/* =====================================================================
   ÉQUIPE & VÉHICULES — techniciens, demandes de présence (WhatsApp / SMS / email),
   véhicules, affectations transport, plannings de disponibilité
   ===================================================================== */
const CREW_ST = {
  attente: { l: 'En attente', c: '#ffb547', cls: 'warn', ic: '⏳' },
  option: { l: 'Option', c: '#5b8cff', cls: 'info', ic: '🟦' },
  valide: { l: 'Validé', c: '#3ccf8e', cls: 'ok', ic: '✅' },
  indispo: { l: 'Indispo', c: '#ff5d6c', cls: 'bad', ic: '❌' }
};
const ST_RANK = { valide: 4, option: 3, attente: 2, indispo: 1 };
const LICENCES = { '': 'Aucun', B: 'B', C1: 'C1', C: 'C (poids lourd)', CE: 'CE (super lourd)' };
const LIC_RANK = { '': 0, B: 1, C1: 2, C: 3, CE: 4 };
const VEH_TYPES = ['Véhicule léger', 'Utilitaire 12 m³', 'Porteur 20 m³', 'PL 12 t', 'PL 19 t', 'Semi-remorque', 'Remorque'];
const MSG_KINDS = { option: 'Demande d\'option', demande: 'Demande de booking', relance: 'Relance', confirm: 'Confirmation booking', update: 'Mise à jour du projet', release: 'Levée d\'option', transport: 'Transport', grp: 'Invitation au groupe WhatsApp', fdr: 'Feuille de route' };
const MSG_SHORT = { option: '🟦 Option', demande: '✅ Booking', relance: '⏰ Relance', confirm: '📌 Booking (option)', update: '🔄 Mise à jour', release: '↩ Levée' };
/* Ce qui a été validé par le technicien (pour détecter un changement d'organisation) */
const ackSnap = (r, p) => ({ dates: [...r.dates].sort().join(','), hours: hoursShort(r), role: r.role || '', lieu: p.venue || '' });
const SNAP_NAMES = { dates: 'dates', hours: 'horaires', role: 'poste', lieu: 'lieu' };
function ackChanges(r, p) { if (r.status !== 'valide' || !r.ack || !r.ackSnap) return []; const now = ackSnap(r, p); return Object.keys(now).filter((k) => now[k] !== r.ackSnap[k]); }
function changesMsg(r, p) {
  const ch = r.ackSnap ? Object.keys(ackSnap(r, p)).filter((k) => ackSnap(r, p)[k] !== r.ackSnap[k]) : []; if (!ch.length) return '';
  const was = r.ackSnap; const L = ['🔄 Ce qui change :'];
  ch.forEach((k) => { if (k === 'dates') L.push(`• Dates : ${fmtDays(was.dates ? was.dates.split(',') : [])} → ${fmtDays(r.dates)}`); else if (k === 'hours') L.push(`• Horaires : ${was.hours || '—'} → ${hoursShort(r) || '—'}`); else if (k === 'role') L.push(`• Poste : ${was.role || '—'} → ${r.role || '—'}`); else L.push(`• Lieu : ${was.lieu || '—'} → ${p.venue || '—'}`); });
  return L.join('\n');
}

const getTech = (id) => Store.db.techs.find((t) => t.id === id);
/* Indisponibilités déclarées par le technicien (espace « Mes bookings ») : t.indispo = { days: [...], note, at } */
const techIndispo = (t) => (t && t.indispo && Array.isArray(t.indispo.days) ? t.indispo.days : []);
const indispoOn = (t, dates) => { const s = new Set(techIndispo(t)); return (dates || []).filter((d) => s.has(d)).sort(); };
const indispoTxt = (days) => `🚫 Indisponible (déclaré) : ${fmtDaysShort(days)}`;
const getVehicle = (id) => Store.db.vehicles.find((v) => v.id === id);
const techName = (t) => (t ? `${t.firstName || ''} ${t.lastName || ''}`.trim() || 'Sans nom' : 'Technicien supprimé');
const activeProjects = () => Store.db.projects.filter((p) => p.status !== 'annule');

/* ---------- Dates ---------- */
function rangeDays(a, b) {
  const out = []; if (!a) return out; let d = a; const end = b && b >= a ? b : a; let g = 0;
  while (d <= end && g++ < 370) { out.push(d); d = addDays(d, 1); }
  return out;
}
const projectDays = (p) => rangeDays(p.start, p.end);
function dayRuns(dates) {
  const d = [...new Set(dates)].sort(); const runs = []; if (!d.length) return runs;
  let a = d[0], b = d[0];
  for (let i = 1; i < d.length; i++) { if (d[i] === addDays(b, 1)) b = d[i]; else { runs.push([a, b]); a = b = d[i]; } }
  runs.push([a, b]); return runs;
}
function fmtDays(dates) {
  const runs = dayRuns(dates); if (!runs.length) return 'dates à définir';
  const f = (x) => new Date(x + 'T00:00:00').toLocaleDateString('fr-FR', { weekday: 'short', day: 'numeric', month: 'short' });
  return runs.map(([x, y]) => (x === y ? f(x) : `du ${f(x)} au ${f(y)}`)).join(', ');
}
function fmtDaysShort(dates) {
  const runs = dayRuns(dates); if (!runs.length) return '—';
  const f = (x) => { const d = new Date(x + 'T00:00:00'); return `${d.getDate()}/${String(d.getMonth() + 1).padStart(2, '0')}`; };
  return runs.map(([x, y]) => (x === y ? f(x) : `${f(x)}→${f(y)}`)).join(', ');
}
const dayLabel = (d) => new Date(d + 'T00:00:00').toLocaleDateString('fr-FR', { weekday: 'short', day: 'numeric', month: 'short' });

/* ---------- Messages ---------- */
function normPhone(raw) {
  let s = String(raw || '').trim(); const plus = s.startsWith('+'); s = s.replace(/\D/g, '');
  if (!s) return ''; if (plus) return s; if (s.startsWith('00')) return s.slice(2);
  if (s.startsWith('0')) return String(Store.db.settings.countryCode || '33').replace(/\D/g, '') + s.slice(1);
  return s;
}
function fillTemplate(tpl, vars) {
  const out = [];
  String(tpl || '').split('\n').forEach((line) => {
    let had = false, empty = true;
    const res = line.replace(/\{(\w+)\}/g, (m, k) => { if (!(k in vars)) return m; had = true; const v = vars[k] == null ? '' : String(vars[k]); if (v.trim()) empty = false; return v; });
    if (!(had && empty)) out.push(res);
  });
  return out.join('\n').replace(/\n{3,}/g, '\n\n');
}
function reqVars(r, p) {
  const t = getTech(r.techId) || {}; const st = Store.db.settings;
  return { prenom: t.firstName, nom: t.lastName, societe: st.company, projet: p.name, client: p.client, lieu: p.venue, dates: fmtDays(r.dates), horaires: hoursMsg(r), role: r.role, nbjours: r.dates.length, lien: reqLink(r), changements: changesMsg(r, p) };
}
function fleetVars(f, p) {
  const t = getTech(f.driverId) || {}; const v = getVehicle(f.vehicleId) || {};
  return { prenom: t.firstName, nom: t.lastName, societe: Store.db.settings.company, projet: p.name, client: p.client, lieu: p.venue, dates: fmtDays(rangeDays(f.start, f.end)), vehicule: v.name, immat: v.plate, role: 'Chauffeur' };
}
// Message proposé selon l'étape : option/booking → relance → confirmation officielle
const autoKind = (r) => (r.status === 'valide' ? 'update' : r.status === 'option' ? 'confirm' : r.status === 'attente' && r.sentAt ? 'relance' : r.kind === 'option' ? 'option' : 'demande');
// Ce que la page de réponse du technicien doit proposer pour ce message
const pageKind = (r, kind) => ({ confirm: 'confirm', update: 'confirm', option: 'option', demande: 'booking', relance: r.kind === 'option' ? 'option' : 'booking' }[kind] || null);
const tplFor = (kind) => { const st = Store.db.settings; return { option: st.msgOption, demande: st.msgDemande, relance: st.msgRelance, confirm: st.msgConfirm, update: st.msgUpdate, release: st.msgRelease, transport: st.msgTransport, grp: st.msgGroup, fdr: st.msgRoadmap }[kind]; };
// Mode « collage » (par défaut) : le message va dans le presse-papiers et WhatsApp s'ouvre sur la conversation
// → Ctrl+V puis Entrée. WhatsApp Desktop supprime souvent les emojis d'un texte pré-rempli par lien.
const waPaste = () => Store.db.settings.waPaste !== false;
function waLink(phone, text) {
  const n = normPhone(phone); const t = text && !waPaste() ? encodeURIComponent(text) : '';
  const mode = Store.db.settings.waMode;
  if (mode === 'app') return `whatsapp://send?phone=${n}${t ? '&text=' + t : ''}`;
  if (mode === 'web') return `https://web.whatsapp.com/send?phone=${n}${t ? '&text=' + t : ''}`;
  // auto : l'application de bureau convertit ce lien vers WhatsApp Desktop s'il est installé, sinon page web
  return `https://wa.me/${n}${t ? '?text=' + t : ''}`;
}
const smsLink = (phone, text) => `sms:+${normPhone(phone)}?body=${encodeURIComponent(text)}`;
const mailLink = (email, subject, text) => `mailto:${encodeURIComponent(email)}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(text)}`;
async function openExternal(url) {
  try {
    if (window.desktop && window.desktop.openExternal) return await window.desktop.openExternal(url);
  } catch (e) { /* repli ci-dessous */ }
  if (/^https?:/.test(url)) { window.open(url, '_blank', 'noopener'); return; }
  const a = document.createElement('a'); a.href = url; a.click();
}
async function copyText(t, quiet) {
  try { await navigator.clipboard.writeText(t); }
  catch (e) { const ta = document.createElement('textarea'); ta.value = t; document.body.appendChild(ta); ta.select(); document.execCommand('copy'); ta.remove(); }
  if (!quiet) toast('Message copié 📋');
}

/* ---------- Conflits & charges ---------- */
function techBusy(techId, dates, excludeReqId) {
  const out = [];
  activeProjects().forEach((p) => p.crew.forEach((r) => {
    if (r.techId !== techId || r.id === excludeReqId || r.status === 'attente' || r.released) return;
    const common = r.dates.filter((d) => dates.includes(d)); if (common.length) out.push({ p, r, common });
  }));
  return out.sort((a, b) => ST_RANK[b.r.status] - ST_RANK[a.r.status]);
}
const busyTxt = (b) => `${CREW_ST[b.r.status].ic} ${CREW_ST[b.r.status].l} sur ${esc(b.p.name)} (${fmtDaysShort(b.common)})`;
function vehicleBusy(vehicleId, start, end, excludeId) {
  const out = [];
  activeProjects().forEach((p) => p.fleet.forEach((f) => {
    if (f.vehicleId !== vehicleId || f.id === excludeId) return;
    if (overlaps(start, end, f.start, f.end)) out.push({ p, f });
  }));
  return out;
}
function vehAlerts(v, until) {
  const out = []; const t = todayISO();
  [['ctDate', 'Contrôle technique'], ['serviceDate', 'Entretien']].forEach(([k, l]) => {
    const d = v[k]; if (!d) return;
    if (d < t) out.push({ cls: 'bad', txt: `${l} dépassé (${fmtDate(d)})` });
    else if (until && d <= until) out.push({ cls: 'bad', txt: `${l} échoit avant la fin de mission (${fmtDate(d)})` });
    else if (d <= addDays(t, 30)) out.push({ cls: 'warn', txt: `${l} le ${fmtDate(d)}` });
  });
  return out;
}
function projectLoad(p) {
  let kg = 0, m3 = 0, missingW = 0, missingV = 0;
  projectUsage(p).forEach((u, pid) => {
    const x = getProduct(pid); if (!x) return;
    if (num(x.weightKg)) kg += u.qty * num(x.weightKg); else missingW++;
    if (num(x.volumeM3)) m3 += u.qty * num(x.volumeM3); else missingV++;
  });
  let capKg = 0, capM3 = 0;
  p.fleet.forEach((f) => { const v = getVehicle(f.vehicleId); if (v) { capKg += num(v.payloadKg); capM3 += num(v.volumeM3); } });
  return { kg, m3, capKg, capM3, missingW, missingV };
}

/* =====================================================================
   SECTIONS DANS LA FICHE PROJET
   ===================================================================== */
function statusButtons(r) {
  return `<div class="seg st-seg">${Object.entries(CREW_ST).map(([k, s]) => `<button class="${r.status === k ? 'on' : ''}" style="${r.status === k ? `background:${s.c};color:#06131a` : ''}" data-act="reqStatus" data-id="${r.id}" data-v="${k}" title="${s.l}">${s.ic} ${s.l}</button>`).join('')}</div>`;
}
function crewSection(p) {
  const days = [...new Set([...projectDays(p), ...p.crew.flatMap((r) => r.dates)])].sort();
  const cnt = (st) => p.crew.filter((r) => r.status === st).length;
  const unsent = p.crew.filter((r) => r.status === 'attente' && !r.sentAt && getTech(r.techId) && getTech(r.techId).phone);
  const rows = [...p.crew].sort((a, b) => ST_RANK[b.status] - ST_RANK[a.status] || techName(getTech(a.techId)).localeCompare(techName(getTech(b.techId))));
  const cover = days.length ? `<div class="cover-strip">${days.map((d) => {
    const v = p.crew.filter((r) => r.status === 'valide' && r.dates.includes(d)).length; const o = p.crew.filter((r) => r.status === 'option' && r.dates.includes(d)).length;
    const need = num(p.crewNeeded); const cls = !need ? '' : v >= need ? 'ok' : v + o >= need ? 'warn' : 'bad';
    return `<div class="cov ${cls}" title="${dayLabel(d)} : ${v} validé(s), ${o} option(s)${need ? ' / besoin ' + need : ''}"><span>${dayLabel(d).replace('.', '')}</span><b>${v}${need ? '/' + need : ''}</b>${o ? `<i>+${o} opt.</i>` : '<i>&nbsp;</i>'}</div>`;
  }).join('')}</div>` : '';
  return `<div class="row" style="justify-content:space-between;margin:26px 0 12px"><h2 style="margin:0">👷 Équipe technique</h2>
    <div class="row">${replyActive() ? `<span class="tiny muted reply-badge">${replyBadgeText()}</span><button class="sm" data-act="replySync" title="Vérifier les réponses maintenant">🔄</button>` : ''}<label class="row small muted" style="gap:6px">Besoin / jour <input type="number" min="0" data-crewneeded value="${p.crewNeeded || 0}" style="width:64px"></label>
    ${unsent.length ? `<button data-act="queueUnsent">📲 Envoyer les ${unsent.length} demande(s) non envoyée(s)</button>` : ''}
    ${p.crew.filter((r) => ackChanges(r, p).length).length ? `<button class="primary" data-act="updateAllChanged">🔄 Prévenir ${p.crew.filter((r) => ackChanges(r, p).length).length} tech(s) du changement</button>` : ''}
    ${p.crew.filter((r) => r.status === 'option').length > 1 ? `<button data-act="confirmAllOptions">📌 Valider les ${p.crew.filter((r) => r.status === 'option').length} options</button>` : ''}
    <button class="primary" data-act="solicit" ${Store.db.techs.length ? '' : 'disabled title="Ajoutez d\'abord des techniciens (menu Équipe)"'}>＋ Solliciter des techniciens</button></div></div>
  <div class="card flat">
    <div style="padding:14px 16px 4px" class="row">${Object.entries(CREW_ST).map(([k, s]) => `<span class="tag ${s.cls}">${s.ic} ${s.l} : ${cnt(k)}</span>`).join('')}</div>
    ${cover ? `<div style="padding:8px 16px 12px">${cover}</div>` : ''}
    ${rows.length ? `<table><tr><th>Technicien</th><th>Poste</th><th>Dates</th><th>Statut</th><th>Dernier envoi</th><th class="num">Contacter</th></tr>
    ${rows.map((r) => {
      const t = getTech(r.techId); const busy = t ? techBusy(t.id, r.dates, r.id).filter((b) => b.r.status !== 'indispo') : [];
      const kind = autoKind(r); const hasPhone = t && normPhone(t.phone);
      return `<tr><td><b>${esc(techName(t))}</b><div class="tiny muted">${esc(t ? t.phone || 'pas de téléphone' : '')}</div>${busy.length && r.status !== 'indispo' ? `<div class="tiny" style="color:var(--warn)">⚠ ${busy.map(busyTxt).join(' · ')}</div>` : ''}${r.status !== 'indispo' && indispoOn(t, r.dates).length ? `<div class="tiny" style="color:var(--bad)">${indispoTxt(indispoOn(t, r.dates))}</div>` : ''}</td>
      <td><input data-reqrole="${r.id}" value="${esc(r.role || '')}" list="skillList" style="width:150px"></td>
      <td><a data-act="reqDates" data-id="${r.id}" title="Modifier les dates">${fmtDaysShort(r.dates)} ✎</a><div class="tiny muted">${r.dates.length} jour(s)</div>${hoursShort(r) ? `<div class="tiny" style="color:var(--accent-hi);max-width:220px">🕐 ${esc(hoursShort(r))}</div>` : ''}
        <div style="margin-top:3px">${r.released ? '<span class="tag">↩ Option levée</span>' : r.kind === 'option' ? '<span class="tag info">Demande d\'option</span>' : '<span class="tag">Booking direct</span>'}</div></td>
      <td>${statusButtons(r)}${bookingStep(r)}${replyCell(r)}${calCell(p, r)}</td>
      <td class="small">${r.sentAt ? `${new Date(r.sentAt).toLocaleDateString('fr-FR', { day: '2-digit', month: 'short' })} ${new Date(r.sentAt).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}${r.history.filter((h) => h.action === 'envoi').length > 1 ? `<div class="tiny muted">${r.history.filter((h) => h.action === 'envoi').length} envois</div>` : ''}` : '<span class="tag warn">Jamais envoyé</span>'}</td>
      <td class="num" style="white-space:nowrap">${r.status === 'option'
        ? `<button class="sm primary" data-act="reqConfirm" data-id="${r.id}" ${hasPhone ? '' : 'disabled'} title="Envoyer la confirmation officielle du booking">📌 Valider le booking</button>
           <button class="sm" data-act="reqRelease" data-id="${r.id}" ${hasPhone ? '' : 'disabled'} title="Prévenir le technicien qu'il est libéré">↩ Lever</button>
           <button class="sm ghost" data-act="reqSend" data-id="${r.id}" ${hasPhone ? '' : 'disabled'} title="Autre message">💬</button>`
        : `<button class="sm wa" data-act="reqSend" data-id="${r.id}" ${hasPhone ? '' : 'disabled title="Pas de téléphone"'}>💬 ${MSG_KINDS[kind]}</button>`}
        <button class="sm ghost danger" data-act="reqDel" data-id="${r.id}" title="Retirer">✕</button></td></tr>`;
    }).join('')}</table>` : `<div class="empty" style="padding:26px"><div class="e">👷</div>Personne n'est encore sollicité sur ce projet.</div>`}
  </div><datalist id="skillList">${(Store.db.settings.skills || []).map((s) => `<option value="${esc(s)}">`).join('')}</datalist>`;
}
function fleetSection(p) {
  const L = projectLoad(p);
  const bar = (v, cap) => { const pct = cap ? Math.min(100, v / cap * 100) : (v ? 100 : 0); return `<div class="bar" style="width:160px"><i class="${cap && v > cap ? 'bad' : pct > 85 ? 'warn' : ''}" style="width:${pct}%"></i></div>`; };
  const valid = new Set(p.crew.filter((r) => r.status === 'valide').map((r) => r.techId));
  const techs = [...Store.db.techs].filter((t) => t.active !== false).sort((a, b) => (valid.has(b.id) - valid.has(a.id)) || techName(a).localeCompare(techName(b)));
  return `<div class="row" style="justify-content:space-between;margin:26px 0 12px"><h2 style="margin:0">🚚 Transport</h2>
    <button class="primary" data-act="addFleet" ${Store.db.vehicles.length ? '' : 'disabled title="Ajoutez d\'abord des véhicules (menu Véhicules)"'}>＋ Affecter un véhicule</button></div>
  <div class="card flat">
    <div class="row" style="padding:14px 16px;gap:26px">
      <div><div class="tiny muted">POIDS ESTIMÉ / CHARGE UTILE</div><div class="row" style="gap:10px"><b>${fmt(L.kg)} kg</b> / ${fmt(L.capKg)} kg ${bar(L.kg, L.capKg)}</div>${L.missingW ? `<div class="tiny muted">${L.missingW} référence(s) sans poids renseigné</div>` : ''}</div>
      <div><div class="tiny muted">VOLUME ESTIMÉ / VOLUME UTILE</div><div class="row" style="gap:10px"><b>${fmt(L.m3, 1)} m³</b> / ${fmt(L.capM3, 1)} m³ ${bar(L.m3, L.capM3)}</div>${L.missingV ? `<div class="tiny muted">${L.missingV} référence(s) sans volume renseigné</div>` : ''}</div>
      ${L.capKg && L.kg > L.capKg ? '<span class="tag bad">Surcharge !</span>' : ''}${L.capM3 && L.m3 > L.capM3 ? '<span class="tag bad">Volume insuffisant</span>' : ''}
    </div>
    ${p.fleet.length ? `<table><tr><th>Véhicule</th><th>Départ</th><th>Retour</th><th>Chauffeur</th><th>Note</th><th class="num"></th></tr>
    ${p.fleet.map((f) => {
      const v = getVehicle(f.vehicleId); const d = getTech(f.driverId);
      const warn = [];
      if (v) {
        vehicleBusy(v.id, f.start, f.end, f.id).forEach((b) => warn.push({ cls: 'bad', txt: `Déjà pris sur ${esc(b.p.name)} (${fmtDaysShort(rangeDays(b.f.start, b.f.end))})` }));
        vehAlerts(v, f.end).forEach((a) => warn.push(a));
        if (d && LIC_RANK[d.licence || ''] < LIC_RANK[v.licence || '']) warn.push({ cls: 'bad', txt: `${esc(d.firstName)} n'a pas le permis ${v.licence}` });
      }
      if (d) techBusy(d.id, rangeDays(f.start, f.end)).filter((b) => b.p.id !== p.id && b.r.status === 'valide').forEach((b) => warn.push({ cls: 'warn', txt: `Chauffeur ${busyTxt(b)}` }));
      return `<tr><td><select data-fl="vehicleId" data-id="${f.id}" style="max-width:210px">${Store.db.vehicles.map((x) => `<option value="${x.id}" ${x.id === f.vehicleId ? 'selected' : ''}>${esc(x.name)} — ${esc(x.plate || '')}</option>`).join('')}</select>
        ${warn.map((w) => `<div class="tiny" style="color:var(--${w.cls === 'bad' ? 'bad' : 'warn'})">⚠ ${w.txt}</div>`).join('')}</td>
      <td><input type="date" data-fl="start" data-id="${f.id}" value="${f.start || ''}"></td><td><input type="date" data-fl="end" data-id="${f.id}" value="${f.end || ''}"></td>
      <td><select data-fl="driverId" data-id="${f.id}"><option value="">— À définir —</option>${techs.map((t) => `<option value="${t.id}" ${t.id === f.driverId ? 'selected' : ''}>${valid.has(t.id) ? '★ ' : ''}${esc(techName(t))} (${t.licence || '—'})</option>`).join('')}</select></td>
      <td><input data-fl="note" data-id="${f.id}" value="${esc(f.note || '')}" placeholder="Chargement, horaires…" style="width:150px"></td>
      <td class="num" style="white-space:nowrap"><button class="sm wa" data-act="fleetSend" data-id="${f.id}" ${d && normPhone(d.phone) ? '' : 'disabled title="Choisissez un chauffeur avec téléphone"'}>💬 Chauffeur</button>
        <button class="sm ghost danger" data-act="delFleet" data-id="${f.id}">✕</button></td></tr>`;
    }).join('')}</table>` : `<div class="empty" style="padding:26px"><div class="e">🚚</div>Aucun véhicule affecté.</div>`}
    <div class="tiny muted" style="padding:8px 16px 12px">★ = technicien validé sur ce projet. Poids et volume calculés depuis le catalogue (poids / volume unitaire de chaque référence).</div>
  </div>`;
}

/* ---------- Modale : solliciter ---------- */
function solicitHTML() {
  const p = curProject(); const s = ui.sol; const st = Store.db.settings;
  const days = [...new Set([...projectDays(p), ...s.dates])].sort();
  const inProject = new Set(p.crew.map((r) => r.techId));
  let techs = Store.db.techs.filter((t) => t.active !== false && (!s.skill || (t.skills || []).includes(s.skill)));
  techs = techs.map((t) => { const ind = indispoOn(t, s.dates); return { t, busy: techBusy(t.id, s.dates), ind, full: !!s.dates.length && ind.length === s.dates.length }; })
    .sort((a, b) => (a.full - b.full) || (a.ind.length - b.ind.length) || (a.busy.length - b.busy.length) || techName(a.t).localeCompare(techName(b.t)));
  return `<h2>Solliciter des techniciens — ${esc(p.name)}</h2>
  <h3 style="margin-top:14px">Type de demande</h3>
  <div class="grid g2" style="gap:10px">
    <button class="kind-card ${s.kind === 'option' ? 'on' : ''}" data-act="solKind" data-v="option"><b>🟦 Demande d'option</b><span>Pré-réservation : le technicien bloque les dates, vous confirmerez le booking plus tard.</span></button>
    <button class="kind-card ${s.kind !== 'option' ? 'on' : ''}" data-act="solKind" data-v="booking"><b>✅ Booking direct</b><span>Demande ferme : s'il est disponible, il est booké.</span></button></div>
  <h3 style="margin-top:14px">1. Dates de présence</h3>
  <div class="row" style="gap:6px">${days.map((d) => `<button class="sm chip ${s.dates.includes(d) ? 'on' : ''}" data-act="solDay" data-v="${d}">${dayLabel(d)}</button>`).join('')}</div>
  <div class="row" style="margin-top:8px"><button class="sm ghost" data-act="solAll" data-v="1">Toutes</button><button class="sm ghost" data-act="solAll" data-v="0">Aucune</button>
    <input type="date" id="solExtra"><button class="sm" data-act="solAddDay">＋ Ajouter cette date</button></div>
  <div class="form" style="grid-template-columns:1fr 1fr;margin-top:14px">
    <label class="f">2. Poste demandé<input data-sol="role" list="skillList2" value="${esc(s.role)}" placeholder="ex. Technicien LED"></label>
    <label class="f">Filtrer par compétence<select data-sol="skill"><option value="">Toutes</option>${(st.skills || []).map((k) => `<option ${s.skill === k ? 'selected' : ''}>${esc(k)}</option>`).join('')}</select></label></div>
  <h3 style="margin-top:14px">Horaires (facultatif)</h3>${hoursEditorHTML(s.hours, s.dates, 'sol')}
  <datalist id="skillList2">${(st.skills || []).map((k) => `<option value="${esc(k)}">`).join('')}</datalist>
  <h3 style="margin-top:14px">3. Techniciens (${s.techIds.length} sélectionné(s))</h3>
  <div class="sol-list">${techs.length ? techs.map(({ t, busy, ind, full }) => {
    const already = inProject.has(t.id); const hard = busy.filter((b) => b.r.status === 'valide' || b.r.status === 'option');
    return `<label class="sol-item ${already || full ? 'dis' : ''}" ${full ? 'title="Il a déclaré être indisponible sur toutes ces dates"' : ''}><input type="checkbox" data-sol-tech="${t.id}" ${s.techIds.includes(t.id) && !full ? 'checked' : ''} ${already || full ? 'disabled' : ''}>
      <div class="grow"><b>${esc(techName(t))}</b> <span class="tiny muted">${esc((t.skills || []).join(' · '))}</span>
      <div class="tiny">${ind.length ? `<span class="tag bad">${indispoTxt(ind)}</span> ` : ''}${already ? '<span class="tag info">Déjà sur ce projet</span> ' : ''}${!normPhone(t.phone) ? '<span class="tag bad">Pas de téléphone</span> ' : ''}${busy.length ? busy.map((b) => `<span style="color:${hard.includes(b) ? 'var(--warn)' : 'var(--muted)'}">${busyTxt(b)}</span>`).join(' · ') : (s.dates.length ? '<span style="color:var(--ok)">Libre sur ces dates</span>' : '')}</div></div></label>`;
  }).join('') : '<div class="muted small">Aucun technicien (ou aucun avec cette compétence).</div>'}</div>
  <div class="modal-actions"><button data-act="closeModal">Annuler</button><button data-act="solCreate" data-v="0">Créer sans envoyer</button>
    <button class="primary" data-act="solCreate" data-v="1">${s.kind === 'option' ? 'Demander l\'option' : 'Demander le booking'} sur WhatsApp ▶</button></div>`;
}
/* ---------- Modale : dates d'une demande ---------- */
function datesHTML() {
  const p = curProject(); const e = ui.edDates; const r = p.crew.find((x) => x.id === e.id); const t = getTech(r.techId);
  const days = [...new Set([...projectDays(p), ...e.dates])].sort();
  const busy = techBusy(r.techId, e.dates, r.id);
  return `<h2>Dates & horaires de ${esc(techName(t))}</h2>
  <div class="row" style="gap:6px">${days.map((d) => `<button class="sm chip ${e.dates.includes(d) ? 'on' : ''}" data-act="edDay" data-v="${d}">${dayLabel(d)}</button>`).join('')}</div>
  <div class="row" style="margin-top:8px"><input type="date" id="edExtra"><button class="sm" data-act="edAddDay">＋ Ajouter cette date</button></div>
  ${busy.length ? `<div class="alert" style="margin-top:12px">${busy.map(busyTxt).join('<br>')}</div>` : ''}
  <h3 style="margin-top:16px">Horaires</h3>${hoursEditorHTML(e.hours, e.dates, 'ed')}
  <div class="modal-actions"><button data-act="closeModal">Annuler</button><button class="primary" data-act="edSave">Enregistrer</button></div>`;
}
/* ---------- Modale : envoi guidé ---------- */
function queueItem() {
  const q = ui.queue; const p = getProject(q.projectId); const it = q.items[q.i];
  if (it.type === 'fdr') { const t = getTech(it.techId); return t && { p, t, kind: 'fdr', vars: fdrVars(p, it.techId), fdr: true }; }
  if (it.type === 'grp') { const t = getTech(it.techId); return t && { p, t, kind: 'grp', vars: Object.assign(fdrVars(p, it.techId), { groupe: ensureRoadmap(p).groupLink || '' }), grp: true }; }
  if (it.type === 'fleet') { const f = p.fleet.find((x) => x.id === it.id); return f && { p, f, t: getTech(f.driverId), kind: 'transport', vars: fleetVars(f, p) }; }
  const r = p.crew.find((x) => x.id === it.id); if (!r) return null;
  const kind = q.kind || it.kind || autoKind(r); const pk = pageKind(r, kind);
  const vars = reqVars(r, p);
  if (replyActive() && pk && (!it.reg || it.regKind !== pk)) { it.regKind = pk; it.reg = ensureRegistered(r, p, pk).then(() => true, (e) => { it.reg = null; return e; }); }
  return { p, r, t: getTech(r.techId), kind, vars, it };
}
function queueHTML() {
  const q = ui.queue; const it = queueItem(); if (!it) return '';
  const msg = it.fdr && !it.vars.lienfdr ? `Bonjour ${it.vars.prenom || ''} 👋\n\n${roadmapText(it.p)}` : fillTemplate(tplFor(it.kind), it.vars); const n = q.items.length;
  return `<div class="row" style="justify-content:space-between"><h2 style="margin:0">💬 Envoi ${n > 1 ? `${q.i + 1} / ${n}` : ''} — ${esc(techName(it.t))}</h2><span class="small muted">+${normPhone(it.t && it.t.phone)}</span></div>
  ${it.r ? `<div class="row" style="margin:12px 0"><span class="small muted">Message :</span><div class="seg">${['option', 'demande', 'relance', 'confirm', 'update', 'release'].map((k) => `<button class="${it.kind === k ? 'on' : ''}" data-act="queueKind" data-v="${k}" title="${MSG_KINDS[k]}">${MSG_SHORT[k]}</button>`).join('')}</div>
    <span class="tag ${CREW_ST[it.r.status].cls}">${CREW_ST[it.r.status].ic} ${CREW_ST[it.r.status].l}</span></div>
    <div class="tiny" style="margin:-4px 0 10px;color:var(--accent-hi)">${{ option: 'Pré-réservation : le statut passera en 🟦 Option quand il acceptera.', demande: 'Booking direct : s\'il répond disponible, il passe en ✅ Validé.', relance: 'Relance de la demande en cours.', confirm: 'Confirmation officielle : à l\'envoi, le statut passe en ✅ Validé et il pourra confirmer sa présence en 1 clic.', release: 'Levée d\'option : à l\'envoi, le technicien est libéré (statut ❌, dates libérées).' }[it.kind]}</div>` : '<div style="height:12px"></div>'}
  <textarea id="qMsg" style="min-height:240px;font-family:inherit">${esc(msg)}</textarea>
  <div class="tiny muted" style="margin-top:6px">${waPaste() ? 'Vous pouvez retoucher le texte. Le message est copié et WhatsApp s\'ouvre sur la conversation : faites <b>Ctrl+V</b> puis <b>Entrée</b> (emojis compris).' : 'Vous pouvez retoucher le texte. WhatsApp s\'ouvre avec le message prêt : il ne reste qu\'à appuyer sur <b>Envoyer</b>.'}</div>
  <div class="modal-actions">${n > 1 ? `<button class="ghost" data-act="queueSkip" style="margin-right:auto">Passer ⏭</button>` : '<span style="margin-right:auto"></span>'}
    <button data-act="queueCopy">📋 Copier</button><button data-act="queueSms">✉ SMS</button>${it.t && it.t.email ? '<button data-act="queueMail">@ Email</button>' : ''}
    <button class="primary wa-btn" data-act="queueWA">💬 ${waPaste() ? 'Copier et ouvrir WhatsApp' : 'Ouvrir WhatsApp'}${n > 1 && q.i < n - 1 ? ' ▶ suivant' : ''}</button></div>`;
}
/* Le lien de réponse doit être enregistré côté script avant d'envoyer le message */
async function linkReady(it, msg) {
  if (!it.r || !replyActive() || !msg.includes(reqLink(it.r))) return;
  try { const res = await withTimeout(it.it.reg || ensureRegistered(it.r, it.p, pageKind(it.r, it.kind) || 'booking'), 15000); if (res instanceof Error) throw res; }
  catch (e) { it.it.reg = null; toast('⚠ Lien de réponse non activé (' + e.message + ') — le technicien pourra quand même répondre sur WhatsApp', 'warn'); }
}
function queueNext() {
  const q = ui.queue; q.i++; q.kind = null;
  if (q.i >= q.items.length) { closeModal(); ui.queue = null; render(); toast('Envois terminés ✔ Pensez à mettre à jour les statuts quand ils répondent.'); }
  else openModal(queueHTML());
}
function queueMark(via) {
  const it = queueItem(); const now = new Date().toISOString();
  if (it.fdr) { const rm = ensureRoadmap(it.p); rm.sentTo = rm.sentTo || {}; rm.sentTo[it.t.id] = now; Store.save(); return; }
  if (it.grp) { const rm = ensureRoadmap(it.p); rm.groupInvited = rm.groupInvited || {}; rm.groupInvited[it.t.id] = now; Store.save(); return; }
  const tgt = it.r || it.f;
  tgt.sentAt = now; tgt.history = tgt.history || []; tgt.history.push({ at: now, action: 'envoi', via, kind: it.kind });
  const r = it.r;
  if (r) {
    if (it.kind === 'confirm') {
      if (r.status !== 'valide') { r.status = 'valide'; r.history.push({ at: now, action: 'statut', status: 'valide' }); }
      r.confirmSentAt = now; r.ack = null; r.released = false;
    } else if (it.kind === 'update') {
      r.updateSentAt = now; r.confirmSentAt = now; r.ack = null; r.released = false;
    } else if (it.kind === 'release') {
      r.status = 'indispo'; r.released = true; r.history.push({ at: now, action: 'statut', status: 'indispo', note: 'option levée' });
    } else if (it.kind === 'option' || it.kind === 'demande') {
      r.kind = it.kind === 'option' ? 'option' : 'booking';
      if (r.status === 'indispo') { r.status = 'attente'; r.released = false; }
    }
  }
  Store.save();
}
/* Étape du booking affichée sous les statuts */
function bookingStep(r) {
  if (r.released) return '';
  if (r.status === 'option') return '<div class="tiny" style="margin-top:4px;color:#8fb0ff">🟦 Option posée — booking à valider</div>';
  if (r.status !== 'valide') return '';
  const dd = (iso) => new Date(iso).toLocaleDateString('fr-FR', { day: '2-digit', month: 'short' });
  if (r.ack) {
    const p = Store.db.projects.find((x) => x.crew.includes(r)); const ch = p ? ackChanges(r, p) : [];
    if (ch.length) return `<div class="tiny" style="margin-top:4px;color:var(--warn)">⚠ Modifié depuis sa validation : ${ch.map((k) => SNAP_NAMES[k]).join(', ')} <button class="sm" data-act="reqUpdate" data-id="${r.id}">🔄 Envoyer la mise à jour</button></div>`;
    return `<div class="tiny" style="margin-top:4px;color:var(--ok)">✅ Booking validé par le technicien le ${dd(new Date(r.ack.at).toISOString())}</div>`;
  }
  if (r.updateSentAt) return `<div class="tiny" style="margin-top:4px;color:var(--warn)">🔄 Mise à jour envoyée le ${dd(r.updateSentAt)} · « toujours dispo ? » en attente</div>`;
  if (r.confirmSentAt) return `<div class="tiny" style="margin-top:4px;color:var(--warn)">📌 Booking envoyé le ${dd(r.confirmSentAt)} · réponse du tech attendue</div>`;
  return '<div class="tiny muted" style="margin-top:4px">✅ Validé (saisi à la main)</div>';
}
function startQueue(projectId, items) {
  ui.queue = { projectId, items, i: 0, kind: null };
  if (!queueItem()) return; openModal(queueHTML());
}

/* =====================================================================
   PAGES : ÉQUIPE / VÉHICULES
   ===================================================================== */
function dayGrid(start, days, rows, emptyMsg) {
  const t = todayISO();
  const head = Array.from({ length: days }, (_, i) => { const d = addDays(start, i); const dt = new Date(d + 'T00:00:00'); const we = dt.getDay() === 0 || dt.getDay() === 6;
    return `<div class="g-day ${we ? 'we' : ''} ${d === t ? 'today' : ''}">${dt.getDate() === 1 || i === 0 ? dt.toLocaleDateString('fr-FR', { month: 'short' }) + '<br>' : ''}${dt.getDate()}</div>`; }).join('');
  return `<div class="card flat gantt"><div style="min-width:1100px">
    <div class="g-head"><div class="g-label" style="background:var(--panel2)"><b>${rows.title}</b></div><div style="display:flex;flex:1">${head}</div></div>
    ${rows.list.length ? rows.list.map((r) => `<div class="g-row"><div class="g-label"><b>${r.label}</b><span class="tiny muted">${r.sub || ''}</span></div>
      <div style="display:flex;flex:1">${Array.from({ length: days }, (_, i) => { const d = addDays(start, i); const dt = new Date(d + 'T00:00:00'); const we = dt.getDay() === 0 || dt.getDay() === 6;
        return `<div class="av-cell ${we ? 'we' : ''} ${d === t ? 'today' : ''}">${r.cell(d)}</div>`; }).join('')}</div></div>`).join('')
    : `<div class="empty"><div class="e">🗓️</div>${emptyMsg}</div>`}</div></div>`;
}
const gridNav = (act) => `<div class="row"><button data-act="${act}" data-v="-14">◀ 2 sem.</button><button data-act="${act}" data-v="0">Aujourd'hui</button><button data-act="${act}" data-v="14">2 sem. ▶</button></div>`;
const abbr = (s) => esc(String(s || '').split(/\s+/).map((w) => w[0]).join('').slice(0, 3).toUpperCase());

function vTeam() {
  ui.teamTab = ui.teamTab || 'list'; ui.teamStart = ui.teamStart || addDays(todayISO(), -3);
  const tabs = [['list', '👷 Techniciens'], ['dispo', '🗓️ Disponibilités'], ['messages', '💬 Messages types'], ['reponses', '📱 Réponses en 1 clic']];
  let body = '';
  if (ui.teamTab === 'list') {
    const t0 = todayISO(); const q = (ui.teamSearch || '').toLowerCase();
    const list = [...Store.db.techs].filter((t) => !q || [t.firstName, t.lastName, t.phone, ...(t.skills || [])].join(' ').toLowerCase().includes(q)).sort((a, b) => (b.active !== false) - (a.active !== false) || (a.lastName || '').localeCompare(b.lastName || ''));
    const upcoming = (t) => activeProjects().filter((p) => (p.end || p.start || '') >= t0).flatMap((p) => p.crew.filter((r) => r.techId === t.id).map((r) => ({ p, r })));
    body = `<div class="toolbar"><input placeholder="🔎 Rechercher un nom, un téléphone, une compétence…" value="${esc(ui.teamSearch || '')}" data-ui="teamSearch" style="max-width:380px" class="grow">${pagesActive() ? '<button data-act="espaceAll" title="Un lien personnel par technicien : ses bookings sur son téléphone">📱 Espace mobile des techs</button>' : ''}</div>
    <div class="card flat">${list.length ? `<table><tr><th>Technicien</th><th>Téléphone</th><th>Compétences</th><th>Permis</th><th>À venir</th><th class="num"></th></tr>
    ${list.map((t) => { const up = upcoming(t); return `<tr class="click" data-act="editTech" data-id="${t.id}" style="${t.active === false ? 'opacity:.5' : ''}"><td><b>${esc(techName(t))}</b>${t.active === false ? ' <span class="tag">Inactif</span>' : ''}${(() => { const f = techIndispo(t).filter((d) => d >= t0); return f.length ? ` <span class="tag bad" title="${esc(f.map(dayLabel).join(', ') + (t.indispo.note ? ' — ' + t.indispo.note : ''))}">🚫 ${f.length} j. indispo</span>` : ''; })()}<div class="tiny muted">${esc(t.email || '')}</div></td>
      <td>${esc(t.phone || '')}${t.phone && !normPhone(t.phone) ? ' <span class="tag bad">invalide</span>' : ''}</td><td class="small">${(t.skills || []).map((s) => `<span class="tag">${esc(s)}</span>`).join(' ')}</td><td>${esc(t.licence || '—')}</td>
      <td class="small">${up.length ? up.slice(0, 3).map((x) => `<span class="tag ${CREW_ST[x.r.status].cls}" title="${CREW_ST[x.r.status].l}">${CREW_ST[x.r.status].ic} ${esc(x.p.name)}</span>`).join(' ') + (up.length > 3 ? ` +${up.length - 3}` : '') : '<span class="dim">—</span>'}</td>
      <td class="num" style="white-space:nowrap">${pagesActive() ? `<button class="sm ${t.espace ? 'ghost' : ''}" data-act="espaceSend" data-id="${t.id}" title="${t.espace ? 'Renvoyer' : 'Envoyer'} son espace mobile (ses bookings sur téléphone)">📱</button>` : ''}${normPhone(t.phone) ? `<button class="sm wa" data-act="techChat" data-id="${t.id}" title="Ouvrir la discussion WhatsApp">💬</button>` : ''}</td></tr>`; }).join('')}</table>`
      : `<div class="empty"><div class="e">👷</div>Aucun technicien. Ajoutez votre équipe et vos intermittents !</div>`}</div>`;
  } else if (ui.teamTab === 'dispo') {
    const list = Store.db.techs.filter((t) => t.active !== false).sort((a, b) => (a.lastName || '').localeCompare(b.lastName || ''));
    body = `<div class="row" style="justify-content:space-between;margin-bottom:12px"><div class="row">${Object.values(CREW_ST).map((s) => `<span class="legend-chip"><span class="dot" style="background:${s.c}"></span>${s.l}</span>`).join('')}<span class="legend-chip">🚫 Indispo déclarée</span></div>${gridNav('teamShift')}</div>
    ${dayGrid(ui.teamStart, 42, { title: 'Technicien', list: list.map((t) => ({ label: esc(techName(t)), sub: esc((t.skills || []).slice(0, 2).join(' · ')), cell: (d) => {
      const hits = []; activeProjects().forEach((p) => p.crew.forEach((r) => { if (r.techId === t.id && r.dates.includes(d)) hits.push({ p, r }); }));
      if (!hits.length) return techIndispo(t).includes(d) ? `<div class="av-chip" style="background:#3a1f25;color:#ff8a96;border:1px dashed #ff5d6c" title="${dayLabel(d)} — indisponible (déclaré par le technicien)${t.indispo.note ? ' : ' + esc(t.indispo.note) : ''}">🚫</div>` : ''; hits.sort((a, b) => ST_RANK[b.r.status] - ST_RANK[a.r.status]); const h = hits[0];
      return `<div class="av-chip" style="background:${CREW_ST[h.r.status].c}" data-act="openProject" data-id="${h.p.id}" title="${dayLabel(d)} — ${hits.map((x) => `${x.p.name} : ${CREW_ST[x.r.status].l}`).join(' / ')}">${abbr(h.p.name)}${hits.length > 1 ? '+' : ''}</div>`;
    } })) }, 'Aucun technicien actif.')}<p class="tiny muted">Cliquez sur une case pour ouvrir le projet. « + » = plusieurs demandes ce jour-là.</p>`;
  } else if (ui.teamTab === 'reponses') {
    body = replySetupHTML() + pagesSetupHTML() + calSetupHTML();
  } else {
    const st = Store.db.settings; const ex = { prenom: 'Karim', nom: 'Martin', societe: st.company, projet: 'Salon Auto Lille', client: 'Lille Grand Palais', lieu: 'Lille Grand Palais', dates: fmtDays([todayISO(), addDays(todayISO(), 1), addDays(todayISO(), 2)]), role: 'Technicien LED', nbjours: 3, vehicule: 'Camion 19 t', immat: 'EF-456-GH', horaires: '08:00 → 18:00 — RDV dépôt 7h30', lienfdr: replyActive() ? st.replyUrl + '?f=fexemple' : '', lien: replyActive() ? st.replyUrl + '?t=rexemple' : '' };
    const box = (k, l) => `<div class="card"><h3>${l}</h3><div class="grid g2"><textarea data-set="${k}" style="min-height:220px">${esc(st[k])}</textarea><pre class="msg-preview">${esc(fillTemplate(st[k], ex))}</pre></div></div>`;
    body = `<div class="card" style="margin-bottom:16px"><div class="form">
      <label class="f">Ouvrir WhatsApp avec<select data-set="waMode">
        <option value="auto" ${!['app', 'web'].includes(st.waMode) ? 'selected' : ''}>Automatique (application WhatsApp si installée)</option>
        <option value="app" ${st.waMode === 'app' ? 'selected' : ''}>Toujours l'application WhatsApp Desktop</option>
        <option value="web" ${st.waMode === 'web' ? 'selected' : ''}>Toujours WhatsApp Web (navigateur)</option></select>
        <span class="tiny" id="waDetect"></span></label>
      <label class="f">Façon de remplir le message<select data-set="waPaste">
        <option value="1" ${waPaste() ? 'selected' : ''}>Copier puis Ctrl+V (emojis garantis)</option>
        <option value="0" ${!waPaste() ? 'selected' : ''}>Texte pré-rempli (WhatsApp peut retirer les emojis)</option></select></label>
      <label class="f">Indicatif pays par défaut<input data-set="countryCode" value="${esc(st.countryCode)}" placeholder="33"></label>
      <label class="f span2">Compétences / postes (séparés par des virgules)<input data-skills value="${esc((st.skills || []).join(', '))}"></label></div>
      <div class="tiny muted" style="margin-top:10px">Variables : <code>{prenom} {nom} {societe} {projet} {client} {lieu} {dates} {horaires} {role} {nbjours} {lien} {changements}</code> — feuille de route : <code>{lienfdr}</code> — groupe : <code>{groupe}</code> — transport : <code>{vehicule} {immat}</code>. Une ligne dont toutes les variables sont vides (ex. lieu non renseigné) est retirée automatiquement.</div></div>
    <div class="grid" style="gap:16px">${box('msgOption', '🟦 Demande d\'option (pré-réservation)')}${box('msgDemande', '✅ Demande de booking direct')}${box('msgRelance', '⏰ Relance')}${box('msgConfirm', '📌 Option → booking (passer une option en booking)')}${box('msgUpdate', '🔄 Mise à jour du projet (toujours dispo ?)')}${box('msgRelease', '↩ Levée d\'option')}${box('msgTransport', '🚚 Chauffeur / transport')}${box('msgRoadmap', '📋 Envoi de la feuille de route')}${box('msgGroup', '👥 Invitation au groupe WhatsApp du projet')}</div>`;
  }
  return `<div class="page-head"><div><h1>Équipe</h1><div class="sub">${Store.db.techs.filter((t) => t.active !== false).length} technicien(s) actif(s)</div></div>
    <div class="row"><button data-act="exportTechsCSV">⇩ Export CSV</button><button data-act="importTechsCSV">⇧ Import CSV</button><button class="primary" data-act="newTech">＋ Technicien</button></div></div>
  <div class="tabs">${tabs.map(([k, v]) => `<a class="${ui.teamTab === k ? 'on' : ''}" data-act="teamTab" data-v="${k}">${v}</a>`).join('')}</div>${body}`;
}
function techForm(t) {
  const f = (k, label, type = 'text', cls = '') => `<label class="f ${cls}">${label}<input data-tf="${k}" type="${type}" value="${esc(t[k] == null ? '' : t[k])}"></label>`;
  const skills = [...new Set([...(Store.db.settings.skills || []), ...(t.skills || [])])];
  return `<h2>${t._new ? 'Nouveau technicien' : 'Fiche technicien'}</h2><div class="form">
    ${f('firstName', 'Prénom *')}${f('lastName', 'Nom')}${f('phone', 'Téléphone mobile (WhatsApp) *', 'tel')}${f('email', 'Email (invitations Google Agenda)', 'email')}
    <label class="f">Permis<select data-tf="licence">${Object.entries(LICENCES).map(([k, v]) => `<option value="${k}" ${(t.licence || '') === k ? 'selected' : ''}>${v}</option>`).join('')}</select></label>
    ${f('dailyRate', 'Tarif jour (€)', 'number')}${f('city', 'Ville')}
    <label class="f" style="justify-content:flex-end"><span class="row" style="gap:8px"><input type="checkbox" data-tfc="active" ${t.active !== false ? 'checked' : ''}> Actif</span></label>
    <div class="span4"><div class="small muted" style="margin-bottom:6px">Compétences</div><div class="row" style="gap:6px">${skills.map((s) => `<label class="chip-check"><input type="checkbox" data-tskill="${esc(s)}" ${(t.skills || []).includes(s) ? 'checked' : ''}>${esc(s)}</label>`).join('')}
      <span class="row" style="gap:4px"><input id="newSkill" placeholder="＋ Nouveau poste" style="width:170px"><button class="sm" data-act="addSkill">Ajouter</button></span></div></div>
    <label class="f span4">Notes<textarea data-tf="notes">${esc(t.notes || '')}</textarea></label></div>
  <div class="modal-actions">${t._new ? '' : '<button class="danger" data-act="deleteTech" style="margin-right:auto">Supprimer</button>'}<button data-act="closeModal">Annuler</button><button class="primary" data-act="saveTech">Enregistrer</button></div>`;
}

function vVehicles() {
  ui.vehTab = ui.vehTab || 'list'; ui.vehStart = ui.vehStart || addDays(todayISO(), -3);
  const tabs = [['list', '🚚 Véhicules'], ['planning', '🗓️ Planning']];
  let body = '';
  if (ui.vehTab === 'list') {
    const list = [...Store.db.vehicles].sort((a, b) => (b.active !== false) - (a.active !== false) || (a.name || '').localeCompare(b.name || ''));
    const t0 = todayISO();
    body = `<div class="card flat">${list.length ? `<table><tr><th>Véhicule</th><th>Immatriculation</th><th>Type</th><th class="num">Charge utile</th><th class="num">Volume</th><th>Permis</th><th>Contrôle technique</th><th>Entretien</th><th>Prochaine sortie</th></tr>
    ${list.map((v) => { const al = vehAlerts(v); const next = activeProjects().flatMap((p) => p.fleet.filter((f) => f.vehicleId === v.id && (f.end || f.start || '') >= t0).map((f) => ({ p, f }))).sort((a, b) => (a.f.start || '').localeCompare(b.f.start || ''))[0];
      const dcell = (k) => { const a = al.find((x) => x.txt.startsWith(k === 'ctDate' ? 'Contrôle' : 'Entretien')); return `<td class="small">${v[k] ? fmtDate(v[k]) : '<span class="dim">—</span>'}${a ? ` <span class="tag ${a.cls}">${a.cls === 'bad' ? 'dépassé' : 'bientôt'}</span>` : ''}</td>`; };
      return `<tr class="click" data-act="editVehicle" data-id="${v.id}" style="${v.active === false ? 'opacity:.5' : ''}"><td><b>${esc(v.name)}</b>${v.active === false ? ' <span class="tag">Inactif</span>' : ''}</td><td><span class="plate">${esc(v.plate || '—')}</span></td><td class="small">${esc(v.type || '')}</td>
      <td class="num">${v.payloadKg ? fmt(v.payloadKg) + ' kg' : '—'}</td><td class="num">${v.volumeM3 ? fmt(v.volumeM3, 1) + ' m³' : '—'}</td><td>${esc(v.licence || '—')}</td>${dcell('ctDate')}${dcell('serviceDate')}
      <td class="small">${next ? `<span class="dot" style="background:${next.p.color}"></span>${esc(next.p.name)} · ${fmtDate(next.f.start)}` : '<span class="dim">—</span>'}</td></tr>`; }).join('')}</table>`
      : `<div class="empty"><div class="e">🚚</div>Aucun véhicule. Ajoutez votre flotte (ou vos locations récurrentes).</div>`}</div>`;
  } else {
    const list = Store.db.vehicles.filter((v) => v.active !== false);
    body = `<div class="row" style="justify-content:flex-end;margin-bottom:12px">${gridNav('vehShift')}</div>
    ${dayGrid(ui.vehStart, 42, { title: 'Véhicule', list: list.map((v) => ({ label: esc(v.name), sub: esc(v.plate || ''), cell: (d) => {
      const hits = []; activeProjects().forEach((p) => p.fleet.forEach((f) => { if (f.vehicleId === v.id && f.start && d >= f.start && d <= (f.end || f.start)) hits.push({ p, f }); }));
      if (!hits.length) return ''; const h = hits[0];
      return `<div class="av-chip" style="background:${hits.length > 1 ? 'var(--bad)' : h.p.color}" data-act="openProject" data-id="${h.p.id}" title="${dayLabel(d)} — ${hits.map((x) => x.p.name + (getTech(x.f.driverId) ? ' (' + techName(getTech(x.f.driverId)) + ')' : '')).join(' / ')}">${hits.length > 1 ? '⚠' : abbr(h.p.name)}</div>`;
    } })) }, 'Aucun véhicule actif.')}<p class="tiny muted">⚠ rouge : véhicule réservé sur plusieurs projets le même jour.</p>`;
  }
  return `<div class="page-head"><div><h1>Véhicules</h1><div class="sub">Flotte et affectations transport</div></div><button class="primary" data-act="newVehicle">＋ Véhicule</button></div>
  <div class="tabs">${tabs.map(([k, v]) => `<a class="${ui.vehTab === k ? 'on' : ''}" data-act="vehTab" data-v="${k}">${v}</a>`).join('')}</div>${body}`;
}
function vehicleForm(v) {
  const f = (k, label, type = 'text', cls = '') => `<label class="f ${cls}">${label}<input data-vf="${k}" type="${type}" value="${esc(v[k] == null ? '' : v[k])}" ${type === 'number' ? 'step="any"' : ''}></label>`;
  return `<h2>${v._new ? 'Nouveau véhicule' : 'Fiche véhicule'}</h2><div class="form">
    ${f('name', 'Nom *', 'text', 'span2')}${f('plate', 'Immatriculation')}
    <label class="f">Type<input data-vf="type" list="vehTypes" value="${esc(v.type || '')}"></label><datalist id="vehTypes">${VEH_TYPES.map((x) => `<option value="${x}">`).join('')}</datalist>
    ${f('payloadKg', 'Charge utile (kg)', 'number')}${f('volumeM3', 'Volume utile (m³)', 'number')}
    <label class="f">Permis requis<select data-vf="licence">${Object.entries(LICENCES).filter(([k]) => k).map(([k, l]) => `<option value="${k}" ${(v.licence || 'B') === k ? 'selected' : ''}>${l}</option>`).join('')}</select></label>
    <label class="f" style="justify-content:flex-end"><span class="row" style="gap:8px"><input type="checkbox" data-vfc="active" ${v.active !== false ? 'checked' : ''}> Actif</span></label>
    ${f('ctDate', 'Prochain contrôle technique', 'date')}${f('serviceDate', 'Prochain entretien', 'date')}${f('insuranceDate', 'Échéance assurance', 'date')}${f('lengthM', 'Longueur caisse (m)', 'number')}
    <label class="f span4">Notes (hayon, sangles, carte carburant…)<textarea data-vf="notes">${esc(v.notes || '')}</textarea></label></div>
  <div class="modal-actions">${v._new ? '' : '<button class="danger" data-act="deleteVehicle" style="margin-right:auto">Supprimer</button>'}<button data-act="closeModal">Annuler</button><button class="primary" data-act="saveVehicle">Enregistrer</button></div>`;
}

async function showWaDetect() {
  const el = document.getElementById('waDetect'); if (!el) return;
  if (!(window.desktop && window.desktop.hasWhatsApp)) { el.textContent = ''; return; }
  try { const ok = await window.desktop.hasWhatsApp(); el.innerHTML = ok ? '<span style="color:var(--ok)">✔ WhatsApp Desktop détecté sur ce PC</span>' : '<span style="color:var(--warn)">WhatsApp Desktop non détecté — ouverture par le navigateur</span>'; } catch (e) { /* ignore */ }
}

/* ---------- Accueil : à faire ---------- */
function todoHTML() {
  const t0 = todayISO(); const items = [];
  activeProjects().filter((p) => (p.end || p.start || '') >= t0).forEach((p) => {
    const unsent = p.crew.filter((r) => r.status === 'attente' && !r.sentAt).length;
    const waiting = p.crew.filter((r) => r.status === 'attente' && r.sentAt).length;
    const opt = p.crew.filter((r) => r.status === 'option').length;
    const parts = [];
    if (unsent) parts.push(`<b>${unsent}</b> demande(s) à envoyer`);
    if (waiting) parts.push(`<b>${waiting}</b> réponse(s) attendue(s)`);
    if (opt) parts.push(`<b>${opt}</b> option(s) à transformer en booking`);
    const noAck = p.crew.filter((r) => r.status === 'valide' && r.confirmSentAt && !r.ack).length;
    const changed = p.crew.filter((r) => ackChanges(r, p).length).length;
    if (changed) parts.push(`<b>${changed}</b> technicien(s) à prévenir d'un changement (mise à jour)`);
    if (noAck) parts.push(`<b>${noAck}</b> réponse(s) de booking / mise à jour attendue(s)`);
    if (parts.length) items.push(`<div class="alert">👷 <b>${esc(p.name)}</b> — ${parts.join(', ')} <a data-act="openProject" data-id="${p.id}">Voir →</a></div>`);
  });
  Store.db.vehicles.filter((v) => v.active !== false).forEach((v) => vehAlerts(v).forEach((a) => items.push(`<div class="alert ${a.cls === 'bad' ? 'bad' : ''}">🚚 <b>${esc(v.name)}</b> (${esc(v.plate || '')}) — ${a.txt} <a data-nav-go="vehicles">Voir →</a></div>`)));
  return items.length ? `<hr class="sep"><h3>Équipe & véhicules</h3>${items.join('')}` : '';
}

/* ---------- PDF : page équipe & transport ---------- */
function crewPdfPage(p, hdr) {
  const crew = p.crew.filter((r) => r.status !== 'indispo').sort((a, b) => ST_RANK[b.status] - ST_RANK[a.status]);
  if (!crew.length && !p.fleet.length) return '';
  return `<div class="page">${hdr('Équipe & transport')}
    ${crew.length ? `<h2>Équipe technique</h2><table><tr><th>Technicien</th><th>Téléphone</th><th>Poste</th><th>Dates</th><th>Statut</th></tr>
    ${crew.map((r) => { const t = getTech(r.techId) || {}; return `<tr><td><b>${esc(techName(t))}</b></td><td>${esc(t.phone || '')}</td><td>${esc(r.role || '')}</td><td>${esc(fmtDays(r.dates))}${hoursShort(r) ? '<br><small>🕐 ' + esc(hoursShort(r)) + '</small>' : ''}</td><td>${CREW_ST[r.status].l}</td></tr>`; }).join('')}</table>` : ''}
    ${p.fleet.length ? `<h2 style="margin-top:16px">Transport</h2><table><tr><th>Véhicule</th><th>Immatriculation</th><th>Départ</th><th>Retour</th><th>Chauffeur</th><th>Téléphone</th><th>Note</th></tr>
    ${p.fleet.map((f) => { const v = getVehicle(f.vehicleId) || {}; const d = getTech(f.driverId) || {}; return `<tr><td><b>${esc(v.name || '')}</b></td><td>${esc(v.plate || '')}</td><td>${fmtDate(f.start)}</td><td>${fmtDate(f.end)}</td><td>${f.driverId ? esc(techName(d)) : '—'}</td><td>${esc(d.phone || '')}</td><td>${esc(f.note || '')}</td></tr>`; }).join('')}</table>
    <div class="muted" style="margin-top:4px">Charge estimée : ${fmt(projectLoad(p).kg)} kg / ${fmt(projectLoad(p).capKg)} kg · ${fmt(projectLoad(p).m3, 1)} m³ / ${fmt(projectLoad(p).capM3, 1)} m³</div>` : ''}</div>`;
}

/* =====================================================================
   ACTIONS
   ===================================================================== */
function readInto(sel, key, obj) { document.querySelectorAll(sel).forEach((el) => { obj[el.dataset[key]] = el.value; }); }
const findReq = (id) => { for (const p of Store.db.projects) { const r = p.crew.find((x) => x.id === id); if (r) return { p, r }; } return {}; };
const findFleet = (id) => { for (const p of Store.db.projects) { const f = p.fleet.find((x) => x.id === id); if (f) return { p, f }; } return {}; };

const teamActions = {
  // --- techniciens ---
  newTech() { ui.edit = { _new: true, id: uid('tec'), firstName: '', lastName: '', phone: '', email: '', licence: 'B', dailyRate: '', skills: [], notes: '', active: true }; openModal(techForm(ui.edit)); },
  editTech(el) { const t = getTech(el.dataset.id); if (!t) return; ui.edit = deepClone(t); openModal(techForm(ui.edit)); },
  addSkill() {
    const v = (document.getElementById('newSkill').value || '').trim(); if (!v) return toast('Indiquez le nom du poste', 'warn');
    const t = ui.edit; readInto('[data-tf]', 'tf', t); t.active = document.querySelector('[data-tfc=active]').checked;
    t.skills = [...document.querySelectorAll('[data-tskill]')].filter((x) => x.checked).map((x) => x.dataset.tskill);
    const st = Store.db.settings; st.skills = st.skills || [];
    const existing = st.skills.find((k) => k.toLowerCase() === v.toLowerCase()) || v;
    if (!st.skills.includes(existing)) st.skills.push(existing);
    if (!t.skills.includes(existing)) t.skills.push(existing);
    Store.save(); openModal(techForm(t)); toast(`Poste « ${existing} » ajouté`);
  },
  saveTech() {
    const t = ui.edit; readInto('[data-tf]', 'tf', t);
    t.active = document.querySelector('[data-tfc=active]').checked;
    t.skills = [...document.querySelectorAll('[data-tskill]')].filter((x) => x.checked).map((x) => x.dataset.tskill);
    t.dailyRate = num(t.dailyRate);
    if (!t.firstName) return toast('Le prénom est obligatoire', 'warn');
    if (t.email && !validEmail(t.email)) return toast('Adresse email invalide', 'warn');
    if (!t.phone) return toast('Le téléphone est nécessaire pour WhatsApp', 'warn');
    if (!normPhone(t.phone) || normPhone(t.phone).length < 8) return toast('Numéro de téléphone invalide', 'warn');
    const isNew = t._new; delete t._new;
    if (isNew) Store.db.techs.push(t); else Store.db.techs[Store.db.techs.findIndex((x) => x.id === t.id)] = t;
    Store.save(); closeModal(); render(); toast(isNew ? `${t.firstName} rejoint l'équipe 🎉` : 'Fiche mise à jour');
  },
  deleteTech() {
    const id = ui.edit.id; const used = Store.db.projects.filter((p) => p.crew.some((r) => r.techId === id) || p.fleet.some((f) => f.driverId === id));
    if (used.length) { if (!confirm(`${techName(ui.edit)} apparaît sur ${used.length} projet(s). Le passer plutôt en « inactif » ?`)) return; const t = getTech(id); t.active = false; Store.save(); closeModal(); render(); return; }
    if (!confirm('Supprimer ce technicien ?')) return;
    Store.db.techs = Store.db.techs.filter((t) => t.id !== id); Store.save(); closeModal(); render();
  },
  techChat(el, e) { e.stopPropagation(); const t = getTech(el.dataset.id); openExternal(waLink(t.phone, '')); },
  teamTab(el) { ui.teamTab = el.dataset.v; render(); },
  teamShift(el) { const v = num(el.dataset.v); ui.teamStart = v ? addDays(ui.teamStart, v) : addDays(todayISO(), -3); render(); },
  exportTechsCSV() {
    const cols = ['firstName', 'lastName', 'phone', 'email', 'licence', 'dailyRate', 'city', 'skills', 'notes'];
    const lines = [cols.join(';'), ...Store.db.techs.map((t) => cols.map((k) => csvCell(k === 'skills' ? (t.skills || []).join(', ') : t[k] == null ? '' : t[k])).join(';'))];
    saveFileText('techniciens_impulsion.csv', '﻿' + lines.join('\r\n'), 'csv', 'CSV');
  },
  async importTechsCSV() {
    const txt = await openTextFile('csv'); if (!txt) return;
    const rows = txt.replace(/^﻿/, '').split(/\r?\n/).filter((l) => l.trim()); const sep = rows[0].includes(';') ? ';' : ',';
    const head = parseCSVLine(rows[0], sep).map((h) => h.trim()); let added = 0, updated = 0;
    rows.slice(1).forEach((l) => {
      const v = parseCSVLine(l, sep); const o = {}; head.forEach((h, i) => { o[h] = (v[i] || '').trim(); });
      if (!o.firstName && !o.lastName) return;
      o.skills = o.skills ? o.skills.split(',').map((s) => s.trim()).filter(Boolean) : []; o.dailyRate = num(o.dailyRate);
      const ex = Store.db.techs.find((t) => normPhone(t.phone) && normPhone(t.phone) === normPhone(o.phone));
      if (ex) { Object.assign(ex, o); updated++; } else { o.id = uid('tec'); o.active = true; Store.db.techs.push(o); added++; }
    });
    Store.save(); render(); toast(`Import : ${added} ajouté(s), ${updated} mis à jour`);
  },
  // --- demandes ---
  solicit() { const p = curProject(); ui.sol = { dates: projectDays(p), role: '', skill: '', techIds: [], hours: Store.db.settings.lastHours ? deepClone(Store.db.settings.lastHours) : emptyHours(), kind: Store.db.settings.lastReqKind === 'booking' ? 'booking' : 'option' }; openModal(solicitHTML()); },
  solDay(el) { const d = el.dataset.v; const s = ui.sol; s.dates = s.dates.includes(d) ? s.dates.filter((x) => x !== d) : [...s.dates, d].sort(); openModal(solicitHTML()); },
  solAll(el) { ui.sol.dates = el.dataset.v === '1' ? [...new Set([...projectDays(curProject()), ...ui.sol.dates])].sort() : []; openModal(solicitHTML()); },
  solAddDay() { const v = document.getElementById('solExtra').value; if (!v) return; if (!ui.sol.dates.includes(v)) ui.sol.dates = [...ui.sol.dates, v].sort(); openModal(solicitHTML()); },
  solKind(el) { ui.sol.kind = el.dataset.v; Store.db.settings.lastReqKind = el.dataset.v; openModal(solicitHTML()); },
  reqUpdate(el) { const { p, r } = findReq(el.dataset.id); if (r) startQueue(p.id, [{ type: 'req', id: r.id, kind: 'update' }]); },
  updateAllChanged() { const p = curProject(); startQueue(p.id, p.crew.filter((r) => ackChanges(r, p).length && normPhone((getTech(r.techId) || {}).phone)).map((r) => ({ type: 'req', id: r.id, kind: 'update' }))); },
  reqConfirm(el) { const { p, r } = findReq(el.dataset.id); if (r) startQueue(p.id, [{ type: 'req', id: r.id, kind: 'confirm' }]); },
  reqRelease(el) { const { p, r } = findReq(el.dataset.id); if (r) startQueue(p.id, [{ type: 'req', id: r.id, kind: 'release' }]); },
  confirmAllOptions() { const p = curProject(); startQueue(p.id, p.crew.filter((r) => r.status === 'option' && normPhone((getTech(r.techId) || {}).phone)).map((r) => ({ type: 'req', id: r.id, kind: 'confirm' }))); },
  solCreate(el) {
    const s = ui.sol; const p = curProject();
    if (!s.techIds.length) return toast('Sélectionnez au moins un technicien', 'warn');
    if (!s.dates.length) return toast('Choisissez au moins une date', 'warn');
    const now = new Date().toISOString();
    const kind = s.kind === 'option' ? 'option' : 'booking';
    const hrs = cleanHours(s.hours, s.dates); Store.db.settings.lastHours = s.hours ? Object.assign(emptyHours(), { from: s.hours.from, to: s.hours.to, note: '' }) : null;
    const reqs = s.techIds.map((techId) => ({ id: uid('req'), techId, role: s.role, kind, dates: [...s.dates], hours: hrs ? deepClone(hrs) : null, status: 'attente', sentAt: null, history: [{ at: now, action: 'creation', kind }] }));
    p.crew.push(...reqs); Store.save(); ui.sol = null;
    if (el.dataset.v === '1') { render(); startQueue(p.id, reqs.filter((r) => normPhone((getTech(r.techId) || {}).phone)).map((r) => ({ type: 'req', id: r.id }))); }
    else { closeModal(); render(); toast(`${reqs.length} demande(s) créée(s)`); }
  },
  reqStatus(el) {
    const { r } = findReq(el.dataset.id); if (!r || r.status === el.dataset.v) return;
    r.status = el.dataset.v; r.history.push({ at: new Date().toISOString(), action: 'statut', status: r.status }); Store.save(); render();
    if (r.status === 'valide') toast(`${techName(getTech(r.techId))} validé ✅ — le bouton 💬 envoie maintenant la confirmation`);
  },
  reqSend(el) { const { p, r } = findReq(el.dataset.id); if (r) startQueue(p.id, [{ type: 'req', id: r.id }]); },
  queueUnsent() { const p = curProject(); startQueue(p.id, p.crew.filter((r) => r.status === 'attente' && !r.sentAt && normPhone((getTech(r.techId) || {}).phone)).map((r) => ({ type: 'req', id: r.id }))); },
  reqDel(el) { const { p, r } = findReq(el.dataset.id); if (!r || !confirm(`Retirer ${techName(getTech(r.techId))} de ce projet ?`)) return; calTrashReq(r); p.crew = p.crew.filter((x) => x.id !== r.id); Store.save(); render(); },
  reqDates(el) { const { r } = findReq(el.dataset.id); ui.edDates = { id: r.id, dates: [...r.dates], hours: r.hours ? deepClone(r.hours) : emptyHours() }; openModal(datesHTML()); },
  edDay(el) { const d = el.dataset.v; const e = ui.edDates; e.dates = e.dates.includes(d) ? e.dates.filter((x) => x !== d) : [...e.dates, d].sort(); openModal(datesHTML()); },
  edAddDay() { const v = document.getElementById('edExtra').value; if (v && !ui.edDates.dates.includes(v)) ui.edDates.dates = [...ui.edDates.dates, v].sort(); openModal(datesHTML()); },
  edSave() { const { r } = findReq(ui.edDates.id); if (!ui.edDates.dates.length) return toast('Au moins une date', 'warn'); r.dates = ui.edDates.dates; r.hours = cleanHours(ui.edDates.hours || emptyHours(), r.dates); r.history.push({ at: new Date().toISOString(), action: 'dates' }); Store.save(); closeModal(); render(); toast('Dates mises à jour — pensez à prévenir le technicien'); },
  // --- envoi guidé ---
  queueKind(el) { ui.queue.kind = el.dataset.v; openModal(queueHTML()); },
  queueSkip() { queueNext(); },
  queueCopy() { copyText(document.getElementById('qMsg').value); },
  async queueWA() {
    const it = queueItem(); const msg = document.getElementById('qMsg').value;
    if (waPaste()) { await copyText(msg, true); toast('Message copié 📋 — dans WhatsApp : Ctrl+V puis Entrée'); }
    await linkReady(it, msg);
    openExternal(waLink(it.t.phone, msg)); queueMark('whatsapp'); queueNext();
  },
  async queueSms() { const it = queueItem(); await linkReady(it, document.getElementById('qMsg').value); openExternal(smsLink(it.t.phone, document.getElementById('qMsg').value)); queueMark('sms'); queueNext(); },
  async queueMail() { const it = queueItem(); await linkReady(it, document.getElementById('qMsg').value); openExternal(mailLink(it.t.email, `${it.p.name} — ${MSG_KINDS[it.kind]}`, document.getElementById('qMsg').value)); queueMark('email'); queueNext(); },
  // --- transport ---
  addFleet() {
    const p = curProject(); const used = new Set(p.fleet.map((f) => f.vehicleId));
    const free = Store.db.vehicles.filter((v) => v.active !== false && !used.has(v.id)).sort((a, b) => vehicleBusy(a.id, p.start, p.end).length - vehicleBusy(b.id, p.start, p.end).length)[0] || Store.db.vehicles[0];
    p.fleet.push({ id: uid('flt'), vehicleId: free.id, start: p.start, end: p.end, driverId: '', note: '' }); Store.save(); render();
  },
  delFleet(el) { const { p, f } = findFleet(el.dataset.id); if (!f) return; p.fleet = p.fleet.filter((x) => x.id !== f.id); Store.save(); render(); },
  fleetSend(el) { const { p, f } = findFleet(el.dataset.id); if (f) startQueue(p.id, [{ type: 'fleet', id: f.id }]); },
  // --- véhicules ---
  newVehicle() { ui.edit = { _new: true, id: uid('veh'), name: '', plate: '', type: '', payloadKg: '', volumeM3: '', licence: 'B', ctDate: '', serviceDate: '', notes: '', active: true }; openModal(vehicleForm(ui.edit)); },
  editVehicle(el) { const v = getVehicle(el.dataset.id); if (!v) return; ui.edit = deepClone(v); openModal(vehicleForm(ui.edit)); },
  saveVehicle() {
    const v = ui.edit; readInto('[data-vf]', 'vf', v); v.active = document.querySelector('[data-vfc=active]').checked;
    ['payloadKg', 'volumeM3', 'lengthM'].forEach((k) => { v[k] = num(v[k]); });
    if (!v.name) return toast('Donnez un nom au véhicule', 'warn');
    const isNew = v._new; delete v._new;
    if (isNew) Store.db.vehicles.push(v); else Store.db.vehicles[Store.db.vehicles.findIndex((x) => x.id === v.id)] = v;
    Store.save(); closeModal(); render(); toast(isNew ? 'Véhicule ajouté 🚚' : 'Véhicule mis à jour');
  },
  deleteVehicle() {
    const id = ui.edit.id; const used = Store.db.projects.filter((p) => p.fleet.some((f) => f.vehicleId === id));
    if (used.length) { if (!confirm(`Ce véhicule est affecté à ${used.length} projet(s). Le passer plutôt en « inactif » ?`)) return; getVehicle(id).active = false; Store.save(); closeModal(); render(); return; }
    if (!confirm('Supprimer ce véhicule ?')) return;
    Store.db.vehicles = Store.db.vehicles.filter((v) => v.id !== id); Store.save(); closeModal(); render();
  },
  vehTab(el) { ui.vehTab = el.dataset.v; render(); },
  vehShift(el) { const v = num(el.dataset.v); ui.vehStart = v ? addDays(ui.vehStart, v) : addDays(todayISO(), -3); render(); }
};

/* Champs modifiés (appelé par le gestionnaire global "change") — renvoie true si traité */
function teamChange(t) {
  if (hoursChange(t)) return true;
  if (t.dataset.solTech !== undefined && ui.sol) { const id = t.dataset.solTech; ui.sol.techIds = t.checked ? [...ui.sol.techIds, id] : ui.sol.techIds.filter((x) => x !== id); openModal(solicitHTML()); return true; }
  if (t.dataset.sol && ui.sol) { ui.sol[t.dataset.sol] = t.value; if (t.dataset.sol === 'skill') openModal(solicitHTML()); return true; }
  if (t.dataset.crewneeded !== undefined) { curProject().crewNeeded = Math.max(0, num(t.value)); Store.save(); render(); return true; }
  if (t.dataset.reqrole) { const { r } = findReq(t.dataset.reqrole); if (r) { r.role = t.value; Store.save(); } return true; }
  if (t.dataset.fl) {
    const { f } = findFleet(t.dataset.id); if (!f) return true; f[t.dataset.fl] = t.value;
    if (t.dataset.fl === 'start' && f.end && f.end < f.start) f.end = f.start;
    Store.save(); if (t.dataset.fl !== 'note') render(); return true;
  }
  if (t.dataset.skills !== undefined) { Store.db.settings.skills = t.value.split(',').map((s) => s.trim()).filter(Boolean); Store.save(); return true; }
  return false;
}
