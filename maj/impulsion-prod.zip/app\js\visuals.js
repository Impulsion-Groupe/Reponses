/* =====================================================================
   VISUELS → MATRICES (boarding)
   Le client fournit 1 visuel par zone (PNG / JPG / MP4…), ex. « molten 1280x80.png », « molten 1536x80.mp4 ».
   L'application range chaque fichier dans la bonne zone (taille dans le nom, ou taille réelle, ou nom de zone),
   fait un « jeu » par annonceur, et fabrique les matrices 1920×1080 / 3840×2160 selon le mapping de sortie :
   PNG si le jeu ne contient que des images, MP4 (H.264) dès qu'il y a une vidéo.
   s.visuals = { sets: [{ id, name, items: { [zoneId]: { fid, name, kind, w, h, dur, fit } } }], fps, dur, quality }
   Les fichiers eux-mêmes restent sur ce PC (base locale), seules leurs infos sont dans les données.
   ===================================================================== */
const VIS_FITS = [['cover', 'Remplir (recadré)'], ['contain', 'Ajuster (bandes noires)'], ['stretch', 'Étirer']];
const visCache = new Map(); // fid → { url, el, kind }
const visState = { playing: false, t: 0, raf: 0, busy: false, cancel: false };

/* ---------- Base locale des fichiers (IndexedDB) ---------- */
let visDbP = null;
function visDb() {
  if (!visDbP) visDbP = new Promise((res, rej) => { const r = indexedDB.open('ilm-visuels', 1); r.onupgradeneeded = () => r.result.createObjectStore('files', { keyPath: 'id' }); r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); });
  return visDbP;
}
async function visPut(rec) { const db = await visDb(); return new Promise((res, rej) => { const tx = db.transaction('files', 'readwrite'); tx.objectStore('files').put(rec); tx.oncomplete = () => res(); tx.onerror = () => rej(tx.error); }); }
async function visGet(id) { const db = await visDb(); return new Promise((res) => { const r = db.transaction('files').objectStore('files').get(id); r.onsuccess = () => res(r.result || null); r.onerror = () => res(null); }); }
async function visDel(id) { const db = await visDb(); return new Promise((res) => { const tx = db.transaction('files', 'readwrite'); tx.objectStore('files').delete(id); tx.oncomplete = () => res(); tx.onerror = () => res(); }); }

/* Charge un fichier en <img> ou <video> (avec cache) */
async function visLoad(fid) {
  if (visCache.has(fid)) return visCache.get(fid);
  const rec = await visGet(fid); if (!rec) { visCache.set(fid, null); return null; }
  const url = URL.createObjectURL(rec.blob); let el;
  if (rec.kind === 'video') {
    el = document.createElement('video'); el.muted = true; el.playsInline = true; el.preload = 'auto'; el.loop = true; el.src = url;
    await new Promise((res) => { el.onloadeddata = res; el.onerror = res; setTimeout(res, 8000); });
  } else { el = new Image(); el.src = url; await el.decode().catch(() => {}); }
  const v = { url, el, kind: rec.kind }; visCache.set(fid, v); return v;
}
function readMedia(file) {
  const url = URL.createObjectURL(file); const isVid = /^video\//.test(file.type) || /\.(mp4|mov|m4v|webm)$/i.test(file.name);
  return new Promise((res) => {
    if (isVid) { const v = document.createElement('video'); v.muted = true; v.preload = 'metadata'; v.onloadedmetadata = () => { res({ kind: 'video', w: v.videoWidth, h: v.videoHeight, dur: v.duration }); URL.revokeObjectURL(url); }; v.onerror = () => { res(null); URL.revokeObjectURL(url); }; v.src = url; }
    else { const i = new Image(); i.onload = () => { res({ kind: 'img', w: i.naturalWidth, h: i.naturalHeight, dur: 0 }); URL.revokeObjectURL(url); }; i.onerror = () => { res(null); URL.revokeObjectURL(url); }; i.src = url; }
  });
}

/* ---------- Données ---------- */
function visCfg(s) { if (!s.visuals) s.visuals = {}; const V0 = s.visuals; [['sets', []], ['fps', 25], ['dur', 0], ['quality', 'high'], ['fixed', {}]].forEach(([k, d]) => { if (V0[k] === undefined) V0[k] = Array.isArray(d) ? [] : typeof d === 'object' ? {} : d; }); if (!s.visuals.sets.length) s.visuals.sets.push({ id: uid('vis'), name: 'Jeu 1', items: {} }); return s.visuals; }
function curSet(s) { const V = visCfg(s); let st = V.sets.find((x) => x.id === ui.visSet); if (!st) { st = V.sets[0]; ui.visSet = st.id; } return st; }
const zonePx = (s, z) => { const p = getProduct(s.productId) || {}; return { w: z.count * (num(p.pxW) || 128), h: zRows(s, z) * (num(p.pxH) || 128) }; };
/* Zones figées : le même visuel dans tous les jeux (V.fixed[zoneId]) */
const visFixed = (s) => (visCfg(s).fixed = visCfg(s).fixed || {});
const itemOf = (s, st, zid) => visFixed(s)[zid] || st.items[zid];
function effItems(s, st) { const o = {}; s.zones.forEach((z) => { const it = itemOf(s, st, z.id); if (it) o[z.id] = it; }); return o; }
const setHasVideo = (st, s = curScreen()) => Object.values(effItems(s, st)).some((it) => it && it.kind === 'video');
function setDuration(s, st) { const V = visCfg(s); if (num(V.dur) > 0) return num(V.dur); const d = Math.max(0, ...Object.values(effItems(s, st)).filter((it) => it && it.kind === 'video').map((it) => num(it.dur))); return d || 10; }
const normTxt = (t) => String(t || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9]+/g, ' ').trim();
/* « molten 1280x80.mp4 » → { sponsor: 'molten', w: 1280, h: 80 } */
function parseVisName(name) {
  const base = name.replace(/\.[a-z0-9]{2,4}$/i, ''); const m = base.match(/(\d{2,5})\s*[x×X*]\s*(\d{2,5})\s*(px)?/);
  const sponsor = (m ? base.replace(m[0], ' ') : base).replace(/[_\-–.]+/g, ' ').replace(/\s+/g, ' ').trim();
  return { sponsor: sponsor || base, w: m ? +m[1] : 0, h: m ? +m[2] : 0 };
}

/* Range une liste de fichiers : par taille (nom ou réelle), sinon par nom de zone ; un jeu par annonceur */
async function visImportFiles(s, files, opts = {}) {
  const V = visCfg(s); const report = { placed: [], unplaced: [], sets: new Set() };
  for (const file of files) {
    const meta = await readMedia(file); if (!meta) { report.unplaced.push(`${file.name} (format non lu)`); continue; }
    const pn = parseVisName(file.name); const W = pn.w || meta.w, H = pn.h || meta.h;
    let zones = opts.zid ? s.zones.filter((z) => z.id === opts.zid) : s.zones.filter((z) => { const zp = zonePx(s, z); return zp.w === W && zp.h === H; });
    let sponsor = pn.sponsor;
    if (!opts.zid && zones.length > 1) { // plusieurs zones de cette taille : si le nom cite une zone (« molten Long JAR 1632x80 »), seulement celle-là
      const n = normTxt(pn.sponsor); const named = zones.filter((z) => normTxt(z.name) && (' ' + n + ' ').includes(' ' + normTxt(z.name) + ' ')).sort((a, b) => normTxt(b.name).length - normTxt(a.name).length);
      if (named.length) { zones = [named[0]]; const esc2 = named[0].name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); sponsor = pn.sponsor.replace(new RegExp(esc2, 'i'), ' ').replace(/\s+/g, ' ').trim() || pn.sponsor; }
    }
    if (!zones.length) { // par nom de zone
      const n = normTxt(file.name); const byName = s.zones.filter((z) => normTxt(z.name) && n.includes(normTxt(z.name))).sort((a, b) => normTxt(b.name).length - normTxt(a.name).length);
      if (byName.length) { zones = [byName[0]]; sponsor = normTxt(pn.sponsor).replace(normTxt(byName[0].name), '').trim() || pn.sponsor; }
    }
    const FXz = visFixed(s); const skipped = opts.zid ? [] : zones.filter((z) => FXz[z.id]); if (!opts.zid) zones = zones.filter((z) => !FXz[z.id]);
    if (!zones.length) { report.unplaced.push(skipped.length ? `${file.name} (zone figée : ${skipped.map((z) => z.name).join(', ')})` : `${file.name} (${W}×${H} px : aucune zone de cette taille)`); continue; }
    let st = opts.set || (opts.oneSet ? curSet(s) : V.sets.find((x) => normTxt(x.name) === normTxt(sponsor)));
    if (!st) { const empty = V.sets.find((x) => !Object.keys(x.items).length && /^Jeu \d+$/.test(x.name)); st = empty || { id: uid('vis'), items: {} }; st.name = sponsor; if (!empty) V.sets.push(st); }
    const fid = uid('vf'); await visPut({ id: fid, name: file.name, kind: meta.kind, blob: file, w: meta.w, h: meta.h, dur: meta.dur });
    zones.forEach((z) => { const item = { fid, name: file.name, kind: meta.kind, w: meta.w, h: meta.h, dur: meta.dur, fit: ((FXz[z.id] || st.items[z.id]) || {}).fit || 'cover' }; if (opts.zid && FXz[z.id]) FXz[z.id] = item; else st.items[z.id] = item; });
    report.placed.push(`${file.name} → ${zones.map((z) => z.name).join(', ')}`); report.sets.add(st.name); ui.visSet = st.id;
  }
  Store.save(); return report;
}

/* ---------- Rendu ---------- */
function drawFit(ctx, src, sw, sh, W, H, fit) {
  if (!sw || !sh) return;
  if (fit === 'stretch') return ctx.drawImage(src, 0, 0, sw, sh, 0, 0, W, H);
  const sc = fit === 'contain' ? Math.min(W / sw, H / sh) : Math.max(W / sw, H / sh); const dw = sw * sc, dh = sh * sc;
  ctx.drawImage(src, 0, 0, sw, sh, (W - dw) / 2, (H - dh) / 2, dw, dh);
}
/* Image de chaque zone à sa résolution native */
function zoneCanvases(s, st, media) {
  const out = {};
  s.zones.forEach((z) => {
    const it = itemOf(s, st, z.id); const zp = zonePx(s, z); const c = document.createElement('canvas'); c.width = zp.w; c.height = zp.h; const ctx = c.getContext('2d');
    ctx.fillStyle = '#000'; ctx.fillRect(0, 0, zp.w, zp.h);
    const m = it && media[it.fid];
    if (m) { const el = m.el; const sw = m.kind === 'video' ? el.videoWidth : el.naturalWidth, sh = m.kind === 'video' ? el.videoHeight : el.naturalHeight; ctx.imageSmoothingQuality = 'high'; drawFit(ctx, el, sw, sh, zp.w, zp.h, it.fit || 'cover'); }
    out[z.id] = c;
  });
  return out;
}
function composeOut(canvas, s, zc, o) {
  const L = boardMap(s); canvas.width = L.W; canvas.height = L.H; const ctx = canvas.getContext('2d');
  ctx.fillStyle = '#000'; ctx.fillRect(0, 0, L.W, L.H);
  L.segs.filter((g) => g.out === o).forEach((g) => { const src = zc[g.z.id]; if (!src) return; if (g.rot) blitRot(ctx, src, 0, 0, g.Wz, g.zh, g.x, g.y, g.w, g.h, g.rot); else ctx.drawImage(src, g.off, 0, g.w, g.h, g.x, g.y, g.w, g.h); });
  return L;
}
async function loadSetMedia(st, s = curScreen()) { const media = {}; for (const it of Object.values(effItems(s, st))) if (it && !(it.fid in media)) media[it.fid] = await visLoad(it.fid); return media; }
async function seekAll(media, t) {
  await Promise.all(Object.values(media).filter((m) => m && m.kind === 'video').map((m) => new Promise((res) => {
    const v = m.el; const d = v.duration || 1; const target = Math.min(d - 0.001, t % d);
    if (Math.abs(v.currentTime - target) < 0.0005 && v.readyState >= 2) return res();
    const done = () => { v.removeEventListener('seeked', done); clearTimeout(to); res(); }; const to = setTimeout(done, 3000);
    v.addEventListener('seeked', done); v.currentTime = target;
  })));
}

/* ---------- Onglet ---------- */
function visualsTab(s) {
  const V = visCfg(s); const st = curSet(s); const L = boardMap(s); const vid = setHasVideo(st);
  const filled = s.zones.filter((z) => itemOf(s, st, z.id)).length; const FX = visFixed(s);
  const sizes = {}; s.zones.forEach((z) => { const zp = zonePx(s, z); const k = zp.w + 'x' + zp.h; (sizes[k] = sizes[k] || []).push(z.name); });
  const rows = s.zones.map((z, zi) => {
    const fixed = !!FX[z.id]; const it = itemOf(s, st, z.id); const zp = zonePx(s, z);
    const ratio = it && it.w && it.h ? (it.w / it.h) / (zp.w / zp.h) : 1; const diff = Math.abs(ratio - 1);
    const sizeOk = it && it.w === zp.w && it.h === zp.h;
    return `<tr data-vdrop="${z.id}" class="${fixed ? 'vis-fixed' : ''}"><td><span class="dot" style="background:${(boardMapCfg(s).items.find((x) => x.zid === z.id) || {}).color || zoneColor(zi)}"></span><b>${esc(z.name)}</b>${fixed ? ' <span class="vis-pin">📌 figée</span>' : ''}<div class="tiny muted">${zp.w} × ${zp.h} px</div></td>
      <td>${it ? `<div class="vis-file">${it.kind === 'video' ? '🎞' : '🖼'} <span title="${esc(it.name)}">${esc(it.name)}</span></div><div class="tiny ${sizeOk ? 'muted' : diff > 0.02 ? 'warn-t' : 'muted'}">${it.w} × ${it.h}${it.kind === 'video' ? ` · ${fmt(it.dur, 1)} s` : ''}${sizeOk ? ' · ✔ taille exacte' : diff > 0.02 ? ` · ⚠ format différent (${ratio > 1 ? 'plus large' : 'plus haut'} de ${Math.round(diff * 100)} %)` : ' · mis à l\'échelle'}</div>` : '<span class="tiny muted">Glissez un fichier ici ou importez</span>'}</td>
      <td>${it ? `<select data-vfit="${z.id}">${VIS_FITS.map(([v, l]) => `<option value="${v}" ${(it.fit || 'cover') === v ? 'selected' : ''}>${l}</option>`).join('')}</select>` : ''}</td>
      <td style="white-space:nowrap"><button class="sm" data-act="visPick" data-zid="${z.id}">${it ? '⇄' : '＋'} Fichier</button>
        ${it ? (fixed ? `<button class="sm" data-act="visUnfix" data-zid="${z.id}" title="Chaque jeu reprend son propre visuel pour cette zone">📌 Défiger</button>` : `<button class="sm ghost" data-act="visFix" data-zid="${z.id}" title="Ce visuel sera utilisé dans TOUS les jeux pour cette zone">📌 Figer</button>`) : ''}
        ${it ? `<button class="sm ghost" data-act="visClear" data-zid="${z.id}" title="${fixed ? 'Défiger et retirer' : 'Retirer de ce jeu'}">✕</button>` : ''}</td></tr>`;
  }).join('');
  return `<div class="card"><div class="row" style="justify-content:space-between;flex-wrap:wrap;gap:10px">
      <div><h3 style="margin:0">Visuels → matrices</h3><div class="tiny muted">Un jeu = un annonceur / une séquence. Les matrices suivent le mapping de sortie (onglet Pixel map) : ${L.W} × ${L.H} px${L.outs > 1 ? `, ${L.outs} sorties` : ''}.</div></div>
      <div class="row" style="gap:8px"><button class="primary" data-act="visBulk">⇪ Importer des visuels (tous annonceurs)</button></div></div>
    <div class="vis-sets">${V.sets.map((x) => `<button class="vis-set ${x.id === st.id ? 'on' : ''}" data-act="visSel" data-id="${x.id}">${setHasVideo(x) ? '🎞' : '🖼'} ${esc(x.name)} <span class="tiny muted">${s.zones.filter((z) => itemOf(s, x, z.id)).length}/${s.zones.length}</span></button>`).join('')}<button class="vis-set add" data-act="visNew">＋ Jeu</button></div>
    <div class="tiny muted" style="margin-top:6px">Astuce : nommez les fichiers « annonceur largeurxhauteur » (ex. <b>molten 1280x80.png</b>, <b>molten 1536x80.mp4</b>) et importez-les tous d'un coup : un jeu est créé par annonceur et chaque fichier va dans toutes les zones de cette taille.
      Tailles de ce boarding : ${Object.entries(sizes).map(([k, n]) => `<b>${k}</b> (${n.map(esc).join(', ')})`).join(' · ')}</div>
  </div>
  <div class="grid" style="grid-template-columns:minmax(0,1fr) 320px;gap:16px;margin-top:16px;align-items:start">
    <div>
      <div class="card"><div class="row" style="justify-content:space-between"><h3 style="margin:0">${esc(st.name)} — aperçu ${vid ? `<span class="tiny muted" id="visTime"></span>` : ''}</h3>
        <div class="row" style="gap:6px">${vid ? `<button class="sm" data-act="visPlay">${visState.playing ? '⏸ Pause' : '▶ Lire'}</button>` : ''}<button class="sm ghost" data-act="visRename">✎ Renommer</button><button class="sm ghost" data-act="visDup">⧉ Dupliquer</button><button class="sm ghost danger" data-act="visDelSet">✕</button></div></div>
        <div class="bm-outs">${Array.from({ length: L.outs }, (_, o) => `<div><div class="tiny muted" style="margin:10px 0 4px">${L.outs > 1 ? `Sortie ${o + 1} — ` : ''}${L.W} × ${L.H} px</div><canvas class="vis-canvas" data-o="${o}"></canvas></div>`).join('')}</div></div>
      <div class="card" style="margin-top:16px"><h3>Zones (${filled}/${s.zones.length})</h3>
        <div style="overflow-x:auto"><table class="tbl vis-tbl"><thead><tr><th>${zTerm(s).One}</th><th>Visuel</th><th>Cadrage</th><th></th></tr></thead><tbody>${rows}</tbody></table></div>
        <div class="row" style="gap:8px;margin-top:10px"><button class="sm" data-act="visAllSame">Même fichier pour toutes les zones…</button><button class="sm" data-act="visMedia">🗑 Gérer / supprimer des médias</button></div>
        <div class="tiny muted" style="margin-top:8px">📌 <b>Figer</b> une zone : son visuel actuel est utilisé dans tous les jeux (ex. logo de l'organisateur sur « Compet ») ; les imports suivants ne la remplacent pas.</div></div>
    </div>
    <div><div class="card"><h3>Export</h3>
      <div class="small" style="margin-bottom:8px">${vid ? '🎞 Ce jeu contient de la vidéo → <b>MP4</b> (H.264)' : '🖼 Ce jeu ne contient que des images → <b>PNG</b>'}</div>
      ${vid ? `<div class="row" style="gap:8px"><label class="f">Images / s<select data-vset="fps">${[24, 25, 30, 50, 60].map((f) => `<option ${num(V.fps) === f ? 'selected' : ''}>${f}</option>`).join('')}</select></label>
        <label class="f">Durée (s)<input type="number" min="0" step="0.5" data-vset="dur" value="${num(V.dur) || ''}" placeholder="auto ${fmt(setDuration(s, Object.assign({}, st)), 1)}" style="width:90px"></label></div>
        <label class="f" style="margin-top:6px">Qualité<select data-vset="quality"><option value="high" ${V.quality !== 'std' ? 'selected' : ''}>Haute (diffusion)</option><option value="std" ${V.quality === 'std' ? 'selected' : ''}>Standard (fichier plus léger)</option></select></label>
        <div class="tiny muted" style="margin-top:6px">Durée auto = la vidéo la plus longue ; les plus courtes bouclent, les images restent fixes.</div>` : ''}
      <button class="primary" data-act="visExport" style="width:100%;justify-content:center;margin-top:12px">⇩ Matrice « ${esc(st.name)} »</button>
      <button data-act="visExportAll" style="width:100%;justify-content:center;margin-top:8px">⇩ Toutes les matrices (${V.sets.length} jeu${V.sets.length > 1 ? 'x' : ''})</button>
      <div class="tiny muted" style="margin-top:8px">PNG : un fichier .zip avec toutes les matrices. MP4 : un fichier par jeu et par sortie. Noms : <i>Projet_Annonceur_3840x2160.png</i></div></div>
      <div class="card" style="margin-top:16px"><h3>Fichiers</h3><div class="tiny muted">Les visuels importés restent sur ce PC. Sur un autre poste, le jeu apparaît mais il faut réimporter les fichiers.</div></div></div>
  </div>`;
}
async function visDrawPreview(s) {
  const st = curSet(s); const canvases = [...document.querySelectorAll('.vis-canvas')]; if (!canvases.length) return;
  const media = await loadSetMedia(st);
  const paint = () => { const zc = zoneCanvases(s, st, media); canvases.forEach((c) => { composeOut(c, s, zc, +c.dataset.o); c.style.width = '100%'; c.style.maxWidth = '1100px'; }); const tt = document.getElementById('visTime'); const v = Object.values(media).find((m) => m && m.kind === 'video'); if (tt && v) tt.textContent = `· ${fmt(v.el.currentTime, 1)} s`; };
  cancelAnimationFrame(visState.raf);
  if (visState.playing) { Object.values(media).forEach((m) => { if (m && m.kind === 'video') m.el.play().catch(() => {}); }); const loop = () => { if (!visState.playing || !document.querySelector('.vis-canvas')) { Object.values(media).forEach((m) => { if (m && m.kind === 'video') m.el.pause(); }); return; } paint(); visState.raf = requestAnimationFrame(loop); }; loop(); }
  else { Object.values(media).forEach((m) => { if (m && m.kind === 'video') m.el.pause(); }); await seekAll(media, 0); paint(); }
}
function pickFiles(multiple) {
  return new Promise((res) => { const i = document.createElement('input'); i.type = 'file'; i.multiple = multiple; i.accept = 'image/png,image/jpeg,image/webp,image/gif,video/mp4,video/webm,video/quicktime,.mp4,.mov,.m4v'; i.onchange = () => res([...i.files]); i.click(); });
}
function showReport(r) {
  openModal(`<h2>Import des visuels</h2>
    ${r.placed.length ? `<div class="alert ok">✔ ${r.placed.length} fichier(s) rangé(s) — jeu(x) : ${[...r.sets].map(esc).join(', ')}</div><div class="tiny" style="max-height:220px;overflow:auto;margin-top:8px;line-height:1.6">${r.placed.map(esc).join('<br>')}</div>` : ''}
    ${r.unplaced.length ? `<div class="alert warn" style="margin-top:10px">⚠ Non rangé(s) :<br>${r.unplaced.map(esc).join('<br>')}<div class="tiny" style="margin-top:6px">Vérifiez la taille dans le nom du fichier, ou importez-le à la main dans la zone voulue (bouton « ＋ Fichier »).</div></div>` : ''}
    <div class="modal-actions"><button class="primary" data-act="closeModal">OK</button></div>`);
}

/* ---------- Export ---------- */
async function renderSetPNGs(s, st) {
  const media = await loadSetMedia(st); const zc = zoneCanvases(s, st, media); const L = boardMap(s); const out = [];
  for (let o = 0; o < L.outs; o++) { const c = document.createElement('canvas'); composeOut(c, s, zc, o); const blob = await new Promise((r) => c.toBlob(r, 'image/png')); out.push({ name: `${safeName(curProject().name)}_${safeName(st.name)}_${L.W}x${L.H}${L.outs > 1 ? '_sortie' + (o + 1) : ''}.png`, blob }); }
  return out;
}
function progressModal(title) {
  openModal(`<h2>${esc(title)}</h2><div class="vis-prog"><div id="visBar"></div></div><div class="small" id="visProgTxt" style="margin-top:8px">Préparation…</div>
    <div class="modal-actions"><button data-act="visCancel">Annuler</button></div>`);
  return (p, txt) => { const b = document.getElementById('visBar'); if (b) b.style.width = Math.round(p * 100) + '%'; const t = document.getElementById('visProgTxt'); if (t) t.textContent = txt; };
}
async function renderSetMP4(s, st, o, prog) {
  if (typeof VideoEncoder === 'undefined') throw new Error('L\'encodage vidéo n\'est pas disponible dans ce navigateur (mettez Microsoft Edge à jour).');
  const V = visCfg(s); const L = boardMap(s); const fps = num(V.fps) || 25; const dur = setDuration(s, st); const n = Math.max(1, Math.round(dur * fps));
  const W = L.W + (L.W % 2), H = L.H + (L.H % 2); const bitrate = Math.round(W * H * fps * (V.quality === 'std' ? 0.08 : 0.2));
  const cfg = await pickH264(W, H, fps, Math.min(bitrate, 120e6)); if (!cfg) throw new Error(`Encodage H.264 ${W}×${H} non pris en charge sur ce PC.`);
  const media = await loadSetMedia(st); Object.values(media).forEach((m) => { if (m && m.kind === 'video') m.el.pause(); });
  const mux = new Mp4Writer(W, H, fps); let err = null;
  const enc = new VideoEncoder({ output: (chunk, meta) => mux.add(chunk, meta), error: (e) => { err = e; } }); enc.configure(cfg);
  const c = document.createElement('canvas'); c.width = W; c.height = H; const ctx = c.getContext('2d'); const tmp = document.createElement('canvas');
  for (let i = 0; i < n; i++) {
    if (visState.cancel) { enc.close(); throw new Error('Annulé'); } if (err) throw err;
    await seekAll(media, (i + 0.5) / fps); const zc = zoneCanvases(s, st, media); composeOut(tmp, s, zc, o);
    ctx.fillStyle = '#000'; ctx.fillRect(0, 0, W, H); ctx.drawImage(tmp, 0, 0);
    const frame = new VideoFrame(c, { timestamp: Math.round(i * 1e6 / fps), duration: Math.round(1e6 / fps) });
    enc.encode(frame, { keyFrame: i % fps === 0 }); frame.close();
    while (enc.encodeQueueSize > 6) await new Promise((r) => setTimeout(r, 5));
    if (i % 5 === 0) { prog((i + 1) / n, `Image ${i + 1} / ${n} (${fmt((i + 1) / fps, 1)} s sur ${fmt(dur, 1)} s)`); await new Promise((r) => setTimeout(r, 0)); }
  }
  await enc.flush(); enc.close(); if (err) throw err;
  return { name: `${safeName(curProject().name)}_${safeName(st.name)}_${W}x${H}${L.outs > 1 ? '_sortie' + (o + 1) : ''}_${fps}fps.mp4`, blob: mux.finish() };
}
async function exportSets(s, sets) {
  if (visState.busy) return; visState.busy = true; visState.cancel = false; visState.playing = false;
  const L = boardMap(s); const pngs = []; const vids = sets.filter((x) => setHasVideo(x, s));
  const prog = progressModal(sets.length > 1 ? 'Fabrication des matrices' : `Matrice « ${sets[0].name} »`);
  try {
    let k = 0;
    for (const st of sets) {
      if (!s.zones.some((z) => st.items[z.id])) continue; // jeu vide (zones figées seules) : rien à exporter
      if (setHasVideo(st)) {
        for (let o = 0; o < L.outs; o++) {
          const f = await renderSetMP4(s, st, o, (p, txt) => prog((k + p) / (vids.length * L.outs + (sets.length - vids.length ? 1 : 0)), `${st.name}${L.outs > 1 ? ` · sortie ${o + 1}` : ''} — ${txt}`));
          prog((k + 1) / (vids.length * L.outs + 1), `${st.name} : enregistrement…`); await saveBlob(f.name, f.blob, 'mp4', 'Vidéo MP4'); k++;
        }
      } else { prog(k / Math.max(1, sets.length), `${st.name} : images…`); pngs.push(...(await renderSetPNGs(s, st))); }
    }
    if (pngs.length === 1) await saveBlob(pngs[0].name, pngs[0].blob, 'png', 'Image PNG');
    else if (pngs.length > 1) { const files = []; for (const f of pngs) files.push({ name: f.name, data: new Uint8Array(await f.blob.arrayBuffer()) }); await saveBlob(`${safeName(curProject().name)}_${safeName(s.name)}_matrices_${L.W}x${L.H}.zip`, makeZip(files), 'zip', 'Archive ZIP'); }
    closeModal(); toast(`Matrices prêtes ✔ (${pngs.length} PNG${vids.length ? `, ${vids.length * L.outs} MP4` : ''})`); confetti();
  } catch (e) { closeModal(); if (e.message !== 'Annulé') toast('Export impossible : ' + (e.message || e), 'bad'); else toast('Export annulé'); }
  finally { visState.busy = false; }
}

const visualsActions = {
  visSel(el) { ui.visSet = el.dataset.id; visState.playing = false; render(); },
  visNew() { const V = visCfg(curScreen()); const st = { id: uid('vis'), name: 'Jeu ' + (V.sets.length + 1), items: {} }; V.sets.push(st); ui.visSet = st.id; Store.save(); render(); },
  visRename() { const st = curSet(curScreen()); const n = prompt('Nom du jeu (annonceur, séquence…)', st.name); if (n && n.trim()) { st.name = n.trim(); Store.save(); render(); } },
  visDup() { const s = curScreen(); const V = visCfg(s); const st = curSet(s); const c = deepClone(st); c.id = uid('vis'); c.name = st.name + ' (copie)'; V.sets.push(c); ui.visSet = c.id; Store.save(); render(); },
  visDelSet() { const s = curScreen(); const V = visCfg(s); const st = curSet(s); if (!confirm(`Supprimer le jeu « ${st.name} » ?`)) return; V.sets = V.sets.filter((x) => x.id !== st.id); ui.visSet = null; Store.save(); render(); },
  async visBulk() { const s = curScreen(); const files = await pickFiles(true); if (!files.length) return; toast('Import en cours…'); const r = await visImportFiles(s, files); render(); showReport(r); },
  async visPick(el) { const s = curScreen(); const files = await pickFiles(false); if (!files.length) return; const r = await visImportFiles(s, files, { zid: el.dataset.zid, set: curSet(s) }); render(); if (r.unplaced.length) showReport(r); },
  async visAllSame() { const s = curScreen(); const files = await pickFiles(false); if (!files.length) return; const st = curSet(s); for (const z of s.zones) await visImportFiles(s, files, { zid: z.id, set: st }); render(); toast('Même visuel dans toutes les zones ✔'); },
  visClear(el) { const s = curScreen(); const z = el.dataset.zid; if (visFixed(s)[z]) delete visFixed(s)[z]; else delete curSet(s).items[z]; Store.save(); render(); },
  visFix(el) { const s = curScreen(); const z = el.dataset.zid; const it = itemOf(s, curSet(s), z); if (!it) return; visFixed(s)[z] = deepClone(it); Store.save(); render(); toast(`📌 « ${it.name} » figé sur ${(s.zones.find((x) => x.id === z) || {}).name} pour tous les jeux`); },
  visUnfix(el) { const s = curScreen(); delete visFixed(s)[el.dataset.zid]; Store.save(); render(); toast('Zone défigée : chaque jeu reprend son propre visuel'); },
  visMedia() { openModal('<h2>Médias importés</h2><div class="small muted">Chargement…</div>'); visMediaModal(curScreen()); },
  visMediaAll(el) { document.querySelectorAll('[data-vmsel]').forEach((c) => { c.checked = el.dataset.v === '1'; }); },
  async visMediaDel() {
    const s = curScreen(); const V = visCfg(s); const fids = new Set([...document.querySelectorAll('[data-vmsel]:checked')].map((c) => c.dataset.vmsel)); const sids = new Set([...document.querySelectorAll('[data-vssel]:checked')].map((c) => c.dataset.vssel));
    if (!fids.size && !sids.size) return toast('Cochez des médias ou des jeux à supprimer', 'warn');
    if (!confirm(`Supprimer ${fids.size ? fids.size + ' média(s)' : ''}${fids.size && sids.size ? ' et ' : ''}${sids.size ? sids.size + ' jeu(x)' : ''} de ce boarding ?`)) return;
    V.sets = V.sets.filter((x) => !sids.has(x.id)); const had = new Set(V.sets.filter((x) => Object.keys(x.items).length).map((x) => x.id));
    V.sets.forEach((x) => Object.keys(x.items).forEach((z) => { if (fids.has(x.items[z].fid)) delete x.items[z]; }));
    Object.keys(visFixed(s)).forEach((z) => { if (fids.has(visFixed(s)[z].fid)) delete visFixed(s)[z]; });
    const before = V.sets.length; V.sets = V.sets.filter((x) => Object.keys(x.items).length || !had.has(x.id)); if (!V.sets.length) V.sets.push({ id: uid('vis'), name: 'Jeu 1', items: {} });
    Store.save(); await visPurge(); ui.visSet = null; closeModal(); render(); toast(`Supprimé ✔${before !== V.sets.length ? ` (${before - V.sets.length} jeu(x) vide(s) retiré(s))` : ''}`);
  },
  async visPurgeNow() { const n = await visPurge(); toast(n ? `${n} fichier(s) inutilisé(s) supprimé(s) de ce PC ✔` : 'Aucun fichier inutilisé'); visMediaModal(curScreen()); },
  visPlay() { visState.playing = !visState.playing; render(); },
  visExport() { const s = curScreen(); exportSets(s, [curSet(s)]); },
  visExportAll() { const s = curScreen(); exportSets(s, visCfg(s).sets); },
  visCancel() { visState.cancel = true; }
};
function visualsChange(t) {
  const s = curScreen(); if (!s || (!t.dataset.vfit && !t.dataset.vset)) return false;
  if (t.dataset.vfit) { const it = itemOf(s, curSet(s), t.dataset.vfit); if (it) it.fit = t.value; }
  else { const V = visCfg(s); V[t.dataset.vset] = t.dataset.vset === 'quality' ? t.value : num(t.value); }
  Store.save(); render(); return true;
}
/* Glisser-déposer des fichiers sur une zone (ou n'importe où dans l'onglet = import groupé) */
document.addEventListener('dragover', (e) => { if (ui.tab === 'visuals' && e.dataTransfer && [...e.dataTransfer.types].includes('Files')) { e.preventDefault(); const tr = e.target.closest && e.target.closest('[data-vdrop]'); document.querySelectorAll('.vdrop-on').forEach((x) => x !== tr && x.classList.remove('vdrop-on')); if (tr) tr.classList.add('vdrop-on'); } });
document.addEventListener('drop', async (e) => {
  if (ui.tab !== 'visuals' || !e.dataTransfer || !e.dataTransfer.files.length) return; e.preventDefault();
  const s = curScreen(); if (!s || !isBoard(s)) return; const files = [...e.dataTransfer.files]; const tr = e.target.closest && e.target.closest('[data-vdrop]');
  const r = tr && files.length === 1 ? await visImportFiles(s, files, { zid: tr.dataset.vdrop, set: curSet(s) }) : await visImportFiles(s, files);
  render(); if (!tr || r.unplaced.length || files.length > 1) showReport(r);
});

/* ---------- Gestion des médias (suppression, nettoyage) ---------- */
async function visAllRecs() { const db = await visDb(); return new Promise((res) => { const r = db.transaction('files').objectStore('files').getAll(); r.onsuccess = () => res(r.result || []); r.onerror = () => res([]); }); }
function usedFids() { const u = new Set(); Store.db.projects.forEach((p) => p.screens.forEach((sc) => { const V = sc.visuals; if (!V) return; (V.sets || []).forEach((x) => Object.values(x.items || {}).forEach((it) => it && u.add(it.fid))); Object.values(V.fixed || {}).forEach((it) => it && u.add(it.fid)); })); return u; }
/* Supprime de ce PC les fichiers qui ne servent plus dans aucun projet */
async function visPurge() { const used = usedFids(); const recs = await visAllRecs(); let n = 0; for (const r of recs) if (!used.has(r.id)) { await visDel(r.id); const c = visCache.get(r.id); if (c && c.url) URL.revokeObjectURL(c.url); visCache.delete(r.id); n++; } return n; }
const fmtSize = (b) => (b > 1048576 ? fmt(b / 1048576, 1) + ' Mo' : fmt(b / 1024, 0) + ' Ko');
async function visMediaModal(s) {
  const V = visCfg(s); const recs = new Map((await visAllRecs()).map((r) => [r.id, r])); const media = new Map();
  const addUse = (it, where) => { if (!it) return; const m = media.get(it.fid) || { it, uses: [] }; m.uses.push(where); media.set(it.fid, m); };
  V.sets.forEach((x) => s.zones.forEach((z) => addUse(x.items[z.id], `${x.name} · ${z.name}`)));
  Object.entries(visFixed(s)).forEach(([zid, it]) => addUse(it, `📌 ${(s.zones.find((z) => z.id === zid) || {}).name || 'zone'} (tous les jeux)`));
  const used = usedFids(); const orphans = [...recs.values()].filter((r) => !used.has(r.id));
  const total = [...recs.values()].reduce((a, r) => a + (r.blob ? r.blob.size : 0), 0);
  openModal(`<h2>🗑 Médias importés — ${esc(s.name)}</h2>
    <div class="small muted">Cochez ce qui n'a rien à voir avec ce projet. Supprimer un média le retire de tous les jeux de ce boarding ; supprimer un jeu retire le partenaire entier.</div>
    <h3 style="margin-top:14px">Jeux (partenaires)</h3>
    <div class="vm-list">${V.sets.map((x) => `<label class="vm-row"><input type="checkbox" data-vssel="${x.id}"><b>${esc(x.name)}</b><span class="tiny muted">${s.zones.filter((z) => x.items[z.id]).length} zone(s)${setHasVideo(x, s) ? ' · vidéo' : ''}</span></label>`).join('')}</div>
    <div class="row" style="justify-content:space-between;margin-top:14px"><h3 style="margin:0">Fichiers (${media.size})</h3><span><a data-act="visMediaAll" data-v="1">tout cocher</a> · <a data-act="visMediaAll" data-v="0">aucun</a></span></div>
    <div class="vm-list">${[...media.entries()].map(([fid, m]) => { const r = recs.get(fid); return `<label class="vm-row"><input type="checkbox" data-vmsel="${fid}"><span>${m.it.kind === 'video' ? '🎞' : '🖼'} <b>${esc(m.it.name)}</b><div class="tiny muted">${m.it.w} × ${m.it.h}${m.it.kind === 'video' ? ' · ' + fmt(m.it.dur, 1) + ' s' : ''}${r && r.blob ? ' · ' + fmtSize(r.blob.size) : ' · ⚠ fichier absent de ce PC'} — ${m.uses.map(esc).join(', ')}</div></span></label>`; }).join('') || '<div class="tiny muted">Aucun média.</div>'}</div>
    <div class="tiny muted" style="margin-top:12px">Sur ce PC : ${recs.size} fichier(s), ${fmtSize(total)}${orphans.length ? ` — dont <b>${orphans.length} inutilisé(s)</b> (${fmtSize(orphans.reduce((a, r) => a + (r.blob ? r.blob.size : 0), 0))}) <a data-act="visPurgeNow">nettoyer</a>` : ''}.</div>
    <div class="modal-actions"><button data-act="closeModal">Fermer</button><button class="danger" data-act="visMediaDel">🗑 Supprimer la sélection</button></div>`);
}
